#include <ax/App/opengl/axGLTextureSeq.h>
#include <ax/App/graph/axImageSeq.h>
#include <ax/core/math/axRect2.h>


axGLTextureSeq::axGLTextureSeq() {
	currentTime_ = 0;
}

axStatus axGLTextureSeq::loadFile( const char* filename ) {
	axStatus st;
	axImageSeq	img_seq;
	st = img_seq.loadFile( filename );		if( !st ) return st;
	return create( img_seq );
}

axStatus axGLTextureSeq::create( const axImageSeq &img_seq ) {
	if( img_seq.frameCount() == 0 ) {
		destroy();
		return 0;
	}
	
	axStatus st;
	st = frames_.resize( img_seq.frameCount() ); if (!st) return st;
	axSize i;
	for( i=0; i<frames_.size(); i++ ) {
		st = frames_[i].create( img_seq.getFrame(i) ); if (!st) return st;
		frames_[i].time_ = img_seq.getFrame(i).time_;
	}
	max_loop_ = img_seq.maxLoop();
	return 0;
}

void axGLTextureSeq::destroy() {
	
	max_loop_ = 0;
	frames_.clear();
}

axStatus axGLTextureSeq::blt ( const axRect2f &v, const axRect2f &t, bool keep_aspect_ratio ) const {
	axSize out_index=0;	
	if( ! getIndexByTime( out_index, currentTime_ ) ) return 0;
	if( ! frames_.inBound( out_index ) ) return -1;
	return frames_[out_index].blt( v, t, keep_aspect_ratio );
}


bool axGLTextureSeq::getIndexByTime( axSize &out_index, float time ) const {
	if( frames_.size()  == 0 ) return false;
	
	axSize s = 0;
	axSize e = frames_.size() - 1;
	
	float et = frames_[e].time;
	
	if( et == 0 ) { out_index = e; return true; }
	
	if( time > et ) {
		float loop;
		time = ax_modf( time / et, &loop ) * et;
		
		if( max_loop_ != 0 ) {
			if( loop >= max_loop_ )	{ out_index = e; return true; }
		}
	}
	
	if( time < frames_[0].time ) { out_index = 0; return true;}
	
	axSize mid;
	
	for(;;) {
		mid = (e-s) / 2 + s;
		if( time < frames_[mid].time ) {
			e = mid;
		}else{
			if( e-mid == 1 ) {
				out_index = mid+1;
				return true;
			}
			s = mid;
		}
	}
	
	return false;
}
	
void axGLTextureSeq::setMagFilter( int v ) {
	axSize i;
	for( i=0; i<frames_.size(); i++ ) {
		frames_[i].bind();
		frames_[i].setMagFilter( v );
		frames_[i].unbind();		
	}
}

void axGLTextureSeq::setMinFilter( int v ) {
	axSize i;
	for( i=0; i<frames_.size(); i++ ) {
		frames_[i].bind();
		frames_[i].setMinFilter( v );
		frames_[i].unbind();
	}
}

void axGLTextureSeq::setGenMipmap( bool b, int mi, int mx  ) {
	axSize i;
	for( i=0; i<frames_.size(); i++ ) {
		frames_[i].bind();
		frames_[i].setGenMipmap( b, mi, mx );
		frames_[i].unbind();
	}
}



void axGLTextureSeq::setWrap( int s, int t ) {
	axSize i;
	for( i=0; i<frames_.size(); i++ ) {
		frames_[i].bind();
		frames_[i].setWrap( s, t );
		frames_[i].unbind();
	}
}
