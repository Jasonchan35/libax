#include "axImage_GIF.h"

#ifdef axUSE_GIFLIB

int axImage_GIF_read_cb( GifFileType* gif, GifByteType* p, int len ){
	axStatus st;
	axSize count = 0;

	if ( !gif || !p || len < 0 ) { assert( false ); return 0; }

	axImage_GIF* o = (axImage_GIF*) gif->UserData;
	if( !o ) { assert( false ); return 0; }
	if( ! o->ds_.io_raw( p, len ) ) return 0;
	return len;
}

inline void axImage_GIF_copy_line ( axImage &img, GifImageDesc &src, int y, ColorMapObject* color_table, uint8_t *(&idx), int transparent_index  ) {
	axColorRGBAb* pixel = (axColorRGBAb*) img.pixelVoidPointer( src.Left, src.Top + y );
	int x;
	for ( x=0; x<src.Width; x++ ) {
		GifColorType& c = color_table->Colors[ *idx ] ;
		if ( transparent_index != *idx || transparent_index == -1 ) {
			pixel->set( c.Red, c.Green, c.Blue, 0xFF );
		}
		pixel++;
		idx++;
	}
	
}

axStatus axImage_GIF_save(  GifFileType &file_type, axImage &img, axImage &tmp, SavedImage& saved_image, ColorMapObject* color_table ) {
	axStatus st;

	int dispose_method = 0;
	int transparent_index=-1;
	// get extensions
	int i;
	for( i=0; i<saved_image.ExtensionBlockCount; i++ ) {
		ExtensionBlock& ext = saved_image.ExtensionBlocks[ i ];

		switch ( ext.Function ) {
			case GRAPHICS_EXT_FUNC_CODE:{
				if( ext.ByteCount == 4 ) {
					int flag = (int)ext.Bytes[ 0 ];
					int _t =  ( (int) ((( ext.Bytes[1] & 0x000000ff)) | (((ext.Bytes[2] & 0x000000ff))) << 8 ) );
					img.time_ = ((float) _t) / 100.0f ;

					transparent_index = (flag & 0x01) ? (int)(uint8_t)ext.Bytes[3] : -1;
					
					dispose_method = ( flag >> 2 ) & 7;
				}
			}break;
		}
	}

	//printf("transparent_index %d, ", transparent_index );

	//copy image
	GifImageDesc &src = saved_image.ImageDesc;
	uint8_t      *idx = (uint8_t*) saved_image.RasterBits;

	if( img.width()  < src.Left + src.Width  ) return -1;
	if( img.height() < src.Top  + src.Height ) return -2;

	if( *idx+(src.Width*src.Height) < color_table->ColorCount ) return -3;

	int y;
	
	if ( file_type.Image.Interlace ) {
		
		for ( y=0; y<src.Height; y+=8 ) {
			axImage_GIF_copy_line( img, src,y, color_table, idx, transparent_index );
		}
		for ( y=4; y<src.Height; y+=8 ) {
			axImage_GIF_copy_line( img, src,y, color_table, idx, transparent_index );
		}
		for ( y=2; y<src.Height; y+=4 ) {
			axImage_GIF_copy_line( img, src,y, color_table, idx, transparent_index );
		}
		for ( y=1; y<src.Height; y+=2 ) {
			axImage_GIF_copy_line( img, src,y, color_table, idx, transparent_index );
		}
		
	}else {
		for ( y=0; y<src.Height; y++ ) {
			axImage_GIF_copy_line( img, src,y, color_table, idx, transparent_index );
		}
	}
	
	//printf("dispose_method %d\n", dispose_method);
	//ready the backgorunf for next image
	
	switch( dispose_method ) {
		case 0:{// No disposal specified. The decoder is not required to take any action.
		}break;
		case 1:{// Do not dispose. The graphic is to be left in place.
			st = tmp.copy( img );	if( !st ) return st;
		}break;
		case 2:{// Restore to background color. The area used by the graphic must be restored to the background color.
			uint8_t alpha = 0;
			if( transparent_index == file_type.SBackGroundColor ) {
				alpha = 0xff;
			}
			GifColorType *bg = &color_table->Colors[ file_type.SBackGroundColor ];
			st = img.create(  axColor::t_RGBAb, file_type.SWidth, file_type.SHeight );	if( !st ) return st;
			tmp.setAll( axColorRGBAb( bg->Red, bg->Green, bg->Blue, alpha ) );
		}break;
		case 3:{// Restore to previous. The decoder is required to restore 
			// the area overwritten by the graphic with what was there prior to rendering the graphic	
			//== so do nothing here ===
		}break;
	}	
	
	return 0;
}

axImage_GIF::axImage_GIF() {
	_gif = NULL;
}

axStatus axImage_GIF::open( axIByteArray &buf ) {
	close();
	ds_.set( buf );
	_gif = DGifOpen( this, axImage_GIF_read_cb );
	if ( !_gif )  return -1;
	return 0;
}

void axImage_GIF::close() {
	if ( _gif ) {
		if ( !DGifCloseFile( (GifFileType*) _gif ) ) assert( false );
		_gif = NULL;
	}
}

axStatus axImage_GIF::readPixels( axImageSeq& imgs ){
	GifFileType *gif = (GifFileType*) _gif;

	assert( gif );
	axStatus st;

	axImage	tmp;

	imgs.clear();
	ColorMapObject* color_table = NULL;
	int i;
	
	float total_time = 0;
	
	st = DGifSlurp( (GifFileType*) gif ); if ( !st ) goto error;

	st = imgs.setFrameCount( gif->ImageCount ); if ( !st ) goto error;

	st = tmp.create(  axColor::t_RGBAb, gif->SWidth, gif->SHeight );	if( !st ) goto error;
	tmp.setAllByteZero();
	
	
	for ( i=0 ; i<gif->ImageCount; i++ ) {
		SavedImage& saved_image = gif->SavedImages[i];

		color_table = ( saved_image.ImageDesc.ColorMap ) ? saved_image.ImageDesc.ColorMap : gif->SColorMap;
		if ( !color_table ) { assert( 0 ); goto error; }
		if ( color_table->BitsPerPixel > 8 ) { assert( 0 ); goto error; }
		
		axImage &n = imgs.getFrame(i);
		st = n.copy( tmp );	if( !st ) return st;

		st = axImage_GIF_save( *gif, n, tmp, saved_image, color_table );
		if ( !st ) goto error;

		float t = total_time;
		total_time += n.time_;
		n.time_ += t;
	}

	return 0;

error:
	imgs.clear();

	return st;
}

#endif //axUSE_GIFLIB

