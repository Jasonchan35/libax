#include "axImage_PNG.h"

template<> inline	axStatus	ax_take( png_bytep &a, png_bytep &b )	{ a=b; return 0; }

axImage_PNG::axImage_PNG() {
	png = NULL;
	info = NULL;
}

axStatus axImage_PNG::open( axIByteArray &buf ) {
	close();	
	ds_.set( buf );

	png = png_create_read_struct( PNG_LIBPNG_VER_STRING, NULL, NULL, NULL );
	if( !png )  { close(); return -1; }

	info = png_create_info_struct( png );
	if( !info ) { close(); return -2; }
	/*
#if axOS_iOS	
#warning "problem on iOS 5 Beta, so added dummy line below"
	fputs("", stdout );
#endif
*/
	png_set_read_fn( png, (void*)this, &read_cb );
		
	//if( setjmp( png_jmpbuf( png ))) { close(); return -3; }
	
	jmp_buf *jmp_context = (jmp_buf*) png_get_error_ptr(png); 
	if( jmp_context ) {
		close();
		return -3;
	}
	
	png_read_info( png, info );
	return 0;
}

axStatus axImage_PNG::setReadFilter( axColor::Type img_type, int color_type, int bit ) {
	switch( img_type ) {
		case axColor::t_RGBAb: {
			if (bit == 16) png_set_strip_16(png);
			if ( ! (color_type & PNG_COLOR_MASK_ALPHA) )
				png_set_filler( png, 0xff, PNG_FILLER_AFTER );// add 0xff when 24 bit

			switch( color_type & PNG_COLOR_MASK_COLOR ) {
				case PNG_COLOR_TYPE_RGB:  return 1;
				case PNG_COLOR_TYPE_GRAY: png_set_gray_to_rgb(png);	return 1;
			}
		}break;

		case axColor::t_RGBb: {
			if (bit == 16) png_set_strip_16(png);
			if ( color_type & PNG_COLOR_MASK_ALPHA )
				png_set_strip_alpha(png);

			switch( color_type & PNG_COLOR_MASK_COLOR ) {
				case PNG_COLOR_TYPE_RGB:  return 1;
				case PNG_COLOR_TYPE_GRAY: png_set_gray_to_rgb(png);	return 1;
			}
		}break;

		case axColor::t_Yb: {
			if (bit == 16) png_set_strip_16(png);
			if ( color_type & PNG_COLOR_MASK_ALPHA )
				png_set_strip_alpha(png);

			switch( color_type & PNG_COLOR_MASK_COLOR ) {
				case PNG_COLOR_TYPE_RGB:  png_set_rgb_to_gray_fixed(png,1,-1,-1);return 1;
				case PNG_COLOR_TYPE_GRAY: return 1;
			}
		}break;

		case axColor::t_YAb: {
			if (bit == 16) png_set_strip_16(png);
			if ( ! (color_type & PNG_COLOR_MASK_ALPHA) )
				png_set_filler( png, 0xff, PNG_FILLER_AFTER );// add 0xff when 24 bit

			switch( color_type & PNG_COLOR_MASK_COLOR ) {
				case PNG_COLOR_TYPE_RGB:  png_set_rgb_to_gray_fixed(png,1,-1,-1);return 1;
				case PNG_COLOR_TYPE_GRAY: return 1;
			}
		}break;

		default: return axStatus::Image_PNG_unsupported_color_type;
	}

	close();
	return axStatus::Image_PNG_unsupported_color_type;
}

axStatus axImage_PNG::readPixels( axImage &img, axColor::Type type ) {
	axStatus st;
	png_uint_32 w, h;
	int bit;
	int color_type;
	int interlace;
	
	png_get_IHDR( png, info, &w, &h, &bit, &color_type, &interlace, NULL, NULL );	
//	printf("width=%d, height=%d, bit=%d, color_type=%d, interlace=%d\n", w, h, bit, color_type, interlace );

	if( type == axColor::t_null ) {
		if( bit == 8 ) {
			switch( color_type ) {
				case PNG_COLOR_TYPE_RGB:		type = axColor::t_RGBb;	break;
				case PNG_COLOR_TYPE_RGB_ALPHA:	type = axColor::t_RGBAb;	break;
				case PNG_COLOR_TYPE_GRAY:		type = axColor::t_Yb;		break;
				case PNG_COLOR_TYPE_GRAY_ALPHA:	type = axColor::t_YAb;	break;
			}
		}
		if( type == axColor::t_null )	return axStatus::Image_PNG_unsupported_color_type;
	}

	st = img.create( type, w,h );
	if( !st ) return st;

	st = setReadFilter( img.type(), color_type, bit );
	if( !st ) return st;

	png_bytep ptr = (png_bytep)img.pixelVoidPointer();
	if( !ptr ) return -1;

	axArray<png_bytep, 1024> row; //row pointers
	st = row.resize( h );	if (!st) return st;

	axSize ptr_offset = img.width() * img.byteSizePerPixel();
	png_uint_32 i;

	for ( i=0; i<h; i++ ) {
		row[i] = ptr;
		ptr += ptr_offset;
	}

	png_set_rows( png, info, row.ptr() );
	png_read_image( png , row.ptr() );    
	return 0;
}

void axImage_PNG::close() {
	if( png ) {
		png_destroy_read_struct( &png, &info, NULL );
		png = NULL;
		info = NULL;
	}
}

void axImage_PNG::read_cb ( png_structp png, png_bytep dest, png_size_t len ) {
	axImage_PNG *o = (axImage_PNG*) png_get_io_ptr( png );
	if( !o ) return;
	o->ds_.io_raw( dest, len );
}


axStatus axImage_PNG::save( axIByteArray &buf, axImage &img ) { 
	axStatus st;
	se_.set( buf );

	int channel;
	int bit_depth;
	int color_type; 

	switch( img.type() ) {
		case axColor::t_Yb: {
			channel = 1;
			bit_depth = 8;
			color_type = PNG_COLOR_TYPE_GRAY; 
		}break;

		case axColor::t_YAb: {
			channel = 2;
			bit_depth = 8;
			color_type = PNG_COLOR_TYPE_GRAY_ALPHA;
		}break;

		case axColor::t_RGBb: {
			channel = 3;
			bit_depth = 8;
			color_type = PNG_COLOR_TYPE_RGB;
		}break;	

		case axColor::t_RGBAb: {
			channel = 4;
			bit_depth = 8;
			color_type = PNG_COLOR_TYPE_RGBA;
		}break;	
		default:
			ax_log( "error: save png unknown image type {?}!\n", img.type() );
			return axStatus::Image_PNG_unsupported_color_type;
	}

	png = png_create_write_struct( PNG_LIBPNG_VER_STRING, NULL,NULL,NULL );
	if( !png ) return -2;

	info = png_create_info_struct( png );
	if ( !info ){
      png_destroy_write_struct( &png, NULL );
      return -3;
	}

	//if( setjmp(png_jmpbuf(png)) ){
	
	jmp_buf *jmp_context = (jmp_buf*) png_get_error_ptr(png); 
 	if (jmp_context) {
	  png_destroy_write_struct( &png, &info );
	  return -4;
	} 

	png_set_compression_level( png,  9 );   

	png_bytep ptr = NULL;

	ptr = (png_bytep)img.pixelVoidPointer();

	png_uint_32 h = (png_uint_32)img.height();

	if( !ptr ) return axStatus::invalid_parameter;
	
	axArray<png_bytep,1024> row; //row pointers
	st = row.resize( h );	if (!st) return st;

	int ptr_offset = img.width() * channel * (bit_depth >> 3);
	png_uint_32 i;

	for ( i=0; i<h; i++ ) {
		row[i] = ptr;
		ptr += ptr_offset;
	}

	png_set_rows( png, info, row.ptr() );
	png_set_IHDR( png, info, img.width(), img.height(), bit_depth, color_type,
				  PNG_INTERLACE_NONE ,PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT );
	png_set_write_fn( png, this, write_cb, NULL );
	png_write_png( png, info, PNG_TRANSFORM_IDENTITY, NULL );
	png_destroy_write_struct( &png, &info );

	return 0;
}


void axImage_PNG::write_cb( png_structp png, png_bytep data, png_size_t len ) {
	axImage_PNG *o = (axImage_PNG*) png_get_io_ptr( png );
	if( !o ) return;
	o->se_.io_raw( data, len );
}



