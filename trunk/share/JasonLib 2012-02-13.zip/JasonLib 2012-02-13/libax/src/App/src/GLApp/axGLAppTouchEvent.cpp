#include <ax/App/GLApp/axGLAppTouchEvent.h>

axGLAppTouchEvent::axGLAppTouchEvent() {
	event = kEventNull;
}

axStatus axGLAppTouches::getTouchIndexById	( axSize &index, axGLAppTouch::TouchId touchId ) {
#if 0
	for( axSize i=0; i<size(); i++ ) {
		#if axOS_MacOSX
			/*
			http://developer.apple.com/library/mac/#documentation/AppKit/Reference/NSTouch_Class/Reference/Reference.html#//apple_ref/occ/instm/NSTouch/identity
			 identity
			 Use this property to track changes to a particular touch during the touch's life. (read-only)
			 
			 @property(readonly, retain) id<NSObject, NSCopying> identity
			 Discussion
			 While touch identities may be re-used, they are unique during the life of the touch, even when multiple devices are present.
			 
			 Identity objects implement the NSCopying protocol so that they may be used as keys in an NSDictionary. Use isEqual: to compare two touch identities.
			 */
			NSTouch*	t = element(i).touchId;
			if ( [ t.identity isEqual:touchId.identity] ) {
				index = i;
				return 0;
			}
		#else
			if( indexOf(i).touchId == touchId ) {
				index = i;
				return 0;
			}		
		#endif
	}
#endif
	return axStatus::not_found;
}
