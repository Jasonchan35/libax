#ifndef __axImage_GIF_h__
#define __axImage_GIF_h__

#include <ax/App/graph/axImageSeq.h>

#ifdef axOS_WIN
    #include <ax/external/giflib/Win32/gif_lib.h>
    #define axUSE_GIFLIB    1

	#ifdef axCOMPILER_VC
		#pragma comment( lib, "ax_libungif.lib" )
	#endif //axCOMPILER_VC

#elif axOS_Android
	#include <ax/external/giflib/Android/gif_lib.h> 

#endif


#if axUSE_GIFLIB
class axImage_GIF : public axNonCopyable {
public:
	axImage_GIF();
	~axImage_GIF()		{ close(); }

	axStatus	open	( axIByteArray &buf );
	void		close	();

	axStatus	readPixels	( axImageSeq& imgs );

	void*			_gif;
	axDeserializer	ds_;
};

#endif //axUSE_GIFLIB


#endif //__axImage_GIF_h__
