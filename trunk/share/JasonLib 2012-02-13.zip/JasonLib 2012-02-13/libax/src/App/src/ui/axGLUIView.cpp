#include <ax/App/ui/axGLUIView.h>

axGLUIView::axGLUIView() {
	parent_ = NULL;
	layoutNeeded_ = true;
	proportion_.set( 1,1 );
	align_.set( 0,0 );
	
	rect_.set(0,0,0,0);
	
	minRequireSize_.set( 0,0 );
	maxRequireSize_.set( axTypeOf<float>::valueMax(), axTypeOf<float>::valueMax() ) ;

	color_.set( 1,1,1,1 );
	
}


axGLUIView::~axGLUIView() {
	removeAllChild();
}

void axGLUIView::doLayout() {
	if( ! layoutNeeded_ ) return;
	layoutNeeded_ = false;
	onLayout();
	for( axSize i=0; i<child_.size(); i++ ) {
		child_[i]->doLayout();
	}
}

void axGLUIView::onLayout() {
	
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
		
		axVec2f content_size = size() - padding_.totalSize();
		
		axVec2f child_min = c->minRequireSize();
		axVec2f child_max = c->maxRequireSize();
		
		if( c->proportion_.x > 0 ) {
		
			c->rect_.w = ax_round( ( content_size.x ) * c->proportion_.x - c->margin_.totalWidth() );
			ax_clamp_it( c->rect_.w, child_min.x, child_max.x );
		
		}
		
		if( c->proportion_.y > 0 ) {
			c->rect_.h = ax_round( ( content_size.y ) * c->proportion_.y - c->margin_.totalHeight() );
			ax_clamp_it( c->rect_.h, child_min.y, child_max.y );
		}

		axVec2f pos = c->layoutPosBySize( content_size ) + padding_.leftTop();
		pos.round();
		c->setPos( pos );

 
	}
	
}

axVec2f axGLUIView::layoutPosBySize( const axVec2f& size ) {
	axVec2f r;
	
	axVec2f client_size;
	
	client_size = size - rect_.size() - margin_.totalSize();
	r = ( align_ + 1.0f ) * client_size / 2 + (  margin_.leftTop() );
		
	return r;
}


void axGLUIView::layoutNeeded() {
	if( layoutNeeded_ ) return;
	layoutNeeded_ = true;
	if( parent_ ) parent_->layoutNeeded();	
}

axVec2f axGLUIView::contentSize	() const {
	return ax_max( rect_.size() - padding_.totalSize(), axVec2f(0,0) );
}

void axGLUIView::onResize( float w, float h ) {
}

axVec2f	axGLUIView::pointFromParent( const axVec2f& pt ) {
	return pt - rect_.pos();
}

void axGLUIView::doTouchEvent( axGLAppTouchEvent &ev ) {
	onTouchEvent( ev );
}

void axGLUIView::onTouchEvent( axGLAppTouchEvent &ev ) {	
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
		if( c->rect_.isInside( ev.pos ) ) {
			ev.pos = c->pointFromParent( ev.pos );			
			c->onTouchEvent( ev );
		}
	}
}

void axGLUIView::doMouseEvent( axGLAppMouseEvent &ev ) {
	onMouseEvent( ev );
}

void axGLUIView::onMouseEvent( axGLAppMouseEvent &ev ) {
}

void axGLUIView::doKeyEvent( axGLAppKeyEvent &ev ) {
	onKeyEvent( ev );
}

void axGLUIView::onKeyEvent( axGLAppKeyEvent &ev ) {
}

void axGLUIView::setPos( const axVec2f& pos ) {
	rect_.pos() = pos;
}

void axGLUIView::setSize( const axVec2f& size ) {
	rect_.size() = size;
}

void axGLUIView::setRect( const axRect2f& rect ) {
	rect_ = rect;
}


void	axGLUIView::setFizedSize		( const axVec2f& size ) {
	proportion_.set( 0, 0 );
	setSize( size );
	layoutNeeded();
}

void axGLUIView::render( axGLAppRenderRequest& req ) const {
	axScopeGLPushMatrix	pm;
	
	glTranslate( rect_.x, rect_.y );
	
	glColor( color_ );
	onRender( req );
		
	renderChild_( req );
}

void axGLUIView::renderChild_(  axGLAppRenderRequest& req ) const {

	

		
	for( axSize i=0; i<child_.size(); i++ ) {
		
		const axGLUIView* c = child_[i];
		
		if( req.ui.showLayout ) {
				
			
			glColor4f( 1,0,0,1 );
			axGLDrawLine( axRect2f( axVec2f( c->rect().x, c->rect().y), c->contentSize() ) );
			/*
			axGLDrawLine( axRect2f(	c->rect().x , c->rect().y, 
									c->size().x, c->size().y ));
			*/
			glColor4f( 1,1,1,1 );	
			
		}
		
		
		c->render( req );
	}
}

void axGLUIView::onRender( axGLAppRenderRequest& req ) const {

	if( req.ui.showLayout ) {
		/*	
		glColor4f( 0,1,0,0.6 );
		glDrawLine( axRect2f( axVec2f( padding().left, padding().top ), contentSize() ) );
		glColor4f( 1,1,1,1 );
	*/
		/*
		glColor4f( 0,1,0,0.6 );
		glDrawLine( axRect2f( axVec2f( padding().left, padding().top ), contentSize() ) );
		glColor4f( 1,1,1,1 );
		*/
	}
}



axStatus	axGLUIView::appendChild	( axGLUIView* c ) {
	axStatus	st;
	c->removeFromParent();
	st = child_.append( c );
	if( !st ) return st;
	c->parent_ = this;
	layoutNeeded();
	return 0;
}

axStatus	axGLUIView::removeChild	( axGLUIView* c ) {
	for( axSize i=0; i<child_.size(); i++ ) {
		if( child_[i].ptr() == c ) {
			c->parent_ = NULL;
			child_.remove(i);
		}
	}
	layoutNeeded();
	return 0;
}

void	axGLUIView::removeAllChild() {
	while( child_.size() ) {
		child_.last()->parent_ = NULL;
		child_.decSize(1);
	}	
	layoutNeeded();
}

void	axGLUIView::removeFromParent() {
	if( ! parent_ ) return;
	parent_->layoutNeeded();
	parent_->removeChild( this );
	parent_ = NULL;
}

void	axGLUIView::setAlign		( float x, float y )	{ align_.set( x,y ); }
void	axGLUIView::setMargin		( float m )				{ margin_.set(m,m,m,m); }
void	axGLUIView::setProportion	( float x, float y )	{ proportion_.set(x,y); layoutNeeded(); }

void	axGLUIView::setMargin		( float top, float bottom, float left, float right )	{ 
	margin_.set(top,bottom,left,right); 
}

void	axGLUIView::setPadding		( float top, float bottom, float left, float right )	{ 
	padding_.set(top,bottom,left,right); 
}

void	axGLUIView::setPadding		( float m )				{ padding_.set(m,m,m,m); }

const	axVec2f&	axGLUIView::align			() const				{ return align_; }
const	axVec2f&	axGLUIView::proportion		() const				{ return proportion_; }
const	axBorder2f& axGLUIView::margin			() const				{ return margin_;  }
const	axBorder2f& axGLUIView::padding			() const				{ return padding_; }	





void	axGLUIView::onClickEvent( axGLUIClickEvent &ev ) {
	if( !parent_ ) return;
	parent_->onClickEvent( ev );
}
			
			
			
			
