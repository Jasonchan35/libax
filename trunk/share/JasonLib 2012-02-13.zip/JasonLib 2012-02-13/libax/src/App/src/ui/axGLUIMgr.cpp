//
//  axGLUIMgr.cpp
//  ax
//
//  Created by Jason on 25/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <ax/App/ui/axGLUIMgr.h>

axGLUIMgr::axGLUIMgr() {
}

void axGLUIMgr::render() {
	ax_gl2DMode();
	/*
	glColor3f( 1,0,0 );
	glDraw( axRect2f( 10,10, 100, 20 ) );
	glColor3f(1,1,1);
	 */
}


//static
axGLUIMgr* axGLUIMgr::getInstance () {
	static	axGLUIMgr uimgr;
	return 	&uimgr;
}
