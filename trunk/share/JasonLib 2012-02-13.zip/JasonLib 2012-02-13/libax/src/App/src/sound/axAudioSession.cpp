/*  Filename = axAudioSession.cpp / Project = libax
 *  Created by Tony on 25/07/2011.
 *  Copyright 2009 Awenix. All rights reserved. */


#include <ax/App/sound/axAudioSession.h>

#if 0
#pragma mark ================= iOS ====================
#endif

#ifdef axOS_iOS

//-----------------------------

@interface axAudioSession_Delegate : NSObject < AVAudioSessionDelegate > {

	axAudioSession *p_;
}


@property (nonatomic, assign) axAudioSession *p_;

@end

@implementation axAudioSession_Delegate

@synthesize p_;

/*
 virtual void callbackInputIsAvailableChanged() {};
 */
- (void)beginInterruption {
	
	assert( p_ != NULL );
	p_->callbackBeginInterruption();
	
}

- (void)endInterruptionWithFlags:(NSUInteger)flags {
	assert( p_ != NULL );
	p_->callbackEndInterruption();
}
 

- (void)inputIsAvailableChanged:(BOOL)isInputAvailable {
	assert( p_ != NULL );
	p_->callbackInputIsAvailableChanged( isInputAvailable );
}




axAudioSession::axAudioSession() {
	delegate_ = nil;
}

axAudioSession::~axAudioSession() {
	close();
}

void axAudioSession::close() {

	if( delegate_ ) {
		[delegate_ release];
		delegate_ = nil;
	}
}


axStatus axAudioSession::init( bool is_solo ) {
	close();
	
	axAudioSession_Delegate *p = [[axAudioSession_Delegate alloc] init];
	if( !p ) return axStatus::not_enough_memory;
	p.p_ = this;
	delegate_ = p;
	
	[[AVAudioSession sharedInstance] setDelegate: delegate_ ];
	
	NSError *err = NULL;
	NSString *categories = nil;
	
	if( is_solo ) {
		categories = AVAudioSessionCategorySoloAmbient;
	}else {
		categories = AVAudioSessionCategoryAmbient;
	}

	
	[[AVAudioSession sharedInstance] setCategory: categories error: &err];
	
	return 0;
}



@end  
 
#endif //axOS_iOS
