#include <ax/App/opengl/axGLArrayBuffer.h>

axGLArrayBuffer::axGLArrayBuffer() { 
	reset_();
}

axGLArrayBuffer::~axGLArrayBuffer() {
	destroy();
}

void axGLArrayBuffer::reset_() {
	id_ = 0; 
	target_ = 0; 
	type_ = 0; 
	elementSize_ = 0; 
}

void axGLArrayBuffer::destroy() {
	if( id_ ) { 
		glDeleteBuffers(1, &id_); 
		id_ = 0; 
	}
}

void axGLArrayBuffer::createId_( GLenum target, GLenum type, GLint elementSize ) { 
	destroy();
	glGenBuffers( 1, &id_ ); 

	target_ = target;
	type_   = type;
	elementSize_ = elementSize;
}

axStatus axGLArrayBuffer::create	( const axIArray<axVec2f> &data, GLenum usage ) {
	createId_( GL_ARRAY_BUFFER, GL_FLOAT, 2 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<axVec3f> &data, GLenum usage ){
	createId_( GL_ARRAY_BUFFER, GL_FLOAT, 3 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<axColorRGBAb> &data, GLenum usage ) {
	createId_( GL_ARRAY_BUFFER, GL_UNSIGNED_BYTE, 4 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<axColorRGBb> &data, GLenum usage ) {
	createId_( GL_ARRAY_BUFFER, GL_UNSIGNED_BYTE, 3 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<axColorRGBAf> &data, GLenum usage ) {
	createId_( GL_ARRAY_BUFFER, GL_FLOAT, 4 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<axColorRGBf> &data, GLenum usage ) {
	createId_( GL_ARRAY_BUFFER, GL_FLOAT, 3 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

axStatus axGLArrayBuffer::create	( const axIArray<uint16_t> &data, GLenum usage ) {
	createId_( GL_ELEMENT_ARRAY_BUFFER, GL_UNSIGNED_SHORT, 1 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

#ifndef axUSE_OpenGL_ES
axStatus axGLArrayBuffer::create	( const axIArray<uint32_t> &data, GLenum usage ) {
	createId_( GL_ELEMENT_ARRAY_BUFFER, GL_UNSIGNED_INT, 1 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}
#endif

axStatus axGLArrayBuffer::onTake( axGLArrayBuffer &src ) {
	if( this == &src ) { assert( false ); return 0; }
	destroy();
	id_			 = src.id_;
	target_		 = src.target_;
	type_		 = src.type_;
	elementSize_ = src.elementSize_;
	src.reset_();
	return 0;
}
	

