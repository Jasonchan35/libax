#include <ax/App/openal/axALContext.h>

#ifdef axUSE_OpenAL

#ifdef axOS_iOS
alBufferDataStaticProcPtr _alBufferDataStatic = NULL;
#endif

axALContext :: axALContext()  {
	device = NULL;
	ctx = NULL;	
}

axALContext :: ~axALContext() { destroy(); }

void axALContext :: destroy() {
	if( ctx ) {
		alcMakeContextCurrent( NULL );
		alcDestroyContext( ctx );
		ctx = NULL;
	}

	if( device ) {
		alcCloseDevice( device );
		device = NULL;
	}
}

axStatus axALContext :: create( const char* device_name ) {
	destroy();
	device = alcOpenDevice( device_name );
	if( !device ) {
		print_openal_if_error( __FUNCTION__ );
		return -1;
	}

	ctx = alcCreateContext( device, NULL );
	if( !ctx ) {
		print_openal_if_error( __FUNCTION__ );
		return -2;
	}

	make_current();

#ifdef axOS_iOS
	
	_alBufferDataStatic = (alBufferDataStaticProcPtr) alcGetProcAddress(NULL, (const ALCchar*) "alBufferDataStatic");

#endif
	
	// Check for EAX 2.0 support
//		g_bEAX = alIsExtensionPresent("EAX2.0");
	return 0;
}

#endif //axUSE_OpenAL

