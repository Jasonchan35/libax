#include <ax/App/graph/axImage.h>
#include <ax/App/graph/axImageSeq.h>
#include <ax/ax_base.h>

#include "axImage_PNG.h"
#include "axImage_DDS.h"
#include "axImage_GIF.h"

axImage::axImage() {
	destroy();
}

axStatus	axImage::onTake( axImage &b ) {
	destroy();
	axStatus st;
	
	width_	= b.width_;
	height_	= b.height_;
	type_	= b.type_;
	byteSizePerPixel_ = b.byteSizePerPixel_;
	time_	= b.time_;
	st = pixelData_.onTake( b.pixelData_ );		if( !st ) return st;
	
	b.width_ = 0;
	b.height_ = 0;
	b.time_ = 0;
	b.type_ = axColor::t_null;
	b.byteSizePerPixel_ = 0;
	
	return 0;
}

void axImage::setAllByteZero() {
	memset( pixelData_.ptr(), 0, pixelData_.size() );
}
	
axStatus axImage::flip( bool horizontal, bool vertical ) {
	axStatus st;
	axByteArray	tmp;
	
	if( ! horizontal && ! vertical ) return 0;
	
	st = tmp.resize( pixelData_.size() );		if( !st ) return st;
	axSize row_byte = byteSizePerPixel() * width_;
	
	if( horizontal ) {
		if( vertical ) {
			for( int y=0; y<height_; y++ ) {
				if( byteSizePerPixel_ ==  4 ) {
					int32_t*	s = (int32_t*)&pixelData_[ row_byte * (y+1) - byteSizePerPixel_ ];
					int32_t*	d = (int32_t*)&tmp[ row_byte * (height_-y-1) ];
					for( int x=0; x<width_; x++ ) {
						*d = *s; d++; s--;
					}	
				}else{
					uint8_t*	s = &pixelData_[ row_byte * (y+1) - byteSizePerPixel_ ];
					uint8_t*	d = &tmp[ row_byte * (height_-y-1) ];
					for( int x=0; x<width_; x++ ) {
						for( axSize c=0; c<byteSizePerPixel_; c++ ) {
							*d = *s; d++; s++;
						}
						s -= byteSizePerPixel_ << 1;
					}						
				}
			}							
		}else{			
			for( int y=0; y<height_; y++ ) {
				if( byteSizePerPixel_ ==  4 ) {
					int32_t*	s = (int32_t*)&pixelData_[ row_byte * (y+1) - byteSizePerPixel_ ];
					int32_t*	d = (int32_t*)&tmp[ row_byte * y ];
					for( int x=0; x<width_; x++ ) {
						*d = *s; d++; s--;
					}	
				}else{
					uint8_t*	s = &pixelData_[ row_byte * (y+1) - byteSizePerPixel_ ];
					uint8_t*	d = &tmp[ row_byte * y ];
					for( int x=0; x<width_; x++ ) {
						for( axSize c=0; c<byteSizePerPixel_; c++ ) {
							*d = *s; d++; s++;
						}
						s -= byteSizePerPixel_ << 1;
					}						
				}
			}							
		}
	}else{
		if( vertical ) {
			for( int y=0; y<height_; y++ ) {
				uint8_t*	s = &pixelData_[ row_byte * (height_-y-1) ];
				uint8_t*	d = &tmp[ row_byte * y ];
				memcpy( d, s, row_byte );
			}				
		}
	}
	
	pixelData_.onTake( tmp );
	return st;
}		

axStatus axImage::create( axColor::Type type, int width, int height ) {
	byteSizePerPixel_ = axColor::get_pixel_size( type );
	if( byteSizePerPixel_ == 0 ) return axStatus::Image_unsupported_color_type;

	axStatus st = pixelData_.resize( width * height * byteSizePerPixel_, false );
	if( !st ) { destroy(); return st; }
	
	width_  = width;
	height_ = height;
	type_ = type;
		
	return 0;
}

template< class T> static 
axStatus	axImage_create( axImage &img, T*  pixels, int width, int height ) {
	axStatus st;
	axColor::Type	type = axColor::get_type<T>();
	if( type == axColor::t_null ) return axStatus::Image_unsupported_color_type;

	st = img.create( type, width, height );	if( !st ) return st;
	memcpy( img.pixelVoidPointer(), pixels, img.bufferByteSize() );
	return 0;
}

axStatus	axImage::create( axColorAb*    pixels, int width, int height ) { return axImage_create( *this, pixels, width, height ); }
axStatus	axImage::create( axColorYb*    pixels, int width, int height ) { return axImage_create( *this, pixels, width, height ); }
axStatus	axImage::create( axColorYAb*   pixels, int width, int height ) { return axImage_create( *this, pixels, width, height ); }
axStatus	axImage::create( axColorRGBb*  pixels, int width, int height ) { return axImage_create( *this, pixels, width, height ); }
axStatus	axImage::create( axColorRGBAb* pixels, int width, int height ) { return axImage_create( *this, pixels, width, height ); }


axStatus	axImage::createFromText	( axFont &font, const wchar_t *text ) {
	return font.makeImageAb( *this, text );
}

axStatus	axImage::createFromTextInRect ( axFont &font, const wchar_t *text, int width, int height, axAlignment align ) {
	return font.makeImageAbInRect( *this, text, width, height, align );
}

void axImage::destroy() {
	width_ = height_ = 0;
	type_  = axColor::t_null;
	time_  = 0;
	pixelData_.clear();
}

axStatus axImage::convert( const axImage& img, axColor::Type type ){
	axStatus st;
	if( type == axColor::t_null || type == img.type() ) {
		width_  = img.width_;
		height_ = img.height_;
		st		= pixelData_.copy( img.pixelData_ );	if( !st ) return st;
		type_	= img.type_;
		byteSizePerPixel_ = img.byteSizePerPixel_;
		return 0;
	}

	st = create( type, img.width_, img.height_ );	if( !st ) return st;

	switch( img.type() ) {
		#define axImage_ColorEnum(T) \
			case axColor::t_##T:	return setPixels( (axColor##T*)img.pixelVoidPointer(), width_, height_ );
		#include "axImage_ColorEnum.h"
		#undef axImage_ColorEnum	
	}
	return axStatus::Image_unsupported_color_type;
}

template<class T> inline
axStatus axImage_setAll( axImage& img, const T &v ) {
	if( img.type() == axColor::get_type<T>() ) {
		int i,j;
		T* p;
		img.pixelPointer(p);
		for( j=0; j<img.height(); j++ ) {
			for( i=0; i<img.width(); i++, p++ ) {
				*p = v;
			}
		}
		return 0;
	}else{
		switch( img.type() ) {
			#define axImage_ColorEnum(T) \
			case axColor::t_##T:   return axImage_setAll( img, axColor##T(v) );
			#include "axImage_ColorEnum.h"
			#undef axImage_ColorEnum	
		}
		return axStatus::Image_unsupported_color_type;
	}
}


template<class DST, class SRC> inline
axStatus	axImage_setPixels_2( axImage &img, const SRC*  pixels, int w, int h ) {
	int cw = ax_min( w, img.width () );
	int ch = ax_min( h, img.height() );

	int i,j;
	for( j=0; j<ch; j++ ) {
		DST* dst = (DST*) img.pixelVoidPointer( 0, j );
		const SRC* src = pixels + (j * w);
		for( i=0; i<cw; i++, dst++, src++ ) {
			*dst = *src;
		}
	}
	return 0;
}

template<class SRC> inline
axStatus	axImage_setPixels( axImage &img, const SRC* pixels, int w, int h ) {

	if( img.type() == axColor::get_type<SRC>() ) {
		if( w == img.width() && h == img.height() ) {
			memcpy( img.pixelVoidPointer(), pixels, w * h * sizeof(SRC) );
		}
	}

	switch( img.type() ) {
		#define axImage_ColorEnum(T) \
		case axColor::t_##T:    return axImage_setPixels_2< axColor##T,   SRC >( img, pixels, w,h );
		#include "axImage_ColorEnum.h"
		#undef axImage_ColorEnum	
		default:
			return axStatus::Image_unsupported_color_type;
	}
}


template<class SRC, class DST> inline
axStatus	axImage_getPixels_2( const axImage &img, DST*  pixels, int w, int h ) {
	int cw = ax_min( w, img.width () );
	int ch = ax_min( h, img.height() );

	int i,j;
	for( j=0; j<ch; j++ ) {
		DST* dst = pixels + (j * w);
		const SRC* src;
		img.pixelPointer( src, 0, j );
		for( i=0; i<cw; i++, dst++, src++ ) {
			*dst = *src;
		}
	}
	return 0;
}

template<class DST> inline
axStatus	axImage_getPixels( const axImage &img, DST* pixels, int w, int h ) {
	if( img.type() == axColor::get_type<DST>() ) {
		if( w == img.width() && h == img.height() ) {
			memcpy( (void*)pixels, img.pixelVoidPointer(), w*h*sizeof(DST) );
		}
	}

	switch( img.type() ) {
		#define axImage_ColorEnum(T) \
		case axColor::t_##T:    return axImage_getPixels_2< axColor##T,   DST >( img, pixels, w,h );
		#include "axImage_ColorEnum.h"
		#undef axImage_ColorEnum	
		default:
			return axStatus::Image_unsupported_color_type;
	}
}


template<class T>
void axImage_setPixel( axImage* img, const T& color, int x, int y ) {
	void* p = img->pixelVoidPointer(x,y);	if( !p ) return;
	switch( img->type() ) {
		#define axImage_ColorEnum(T) \
		case axColor::t_##T:	    *(axColor##T*   )p = color; break;
		#include "axImage_ColorEnum.h"
		#undef axImage_ColorEnum	
		default: assert( false );
	}
}

#define	axTYPE_LIST(T) \
	axStatus axImage::setAll	( const T  &v )						{ return axImage_setAll( *this, v ); } \
	axStatus axImage::setPixels	( const T* pixels, int w, int h )	{ return axImage_setPixels( *this, pixels, w,h ); } \
	axStatus axImage::getPixels	( T* pixels, int w, int h ) const	{ return axImage_getPixels( *this, pixels, w,h ); } \
	void	 axImage::setPixel	( const T& color, int x, int y )	{ axImage_setPixel( this, color, x, y ); } \
//----
	axTYPE_LIST( axColorAb )
	axTYPE_LIST( axColorYb )
	axTYPE_LIST( axColorYAb )
	axTYPE_LIST( axColorRGBb )
	axTYPE_LIST( axColorRGBAb )
#undef axTYPE_LIST

axStatus axImage::subImage( const axImage& src, const axRect2i &src_rc, int x, int y ) {
	int i,j;
	axRect2i rc = src_rc;
	if( x < 0 ) {
		rc.x -= x;
		rc.w += x;
		if( rc.w < 0 ) return 0;
		x = 0;
	}
	if( y < 0 ) {
		rc.y -= y;
		rc.h += y;
		if( rc.h < 0 ) return 0;
		y = 0;
	}

	int w = ax_min( src_rc.right(),  width_ );
	int h = ax_min( src_rc.bottom(), height_ );
	
	for( j=0; j<h; j++ ) {
		for( i=0; i<w; i++ ) {
			const void* src_pixel = pixelVoidPointer( rc.x+i, rc.y+j );
			switch( src.type() ) {
				case axColor::t_Yb:	   setPixel( *(axColorYb*   )src_pixel, x+i, y+j ); break;
				case axColor::t_YAb:   setPixel( *(axColorYAb*  )src_pixel, x+i, y+j ); break; 
				case axColor::t_RGBb:  setPixel( *(axColorRGBb* )src_pixel, x+i, y+j ); break;
				case axColor::t_RGBAb: setPixel( *(axColorRGBAb*)src_pixel, x+i, y+j ); break;
				default:
					return axStatus::Image_unsupported_color_type;
			}
		}
	}

	return 0;
}


axStatus axImage :: loadFile	( const wchar_t* filename,	axColor::Type type ) {
	axStatus st;
	axTempStringA str;
	st = str.set( filename ); if( !st ) return st;
	return loadFile( str, type );
}

axStatus axImage :: loadFile( const char* filename, axColor::Type type ) {
	axStatus st;
	axTempStringA ext;
	st = axFilePath::getFileExt( ext, filename );

	axMemMap	mmap;
	st = mmap.openRead( filename );		if( !st ) return st;

	if( ax_strcasecmp( ext, "dds" ) == 0 ) return loadDds( mmap, type );
	if( ax_strcasecmp( ext, "png" ) == 0 ) return loadPng( mmap, type );
	if( ax_strcasecmp( ext, "gif" ) == 0 ) return loadGif( mmap, type );

	return axStatus::Image_unsupported_format;
}

axStatus axImage :: loadPng ( axIByteArray &buf, axColor::Type type ) {
	axImage_PNG png;
	axStatus st = png.open( buf );
	if( !st ) return st;
	return png.readPixels( *this, type );
}

axStatus axImage :: loadDds ( axIByteArray &buf, axColor::Type type ) {
	axImage_DDS dds;
	axStatus st = dds.load( buf );
	if (!st) return st;
	return dds.readPixels( *this, type );
}

axStatus axImage :: loadGif( axIByteArray &buf, axColor::Type type ) {
#ifdef axUSE_GIFLIB
	axImage_GIF gif;
	axStatus st = gif.open( buf );
	if( !st ) return st;

	axImageSeq img_seq;
	st = gif.readPixels( img_seq ); if( !st ) return st;
	if( img_seq.frameCount() < 1 ) return -101;

	return convert( img_seq.getFrame(0), type );
#else
    return axStatus::Image_unsupported_format;
#endif
}

axStatus	axImage::saveFile	( const char* filename ) {
	axStatus st;
	axFileStream	file;
	st = file.open( filename, "wb" );		if( !st ) return st;

	axTempStringA	ext;
	st = axFilePath::getFileExt(ext,filename);	if( !st ) return st;
	
	axByteArray	buf;
	st = saveMem( buf, ext );	if( !st ) return st;
	
	st = file.write( buf );				if( !st ) return st;
	return 0;
}

axStatus	axImage::saveMem	( axIByteArray &buf, const char* file_ext ) {
	if( ax_strcasecmp( file_ext, "png" ) == 0 ) return savePng( buf );
	if( ax_strcasecmp( file_ext, "dds" ) == 0 ) return saveDds( buf );
	return axStatus::Image_unsupported_format;
}

axStatus axImage :: savePng ( axIByteArray &buf ) {
	axImage_PNG png;
	return png.save( buf, *this );
}

axStatus axImage :: saveDds ( axIByteArray &buf ) {
	axImage_DDS dds;
	return dds.save( buf, *this );
}

#if axOS_iOS
axStatus axImage :: create( UIImage *src ) {
	axStatus st;	
	
	CGContextRef			cg; //CoreGraph
	CGColorSpaceRef			colorSpace;
	
	int w = src.size.width;
	int h = src.size.height;
	
	st = create( axColor::t_RGBAb, w, h );		if( !st ) return st;
	setAllByteZero();
	
	colorSpace = CGColorSpaceCreateDeviceRGB();	
	cg = CGBitmapContextCreate( pixelVoidPointer(), w, h, 8, w * byteSizePerPixel(), 
							   colorSpace, kCGImageAlphaPremultipliedLast );
	CGColorSpaceRelease(colorSpace);
	
	if( !cg ) return -1;
	
	UIGraphicsPushContext(cg);	
	
	CGContextTranslateCTM(cg, 0, h );
	CGContextScaleCTM(cg, 1, -1); 
	
	[ src drawAtPoint:CGPointMake(0,0) ];
	UIGraphicsPopContext();
	
	CGContextRelease(cg);	
	return 0;
}
	
void Image_ReleaseCGDataProviderDate ( void *info, const void *data, size_t size ) {
	free( (void*) data );
}

UIImage* axImage::saveUIImage () {
	if( type_ != axColor::t_RGBAb ) return nil;
	if( width_ == 0 || height_ == 0 ) return nil;
	
	CGDataProviderRef provider = NULL;
	CGColorSpaceRef cs = NULL;
	CGImageRef img = nil;
	UIImage *out_img = nil;
	
	provider = CGDataProviderCreateWithData( NULL, pixelData_.ptr(), pixelData_.size(), NULL );
	if( !provider ) goto cleanup;
	
	cs  = CGColorSpaceCreateDeviceRGB();
	if( !cs )  goto cleanup;
	img = CGImageCreate( width_, height_, 8, 32, (4*width_), cs, kCGBitmapByteOrderDefault, 
						provider, NULL, NO, kCGRenderingIntentDefault );	
	if( !img )  goto cleanup;
	
	UIGraphicsBeginImageContext( CGSizeMake(width_,height_) );		
	
	CGContextDrawImage( UIGraphicsGetCurrentContext(), CGRectMake(0,0,width_,height_), img );
	
	out_img = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
cleanup:
	if( cs		 ) CGColorSpaceRelease( cs );
	if( img		 ) CGImageRelease(img);
	if( provider ) CGDataProviderRelease(provider);								  
	return out_img;
}


UIImage*	UIImage_resize( UIImage* src, float w, float h ) {
	UIGraphicsBeginImageContext( CGSizeMake(w,h) );		
	[src drawInRect: CGRectMake(0,0,w,h) ];	
	UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return newImage;	
}	

UIImage*	UIImage_in_rect( UIImage* src, const axRect2f& rc ) {
	if( ! src ) return nil;
	if( ! src.CGImage ) return nil;
	
	CGImageRef c = CGImageCreateWithImageInRect( src.CGImage, to_CGRect( rc ) );
	if( !c ) return nil;
	
	UIImage* out = [UIImage imageWithCGImage:c]; 
	CGImageRelease( c );
	return out;
}

axStatus	axImage::captureUIView ( UIView  *view ) {
	axStatus st;
	UIGraphicsBeginImageContext( view.bounds.size );
	[ view.layer renderInContext:UIGraphicsGetCurrentContext() ];

	UIImage *t = UIGraphicsGetImageFromCurrentImageContext();
	st = create( t );
	UIGraphicsEndImageContext();

	return st;
}


#endif

#if axOS_MacOSX
axStatus	axImage::captureNSView	( NSView  *view ) {
//Ref: Apple - OpenGL Programming Guide for Mac OS X
//#warning == not yet tested ==

	axStatus st;
	NSBitmapImageRep * bitmap = nil;
	NSInteger samplesPerPixel = 0;

	NSRect rc = [view bounds];
	int w = rc.size.width;
	int h = rc.size.height;

	bitmap = [NSBitmapImageRep alloc];

	[view lockFocus]; 
	[bitmap initWithFocusedViewRect:[view bounds]];
	[view unlockFocus];

	samplesPerPixel = [bitmap samplesPerPixel];

	if(![bitmap isPlanar] && (samplesPerPixel == 3 || samplesPerPixel == 4)) {
		st = create( (samplesPerPixel==4) ? axColor::t_RGBAb : axColor::t_RGBb, w, h );	
		if( !st ) goto ret;
	}else{
		st = axStatus::Image_unsupported_color_type;
		goto ret;
	}

	memcpy( pixelData_.ptr(), [bitmap bitmapData], byteSizePerPixel() * w * h );
ret:
	if( bitmap ) [bitmap release];
	return st;
}
#endif // axOS_MacOSX


