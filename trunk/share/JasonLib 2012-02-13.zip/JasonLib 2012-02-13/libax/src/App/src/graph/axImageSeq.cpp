#include <ax/App/graph/axImageSeq.h>
#include <ax/base/string/axString.h>
#include "axImage_GIF.h"


axImageSeq::axImageSeq() {
	clear();
}

axImageSeq::~axImageSeq() {
	
}
void axImageSeq::clear() {
	max_loop_ = 0;
	frames_.clear();
}

axStatus axImageSeq::loadFile( const char* filename ) {
	axStatus st;

	axTempStringA	ext;
	st = axFilePath::getFileExt(ext,filename);	if( !st ) return st;

	axMemMap	mmap;
	st = mmap.openRead( filename );		if( !st ) return st;

	if( ax_strcasecmp( ext, "gif" ) ) return loadGif( mmap );
	return axStatus::Image_unsupported_format;
}

axStatus axImageSeq::loadGif( axIByteArray &buf ) {
#ifdef axUSE_GIFLIB
	axImage_GIF gif;
	axStatus st = gif.open( buf );		if (!st) return st;
	return gif.readPixels( *this );
#else
    return axStatus::Image_unsupported_format;
#endif
}

bool axImageSeq::getIndexByTime( axSize &out_index, float time ) const {
	if( !frames_.size() ) return false;
	
	axSize s = 0;
	axSize e = frames_.size() - 1;
	
	float et = frames_[e].time_;
	
	if( et == 0 ) { out_index = e; return true; }
	
	if( time > et ) {
		float loop;
		time = ax_modf( time / et, &loop ) * et;
		if( max_loop_ != 0 ) if( loop >= max_loop_ )	{ out_index = e; return true; }
	}
	
	if( time < frames_[0].time_ ) { out_index = 0; return true;}
	
	axSize mid;
	
	for(;;) {
		mid = (e-s) / 2 + s;
		if( time < frames_[mid].time_ ) {
			e = mid;
		}else{
			if( e-mid == 1 ) {
				out_index = mid+1;
				return true;
			}
			s = mid;
		}
	}
	
	return false;
}


