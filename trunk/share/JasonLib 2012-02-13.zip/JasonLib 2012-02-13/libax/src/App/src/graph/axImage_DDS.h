#ifndef __axImage_DDS_h__
#define __axImage_DDS_h__

#include <ax/App/graph/axImage.h>

class axImage;

class axImage_DDS : public axNonCopyable {
public:
	enum DDSPixFormat
	{
		PF_ARGB,
		PF_RGB,
		PF_DXT1,
		PF_DXT2,
		PF_DXT3,
		PF_DXT4,
		PF_DXT5,
		PF_3DC,
		PF_ATI1N,
		PF_LUMINANCE,
		PF_LUMINANCE_ALPHA,
		PF_RXGB, //Doom3 normal maps
		PF_A16B16G16R16,
		PF_R16F,
		PF_G16R16F,
		PF_A16B16G16R16F,
		PF_R32F,
		PF_G32R32F,
		PF_A32B32G32R32F,
		PF_UNKNOWN = 0xFF
	};

	enum { k_dds_sign_len = 4 };

	class DDSHEAD {
	public:
		char sign[k_dds_sign_len];

		uint32_t	size1;				// size of the structure (minus MagicNum)
		uint32_t	flags1; 			// determines what fields are valid
		uint32_t	height; 			// height of surface to be created
		uint32_t	width;				// width of input surface
		uint32_t	linear_size; 		// Formless late-allocated optimized surface size
		uint32_t	depth;				// Depth if a volume texture
		uint32_t	mipmap_count;		// number of mip-map levels requested
		uint32_t	alphabit_depth;		// depth of alpha buffer requested

		uint32_t	not_used[10];

		uint32_t	size2;				// size of structure
		uint32_t	flags2;				// pixel format flags
		uint32_t	fourcc;				// (FOURCC code)
		uint32_t	rgbbit_count;		// how many bits per pixel
		uint32_t	r_bitmask;			// mask for red bit
		uint32_t	g_bitmask;			// mask for green bits
		uint32_t	b_bitmask;			// mask for blue bits
		uint32_t	rgba_bitmask;		// mask for alpha channel

		uint32_t	dds_caps1, dds_caps2, dds_caps3, dds_caps4; // direct draw surface capabilities
		uint32_t	texture_stage;
	};

	class DDSData {
	public:
		DDSPixFormat	fmt;
		uint32_t		block_size;
		int				w;
		int				h;
		int				mipmap_count;
		axByteArray		data;
		DDSData();
	};

private:
	axDeserializer	ds_;
	axSerializer	se_;
	DDSHEAD			header;
	uint32_t		comp_size;		//!< Compressed size
public:
	axImage_DDS();
	~axImage_DDS();
	bool	is_cube_map() const;
	bool	has_mipmap() const;

	axStatus	load( axIByteArray &buf );

	axStatus	readPixels( DDSData &buf, axColor::Type type );
	axStatus	readPixels( axImage &img, axColor::Type type );

	axStatus	save( axIByteArray &buf, axImage &img );

private:
	// ====== decompress functions ====== //
	axStatus	readHeader();
	axStatus	decodePixelFormat( uint32_t &block_size, DDSPixFormat &comp_format );
	axStatus	decompress_dxt1	( DDSData &buf, axImage &img );
	axStatus	decompress_dxt3	( DDSData &buf, axImage &img );
	axStatus	decompress_dxt5	( DDSData &buf, axImage &img );
	// ====== compress functions ====== //
	axStatus	writeHeader	( axImage &img );
	axStatus	compress		( axImage &img );
};

#endif //__axImage_DDS_h__

