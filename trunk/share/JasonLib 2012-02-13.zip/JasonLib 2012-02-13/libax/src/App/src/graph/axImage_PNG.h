#ifndef __axImage_PNG_h__
#define __axImage_PNG_h__

#include <ax/core/file_system/axFile.h>
#include <ax/App/graph/axImage.h>

#if axOS_WIN
	#include <ax/external/libpng/Windows/png.h>

	#ifdef axCOMPILER_VC
		#pragma comment( lib, "ax_libpng.lib" )
		#pragma comment( lib, "ax_zlib.lib" )
	#endif //axCOMPILER_VC

#elif axOS_Android
	#include <ax/external/libpng/Android/png.h> 

#elif axOS_iOS || axOS_MacOSX
    #include <ax/external/libpng/iOS/png.h> 
#elif axOS_FreeBSD || axOS_Linux
        #include <png.h>        
#else
        #error "libpng"
#endif


//! png file
class axImage_PNG : public axNonCopyable {
public:
	axImage_PNG();
	~axImage_PNG()	{ close(); }

	axStatus open( axIByteArray &buf );
	void close();

	axStatus save			( axIByteArray &buf, axImage &img );
	axStatus readPixels		( axImage &img,		 axColor::Type type );

private:
	static void read_cb		( png_structp png, png_bytep dest, png_size_t len );
	static void write_cb	( png_structp png, png_bytep data, png_size_t len );

	axStatus setReadFilter	( axColor::Type img_type, int color_type, int bit );
	png_structp		png;
	png_infop		info;
	axDeserializer	ds_; //for load
	axSerializer	se_; //for save
};

#endif //__axImage_PNG_h__
