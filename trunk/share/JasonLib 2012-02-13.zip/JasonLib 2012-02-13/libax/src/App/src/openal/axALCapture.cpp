#include <ax/App/openal/axALCapture.h>
#include <ax/App/openal/axALContext.h>

#ifdef axUSE_OpenAL

axALCapture::axALCapture( axALContext &oal ) {
	format = 0;
	freq = 0;
	device = NULL;
};


void axALCapture::destroy() {
	if( device ) {
		alcCaptureCloseDevice( device );
		device = NULL;
	}
}

axStatus axALCapture::start() {
	if( !device ) return -1;
	alcCaptureStart( device );
	return 0;
}

axStatus axALCapture::stop()  {
	if( !device ) return -1;
	alcCaptureStop( device );
	return 0;
}

axStatus axALCapture::create( const axALWave &wave, const char* device_name ) {
	return create( wave.format, wave.freq, device_name );
}

axStatus axALCapture::create( ALenum format, int freq, const char* device_name ) {
	destroy();
	this->format = format;
	this->freq = freq;

	if( device_name == NULL ) {
		device_name = device_list();
	}

	device = alcCaptureOpenDevice( device_name, freq, format, freq );
	if( !device ) {
		print_openal_if_error( __FUNCTION__ );
		return -1;
	}
	return 0;
}

axStatus axALCapture::poll( axALWave &w, bool wait_max_sample, uint32_t max_sample ) {

	if( !device ) return -1;
	axStatus st = w.create( format, max_sample, freq );
	if(!st) return st;

	assert( max_sample < INT_MAX );
	int ms = (int)max_sample;

	int a = capture_sample();
	if( wait_max_sample ) {
		if( a < ms ) return 0;
	}

	int s = ax_min( (int)w.buf_sample_size, a );

	alcCaptureSamples( device, w.buf.ptr(), s );
	w.sample = s;
	return 1;
}

int axALCapture::capture_sample() { //The number of capture samples available.
	if( !device ) return 0;
	int i = 0;
	alcGetIntegerv( device, ALC_CAPTURE_SAMPLES, 1, &i );
	return i;
}


#endif //#axUSE_OpenAL

