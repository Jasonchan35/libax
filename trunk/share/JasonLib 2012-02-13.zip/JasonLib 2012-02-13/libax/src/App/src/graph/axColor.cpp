#include <ax/App/graph/axColor.h>

axColorRGBf::axColorRGBf( const axColorHSVf &src ) {
	int i;
	float f, p, q, t;
	float h = (float)src.h;
	float s = (float)src.s;
	float v = (float)src.v;

	if( s == 0 ) {
//		achromatic (grey)
		r = g = b = v;
		return;
	}

	h *= 6;		// sector 0 to 5
	i = (int)floor( h );
	f = h - i;	// factorial part of h
	p = v * ( 1 - s );
	q = v * ( 1 - (s * f) );
	t = v * ( 1 - (s * ( 1 - f )) );
	switch( i ) {
		case 0:	r = v; g = t; b = p; break;
		case 1:	r = q; g = v; b = p; break;
		case 2:	r = p; g = v; b = t; break;
		case 3:	r = p; g = q; b = v; break;
		case 4:	r = t; g = p; b = v; break;
		case 5:	r = v; g = p; b = q; break;
	}
}
	
axStatus ax_str_to( const wchar_t* sz, axColorRGBb &v ) {
	uint32_t tmp[3];
	if( 3 != swscanf( sz, L"%u %u %u", &tmp[0], &tmp[1], &tmp[2] ) )
		return -1;
	if( tmp[0] > 0xff ) return axStatus::out_of_bound;
	if( tmp[1] > 0xff ) return axStatus::out_of_bound;
	if( tmp[2] > 0xff ) return axStatus::out_of_bound;

	v.set( (uint8_t)tmp[0], (uint8_t)tmp[1], (uint8_t)tmp[2] );
	return 0;
}

axStatus ax_str_to( const wchar_t* sz, axColorRGBf &v ) {
	if( 3 != swscanf( sz, L"%f %f %f", &v.r, &v.g, &v.b ) )
		return -1;
	return 0;
}
axStatus ax_str_to( const wchar_t* sz, axColorRGBAb &v )  {
	uint32_t tmp[4];
	if( 4 != swscanf( sz, L"%u %u %u %u", &tmp[0], &tmp[1], &tmp[2], &tmp[3] ) )
		return -1;
	if( tmp[0] > 0xff ) return axStatus::out_of_bound;
	if( tmp[1] > 0xff ) return axStatus::out_of_bound;
	if( tmp[2] > 0xff ) return axStatus::out_of_bound;
	if( tmp[3] > 0xff ) return axStatus::out_of_bound;

	v.set( (uint8_t)tmp[0], (uint8_t)tmp[1], (uint8_t)tmp[2], (uint8_t)tmp[3] );
	return 0;
}
axStatus ax_str_to( const wchar_t* sz, axColorRGBAf &v ) {
	if( 4 != swscanf( sz, L"%f %f %f %f", &v.r, &v.g, &v.b, &v.a) )
		return -1;
	return 0;
}


axStatus ax_str_to( const char* sz, axColorRGBb &v ) {
	uint32_t tmp[3];
	if( 3 != sscanf( sz, "%u %u %u", &tmp[0], &tmp[1], &tmp[2] ) )
		return -1;
	if( tmp[0] > 0xff ) return axStatus::out_of_bound;
	if( tmp[1] > 0xff ) return axStatus::out_of_bound;
	if( tmp[2] > 0xff ) return axStatus::out_of_bound;

	v.set( (uint8_t)tmp[0], (uint8_t)tmp[1], (uint8_t)tmp[2] );
	return 0;
}

axStatus ax_str_to( const char* sz, axColorRGBf &v ) {
	if( 3 != sscanf( sz, "%f %f %f", &v.r.value(), &v.g.value(), &v.b.value() ) )
		return -1;
	return 0;
}

axStatus ax_str_to( const char* sz, axColorRGBAb &v )  {
	uint32_t tmp[4];
	if( 4 != sscanf( sz, "%u %u %u %u", &tmp[0], &tmp[1], &tmp[2], &tmp[3] ) )
		return -1;
	if( tmp[0] > 0xff ) return axStatus::out_of_bound;
	if( tmp[1] > 0xff ) return axStatus::out_of_bound;
	if( tmp[2] > 0xff ) return axStatus::out_of_bound;
	if( tmp[3] > 0xff ) return axStatus::out_of_bound;

	v.set( (uint8_t)tmp[0], (uint8_t)tmp[1], (uint8_t)tmp[2], (uint8_t)tmp[3] );
	return 0;
}

axStatus ax_str_to( const char* sz, axColorRGBAf &v ) {
	if( 4 != sscanf( sz, "%f %f %f %f", &v.r.value(), &v.g.value(), &v.b.value(), &v.a.value()) )
		return -1;
	return 0;
}

