#ifndef __axFreeType2_h__
#define __axFreeType2_h__

#include <ax/App/graph/axFont.h>
#include <ax/App/graph/axImage.h>

#ifdef axUSE_FreeType2

#include <ft2build.h>
#include FT_FREETYPE_H
#include FT_GLYPH_H

class axFreeType2_Face {
public:
	axFreeType2_Face()		{ face_ = NULL; }
	~axFreeType2_Face()		{ close(); }
	void	close();

	axStatus	create			  ( const wchar_t* font_file, float size, bool bold=false, bool italic=false );
	axStatus	getTextRect		  ( int& outWidth, int& outHeight, const wchar_t* text );
	axStatus	makeImageAbInRect ( axImage &img, const wchar_t* text, int width, int height, axFont::Align align );
	
private:	
	FT_Face	face_;
};

class axFreeType2 {
public:
	static	axFreeType2& getInstance();
	
	FT_Library	lib() { return lib_; }
	
private:
	axFreeType2();
	~axFreeType2();
	FT_Library  lib_;
};

#endif //axUSE_FreeType2
#endif //__axFreeType2_h__
