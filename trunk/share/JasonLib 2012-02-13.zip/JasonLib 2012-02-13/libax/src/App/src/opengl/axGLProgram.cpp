/*  Filename = axGLProgram.cpp / Project = awecore
 *  Created by Jason on 18/05/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#include <ax/App/opengl/axGLProgram.h>
#include <ax/App/opengl/axGLShader.h>

#ifdef 	axUSE_OpenGL_ShadingProgram

axGLProgram::axGLProgram() {
	_id = 0;
}

axGLProgram::~axGLProgram() {
	destroy();
}	

void axGLProgram::destroy() {
	if( _id ) {
		glDeleteProgram( _id );
		_id = 0;
	}
}

axStatus	 axGLProgram::create() {
	destroy();
	_id = glCreateProgram();
	if( !_id ) return -1;
	return 0;
}
	
axStatus	axGLProgram::attach_shader( axGLShader	&s ) {
	glAttachShader( _id, s.id() );
	return 0;
}
	
axStatus	 axGLProgram::link() {
	glLinkProgram( _id );

	GLint success = 0;
	glGetProgramiv( _id, GL_LINK_STATUS, &success );
	if( success == 0 ) {
		printf("GLSL Program Link error: ");
		info_log();
		return -1;
	}
	return 0;
}
	
void	axGLProgram::info_log() {
	char msg[2048];
	glGetProgramInfoLog( _id, sizeof(msg), NULL, msg);
	printf("%s\n", msg);
}	
	
void	axGLProgram::bind() {
	glUseProgram( _id );
}
	
void	axGLProgram::unbind() {
	glUseProgram( 0 );
}
	
#endif //axUSE_OpenGL_ShadingProgram


