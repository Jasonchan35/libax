#include <ax/App/opengl/axGLFontTexture.h>

axGLFontTexture::axGLFontTexture() {
	chStart_ = 0;
}

axStatus	axGLFontTexture::createASCII( axFont & font ) {
	axStatus st;
	wchar_t	sz[128];

	chStart_ = 32;
	st = characters_.resize( 128 - chStart_ );		if( !st ) return st;

	int o = 0;
	int cx = 0;
	int cy = 0;
	int w, h;
	for( int i=chStart_; i<128; i++ ) {
		sz[o]   = i;
		sz[o+1] = 0;

		Character & ch = characters_[i - chStart_];
		font.getTextRect( w, h, & sz[o] );		if( !st ) return st;
		ch.rect.set( cx, cy, w, h );
		cx += w;
//		ax_log( "{?} {?} = {?}", i, sz[o], ch.rect );

		o++;
		if( i != chStart_ && (i % 16 == 0) ) {
			cx = 0;
			cy += h;
			sz[o] = '\n';
			o++;
		}
	}
	sz[o] = 0;

	st = tex_.createFromText( font, sz );	if( !st ) return st;
	return 0;
}

axStatus axGLFontTexture::drawText( const axVec3f &pos, const char* text ) {
	if( !text ) return 0;

	axMatrix4f	projection, modelview;
	axRect2f	viewport;

	glGetProjectionMatrix	( projection );
	glGetModelViewMatrix	( modelview  );
	glGetViewport			( viewport   );

	axVec2f p;
	if( ! ax_glTransformVertex( p, pos, modelview, projection, viewport ) ) return 0;

	//ax_log("{?}  ->  {?}", pos, p);

	axScopeGL2DMode		mode;
	
	const char* sz = text;
	for( ; *sz; sz++ ) {
		wchar_t c = *sz - chStart_;
		if( ! characters_.inBound(c) ) continue;
		Character & ch = characters_[c];

		axRect2f	t = to_axRect2f( ch.rect );
		axRect2f	v( p.x, p.y - ch.rect.h, (float)ch.rect.w, (float)ch.rect.h );
		p.x += ch.rect.w;

		tex_.blt( v, t );
	}
	return 0;
}
