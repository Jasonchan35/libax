/*  Filename = axGLShader.cpp / Project = awecore
 *  Created by Jason on 18/05/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#include <ax/App/opengl/axGLShader.h>

#ifdef axUSE_OpenGL_ShadingProgram

axGLShader::axGLShader() {
	_id = 0;
	_type = 0;
}

axGLShader::~axGLShader() {
	destroy();
}	

axStatus	axGLShader::create( GLenum shaderType, const char* glsl ) {
	_id = glCreateShader( shaderType );
	if( !_id ) return -1;	
	_type = shaderType;
	
	glShaderSource( _id, 1, &glsl, NULL );
	glCompileShader( _id );
	
	GLint success;
	glGetShaderiv( _id, GL_COMPILE_STATUS, &success);
	if (success == 0) {
		printf("GLSL compile error: ");
		info_log();
		return -1;
	}	
	return 0;
}

void	axGLShader::destroy() {
	if( _id ) {
		glDeleteShader( _id );
		_id = 0;
		_type = 0;
	}
}

void	axGLShader::info_log() {
	char msg[2048];
	glGetShaderInfoLog( _id, sizeof(msg), NULL, msg);
	printf("%s\n", msg);
}
	
#endif //axUSE_OpenGL_ShadingProgram


