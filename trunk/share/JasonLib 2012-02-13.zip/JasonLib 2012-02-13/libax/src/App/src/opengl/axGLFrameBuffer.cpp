#include <ax/App/opengl/axGLFrameBuffer.h>

axGLFrameBuffer::axGLFrameBuffer() {
	_id = 0;
}

axGLFrameBuffer::~axGLFrameBuffer() {
	destroy();
}	

//-- color 
void axGLFrameBuffer::attachColor( axGLTexture &tex, unsigned index ) {
	glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + index, tex.target(), tex.getId(), 0 );
}

void axGLFrameBuffer::detachColor( axGLTexture &tex, unsigned index ) {
	glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + index , tex.target(), 0, 0 );
}

void	axGLFrameBuffer::attachColor	( axGLRenderBuffer& rbo, unsigned index ) {
	glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + index, GL_RENDERBUFFER, rbo.id() );
}

void	axGLFrameBuffer::detachColor	( axGLRenderBuffer& rbo, unsigned index ) {
	glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0 + index, GL_RENDERBUFFER, 0 );
}

//--- depth
void axGLFrameBuffer::attachDepth( axGLTexture &tex ) {
	glFramebufferTexture2D( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, tex.target(), tex.getId(), 0 );
}

void axGLFrameBuffer::detachDepth( axGLTexture &tex ) {
	glFramebufferTexture2D( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, tex.target(), 0, 0 );
}

void	axGLFrameBuffer::attachDepth	( axGLRenderBuffer& rbo ) {
	glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rbo.id() );
}

void	axGLFrameBuffer::detachDepth	( axGLRenderBuffer& rbo ) {
	glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, 0 );
}

GLuint axGLFrameBuffer::currentBindingId() {
	int n;
	glGet( GL_FRAMEBUFFER_BINDING, n );
	return (GLuint)n;
}

axStatus axGLFrameBuffer::create() {
#ifndef axUSE_OpenGL_ES
	if( !GLEW_EXT_framebuffer_object ) return axStatus::opengl_unsupported_extension;
#endif
	destroy();
	glGenFramebuffers(1, &_id);
	return 0;
}

void axGLFrameBuffer::destroy() {
	if( _id ) {
		glDeleteFramebuffers( 1, &_id );
		_id = 0;
	}
}

bool	axGLFrameBuffer::isReady() {
	GLenum s = checkStatus();
	return ( s == GL_FRAMEBUFFER_COMPLETE );
}

GLenum	axGLFrameBuffer::checkStatus() {
	return glCheckFramebufferStatus( GL_FRAMEBUFFER );
}

const char* axGLFrameBuffer::checkStatusString() {
	GLenum s = checkStatus();
	
	switch( s ) {
		case GL_FRAMEBUFFER_COMPLETE:						return "GL_FRAMEBUFFER_COMPLETE";
		case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:			return "GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT";
#ifdef axUSE_OpenGL_ES
		case GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS:			return "GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS";
#endif
		case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:	return "GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT";
		case GL_FRAMEBUFFER_UNSUPPORTED:					return "GL_FRAMEBUFFER_UNSUPPORTED";			
	}	
	return "unknown";	
}

void axGLFrameBuffer::bind() {
	glBindFramebuffer(GL_FRAMEBUFFER, _id );
}

void axGLFrameBuffer::unbind() {
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
}	

