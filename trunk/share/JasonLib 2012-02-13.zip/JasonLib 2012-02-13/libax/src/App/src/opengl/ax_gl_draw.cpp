#include <ax/App/opengl/ax_gl_draw.h>
	
void axGLDrawAxis( float scale ) {
	axVec3f v[6];
	v[0].set( 0,0,0 );
	v[1].set( scale,0,0 );
	v[2].set( 0,0,0 );
	v[3].set( 0,scale,0 );
	v[4].set( 0,0,0 );
	v[5].set( 0,0,scale );

	axColorRGBAf	col[6];
	col[0].set( 1,0,0,1 );
	col[1].set( 1,0,0,1 );
	col[2].set( 0,1,0,1 );
	col[3].set( 0,1,0,1 );
	col[4].set( 0,0,1,1 );
	col[5].set( 0,0,1,1 );

	//uint16_t idx[6] = { 0,1,0,2,0,3 };

	axScopeGLVertexPointer		vp( v );
	axScopeGLColorPointer		cp( col );
	glDrawArrays( GL_LINES, 0, 6 );
}

void axGLDrawGridXZ( int n, float dis ) {
	axVec3f vtx[4];
	axScopeGLVertexPointer	vp( vtx );	
	int i;
	for( i=-n; i<=n; i++ ) {		
		vtx[0].set(  i*dis,	0,   n*dis );
		vtx[1].set(  i*dis,	0,  -n*dis );
		vtx[2].set(  n*dis,	0,   i*dis );
		vtx[3].set( -n*dis,	0,   i*dis );
		
		glDrawArrays( GL_LINES, 0,4 );
	}
}

void axGLDrawGridXY( int n, float dis ) {
	axVec3f vtx[4];
	axScopeGLVertexPointer	vp( vtx );	
	int i;
	for( i=-n; i<=n; i++ ) {		
		vtx[0].set(  i*dis,	 n*dis, 0 );
		vtx[1].set(  i*dis,	-n*dis, 0 );
		vtx[2].set(  n*dis,	 i*dis, 0 );
		vtx[3].set( -n*dis,	 i*dis, 0 );
		
		glDrawArrays( GL_LINES, 0,4 );
	}
}

void axGLDrawPoint( const axVec3f &point ) {
	axScopeGLVertexPointer	vp( &point );
	glDrawArrays( GL_POINTS, 0, 1 );
}

void axGLDrawPoints( const axIArray< axVec3f > &point ) {
	axScopeGLVertexPointer	vp( point.ptr() );
	glDrawArrays( GL_POINTS, 0, (GLsizei) point.size() );
}

void axGLDrawLine( const axIArray< axVec3f > &v ) {
	axScopeGLVertexPointer	vp( v.ptr() );
	glDrawArrays( GL_LINE_LOOP, 0, (GLsizei) v.size() );
}

void axGLDraw( const axPlane3f &p, float scale ) {
	axGLDrawLine( p.p, p.p + p.n * scale );

	axVec3f c[4];
	const axVec3f &n = p.n;

	axVec3f	side;
	axVec3f	up;

	axVec3f	uy(0,1,0);
	axVec3f	ux(1,0,0);

	if( ax_abs( ux.dot( n ) ) < ax_abs( uy.dot( n ) ) ) {
		side = ( ux ^ n ).normal();
	}else{
		side = ( uy ^ n ).normal();
	}

	up = ( side ^ n ).normal();
		
	c[0] = p.p + up   * scale;
	c[1] = p.p + side * scale;
	c[2] = p.p - up   * scale;
	c[3] = p.p - side * scale;


	axScopeGLVertexPointer	vp( c );
	//draw outline
	glDrawArrays( GL_LINE_LOOP, 0,4 );
	//draw cross on the plane
	uint8_t idx[] = { 0,2,1,3 };
	glDrawElements( GL_LINES, 4, idx );
}

void axGLDraw( const axFrustum3f &fr ) {
	axScopeGLVertexPointer	vp( fr.pt );
	glDrawArrays( GL_LINE_LOOP, 0, 4 );
	glDrawArrays( GL_LINE_LOOP, 4, 4 );
	
	uint8_t idx[] = {
		0,4,	
		1,5,
		2,6,
		3,7,
	};	
	glDrawElements( GL_LINES, 8, idx );
}


void axGLDrawLine( const axVec3f &p0, const axVec3f &p1 ) {
	axVec3f vtx[2] = { p0, p1 };
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINES, 0, 2 );
}

void axGLDrawLine( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2 ) {
	axVec3f vtx[3] = { p0, p1, p2 };
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINE_LOOP, 0, 3 );
}

void axGLDrawLine( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2, const axVec3f &p3 ) {
	axVec3f vtx[4] = { p0, p1, p2, p3 };
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINE_LOOP, 0, 4 );
}

void axGLDrawFill( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2 ) {
	axVec3f vtx[3] = { p0, p1, p2 };
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_TRIANGLE_FAN , 0, 3 );
}

void axGLDrawFill( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2, const axVec3f &p3 ) {
	axVec3f vtx[4] = { p0, p1, p2, p3 };
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_TRIANGLE_FAN , 0, 4 );
}


void axGLDrawFill( const axIArray< axVec3f > & vtx ) {
	axScopeGLVertexPointer	vp( vtx.ptr() );
	glDrawArrays( GL_TRIANGLE_FAN , 0, (GLsizei)vtx.size() );
}


void axGLDraw( const axRay3f &r, float scale ) {
	axVec3f vtx[2] = { r.o, r.o + r.v * scale };	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINES, 0, 2 );
}

void axGLDraw( const axRect2f &rc ) {
	axVec2f vtx[4];
	vtx[0].set( rc.x,		rc.y );
	vtx[1].set( rc.right(), rc.y );
	vtx[2].set( rc.right(), rc.bottom() );
	vtx[3].set( rc.x,		rc.bottom() );
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_TRIANGLE_FAN, 0, 4 );
}

void axGLDrawLine( const axRect2f &rc ) {
	axVec2f vtx[4];
	vtx[0].set( rc.x,		rc.y );
	vtx[1].set( rc.right(), rc.y );
	vtx[2].set( rc.right(), rc.bottom() );
	vtx[3].set( rc.x,		rc.bottom() );
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINE_LOOP, 0, 4 );
}

void axGLDraw( const axBBox3f &box ) {
	const axVec3f	&a = box.minPoint();
	const axVec3f	&b = box.maxPoint();

	axVec3f	v[8];
	//top 
	v[0].set( a.x, a.y, a.z );
	v[1].set( a.x, a.y, b.z );
	v[2].set( b.x, a.y, b.z );
	v[3].set( b.x, a.y, a.z );
	//bottom
	v[4].set( a.x, b.y, a.z );
	v[5].set( a.x, b.y, b.z );
	v[6].set( b.x, b.y, b.z );
	v[7].set( b.x, b.y, a.z );

	uint8_t	index[] = { 
		0,1,2,3, //top
		0,3,7,4, //front
		1,2,6,5, //back
		0,1,5,4, //left
		3,2,6,7, //right
		4,5,6,7, //bottom
	};

	axScopeGLVertexPointer	vp( v );
	int i;
	for( i=0; i<6; i++ )
		glDrawElements( GL_TRIANGLE_FAN, 4, index + i*4 );
}

void axGLDrawLine( const axBBox3f &box ) {
	const axVec3f	&a = box.minPoint();
	const axVec3f	&b = box.maxPoint();

	axVec3f	v[8];
	//top 
	v[0].set( a.x, a.y, a.z );
	v[1].set( a.x, a.y, b.z );
	v[2].set( b.x, a.y, b.z );
	v[3].set( b.x, a.y, a.z );
	//bottom
	v[4].set( a.x, b.y, a.z );
	v[5].set( a.x, b.y, b.z );
	v[6].set( b.x, b.y, b.z );
	v[7].set( b.x, b.y, a.z );

	uint8_t	index[] = { 
		0,1,2,3, //top
		0,3,7,4, //front
		1,2,6,5, //back
		0,1,5,4, //left
		3,2,6,7, //right
		4,5,6,7, //bottom
	};

	axScopeGLVertexPointer	vp( v );
	unsigned i;
	for( i=0; i<6; i++ )
		glDrawElements( GL_LINE_LOOP, 4, index +(i*4) );
}

void axGLDrawArrow( float length, float arrow_length, float arrow_width ) {
	float w = arrow_width / 2;
	float p = length - arrow_length;

	axVec3f vtx[6];
	//line
	vtx[0].set( 0,0,0 );		
	vtx[1].set( 0,0,p );
	//arrow
	vtx[2].set( 0, w, p );
	vtx[3].set( 0, 0, length );
	vtx[4].set( 0,-w, p );	
	vtx[5].set( 0,0,p );
	
	axScopeGLVertexPointer	vp( vtx );
	glDrawArrays( GL_LINE_STRIP, 0, 6 );
}

void axGLDrawGradient( const axRect2f &rc, 
					 const axColorRGBAf &color0,  const axColorRGBAf &color1,
					 const axColorRGBAf &color2,  const axColorRGBAf &color3 ) 
{
	axVec2f vtx[4];
	vtx[0].set( rc.x,		rc.y );
	vtx[1].set( rc.right(), rc.y );
	vtx[2].set( rc.right(), rc.bottom() );
	vtx[3].set( rc.x,		rc.bottom() );
	
	axColorRGBAf c[4] = { color0,color1,color2,color3 };

	axScopeGLColorPointer	cp( c );
	axScopeGLVertexPointer vp( vtx );
	glDrawArrays( GL_TRIANGLE_FAN, 0, 4 );
}
