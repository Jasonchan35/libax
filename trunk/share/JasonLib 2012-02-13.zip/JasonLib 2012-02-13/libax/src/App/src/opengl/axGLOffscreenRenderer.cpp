/*  Filename = axGLOffscreenRenderer.cpp / Project = awecore
 *  Created by Jason on 21/07/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#include <ax/App/opengl/axGLOffscreenRenderer.h>

axGLOffscreenRenderer::axGLOffscreenRenderer() {
	_binding = false;
	_created = false;
	_w = _h = 0;
}

axGLOffscreenRenderer::~axGLOffscreenRenderer() {
	destroy();
}	

axStatus	axGLOffscreenRenderer::create( int width, int height ) {
	destroy();

	axStatus st;

	_w = width;
	_h = height;
		
	st = color_buf.createRGBA ( _w, _h );		if( !st ) return st;
	st = depth_buf.createDepth( _w, _h );		if( !st ) return st;
	st = fbo.create();							if( !st ) return st;
	bind();
			
	fbo.attachColor( color_buf );
	fbo.attachDepth( depth_buf );	
	
	if( ! fbo.isReady() ) {
		unbind();
		return -2;
	}
	
	glViewport( 0,0,_w,_h );
	_created = true;
	return 0;
}
	
void	axGLOffscreenRenderer::destroy() {
	if( !_created ) return;
	_created = false;
	bind();

	if( fbo.isValid() ) {
		if( color_buf.isValid() ) fbo.detachColor( color_buf );
		if( depth_buf.isValid() ) fbo.detachDepth( depth_buf );
	}

	if( color_buf.isValid() ) color_buf.destroy();
	if( depth_buf.isValid() ) depth_buf.destroy();
	if( fbo.isValid() ) fbo.destroy();

	unbind();
}

void	axGLOffscreenRenderer::bind() {
	if( !_created ) return;
	if( _binding ) return;
	_binding = true;
	
	glGetViewport( _old_viewport );	
	_old_fbo = axGLFrameBuffer::currentBindingId();
	fbo.bind();	
	
	glViewport( 0,0,_w,_h );
}
	
void	axGLOffscreenRenderer::unbind() {
	if( !_created ) return;
	if( !_binding ) return;
	_binding = false;
	
	fbo.unbind();
	glBindFramebuffer( GL_FRAMEBUFFER, _old_fbo );
	glViewport( _old_viewport );
}


