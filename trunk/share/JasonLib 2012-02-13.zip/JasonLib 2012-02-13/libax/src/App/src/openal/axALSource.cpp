#include <ax/App/openal/axALSource.h>

#ifdef axUSE_OpenAL

axALSource::axALSource()  { _id = 0; }
axALSource::~axALSource() { destroy(); }

void axALSource::destroy() {

	if( _id ) {
		alDeleteSources( 1, &_id );
		_id = 0;
	}
}

axStatus axALSource::create() {
	if( !_id ) {
		alGenSources( 1, &_id );
	}
	return 0;
}

axStatus axALSource::bind( axALBuffer &buf ) {
	alSourcei( _id, AL_BUFFER, buf._id );
	print_openal_if_error( __FUNCTION__ );
	return 0;
}

axStatus axALSource::query( axALBuffer &buf ) {
	
	alSourceQueueBuffers( _id, 1, &buf._id );
	print_openal_if_error( __FUNCTION__ );

	return 0;
}

axStatus axALSource::unquery( axALBuffer &buf ) {
	alSourceUnqueueBuffers( _id, 1, &buf._id );
	return print_openal_if_error( __FUNCTION__ );
}

ALint axALSource::state() {
	ALint st = AL_SOURCE_STATE;
	if( _id ) { alGetSourcei( _id, AL_SOURCE_STATE, &st); }
	return st;
}

void axALSource::play()			{ if( _id ) alSourcePlay( _id ); }
void axALSource::keep_play()	{ if( !is_playing() ) play(); }

void axALSource::stop()			{ if( _id ) alSourceStop( _id ); }
bool axALSource::is_playing()	{ return AL_PLAYING == state(); }

int axALSource::processed_buf() {
	int v;
	alGetSourcei( _id, AL_BUFFERS_PROCESSED, &v );
	return v;
}
	
bool axALSource::is_created() { return ( _id != 0); }
	
#endif // axUSE_OpenAL
