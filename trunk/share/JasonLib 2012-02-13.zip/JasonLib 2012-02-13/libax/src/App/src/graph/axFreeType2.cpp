#include "axFreeType2.h"

#ifdef axUSE_FreeType2

axFreeType2::axFreeType2() {
	FT_Init_FreeType( &lib_ );
//	ax_log("init FreeType");
}

axFreeType2::~axFreeType2() {
	if( lib_ ) {
		FT_Done_FreeType( lib_ );
		lib_ = NULL;
	}
}

axFreeType2&	axFreeType2::getInstance() {
	static	axFreeType2 t;
	return t;
}

axStatus	axFreeType2_Face::create( const wchar_t* font_file, float size, bool bold, bool italic ) {
	close();
	axStatus	st;
	axFreeType2	&ft = axFreeType2::getInstance();

	axStringA_< axFileSystem::kPathMax >	font_file_a;
	st = font_file_a.set( font_file );		if( !st ) return st;

	FT_Error error;
	error = FT_New_Face( ft.lib(), font_file_a.c_str(), 0, &face_ );
	if( error ) {
		ax_log("FT_NewFace {?} error {?}", font_file_a, error );
		return -1;
	}

	FT_UInt	pixel_size = (FT_UInt) size;
	FT_Set_Pixel_Sizes( face_, pixel_size, pixel_size );
	return 0;
}

void axFreeType2_Face::close() {
	if( face_ ) {
		FT_Done_Face( face_ );
		face_ = NULL;
	}
}

axStatus axFreeType2_Face::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axFont::Align align ) {
	if( ! face_ ) return -1;
	axStatus st;
	st = img.create( axColor::t_Ab, width, height );	if( !st ) return st;
	img.setAllByteZero();

	FT_Face			face = face_;
	FT_GlyphSlot	slot = face->glyph;
	FT_UInt			glyph_index;
	FT_Bool			use_kerning;
	FT_UInt			previous = 0;
	int				pen_x = 0;
	int				pen_y = 0;
	int				n;
	FT_Error		error;
	int				num_chars = ax_strlen( text );
	axColorAb*		p;

	use_kerning = FT_HAS_KERNING( face );
	previous    = 0;

	bool		new_line = true;
	int			font_height = (face->size->metrics.ascender >> 6) - (face->size->metrics.descender >> 6);
	int			ascenter    = (face->size->metrics.ascender >> 6);
	FT_Vector	delta;

	int totalWidth, totalHeight;
	st = getTextRect( totalWidth, totalHeight, text );		if( !st ) return st;

	if( align.isBottom() ) {
		pen_y = height - totalHeight;
	}else if( align.isCenterY() ) {
		pen_y = (height - totalHeight) / 2;
	}

	for ( n=0; n<num_chars; n++ ) {
		if( new_line ) { //count pixel in this line
			new_line = false;
			pen_x = 0;
			if( ! align.isLeft() ) {
				FT_UInt		previous2 = 0;
				for( int q=0; ; q++ ) {
					wchar_t text_ch = text[n+q];
					if( text_ch == 0 ) break;
					if( text_ch == '\n' ) break;

					glyph_index = FT_Get_Char_Index( face, text_ch );

					if ( use_kerning && previous2 && glyph_index ) {
						FT_Get_Kerning( face, previous, glyph_index, FT_KERNING_DEFAULT, &delta );
						pen_x += delta.x >> 6;
					}
					error = FT_Load_Glyph( face, glyph_index, FT_LOAD_RENDER );
					if ( error ) { ax_log("FT_Load_Glyph error {?}", error ); continue; }
					pen_x += slot->advance.x >> 6;
					previous2 = glyph_index;
				}
				if( align.isRight() ) {
					pen_x = width - pen_x;
				}else if( align.isCenterX() ) {
					pen_x = (width - pen_x) / 2;
				}
				if( pen_x < 0 ) pen_x = 0;
			}
		}

		glyph_index = FT_Get_Char_Index( face, text[n] );
		if ( use_kerning && previous && glyph_index ) {
			FT_Get_Kerning( face, previous, glyph_index, FT_KERNING_DEFAULT, &delta );
			pen_x += delta.x >> 6;
		}
		error = FT_Load_Glyph( face, glyph_index, FT_LOAD_RENDER );
		if ( error ) { ax_log("FT_Load_Glyph error {?}", error ); continue; }

		if( text[n] == '\n' ) {
			pen_y += font_height;
			new_line = true;
			continue;
		}

		int x,y;
		for (int row = 0; row < slot->bitmap.rows; ++row){
			y = row + pen_y + ascenter - slot->bitmap_top;
			if( y < 0 ) continue;
			if( y >= height ) break;

			img.pixelPointer( p, 0, y );

			for (int pixel = 0; pixel < slot->bitmap.width; ++pixel){
				x = pen_x + pixel + slot->bitmap_left;
				if( x < 0 ) continue;
				if( x >= width ) break;
				p[x].a = slot->bitmap.buffer[pixel + row * slot->bitmap.pitch];
			}
		}	

		pen_x += slot->advance.x >> 6;
		previous = glyph_index;
	}


	return 0;
}

axStatus	axFreeType2_Face::getTextRect( int& outWidth, int& outHeight, const wchar_t* text ) {
	if( ! face_ ) return -1;

	outWidth  = 0;
	outHeight = 0;

	FT_Face			face = face_;
	FT_GlyphSlot	slot = face->glyph;
	FT_UInt			glyph_index;
	FT_Bool			use_kerning;
	FT_UInt			previous;
	int				pen_x = 0;
	int				pen_y = 0;
	int				n;
	FT_Error		error;

	int				num_chars = ax_strlen( text );
	int				font_height = (face->size->metrics.ascender >> 6) - (face->size->metrics.descender >> 6);

	use_kerning = FT_HAS_KERNING( face );
	previous    = 0;

	for ( n = 0; n < num_chars; n++ ) {
		glyph_index = FT_Get_Char_Index( face, text[n] );

		if ( use_kerning && previous && glyph_index ) {
			FT_Vector  delta;
			FT_Get_Kerning( face, previous, glyph_index, FT_KERNING_DEFAULT, &delta );
			pen_x += delta.x >> 6;
		}

		error = FT_Load_Glyph( face, glyph_index, FT_LOAD_TARGET_NORMAL );
		if ( error ) {
			ax_log("FT_Load_Glyph error {?}", error );
			continue;  //ignore errors
		}

		int cw = slot->advance.x >> 6;

		if( text[n] == '\n' ) {
			outWidth = ax_max( outWidth, pen_x );
			pen_x = 0;
			pen_y += font_height;
		}
		pen_x += cw;
		previous = glyph_index;
	}

	outWidth  = ax_max( outWidth, pen_x );
	outHeight = pen_y + font_height;

//	ax_log( "getTextRect {?} {?} ({?},{?})", text, num_chars, outWidth, outHeight );
	return 0;
}

#endif //axUSE_FreeType2

