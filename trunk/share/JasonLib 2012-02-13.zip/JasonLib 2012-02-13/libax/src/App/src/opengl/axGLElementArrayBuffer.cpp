#include <ax/App/opengl/axGLElementArrayBuffer.h>

axGLElementArrayBuffer::axGLElementArrayBuffer() { 
	reset_();
}

axGLElementArrayBuffer::~axGLElementArrayBuffer() {
	destroy();
}

void axGLElementArrayBuffer::reset_() {
	id_ = 0; 
	target_ = 0; 
	type_ = 0; 
	elementSize_ = 0; 
}

void axGLElementArrayBuffer::destroy() {
	if( id_ ) { 
		glDeleteBuffers(1, &id_); 
		id_ = 0; 
	}
}

void axGLElementArrayBuffer::createId_( GLenum target, GLenum type, GLint elementSize ) { 
	destroy();
	glGenBuffers( 1, &id_ ); 
	
	target_ = target;
	type_   = type;
	elementSize_ = elementSize;
}

axStatus axGLElementArrayBuffer::create	( const axIArray<uint16_t> &data, GLenum usage ) {
	createId_( GL_ELEMENT_ARRAY_BUFFER, GL_UNSIGNED_SHORT, 1 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}

#ifndef axUSE_OpenGL_ES
axStatus axGLElementArrayBuffer::create	( const axIArray<uint32_t> &data, GLenum usage ) {
	createId_( GL_ELEMENT_ARRAY_BUFFER, GL_UNSIGNED_INT, 1 );
	bind();
	glBufferData( target_, data.byteSize(), data.ptr(), usage );
	unbind();
	return 0;
}
#endif

axStatus axGLElementArrayBuffer::onTake( axGLElementArrayBuffer &src ) {
	if( this == &src ) { assert( false ); return 0; }
	destroy();
	id_			 = src.id_;
	target_		 = src.target_;
	type_		 = src.type_;
	elementSize_ = src.elementSize_;
	src.reset_();
	return 0;
}


