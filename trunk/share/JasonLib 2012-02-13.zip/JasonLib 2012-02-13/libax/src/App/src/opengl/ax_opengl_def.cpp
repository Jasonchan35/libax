#include <ax/App/opengl/ax_opengl_def.h>

#ifdef __glew_h__
        #include "ax_glew_c.h"
#endif

bool ax_glTransformVertex( axVec2f & out, const axVec3f &v, const axMatrix4f & modelview, const axMatrix4f &projection, const axRect2f & viewport ) {
	axVec4f p = axVec4f( v, 1 ) * modelview * projection;
	if( p.w <= 0 ) return false;
	axVec3f q = p.to_Vec3();
	out.x = (1+q.x) * viewport.w / 2;
	out.y = (1-q.y) * viewport.h / 2;
	return true;
}

void ax_gl2DMode( bool upside_down ) {
	axRect2f rc;
	glGetViewport( rc );

	glMatrixMode( GL_PROJECTION );
		axMatrix4f m;
		if( upside_down ) {
			m.setOrtho( 0, rc.w, rc.h, 0, -1000, 1000 );
		}else{
			m.setOrtho( 0, rc.w, 0, rc.h, -1000, 1000 );
		}	
		glLoadMatrix( m );

	glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();
	
	glDisable( GL_DEPTH_TEST );	
}	

void ax_gl3DMode( float fov_y_in_deg, float zNear, float zFar ) {
	axRect2f rc;
	glGetViewport( rc );

	axMatrix4f	proj, model_view;

	float aspect = 1;
	if( rc.h ) aspect = rc.w / rc.h;

	glMatrixMode( GL_PROJECTION );
	proj.setPerspective( ax_deg_to_rad( fov_y_in_deg ), aspect, zNear, zFar );
	glLoadMatrix( proj );

	glMatrixMode( GL_MODELVIEW );
	
	model_view.setLookAt( axVec3f( 10, 10, 10), axVec3f(0,0,0), axVec3f(0,1,0) );
	glLoadMatrix( model_view );
	
	glEnable( GL_DEPTH_TEST );
}

