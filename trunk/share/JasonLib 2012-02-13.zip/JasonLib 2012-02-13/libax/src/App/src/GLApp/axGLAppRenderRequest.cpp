#include <ax/App/GLApp/axGLAppRenderRequest.h>

axGLAppRenderRequest :: axGLAppRenderRequest() {
	needComputeInverseMatrix_ = true;
	frameTime_		= 0;
}

axGLAppRenderRequest::UI::UI() {
	showLayout = false;
}

void	axGLAppRenderRequest :: setMatrix( const axMatrix4f &projection, const axMatrix4f &modelView ) {
	needComputeInverseMatrix_ = true;
	projectionMatrix_ = projection;
	modelViewMatrix_  = modelView;
}

axRay3f	axGLAppRenderRequest :: getRay( const axVec2f &pointFromScreen ) {
	axRay3f	ray;
	ray.unprojectFromInverseMatrix( pointFromScreen, region_, inverseProjectionMatrix(), inverseModelViewMatrix() );
	return ray;
}

axGLAppRenderRequest::Statistic::Statistic() {
	clear();
}

void axGLAppRenderRequest::Statistic::clear() {
	triangles = 0;
}

void	axGLAppRenderRequest ::computeInverseMatrix() {
	if( ! needComputeInverseMatrix_ ) return;
	needComputeInverseMatrix_ = false;
	inverseProjectionMatrix_ = projectionMatrix_.inverse();
	inverseModelViewMatrix_  = modelViewMatrix_.inverse();
}


