#include <ax/core/system/axSystem.h>
#include <ax/core/system/axAndroid.h>
#include <ax/App/GLApp/axGLAppCommon.h>

const char* axGLAppCommon::_eventName( int event ) {
	switch( event ) {
		case kEventNull:	return "Null";
		case kEventDown:	return "Down";
		case kEventUp:		return "Up";
		case kEventMove:	return "Move";
		case kEventCancel:	return "Cancel";
		case kEventNoChange:return "NoChange";
	}
	return "";
}


#ifdef axOS_MacOSX

//static		
double axGLAppCommon::systemEventTime() {
	return axSystem::uptime();
}
#endif//axOS_MacOSX


#ifdef axOS_iOS

//static		
double axGLAppCommon::systemEventTime() {
	return axSystem::uptime();
}
#endif//axOS_iOS

#ifdef axOS_Android

double axGLAppCommon::systemEventTime() {
	return axSystem::uptime();
}

#endif //axOS_Android

#ifdef axOS_WIN

double axGLAppCommon::systemEventTime() {
	return GetTickCount() / 1000.0;
}

#endif//axOS_WIN
