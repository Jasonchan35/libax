#include <ax/App/opengl/axGLContext.h>

//------------------- all platform ---------------------------

axGLContext* & axGLContext::currentPtr_() {
	static axGLContext* p = NULL;
	return p;
}

axGLContext*	axGLContext::getCurrent() {
	return currentPtr_();
}

void axGLContext::_setAsCurrent() {
	currentPtr_() = this; 
}

axStatus	axGLContext::_createGL( axGLContext* share_with ) {
	axStatus	st;

	if( share_with ) {
		resMgr_.ref( share_with->resMgr_ );
	}else{
		st = resMgr_.newObject();	if( !st ) return st;
	}

#ifdef  __glew_h__
	glewInit();
	if( GLEW_EXT_rescale_normal ) {
		glEnable( GL_RESCALE_NORMAL );
	}else{
		glEnable( GL_NORMALIZE );
	}
#endif //__glew_h__



	extension_GL_APPLE_texture_2D_limited_npot_ = isSupportExtension( "GL_APPLE_texture_2D_limited_npot" );
	extension_GL_ARB_texture_non_power_of_two_  = isSupportExtension( "GL_ARB_texture_non_power_of_two" );
	
	glGet( GL_MAX_TEXTURE_SIZE,  maxTextureSize_  );
	glGet( GL_MAX_TEXTURE_UNITS, maxTextureUnits_ );
	
	glDisable( GL_DEPTH_TEST );
	glEnable( GL_BLEND );
	glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );
	return 0;
}


bool axGLContext::isSupportExtension( const char* ext_name ) {
	const char* ext = (const char*) glGetString(GL_EXTENSIONS);
	
	const char* f = ax_strstr( ext, ext_name );
	if( !f ) return false;
	if( f == ext || *(f-1) ==' ' ) { //seperated by ' '
		return true;
	}else{
		return false;
	}
}

axStatus    axGLContext::printInfo() {
    axStatus    st;
    axStringA_<1024> str;
    st = getInfoString( str );      if( !st ) return st;
    ax_print( str );
    return 0;
}

axStatus    axGLContext::getInfoString( axIStringA &str ) {
    axStatus    st;
	st = str.set( "=== OpenGL info ===\n" );             if( !st ) return st;
	st = str.appendFormat( "Vender  = {?}\n", (const char*)glGetString( GL_VENDOR ) );     if( !st ) return st;
	st = str.appendFormat( "Render  = {?}\n", (const char*)glGetString( GL_RENDERER ) );   if( !st ) return st;
	st = str.appendFormat( "Version = {?}\n", (const char*)glGetString( GL_VERSION ) );    if( !st ) return st;

#ifndef axUSE_OpenGL_ES
	st = str.appendFormat( "Shading Language Version = {?}\n", (const char*)glGetString( GL_SHADING_LANGUAGE_VERSION ) );  if( !st ) return st;
#endif
	
	st = str.appendFormat( "-- extensions --\n" );

	int tmp_int;
#define axLOG_INT( x )  \
	glGet( x, tmp_int ); \
	st = str.appendFormat( #x " = {?}\n", tmp_int );  if( !st ) return st;
	
	axLOG_INT( GL_MAX_PROJECTION_STACK_DEPTH );
	axLOG_INT( GL_MAX_MODELVIEW_STACK_DEPTH );

	axLOG_INT( GL_MAX_LIGHTS );

	axLOG_INT( GL_MAX_TEXTURE_SIZE );
	axLOG_INT( GL_MAX_TEXTURE_UNITS );
	axLOG_INT( GL_MAX_TEXTURE_STACK_DEPTH );

	axLOG_INT( GL_MAX_CLIP_PLANES );
#undef axLOG_INT

	axStringA_<1024> ext_str;
	ext_str.set( (const char*) glGetString(GL_EXTENSIONS) );
	ext_str.replaceChar( ' ', '\n' );
	st = str.appendFormat( "\n=== OpenGL Extensions ===\n{?}=== End of OpenGL info ===\n", ext_str );       if( !st ) return st;
    return 0;
}
	

void axGLContext::getMemoryInfo( MemInfo &info ) {
	info.avail = 0;
	info.total = 0;
	info.vir_avail = 0;
	info.vir_total = 0;
    
/* nVidia opengl ext 'GL_NVX_gpu_memory_info'
#define GL_GPU_MEM_INFO_TOTAL_AVAILABLE_MEM_NVX 0x9048
#define GL_GPU_MEM_INFO_CURRENT_AVAILABLE_MEM_NVX 0x9049

GLint total_mem_kb = 0:
glGetIntegerv(GL_GPU_MEM_INFO_TOTAL_AVAILABLE_MEM_NVX,
              &total_mem_kb);

GLint cur_avail_mem_kb = 0:
glGetIntegerv(GL_GPU_MEM_INFO_CURRENT_AVAILABLE_MEM_NVX,
              &cur_avail_mem_kb);

*/

/* ATI opengl ext  , ' WGL_AMD_gpu_association'
UINT n = wglGetGPUIDsAMD(0, 0);
UINT *ids = new UINT[n];
size_t total_mem_mb = 0;
wglGetGPUIDsAMD(n, ids);
wglGetGPUInfoAMD(ids[0],  WGL_GPU_RAM_AMD,  GL_UNSIGNED_INT,  sizeof(size_t),  &total_mem_mb);

*/

// 'GL_ATI_meminfo'
	#define GL_VBO_FREE_MEMORY_ATI            0x87FB
	#define GL_TEXTURE_FREE_MEMORY_ATI        0x87FC
	#define GL_RENDERBUFFER_FREE_MEMORY_ATI   0x87FD

	GLint param[4];
	glGetIntegerv( GL_TEXTURE_FREE_MEMORY_ATI, param );

	info.total		= param[0];
	info.avail		= param[1];
	info.vir_total	= param[2];
	info.vir_avail	= param[3];
}

axGLContext::axGLContext() {
	_os_ctor();
}

axGLContext::~axGLContext() {
	destroy();
}

#if 0
#pragma mark ================= MS Win ====================
#endif
#ifdef axOS_WIN

void axGLContext::_os_ctor() {
	win_ = NULL;
	dc_ = NULL;
	rc_ = NULL;
}

void axGLContext::destroy() {
	wglMakeCurrent( NULL, NULL );
	if( rc_ ) { wglDeleteContext( rc_ ); rc_=NULL; }
	if( dc_ ) { ReleaseDC( win_, dc_ );  dc_=NULL; }
}

void axGLContext::swapBuffers()		{ 
	::SwapBuffers( dc_ );	
}

void axGLContext::makeCurrent()		{ 
	::wglMakeCurrent ( dc_, rc_ ); 
	_setAsCurrent();
}

axStatus axGLContext::create( HWND win, axGLContext* share_with ) {
	axStatus	st;
	destroy();
	win_ = win;

	PIXELFORMATDESCRIPTOR pfd;
	ZeroMemory( &pfd, sizeof( pfd ) );
	pfd.nSize = sizeof( pfd );
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL
				| PFD_GENERIC_ACCELERATED | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 8;
	pfd.cDepthBits = 16;
	pfd.cAlphaBits = 8;
	pfd.iLayerType = PFD_MAIN_PLANE;

	dc_ = GetDC( win_ );
	int iFormat = ChoosePixelFormat( dc_, &pfd );
	SetPixelFormat( dc_, iFormat, &pfd );

	rc_ = wglCreateContext(dc_);
	makeCurrent();

	if( share_with ) {
		if( ! wglShareLists( share_with->rc_, rc_ ) ) {
			return -1;
		}
	}
	st = _createGL( share_with );		if( !st ) return st;
	
//	SelectObject ( dc_, GetStockObject (SYSTEM_FIXED_FONT) );
//	wglUseFontBitmaps ( dc_, 0, 255, 0 );
	
	return 0;
}

#if 0
#pragma mark ================= iOS ====================
#endif
#elif axOS_iOS

void axGLContext::_os_ctor() {
	ctx_ = NULL;
    viewRenderbuffer_  = 0;
	viewFramebuffer_   = 0;
    depthRenderbuffer_ = 0;	
}

axStatus axGLContext::create( UIView* view, axGLContext* share_with ) {
	axStatus st;
	view_ = view;
	destroy();
	
	unsigned major, minor;
	EAGLGetVersion( &major, &minor );
	ax_log( "OpenGL ES version({?},{?})", major, minor );
	
	if( !view ) return -1;
	CAEAGLLayer *eaglLayer = (CAEAGLLayer *)view.layer;
	
	eaglLayer.opaque = YES;
	eaglLayer.drawableProperties = [NSDictionary dictionaryWithObjectsAndKeys:
                                        [NSNumber numberWithBool:NO], 
										kEAGLDrawablePropertyRetainedBacking, 
										kEAGLColorFormatRGBA8, 
										kEAGLDrawablePropertyColorFormat, nil];
	
	ctx_ = [ [EAGLContext alloc] initWithAPI: kEAGLRenderingAPIOpenGLES1 ];
	if( !ctx_ ) return -1;

    if( share_with ) {
        ax_log("Does not support share with OpenGL Context");
        assert(false);
        return -1;
    }
    
	makeCurrent();
	st = createBuffers();				if( !st ) return st;
	st = _createGL( share_with );		if( !st ) return st;
	return 0;
}

	
axStatus axGLContext::createBuffers() {
	if( !ctx_ ) return 0;

	destroyBuffers();

	GLint backingWidth;
    GLint backingHeight;

    glGenFramebuffersOES(1, &viewFramebuffer_);
    glGenRenderbuffersOES(1, &viewRenderbuffer_);
    
    glBindFramebufferOES(GL_FRAMEBUFFER_OES, viewFramebuffer_);
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer_);
    [ctx_ renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:(CAEAGLLayer*)view_.layer];
    glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, viewRenderbuffer_);
    
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES,  &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);

	if( backingWidth == 0 || backingHeight == 0 ) return 0;

    bool depth_buffer = true;
    if (depth_buffer) {
        glGenRenderbuffersOES(1, &depthRenderbuffer_);
        glBindRenderbufferOES(GL_RENDERBUFFER_OES, depthRenderbuffer_);
        glRenderbufferStorageOES(GL_RENDERBUFFER_OES, GL_DEPTH_COMPONENT16_OES, backingWidth, backingHeight);
        glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER_OES, depthRenderbuffer_);
    }
    
    if(glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES) {
        NSLog(@"failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return -2;
    }	
	
	glViewport( 0, 0, backingWidth, backingHeight );
	
	NSLog(@"backingWidth %d backingHeight %d", backingWidth, backingHeight );
		  
	
	return 0;
}

void axGLContext::swapBuffers() {
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer_);
    [ctx_ presentRenderbuffer:GL_RENDERBUFFER_OES];
}

void axGLContext::destroyBuffers() {
	if( viewFramebuffer_ ) {
		glBindRenderbufferOES(GL_RENDERBUFFER_OES, viewRenderbuffer_);
		
		if( viewRenderbuffer_ ) {//detach
			glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER, 0 );
		}		
		if( depthRenderbuffer_ ) {//detach
			glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT_OES, GL_RENDERBUFFER, 0 );
		}
		
		glBindRenderbufferOES(GL_RENDERBUFFER_OES, 0 );
		
		glDeleteFramebuffersOES(1, &viewFramebuffer_);
		viewFramebuffer_ = 0;
	}
	
	if( viewRenderbuffer_ ) {
		glDeleteRenderbuffersOES(1, &viewRenderbuffer_);
		viewRenderbuffer_ = 0;
    }
	
    if(depthRenderbuffer_) {
        glDeleteRenderbuffersOES(1, &depthRenderbuffer_);
        depthRenderbuffer_ = 0;
    }
}

void axGLContext::destroy() {
	destroyBuffers();

	if( ctx_ ) {
		[ctx_ release];
		ctx_ = nil;
		[EAGLContext setCurrentContext:nil];
	}
}

void axGLContext::makeCurrent() {
	[EAGLContext setCurrentContext:ctx_];
	currentPtr_() = this; 
}



#if 0
#pragma mark ================= MacOSX ====================
#endif
#elif axOS_MacOSX
	
void axGLContext::_os_ctor() {
	ctx_ = nil;
	fmt_ = nil;
}

void axGLContext::swapBuffers()	{
	glFlush();
	[ctx_ flushBuffer];
}

void axGLContext::makeCurrent() {
	[ctx_ makeCurrentContext];
	currentPtr_() = this; 
}

void axGLContext::destroy() {
	[NSOpenGLContext clearCurrentContext];
	if ( ctx_ ) {
		[ctx_ release];
		ctx_ = nil;
	}
	if( fmt_ ) {
		[fmt_ release];
		fmt_ = nil;
	}
}

void axGLContext::setVerticalSync ( bool b ) {
	GLint swapInt = b ? 1 : 0;
	[ctx_ setValues:&swapInt forParameter:NSOpenGLCPSwapInterval];
}

axStatus axGLContext::create( axGLContext* share_with ) {
	destroy();
	axStatus	st;
		
	NSOpenGLPixelFormatAttribute attribs [] = {
		NSOpenGLPFADoubleBuffer,
		NSOpenGLPFADepthSize,   24,
		NSOpenGLPFAStencilSize,  8,
		0
	};
	
	fmt_ = [[NSOpenGLPixelFormat alloc] initWithAttributes: attribs];
	if( !fmt_ ) return -1;

	NSOpenGLContext* share = nil;
	if( share_with ) {
        share = share_with->ctx_;
        resMgr_.ref( share_with->resMgr_ );
    }else{
        st = resMgr_.newObject();     if( !st ) return st;
    }	
	ctx_ = [[NSOpenGLContext alloc] initWithFormat:fmt_ shareContext:share];
	if( !ctx_ ) return -1;
	

	
	makeCurrent();
	st = _createGL( share_with );		if( !st ) return st;

	return 0;
}


#if 0
#pragma mark ================= X11 ====================
#endif
#elif defined(axX11)

void axGLContext::_os_ctor() {
    ctx_ = NULL;
    display_ = NULL;
    window_ = 0;
}

void axGLContext::destroy() {
    if( ctx_ && display_ ) {
        glXDestroyContext( display_, ctx_ );
        display_ = NULL;
        ctx_ = NULL;
    }
}

void  axGLContext::makeCurrent()   { 
	::glXMakeCurrent( display_, window_, ctx_ ); 
	currentPtr_() = this; 
}
void  axGLContext::swapBuffers()		{ 
	::glXSwapBuffers( display_, window_ );	
}

axStatus axGLContext::create( Window win, Display *dis, axGLContext* share_with ) {
    destroy();
    display_ = dis;
    window_ = win;

    int attr[] = {  GLX_RGBA, GLX_DOUBLEBUFFER,
                    GLX_RED_SIZE,   8,
                    GLX_GREEN_SIZE, 8,
                    GLX_BLUE_SIZE,  8,
                    GLX_ALPHA_SIZE, 8,
                    0 /*end*/ };

    XVisualInfo *v = glXChooseVisual( display_, DefaultScreen(display_), attr );

    GLXContext sh = share_with ? share_with->ctx_ : NULL;
	ctx_ = glXCreateContext( display_, v, sh, 1);

    if( !ctx_ ) return -1;
	st = _createGL( share_with );		if( !st ) return st;
    return 0;
}

#if 0
#pragma mark ================= Android ====================
#endif

#elif axOS_Android

void axGLContext::_os_ctor() {
}

axStatus axGLContext::create( axGLContext* share_with ) {
	makeCurrent();
//	st = createBuffers();				if( !st ) return st;
	st = _createGL( share_with );		if( !st ) return st;
	return 0;
}

void axGLContext::destroy() {
}

void axGLContext::makeCurrent() {
	currentPtr_() = this; 
}

void axGLContext::swapBuffers() {
}

#endif //axOS_Android

