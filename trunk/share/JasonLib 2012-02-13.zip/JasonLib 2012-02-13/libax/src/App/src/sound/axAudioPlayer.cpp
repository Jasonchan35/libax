/*  Filename = axAudioPlayer.cpp / Project = libax
 *  Created by Tony on 25/07/2011.
 *  Copyright 2009 Awenix. All rights reserved. */


#include <ax/App/sound/axAudioPlayer.h>
#include <ax/base/string/ax_string.h>


#if 0
#pragma mark ================= iOS ====================
#endif

#ifdef axOS_iOS

//-----------------------------

@interface axAudioPlayer_Delegate : NSObject < AVAudioPlayerDelegate > {

	axAudioPlayer *p_;
}


@property (nonatomic, assign) axAudioPlayer *p_;

@end

@implementation axAudioPlayer_Delegate

@synthesize p_;

- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag {
	
	assert( p_ != NULL );
	
	p_->callbackFinshPlaying( flag );
	
}

- (void)audioPlayerBeginInterruption:(AVAudioPlayer *)player {
	assert( p_ != NULL );
	p_->callbackBeginInterruption();
}
 

- (void)audioPlayerEndInterruption:(AVAudioPlayer *)player withFlags:(NSUInteger)flags {
	assert( p_ != NULL );
	p_->callbackEndInterruption();
}

axAudioPlayer::axAudioPlayer() {
	player_ = NULL;
	delegate_ = nil;
}

axAudioPlayer::~axAudioPlayer() {
	close();
}

void axAudioPlayer::close() {
	
	if( player_ ) {
		[player_ release];
		player_ = NULL;
	}
	
	if( delegate_ ) {
		[delegate_ release];
		delegate_ = nil;
	}
}



axStatus axAudioPlayer::init( const char* file_path ) {
	close();
	
	NSURL *url = [NSURL fileURLWithPath: ax_toNSString( file_path ) ];

	NSError *err = NULL;
	
	player_ = [[AVAudioPlayer alloc] initWithContentsOfURL: url error: &err];
	if( err ) {
		player_ = NULL;
		return -1;
	}
	
	[player_ prepareToPlay];
	setVolume( 1.0f );
	setLoop( -1 );
	
	axAudioPlayer_Delegate *p = [[axAudioPlayer_Delegate alloc] init];
	if( !p ) return axStatus::not_enough_memory;
	p.p_ = this;
	delegate_ = p;
	 
	[player_ setDelegate: delegate_ ];
	
		
	return 0;
	
}



axStatus axAudioPlayer::play() {
	if( !player_ ) return axStatus::pointer_is_null;
	BOOL b = [player_ play];	
	
	if( !b ) return -1;
	return 0;
}

axStatus axAudioPlayer::playAtTime( float v ) {
	if( !player_ ) return axStatus::pointer_is_null;

	NSTimeInterval t = v;            // seconds
    NSTimeInterval curr = player_.deviceCurrentTime;
	
    BOOL b = [player_ playAtTime: curr + t];
	if( !b ) return -1;
	
	return 0;
}


void	 axAudioPlayer::pause() {
	if( !player_ ) return;
	[player_ pause];
}

void	 axAudioPlayer::stop() {
	if( !player_ ) return;
	[player_ stop];
}

void	axAudioPlayer::setVolume( float v ) {
	if( !player_ ) return;
	[player_ setVolume: v];
}

void	axAudioPlayer::setLoop( int v ) {
	if( !player_ ) return;
	if( v <= 0 ) { 
		[player_ setNumberOfLoops: -1 ];
	}else {
		[player_ setNumberOfLoops: v-1 ];
	}
}

float	axAudioPlayer::volume() {
	if( !player_ ) return 0;
	return [player_ volume];
}

bool	axAudioPlayer::is_playing() {
	if( !player_ ) return false;
	return [player_ isPlaying];
}

/*
void axAudioPlayer::callbackFinshPlaying( bool is_success ) {
	ax_log( "callbackFinshPlaying {?}", is_success );
}

void axAudioPlayer::callbackBeginInterruption() {
	ax_log( "callbackBeginInterruption" );
}

void axAudioPlayer::callbackEndInterruption() {
	ax_log( "callbackBeginInterruption" );
}


*/


@end  
 
#endif //axOS_iOS
