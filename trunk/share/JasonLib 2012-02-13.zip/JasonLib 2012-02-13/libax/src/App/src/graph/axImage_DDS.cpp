#include "axImage_DDS.h"

typedef struct DXTColBlock
{
	int16_t col0;
	int16_t col1;

	// no bit fields - use bytes
	int8_t row[4];
} DXTColBlock;

typedef struct DXTAlphaBlockExplicit
{
	int16_t row[4];
} DXTAlphaBlockExplicit;

typedef struct DXTAlphaBlock3BitLinear
{
	int8_t alpha0;
	int8_t alpha1;

	int8_t stuff[6];
} DXTAlphaBlock3BitLinear;


// Defines

//Those 4 were added on 20040516 to make
//the written dds files more standard compliant
#define DDS_CAPS				0x00000001L
#define DDS_HEIGHT				0x00000002L
#define DDS_WIDTH				0x00000004L
#define DDS_RGB					0x00000040L
#define DDS_PIXELFORMAT			0x00001000L
#define DDS_LUMINANCE			0x00020000L

#define DDS_ALPHAPIXELS			0x00000001L
#define DDS_ALPHA				0x00000002L
#define DDS_FOURCC				0x00000004L
#define DDS_PITCH				0x00000008L
#define DDS_COMPLEX				0x00000008L
#define DDS_TEXTURE				0x00001000L
#define DDS_MIPMAPCOUNT			0x00020000L
#define DDS_LINEARSIZE			0x00080000L
#define DDS_VOLUME				0x00200000L
#define DDS_MIPMAP				0x00400000L
#define DDS_DEPTH				0x00800000L

#define DDS_CUBEMAP				0x00000200L
#define DDS_CUBEMAP_POSITIVEX	0x00000400L
#define DDS_CUBEMAP_NEGATIVEX	0x00000800L
#define DDS_CUBEMAP_POSITIVEY	0x00001000L
#define DDS_CUBEMAP_NEGATIVEY	0x00002000L
#define DDS_CUBEMAP_POSITIVEZ	0x00004000L
#define DDS_CUBEMAP_NEGATIVEZ	0x00008000L

/*
 * FOURCC codes for DX compressed-texture pixel formats
 */
#define FOURCC_DXT1  (ax_char4('D','X','T','1'))
#define FOURCC_DXT2  (ax_char4('D','X','T','2'))
#define FOURCC_DXT3  (ax_char4('D','X','T','3'))
#define FOURCC_DXT4  (ax_char4('D','X','T','4'))
#define FOURCC_DXT5  (ax_char4('D','X','T','5'))

axStatus CompressToRXGB( axImage &img, axArray<uint16_t> &xgb, axByteArray &r ) {
	axStatus st;
	axSize		i, j;
	uint16_t	*Data;
	uint8_t		*Alpha;
	uint8_t		*img_head = (uint8_t*)img.pixelVoidPointer();

	st = xgb.resize( img.width() * img.height() );	if (!st) return st;
	st = r.resize  ( img.width() * img.height() );		if (!st) return st;

	//Alias pointers to be able to use copy'n'pasted code :)
	Data = xgb.ptr();
	Alpha = r.ptr();

	axSize bufferByteSize = img.bufferByteSize();
	
	switch ( img.type() ) {
		case axColor::t_RGBb:
			for (i = 0, j = 0; i < bufferByteSize; i += 3, j++) {
/*
				Alpha[j] = img_head[i];
				Data[j] = (img_head[i+1] >> 2) << 5;
				Data[j] |=  img_head[i+2] >> 3;
*/
				Data[j]  = (img_head[i  ] >> 3) << 11;
				Data[j] |= (img_head[i+1] >> 2) << 5;
				Data[j] |=  img_head[i+2] >> 3;
				Alpha[j] = 0xff;
			}
			break;

		case axColor::t_RGBAb:
			for (i = 0, j = 0; i < bufferByteSize; i += 4, j++) {
/*
				Alpha[j]  = img_head[i];
				Data[j] = (img_head[i+1] >> 2) << 5;
				Data[j] |=  img_head[i+2] >> 3;
*/
				Data[j]  = (img_head[i  ] >> 3) << 11;
				Data[j] |= (img_head[i+1] >> 2) << 5;
				Data[j] |=  img_head[i+2] >> 3;
				Alpha[j] = img_head[i+3];
			}
			break;
		default:
			return axStatus::Image_DDS_unsupported_color_type;
	}
	return 0;
}

// Assumed to be 16-bit (5:6:5).
void GetBlock( uint16_t *Block, uint16_t *Data, axImage &img, axSize XPos, axSize YPos ) {
    axSize x, y, i = 0, Offset = YPos * img.width() + XPos;

	for (y = 0; y < 4; y++) {
		for (x = 0; x < 4; x++) {
		    if ((int)x < img.width() && (int)y < img.height() )
				Block[i++] = Data[Offset + x];
			else
			    Block[i++] = Data[Offset];
		}
        Offset += img.width();
	}
}

void GetAlphaBlock( uint8_t *Block, uint8_t *Data, axImage &img, axSize XPos, axSize YPos ) {
	axSize x, y, i = 0, Offset = YPos * img.width() + XPos;

	for (y = 0; y < 4; y++) {
		for (x = 0; x < 4; x++) {
			if ((int)x < img.width() && (int)y < img.height() )
	            Block[i++] = Data[Offset + x];
            else
	            Block[i++] = Data[Offset];
		}
        Offset += img.width();
	}
}

void ShortToColor888( uint16_t Pixel, axColorRGBb *Colour ) {
	Colour->r = ((Pixel & 0xF800) >> 11) << 3;
	Colour->g = ((Pixel & 0x07E0) >> 5)  << 2;
	Colour->b = ((Pixel & 0x001F))       << 3;
}

uint32_t Distance( axColorRGBb *c1, axColorRGBb *c2 ) {
	return  (c1->r - c2->r) * (c1->r - c2->r) +
			(c1->g - c2->g) * (c1->g - c2->g) +
			(c1->b - c2->b) * (c1->b - c2->b);
}

void ChooseEndpoints( uint16_t *Block, uint16_t *ex0, uint16_t *ex1) {
	int			i;
	axColorRGBb	colors[16];
	int			Lowest=0, Highest=0;
	int			sum_color_i, sum_color_low, sum_color_high;

	for (i = 0; i < 16; i++) {
		ShortToColor888( Block[i], &colors[i] );
		sum_color_i = colors[i].r + colors[i].g + colors[i].b;
		sum_color_low = colors[Lowest].r + colors[Lowest].g + colors[Lowest].b;
		sum_color_high = colors[Highest].r + colors[Highest].g + colors[Highest].b;
		if ( sum_color_i < sum_color_low )	Lowest = i;
		if ( sum_color_i > sum_color_high )	Highest = i;
	}
	*ex0 = Block[Highest];
	*ex1 = Block[Lowest];
}

void ChooseAlphaEndpoints( uint8_t *Block, uint8_t *a0, uint8_t *a1 ) {
	uint32_t i, Lowest = 0xFF, Highest = 0;

	for (i = 0; i < 16; i++) {
		if( Block[i] < Lowest )	Lowest = Block[i];
		if (Block[i] > Highest)	Highest = Block[i];
	}

	*a0 = Lowest;
	*a1 = Highest;
}


void CorrectEndDXT1( uint16_t *ex0, uint16_t *ex1, bool HasAlpha ) {
	uint16_t Temp;

	if (HasAlpha) {
		if (*ex0 > *ex1) {
			Temp = *ex0;
			*ex0 = *ex1;
			*ex1 = Temp;
		}
	}
	else {
		if (*ex0 < *ex1) {
			Temp = *ex0;
			*ex0 = *ex1;
			*ex1 = Temp;
		}
	}
}

uint32_t GenBitMask( uint16_t ex0, uint16_t ex1, uint32_t NumCols, uint16_t *In, uint8_t *Alpha, axColorRGBb *OutCol ) {
	uint32_t	i, j, Closest, Dist, BitMask = 0;
	uint8_t		Mask[16];
	axColorRGBb	c, Colours[4];

	ShortToColor888(ex0, &Colours[0]);
	ShortToColor888(ex1, &Colours[1]);
	if (NumCols == 3) {
		Colours[2].r = (Colours[0].r + Colours[1].r) / 2;
		Colours[2].g = (Colours[0].g + Colours[1].g) / 2;
		Colours[2].b = (Colours[0].b + Colours[1].b) / 2;
		Colours[3].r = (Colours[0].r + Colours[1].r) / 2;
		Colours[3].g = (Colours[0].g + Colours[1].g) / 2;
		Colours[3].b = (Colours[0].b + Colours[1].b) / 2;
	}
	else {  // NumCols == 4
		Colours[2].r = (2 * Colours[0].r + Colours[1].r + 1) / 3;
		Colours[2].g = (2 * Colours[0].g + Colours[1].g + 1) / 3;
		Colours[2].b = (2 * Colours[0].b + Colours[1].b + 1) / 3;
		Colours[3].r = (Colours[0].r + 2 * Colours[1].r + 1) / 3;
		Colours[3].g = (Colours[0].g + 2 * Colours[1].g + 1) / 3;
		Colours[3].b = (Colours[0].b + 2 * Colours[1].b + 1) / 3;
	}

	for (i = 0; i < 16; i++) {
		if (Alpha) {  // Test to see if we have 1-bit transparency
			if (Alpha[i] < 128) {
				Mask[i] = 3;  // Transparent
				if (OutCol) {
					OutCol[i].r = Colours[3].r;
					OutCol[i].g = Colours[3].g;
					OutCol[i].b = Colours[3].b;
				}
				continue;
			}
		}

		// If no transparency, try to find which colour is the closest.
		Closest = UINT_MAX;
		ShortToColor888(In[i], &c);
		for (j = 0; j < NumCols; j++) {
			Dist = Distance(&c, &Colours[j]);
			if (Dist < Closest) {
				Closest = Dist;
				Mask[i] = j;
				if (OutCol) {
					OutCol[i].r = Colours[j].r;
					OutCol[i].g = Colours[j].g;
					OutCol[i].b = Colours[j].b;
				}
			}
		}
	}

	for (i = 0; i < 16; i++) {
		BitMask |= (Mask[i] << (i*2));
	}

	return BitMask;
}

void GenAlphaBitMask( uint8_t a0, uint8_t a1, uint8_t *In, uint8_t *Mask, uint8_t *Out ) {
	uint8_t		Alphas[8], M[16];
	uint32_t	i, j, Closest, Dist;

	Alphas[0] = a0;
	Alphas[1] = a1;

	// 8-alpha or 6-alpha block?
	if (a0 > a1) {
		// 8-alpha block:  derive the other six alphas.
		// Bit code 000 = alpha_0, 001 = alpha_1, others are interpolated.
		Alphas[2] = (6 * Alphas[0] + 1 * Alphas[1] + 3) / 7;	// bit code 010
		Alphas[3] = (5 * Alphas[0] + 2 * Alphas[1] + 3) / 7;	// bit code 011
		Alphas[4] = (4 * Alphas[0] + 3 * Alphas[1] + 3) / 7;	// bit code 100
		Alphas[5] = (3 * Alphas[0] + 4 * Alphas[1] + 3) / 7;	// bit code 101
		Alphas[6] = (2 * Alphas[0] + 5 * Alphas[1] + 3) / 7;	// bit code 110
		Alphas[7] = (1 * Alphas[0] + 6 * Alphas[1] + 3) / 7;	// bit code 111
	}
	else {
		// 6-alpha block.
		// Bit code 000 = alpha_0, 001 = alpha_1, others are interpolated.
		Alphas[2] = (4 * Alphas[0] + 1 * Alphas[1] + 2) / 5;	// Bit code 010
		Alphas[3] = (3 * Alphas[0] + 2 * Alphas[1] + 2) / 5;	// Bit code 011
		Alphas[4] = (2 * Alphas[0] + 3 * Alphas[1] + 2) / 5;	// Bit code 100
		Alphas[5] = (1 * Alphas[0] + 4 * Alphas[1] + 2) / 5;	// Bit code 101
		Alphas[6] = 0x00;										// Bit code 110
		Alphas[7] = 0xFF;										// Bit code 111
	}

	for (i = 0; i < 16; i++) {
		Closest = UINT_MAX;
		for (j = 0; j < 8; j++) {
			Dist = abs((int)In[i] - (int)Alphas[j]);
			if (Dist < Closest) {
				Closest = Dist;
				M[i] = j;
			}
		}
	}

	if (Out) {
		for (i = 0; i < 16; i++) {
			Out[i] = Alphas[M[i]];
		}
	}

	//this was changed 20040623. There was a shift bug in here. Now the code
	//produces much higher quality images.
	// First three bytes.
	Mask[0] = (M[0]) | (M[1] << 3) | ((M[2] & 0x03) << 6);
	Mask[1] = ((M[2] & 0x04) >> 2) | (M[3] << 1) | (M[4] << 4) | ((M[5] & 0x01) << 7);
	Mask[2] = ((M[5] & 0x06) >> 1) | (M[6] << 2) | (M[7] << 5);

	// Second three bytes.
	Mask[3] = (M[8]) | (M[9] << 3) | ((M[10] & 0x03) << 6);
	Mask[4] = ((M[10] & 0x04) >> 2) | (M[11] << 1) | (M[12] << 4) | ((M[13] & 0x01) << 7);
	Mask[5] = ((M[13] & 0x06) >> 1) | (M[14] << 2) | (M[15] << 5);
}

axStatus axImage_DDS::compress( axImage &img ) {
	axStatus st;
	axArray<uint16_t>	Data;
	uint16_t	/**Data,*/ Block[16], ex0, ex1, t0, t1;
	int			x, y, i, BitMask;
	axByteArray	Alpha;
	uint8_t		/**Alpha,*/ AlphaBlock[16], AlphaBitMask[6], a0, a1;
	bool		HasAlpha;
	uint32_t	Count = 0;

	st = CompressToRXGB( img, Data, Alpha );	if (!st) return st;

	switch ( img.type() )	{
		case axColor::t_RGBb: {
			for (y = 0; y < img.height(); y += 4) {
				for (x = 0; x < img.width(); x += 4) {
					GetAlphaBlock(AlphaBlock, Alpha.ptr(), img, x, y);
					HasAlpha = false;
					for (i = 0 ; i < 16; i++) {
						if (AlphaBlock[i] < 128) {
							HasAlpha = true;
							break;
						}
					}

					HasAlpha =false;
					GetBlock(Block, Data.ptr(), img, x, y);
					ChooseEndpoints(Block, &ex0, &ex1);
					CorrectEndDXT1(&ex0, &ex1, HasAlpha);
					st = se_.io_le( ex0 );		if (!st) return st;
					st = se_.io_le( ex1 );		if (!st) return st;
					if (HasAlpha)
						BitMask = GenBitMask(ex0, ex1, 3, Block, AlphaBlock, NULL);
					else
						BitMask = GenBitMask(ex0, ex1, 4, Block, NULL, NULL);
					st = se_.io_le( BitMask );	if (!st) return st;
					Count += 8;
				}
			}
		}break;

		case axColor::t_RGBAb: {
			for (y = 0; y < img.height(); y += 4) {
				for (x = 0; x < img.width(); x += 4) {
					GetAlphaBlock(AlphaBlock, Alpha.ptr(), img, x, y);
					ChooseAlphaEndpoints(AlphaBlock, &a0, &a1);
					GenAlphaBitMask(a0, a1, AlphaBlock, AlphaBitMask, NULL );
					st = se_.io_le( a0 );	if (!st) return st;
					st = se_.io_le( a1 );	if (!st) return st;
					st = se_.io_raw( AlphaBitMask, 6);	if (!st) return st;

					GetBlock(Block, Data.ptr(), img, x, y);
					ChooseEndpoints(Block, &t0, &t1);
					ex0 = ax_max(t0, t1);
					ex1 = ax_min(t0, t1);
					CorrectEndDXT1(&ex0, &ex1, 0);
					st = se_.io_le( ex0 );		if (!st) return st;
					st = se_.io_le( ex1 );		if (!st) return st;
					BitMask = GenBitMask(ex0, ex1, 4, Block, NULL, NULL);
					st = se_.io_le( BitMask );	if (!st) return st;
					Count += 16;
				}
			}
		}break;

		default: return axStatus::Image_DDS_unsupported_color_type;
	}
	return 0;
}

axImage_DDS::DDSData::DDSData() {
	fmt = PF_UNKNOWN;
	w = 0;
	h = 0;
	mipmap_count = 0;
}

//=====================================================
axImage_DDS::axImage_DDS() {

}

axImage_DDS::~axImage_DDS() {

}

bool axImage_DDS::is_cube_map() const {
	return (header.dds_caps1 & DDS_COMPLEX) && (header.dds_caps2 & DDS_CUBEMAP);
}

bool axImage_DDS::has_mipmap() const {
	return (header.dds_caps1 & DDS_MIPMAP) && (header.mipmap_count > 0);
}

axStatus axImage_DDS::load( axIByteArray &buf ) {
	ds_.set( buf );
	return 0;
}

axStatus axImage_DDS::readPixels( axImage_DDS::DDSData &buf, axColor::Type type ) {
	axStatus st;
	st = readHeader();	if (!st) return st;

	st = decodePixelFormat( buf.block_size, buf.fmt );
	buf.mipmap_count = has_mipmap() ? header.mipmap_count : 0;
	buf.h = header.height;
	buf.w = header.width;
	if (!st) return st;
	if (!(header.flags1 & (DDS_LINEARSIZE | DDS_PITCH))
		|| header.linear_size == 0) {
		header.flags1 |= DDS_LINEARSIZE;
		header.linear_size = buf.block_size;
	}

	int buf_size = header.linear_size;

	if ( has_mipmap() ) {
		switch ( buf.fmt ) {
			case PF_DXT1: {	buf_size *= 2;	}break;
			case PF_DXT3: {	buf_size *= 4;	}break;
			case PF_DXT5: {	buf_size *= 4;	}break;
			default: return axStatus::Image_DDS_unsupported_color_type;
		}
	}

	if ( is_cube_map() ) buf_size *= 6;

	st = buf.data.resize( buf_size );					if (!st) return st;
	axSize out_len = ax_min( ds_.remainSize(), buf_size ) ;
	st = ds_.io_raw( buf.data.ptr(), out_len );			if( !st ) return st;
	st = buf.data.resize( out_len );					if (!st) return st;
	return 0;
}

axStatus axImage_DDS::readPixels( axImage &img, axColor::Type type ) {
	axStatus st;
	DDSData buf;
	st = readPixels( buf, type );	if (!st) return st;
	switch ( buf.fmt ) {
		case PF_DXT1: return decompress_dxt1( buf, img );
		case PF_DXT3: return decompress_dxt3( buf, img );
		case PF_DXT5: return decompress_dxt5( buf, img );
		default: return axStatus::Image_DDS_unsupported_color_type;
	}
	return axStatus::not_implemented;
}

axStatus axImage_DDS::save( axIByteArray &buf, axImage &img ) {
	se_.set( buf );
	axStatus st;
	st = writeHeader( img );	if (!st) return st;
	st = compress( img );		if (!st) return st;
	return 0;
}

axStatus axImage_DDS::readHeader() {
	// reference : http://msdn.microsoft.com/archive/default.asp?url=/archive/en-us/directx9_c/directx/graphics/reference/ddsfilereference/ddsfileformat.asp
	axStatus st;

	st = ds_.io_raw( header.sign, k_dds_sign_len );		if( !st ) return st;

	if ( ax_strncasecmp( header.sign, "DDS ", k_dds_sign_len ) )	return axStatus::Image_DDS_invalid_data;
	st = ds_.io_le( header.size1 );				if (!st) return st;
	st = ds_.io_le( header.flags1 );			if (!st) return st;
	st = ds_.io_le( header.height );			if (!st) return st;
	st = ds_.io_le( header.width );				if (!st) return st;
	st = ds_.io_le( header.linear_size );		if (!st) return st;
	st = ds_.io_le( header.depth );				if (!st) return st;
	st = ds_.io_le( header.mipmap_count );		if (!st) return st;
	st = ds_.io_le( header.alphabit_depth );	if (!st) return st;

	int i;
	for ( i=0; i<10; i++ ) {
		ds_.io_le( header.not_used[i] );			if (!st) return st;		
	}
	st = ds_.io_le( header.size2 );				if (!st) return st;		
	st = ds_.io_le( header.flags2 );			if (!st) return st;	
	st = ds_.io_le( header.fourcc );			if (!st) return st;	
	st = ds_.io_le( header.rgbbit_count );		if (!st) return st;	
	st = ds_.io_le( header.r_bitmask );			if (!st) return st;
	st = ds_.io_le( header.g_bitmask );			if (!st) return st;
	st = ds_.io_le( header.b_bitmask );			if (!st) return st;
	st = ds_.io_le( header.rgba_bitmask );		if (!st) return st;

	st = ds_.io_le( header.dds_caps1 );			if (!st) return st;
	st = ds_.io_le( header.dds_caps2 );			if (!st) return st;
	st = ds_.io_le( header.dds_caps3 );			if (!st) return st;
	st = ds_.io_le( header.dds_caps4 );			if (!st) return st;

	st = ds_.io_le( header.texture_stage );		if (!st) return st;

	if (header.size1 != 124 && header.size1 != (uint32_t)ax_char4( 'D','D','S',' ') )
		return axStatus::Image_DDS_invalid_data;

	if (header.size2 != 32)
		return axStatus::Image_DDS_invalid_data;

	if (header.width == 0 || header.height == 0)
		return axStatus::Image_DDS_invalid_data;

	if (header.depth == 0)
		header.depth = 1;

	return 0;
}

axStatus axImage_DDS::decodePixelFormat( uint32_t &block_size, DDSPixFormat &comp_format ) {
	if (header.flags2 & DDS_FOURCC) {
		block_size = ((header.width + 3)/4) * ((header.height + 3)/4) * header.depth;
		switch (header.fourcc) {
			case FOURCC_DXT1:
				comp_format = PF_DXT1;
				block_size *= 8;
				break;

			case FOURCC_DXT2:
				comp_format = PF_DXT2;
				block_size *= 16;
				break;

			case FOURCC_DXT3:
				comp_format = PF_DXT3;
				block_size *= 16;
				break;

			case FOURCC_DXT4:
				comp_format = PF_DXT4;
				block_size *= 16;
				break;

			case FOURCC_DXT5:
				comp_format = PF_DXT5;
				block_size *= 16;
				break;
			case ax_char4('A', 'T', 'I', '1'):				comp_format = PF_ATI1N;				block_size *= 8;				break;

			case ax_char4('A', 'T', 'I', '2'):
				comp_format = PF_3DC;
				block_size *= 16;
				break;

			case ax_char4('R', 'X', 'G', 'B'):
				comp_format = PF_RXGB;
				block_size *= 16;
				break;

			case ax_char4('$', '\0', '\0', '\0'):
				comp_format = PF_A16B16G16R16;
				block_size = header.width * header.height * header.depth * 8;
				break;

			case ax_char4('o', '\0', '\0', '\0'):
				comp_format = PF_R16F;
				block_size = header.width * header.height * header.depth * 2;
				break;

			case ax_char4('p', '\0', '\0', '\0'):
				comp_format = PF_G16R16F;
				block_size = header.width * header.height * header.depth * 4;
				break;

			case ax_char4('q', '\0', '\0', '\0'):
				comp_format = PF_A16B16G16R16F;
				block_size = header.width * header.height * header.depth * 8;
				break;

			case ax_char4('r', '\0', '\0', '\0'):
				comp_format = PF_R32F;
				block_size = header.width * header.height * header.depth * 4;
				break;

			case ax_char4('s', '\0', '\0', '\0'):
				comp_format = PF_G32R32F;
				block_size = header.width * header.height * header.depth * 8;
				break;

			case ax_char4('t', '\0', '\0', '\0'):
				comp_format = PF_A32B32G32R32F;
				block_size = header.width * header.height * header.depth * 16;
				break;

			default:
				return axStatus::Image_DDS_invalid_data;
		}
	} else {
		// This dds texture isn't compressed so write out ARGB or luminance format
		if (header.flags2 & DDS_LUMINANCE) {
			if (header.flags2 & DDS_ALPHAPIXELS) {
				comp_format = PF_LUMINANCE_ALPHA;
			} else {
				comp_format = PF_LUMINANCE;
			}
		}
		else {
			if (header.flags2 & DDS_ALPHAPIXELS) {
				comp_format = PF_ARGB;
			} else {
				comp_format = PF_RGB;
			}
		}
		block_size = (header.width * header.height * header.depth * (header.rgbbit_count >> 3));
	}

	return 0;
}

axStatus axImage_DDS::decompress_dxt1( DDSData &buf, axImage &img ) {
	axStatus st;
	int				x, y, i, j, k, select;
	uint8_t			*temp;
	axColorRGBAb	colours[4];
	axColorR5G6B5	color_0, color_1;
	uint32_t		bitmask, offset;

	if ( buf.data.size() == 0 )	return axStatus::invalid_parameter;
	st = img.create( axColor::t_RGBAb, buf.w, buf.h );	if (!st) return st;

	temp = buf.data.ptr();
	colours[0].a = 0xFF;
	colours[1].a = 0xFF;
	colours[2].a = 0xFF;
	//colours[3].a = 0xFF;
	for (y = 0; y < buf.h; y += 4) {
		for (x = 0; x < buf.w; x += 4) {
			color_0.c = ax_le_to_host( *((uint16_t*)temp) );
			color_1.c = ax_le_to_host( *((uint16_t*)(temp + 2)) );

			colours[0] = color_0;
			colours[1] = color_1;

			bitmask = ax_le_to_host( ((uint32_t*)temp)[1] );
			temp += 8;

			if (color_0.c > color_1.c ) {
				// Four-color block: derive the other two colors.
				// 00 = color_0, 01 = color_1, 10 = color_2, 11 = color_3
				// These 2-bit codes correspond to the 2-bit fields
				// stored in the 64-bit block.
				colours[2].b = (2 * colours[0].b + colours[1].b + 1) / 3;
				colours[2].g = (2 * colours[0].g + colours[1].g + 1) / 3;
				colours[2].r = (2 * colours[0].r + colours[1].r + 1) / 3;
				//colours[2].a = 0xFF;

				colours[3].b = (colours[0].b + 2 * colours[1].b + 1) / 3;
				colours[3].g = (colours[0].g + 2 * colours[1].g + 1) / 3;
				colours[3].r = (colours[0].r + 2 * colours[1].r + 1) / 3;
				colours[3].a = 0xFF;
			}
			else {
				// Three-color block: derive the other color.
				// 00 = color_0,  01 = color_1,  10 = color_2,
				// 11 = transparent.
				// These 2-bit codes correspond to the 2-bit fields
				// stored in the 64-bit block.
				colours[2].b = (colours[0].b + colours[1].b) / 2;
				colours[2].g = (colours[0].g + colours[1].g) / 2;
				colours[2].r = (colours[0].r + colours[1].r) / 2;
				//colours[2].a = 0xFF;

				colours[3].b = (colours[0].b + 2 * colours[1].b + 1) / 3;
				colours[3].g = (colours[0].g + 2 * colours[1].g + 1) / 3;
				colours[3].r = (colours[0].r + 2 * colours[1].r + 1) / 3;
				colours[3].a = 0x00;
			}

			for (j = 0, k = 0; j < 4; j++) {
				for (i = 0; i < 4; i++, k++) {
					select = (bitmask & (0x03 << k*2)) >> k*2;
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						*c = colours[select];
					}
				}
			}
		}
	}

	return 0;
}

axStatus axImage_DDS::decompress_dxt3( DDSData &buf, axImage &img ) {
	axStatus st;
	int				x, y, i, j, k, select;
	uint8_t			*temp;
	axColorR5G6B5	color565;
	axColorRGBAb	colours[4];
	uint32_t		bitmask, offset;
	uint16_t		word;
	uint8_t			*alpha;

	if ( buf.data.size() == 0 )	return axStatus::invalid_parameter;
	st = img.create( axColor::t_RGBAb, buf.w, buf.h );	if (!st) return st;

	temp = buf.data.ptr();
	for (y = 0; y < buf.h; y += 4) {
		for (x = 0; x < buf.w; x += 4) {
			alpha = temp;								temp += 8;

			color565.c = ax_le_to_host( *(uint16_t*)temp );	temp += 2;
			colours[0] = color565;

			color565.c = ax_le_to_host( *(uint16_t*)temp );	temp += 2;
			colours[1] = color565;

			bitmask = ax_le_to_host( *(uint32_t*)temp );	temp += 4;

			// Four-color block: derive the other two colors.
			// 00 = color_0, 01 = color_1, 10 = color_2, 11 = color_3
			// These 2-bit codes correspond to the 2-bit fields
			// stored in the 64-bit block.
			colours[2].b = (2 * colours[0].b + colours[1].b + 1) / 3;
			colours[2].g = (2 * colours[0].g + colours[1].g + 1) / 3;
			colours[2].r = (2 * colours[0].r + colours[1].r + 1) / 3;
			//colours[2].a = 0xFF;

			colours[3].b = (colours[0].b + 2 * colours[1].b + 1) / 3;
			colours[3].g = (colours[0].g + 2 * colours[1].g + 1) / 3;
			colours[3].r = (colours[0].r + 2 * colours[1].r + 1) / 3;
			//colours[3].a = 0xFF;

			k = 0;
			for (j = 0; j < 4; j++) {
				for (i = 0; i < 4; i++, k++) {
					select = (bitmask & (0x03 << k*2)) >> k*2;
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						c->r = colours[select].r;
						c->g = colours[select].g;
						c->b = colours[select].b;
					}
				}
			}

			for (j = 0; j < 4; j++) {
				word = alpha[2*j] + 256*alpha[2*j+1];
				for (i = 0; i < 4; i++) {
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						c->a = word & 0x0F;
						c->a = c->a | (c->a << 4);
					}
					word >>= 4;
				}
			}

		}
	}


	return 0;
}

axStatus axImage_DDS::decompress_dxt5( DDSData &buf, axImage &img ) {
	axStatus st;
	int				x, y, i, j, k, select;
	uint8_t			*temp;
	axColorRGBAb	colours[4];
	axColorR5G6B5	color565;
	uint32_t		bitmask, offset;
	uint8_t			alphas[8], *alphamask;
	uint32_t		bits;

	if ( buf.data.size() == 0 )	return axStatus::invalid_parameter;
	st = img.create( axColor::t_RGBAb, buf.w, buf.h );	if (!st) return st;

	temp = buf.data.ptr();
	for (y = 0; y < buf.h; y += 4) {
		for (x = 0; x < buf.w; x += 4) {
			if (y >= buf.h || x >= buf.w)	break;
			alphas[0] = temp[0];
			alphas[1] = temp[1];
			alphamask = temp + 2;
			temp += 8;

			color565.c = ax_le_to_host( *(uint16_t*)temp );	temp+=2;
			colours[0] = color565;

			color565.c = ax_le_to_host( *(uint16_t*)temp );	temp+=2;
			colours[1] = color565;


			bitmask = ax_le_to_host( *(uint32_t*)temp );		temp += 4;

			// Four-color block: derive the other two colors.
			// 00 = color_0, 01 = color_1, 10 = color_2, 11 = color_3
			// These 2-bit codes correspond to the 2-bit fields
			// stored in the 64-bit block.
			colours[2].b = (2 * colours[0].b + colours[1].b + 1) / 3;
			colours[2].g = (2 * colours[0].g + colours[1].g + 1) / 3;
			colours[2].r = (2 * colours[0].r + colours[1].r + 1) / 3;
			//colours[2].a = 0xFF;

			colours[3].b = (colours[0].b + 2 * colours[1].b + 1) / 3;
			colours[3].g = (colours[0].g + 2 * colours[1].g + 1) / 3;
			colours[3].r = (colours[0].r + 2 * colours[1].r + 1) / 3;
			//colours[3].a = 0xFF;

			k = 0;
			for (j = 0; j < 4; j++) {
				for (i = 0; i < 4; i++, k++) {
					select = (bitmask & (0x03 << k*2)) >> k*2;
					// only put pixels out < width or height
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						c->r = colours[select].r;
						c->g = colours[select].g;
						c->b = colours[select].b;

					}
				}
			}

			// 8-alpha or 6-alpha block?
			if (alphas[0] > alphas[1]) {
				// 8-alpha block:  derive the other six alphas.
				// Bit code 000 = alpha_0, 001 = alpha_1, others are interpolated.
				alphas[2] = (6 * alphas[0] + 1 * alphas[1] + 3) / 7;	// bit code 010
				alphas[3] = (5 * alphas[0] + 2 * alphas[1] + 3) / 7;	// bit code 011
				alphas[4] = (4 * alphas[0] + 3 * alphas[1] + 3) / 7;	// bit code 100
				alphas[5] = (3 * alphas[0] + 4 * alphas[1] + 3) / 7;	// bit code 101
				alphas[6] = (2 * alphas[0] + 5 * alphas[1] + 3) / 7;	// bit code 110
				alphas[7] = (1 * alphas[0] + 6 * alphas[1] + 3) / 7;	// bit code 111
			}
			else {
				// 6-alpha block.
				// Bit code 000 = alpha_0, 001 = alpha_1, others are interpolated.
				alphas[2] = (4 * alphas[0] + 1 * alphas[1] + 2) / 5;	// Bit code 010
				alphas[3] = (3 * alphas[0] + 2 * alphas[1] + 2) / 5;	// Bit code 011
				alphas[4] = (2 * alphas[0] + 3 * alphas[1] + 2) / 5;	// Bit code 100
				alphas[5] = (1 * alphas[0] + 4 * alphas[1] + 2) / 5;	// Bit code 101
				alphas[6] = 0x00;										// Bit code 110
				alphas[7] = 0xFF;										// Bit code 111
			}

			// Note: Have to separate the next two loops,
			//	it operates on a 6-uint8_t system.

			// First three bytes
			bits = (alphamask[0]) | (alphamask[1] << 8) | (alphamask[2] << 16);
			for (j = 0; j < 2; j++) {
				for (i = 0; i < 4; i++) {
					// only put pixels out < width or height
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						c->a = alphas[bits & 0x07];
					}
					bits >>= 3;
				}
			}

			// Last three bytes
			bits = (alphamask[3]) | (alphamask[4] << 8) | (alphamask[5] << 16);
			for (j = 2; j < 4; j++) {
				for (i = 0; i < 4; i++) {
					// only put pixels out < width or height
					if (((x + i) < buf.w) && ((y + j) < buf.h)) {
						offset = (y + j) * img.width() + (x + i);
						axColorRGBAb *c = (axColorRGBAb *)img.pixelVoidPointer() + offset;
						c->a = alphas[bits & 0x07];
					}
					bits >>= 3;
				}
			}
		}
	}

	return 0;
}

axStatus axImage_DDS::writeHeader( axImage &img ) {
	axStatus st;
	header.size1 = 124;
	header.flags1 |= DDS_LINEARSIZE | DDS_MIPMAPCOUNT | DDS_WIDTH | DDS_HEIGHT | DDS_CAPS | DDS_PIXELFORMAT;
	header.height = img.height();
	header.width  = img.width();
	header.size2 = 32;	header.flags2 |= DDS_FOURCC;
	header.dds_caps1 = 0;
	header.dds_caps2 = 0;	// @TODO:  Fix the pre-multiplied alpha problem.
	switch ( img.type() ) {
		case axColor::t_RGBb:	{
			header.linear_size = ((img.width() + 3)/4) * ((img.height() + 3)/4) * 8;
			header.fourcc = FOURCC_DXT1;
		}break;
		case axColor::t_RGBAb: {
			header.linear_size = ((img.width() + 3)/4) * ((img.height() + 3)/4) * 16;
			header.fourcc = FOURCC_DXT5;
		}break;
		default: return axStatus::Image_DDS_unsupported_color_type;
	}

	st = se_.io_raw( "DDS ", k_dds_sign_len );		if (!st) return st;

	st = se_.io_le( header.size1 );			if (!st) return st; // size1
	st = se_.io_le( header.flags1 );		if (!st) return st; // flags2
	st = se_.io_le( header.height );		if (!st) return st; // height
	st = se_.io_le( header.width );			if (!st) return st; // width
	st = se_.io_le( header.linear_size );	if (!st) return st; // linear size

	int tmp = 0;
	st = se_.io_le( tmp );					if (!st) return st;	// depth
	tmp = 1;
	st = se_.io_le( tmp );					if (!st) return st;	// mipmap count
	tmp = 0;
	st = se_.io_le( tmp );					if (!st) return st;	// alpha bit depth

	int i;
	for (i = 0; i < 10; i++) {
		st = se_.io_le( tmp );				if (!st) return st;	// not used
	}

	st = se_.io_le( header.size2 );			if (!st) return st; // size2
	st = se_.io_le( header.flags2 );		if (!st) return st; // flags2
	st = se_.io_le( header.fourcc );		if (!st) return st; // fourcc

	tmp = 0;
	st = se_.io_le( tmp );					if (!st) return st; // RGBBit Count
	st = se_.io_le( tmp );					if (!st) return st; // RBit Mask
	st = se_.io_le( tmp );					if (!st) return st; // GBit Mask
	st = se_.io_le( tmp );					if (!st) return st; // BBit Mask
	st = se_.io_le( tmp );					if (!st) return st; // RGBAlphaBit Mask

	st = se_.io_le( header.dds_caps1 );		if (!st) return st; // ddsCaps1
	st = se_.io_le( header.dds_caps2 );		if (!st) return st; // ddsCaps2
	st = se_.io_le( tmp );					if (!st) return st; // ddsCaps3
	st = se_.io_le( tmp );					if (!st) return st; // ddsCaps4
	st = se_.io_le( tmp );					if (!st) return st; // TextureStage
	return 0;
}

