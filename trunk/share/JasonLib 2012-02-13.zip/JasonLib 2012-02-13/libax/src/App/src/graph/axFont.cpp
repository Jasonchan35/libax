#include <ax/App/graph/axFont.h>
#include <ax/App/graph/axColor.h>
#include <ax/App/graph/axImage.h>

axFont::~axFont() {
	close();
}

axStatus axFont::makeImageAb( axImage &img, const wchar_t* text ) {
	axStatus st;
	int w, h;
	st = getTextRect( w, h, text );		if( !st ) return st;
	return makeImageAbInRect( img, text, w, h, axAlignment::kLeft );
}


#if 0
#pragma mark ============= FreeType 2 ==========
#endif
#ifdef axUSE_FreeType2

#include "axFreeType2.h"

axFont::axFont() {
	font_ = NULL;
}

void axFont::close() {
	if( font_ ) {
		delete font_;
		font_ = NULL;
	}
}

axStatus axFont::create( const wchar_t* face, float size,  bool bold, bool italic ) {
	close();
	axStatus st;
	
	axAutoPtr< axFreeType2_Face >	p;
	st = p.newObject();		if( !st ) return st;
	st = p->create( face, size, bold, italic );		if( !st ) return st;
	font_ = p.unref();
	return 0;
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
	if( ! font_ ) return -1;
	return font_->makeImageAbInRect( img, text, width, height, align );
}

axStatus axFont::getTextRect( int& outWidth, int& outHeight, const wchar_t* text ) {
	if( ! font_ ) {
		outWidth  = 0;
		outHeight = 0;
		return -1;
	}
	return font_->getTextRect( outWidth, outHeight, text );	
}

#else //axUSE_FreeType2

#if 0
#pragma mark ============= Android ==========
#endif
#ifdef axOS_Android

axTHREAD_LOCAL	jclass		axFont::jni_class			= NULL;
axTHREAD_LOCAL	jmethodID	axFont::jni_init			= NULL;
axTHREAD_LOCAL	jmethodID	axFont::jni_create			= NULL;
axTHREAD_LOCAL	jmethodID	axFont::jni_getTextRect 	= NULL;
axTHREAD_LOCAL	jmethodID	axFont::jni_makeImageInRect = NULL;

axFont::axFont() {
	font_ = NULL;
}

void axFont::close() {
	if( font_ ) {
		axAndroid::getInstance()->jni->DeleteGlobalRef( font_ );
		font_ = NULL;
	}
}

axStatus axFont::create( const wchar_t* face, float size,  bool bold, bool italic ) {
	axAndroid* an = axAndroid::getInstance();

	if( !jni_class ) {
		jni_class = an->jni->FindClass("com/awenix/libax/axFont");
		if( !jni_class ) {
			ax_log("axFont java  class not found");
			return -1;
		}
		
		jni_init = an->jni->GetMethodID( jni_class, "<init>", "()V" );
		if( !jni_init ) {
			ax_log("axFont::create() method init() not found");
			return -1;
		}
		
		jni_create = an->jni->GetMethodID( jni_class, "create", "(Ljava/lang/String;FI)I" );
		if( !jni_create ) {
			ax_log("axFont::create() method create() not found");
			return -1;
		}
		
		jni_getTextRect = an->jni->GetMethodID( jni_class, "getTextRect", "(Ljava/lang/String;)Landroid/graphics/Rect;" );
		if( !jni_getTextRect ) {
			ax_log("axFont error getTextRect");
			return -1;
		}

		jni_makeImageInRect = an->jni->GetMethodID( jni_class, "makeImageInRect", "(Ljava/lang/String;III)Landroid/graphics/Bitmap;" );
		if( !jni_makeImageInRect ) {
			ax_log("axFont not found makeImageInRect");
			return -1;
		}		
	}
	
	close();
	axStatus st;

	jstring face_j = an->toJString( face );

	int style = 0;
	if( bold   ) style |= 1;
	if( italic ) style |= 2;

	jobject obj;
	obj = an->jni->NewObject( jni_class, jni_init );
	if( !obj ) {
		ax_log("axFont new object error");
		return -1;
	}

	st = an->jni->CallIntMethod( obj, jni_create, face_j, size, style );
	if( !st ) {
		ax_log("axFont::create() error");
		return st;
	}

	font_ = an->jni->NewGlobalRef( obj );
	return 0;
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
	if( ! font_ ) return -1;
	axStatus st;

	axAndroid *an = axAndroid::getInstance();

	jstring 	text_j = an->toJString( text );

	jobject bitmap = an->jni->CallObjectMethod( font_, jni_makeImageInRect, text_j, width, height, align.to_int() );
	if( ! bitmap ) {
		ax_log("axFont error call makeImageInRect");
		return -1;
	}

	int dataSize = width * height;

	jintArray pixels = an->jni->NewIntArray( dataSize );
	if( !pixels ) {
		ax_log("axFont error create pixels array ");
		return -1;
	}

	an->jni->CallVoidMethod( bitmap, an->jni_Bitmap_getPixels, pixels, 0, width, 0, 0, width, height );

	axImage	tmp;
	st = tmp.create( axColor::t_RGBAb, width, height );		if( !st ) return st;
	an->jni->GetIntArrayRegion(pixels, 0, dataSize, (jint*)tmp.pixelVoidPointer() );

	st = img.convert( tmp, axColor::t_Ab );					if( !st ) return st;
	return 0;
}

axStatus axFont::getTextRect( int& outWidth, int& outHeight, const wchar_t* text ) {
	outWidth = 0;
	outHeight = 0;
	if( ! font_ ) return -1;

	axStatus st;
	axAndroid *an = axAndroid::getInstance();

	jstring 	text_j = an->toJString( text );

	jobject rect = an->jni->CallObjectMethod( font_, jni_getTextRect, text_j );
	if( ! rect ) {
		ax_log("axFont::getTextRect() error");
		return -1;
	}

	axRect2i rc = an->getRect2i( rect );
	outWidth  = rc.w;
	outHeight = rc.h;

//	ax_log( "getTextRect() {?} {?}", outWidth, outHeight );
	return 0;
}

#endif //axOS_Android


#if 0
#pragma mark ============= MS Win ==========
#endif
#ifdef axOS_WIN

axFont::axFont() {
	font_ = NULL;
}


axStatus axFont::create( const wchar_t* face, float size,  bool bold, bool italic ) {
	axStatus st;

	close();
	HFONT t = CreateFont(	(int)size, 0, 0,0,
							bold		? FW_BOLD:FW_NORMAL,
							italic 		? 1:0,
							0, //underline
							0, //strike_out
							DEFAULT_CHARSET, 0, 0,
							CLEARTYPE_QUALITY, DEFAULT_PITCH,
							face );
	if( !t ) { return -1; }
	font_ = t;
	return 0;
}

void axFont::close() {
	if( font_ ) { DeleteObject( font_ ); font_ = NULL; }
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
	if( ! font_ ) return -1;
	if( width <= 0 || height <= 0 ) return 0;
	axStatus st = 0;

	st = img.create( axColor::t_Ab, width, height );	if( !st ) return st;
	img.setAllByteZero();

	BITMAPINFO info;
	BITMAPINFOHEADER &hdr = info.bmiHeader;
	
	HBITMAP old_bmp = NULL;
	HFONT   oldfont_ = NULL;	
	
	HBITMAP bm = NULL;

	HDC dc = NULL;
	RECT rect = { 0, 0, width, height };
	RECT text_rc = {0,0,0,0};


	hdr.biSize = sizeof(hdr);
	hdr.biWidth  = img.width();
	hdr.biHeight = -img.height(); //upside down
	hdr.biPlanes = 1;
	hdr.biBitCount = 24;
	hdr.biCompression = BI_RGB;
	hdr.biSizeImage = 0;
	hdr.biXPelsPerMeter = 96;
	hdr.biYPelsPerMeter = 96;
	hdr.biClrUsed = 0;
	hdr.biClrImportant = 0;

	uint8_t* pixel;

	dc = CreateCompatibleDC( NULL );
	if( !dc ) { st = -2; goto cleanup; }

	bm  = CreateDIBSection( dc, &info, DIB_RGB_COLORS, (void**)&pixel, NULL, 0 );
	if( !bm ) {
		st = -2; goto cleanup;
	}
	BITMAP	bmp_info;
	GetObject( bm, sizeof( bmp_info), &bmp_info );

	old_bmp  = (HBITMAP)SelectObject( dc, bm );			if( !old_bmp ) { st = -3; goto cleanup; }
	oldfont_ = (HFONT)  SelectObject( dc, font_ );		if( !oldfont_) { st = -4; goto cleanup; }
	
	if( SetTextColor( dc, RGB(255,255,255) ) == CLR_INVALID )	{ st = -5; goto cleanup; }
	if( SetBkMode   ( dc, TRANSPARENT ) == 0 )					{ st = -6; goto cleanup; }

	memset( pixel, 0, bmp_info.bmWidthBytes * height );


	UINT uformat = 0;

	if( align.hasLeft() ) {
		uformat |= DT_LEFT;	
	}else if( align.hasRight() ) {
		uformat |= DT_RIGHT;
	}else if( align.hasCenterX() ) {
		uformat |= DT_CENTER;
	}
	

	DrawText( dc, text, -1, &text_rc, DT_CALCRECT );

//vertical align
	int offset_y = 0; //default to top
	if( align.hasTop() ) {
		offset_y = 0;
	}else if( align.hasBottom() ) {
		offset_y = rect.bottom - text_rc.bottom;
	}else if( align.hasCenterY() ) {
		offset_y = (rect.bottom - text_rc.bottom) / 2;
	}
	rect.top    += offset_y;
	rect.bottom += offset_y;

	int ret = DrawText( dc, text, -1, &rect, uformat );			if( ret == 0 ) { st = -7; goto cleanup; }

	int i,j, w,h;
	h = ax_min( (int)rect.bottom, img.height() );
	w = ax_min( (int)rect.right,  img.width () );

	float y = 0;
		
	for( j=0; j<h; j++ ) {
		axColorByte* dst = (axColorByte*) img.pixelVoidPointer( 0, j );
		axColorRGBb* src = (axColorRGBb*) (pixel + bmp_info.bmWidthBytes * j);
		for( i=0; i<w; i++, dst++, src++ ) {
			*dst = src->g; //only take green component
		}
	}

cleanup:
	//must delete dc before bm, otherwise it cause memory leak on WinCE 5.0
	
	if( dc ) { 
		if( old_bmp ) {
			SelectObject( dc, old_bmp );
			old_bmp = NULL;
		}
		
		if( oldfont_ ) {
			SelectObject( dc, oldfont_ );
			oldfont_ = NULL;
		}
		DeleteDC( dc ); 
		dc = NULL; 
	}
	if( bm ) { DeleteObject( bm ); bm=NULL; }

	GdiFlush();
	return st;
}


axStatus	axFont::getTextRect( int& outWidth, int& outHeight, const wchar_t* text ) {
	axStatus st = 0;
	HDC  dc = NULL;
	HFONT oldfont_ = NULL;

	dc = CreateCompatibleDC( NULL );				if( !dc ) { st=-1; goto cleanup; }

	oldfont_ = (HFONT)  SelectObject( dc, font_ );	if( !oldfont_) { st = -4; goto cleanup; }
	
	RECT rect;
	ax_memzero( rect );
	int ret = DrawText( dc, text, -1, &rect, DT_CALCRECT );		if( ret == 0 ) { st = -7; goto cleanup; }

	outWidth  = rect.right;
	outHeight = rect.bottom;
cleanup:
	if( dc ) { 
		if( oldfont_ ) {
			SelectObject( dc, oldfont_ );
			oldfont_ = NULL;
		}
		DeleteDC( dc ); 
		dc=NULL; 
	}
	return st;
}


#endif //axOS_WIN


#if 0
#pragma mark ============= MacOS X ==========
#endif

#ifdef axOS_MacOSX

axFont::axFont() {
	font_ = nil;
}

void   axFont::close() {
	if( font_ ) {
		[font_ release];
		font_ = nil;
	}
}

axStatus axFont::create( const wchar_t* face, float size, bool bold, bool italic ) {
	close();
	
	if( face ) {
		NSString* f = ax_toNSString( face );
		font_ = [[NSFont fontWithName:f size:size] retain ];
	}else{
		font_ = [[NSFont userFixedPitchFontOfSize:size] retain];
	}
	
	if( !font_ ) {
		ax_log( "error create font face {?}", face );
		return -1;
	}

	return 0;
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
	if( !font_ ) return -1;
	if( width <= 0 || height <= 0 ) return 0;

	axStatus	st;

	CGContextRef			cg; //CoreGraph
	CGColorSpaceRef			colorSpace;

	st = img.create( axColor::t_Ab, width, height );	if( !st ) return st;
	img.setAllByteZero();
	
	colorSpace = CGColorSpaceCreateDeviceGray();

	cg = CGBitmapContextCreate( img.pixelVoidPointer(), width, height, 8, width, colorSpace, kCGImageAlphaNone );
	CGColorSpaceRelease(colorSpace);

//	int ub = NSLineBreakByWordWrapping;
	NSMutableParagraphStyle*	para = [[[NSMutableParagraphStyle alloc] init] autorelease];
	
	if( align.hasLeft() ) {
		[para setAlignment: NSLeftTextAlignment];  
	}else if( align.hasRight() ) {
		[para setAlignment: NSRightTextAlignment]; 
	}else if( align.hasCenterX() ) {
		[para setAlignment: NSCenterTextAlignment];
	}
	
	[para setLineBreakMode: NSLineBreakByWordWrapping ];
		
	NSDictionary* attr = [NSDictionary dictionaryWithObjectsAndKeys:
										font_, NSFontAttributeName,
										[NSColor whiteColor], NSForegroundColorAttributeName,
										para,NSParagraphStyleAttributeName,
										nil];
		
#if 0//upside down
	CGContextTranslateCTM(cg, 0, height );
	CGContextScaleCTM(cg, 1, -1); 
#endif

	NSGraphicsContext* gc = [[NSGraphicsContext graphicsContextWithGraphicsPort:cg flipped:NO] retain];
	NSGraphicsContext* savedContext = [NSGraphicsContext currentContext];
	[NSGraphicsContext setCurrentContext:gc];
			
	NSString *ns_str = ax_toNSString( text );
	NSSize s = [ ns_str sizeWithAttributes:attr ];
	
	float y = 0;
	
	if( align.hasBottom() ) {
		y = - ( height - s.height );
	}else if( align.hasCenterY() ) {
		y = - (height - s.height) /2;  
	}
		
	[ns_str drawInRect:NSMakeRect( 0, y, width, height ) withAttributes:attr ];
	[NSGraphicsContext setCurrentContext:savedContext];	
	[gc release];
	
	CGContextRelease(cg);
	return 0;	
}

	
axStatus axFont::getTextRect( int &outWidth, int &outHeight, const wchar_t* text ) {
	NSString *ns_str = ax_toNSString( text );
	
	NSMutableParagraphStyle*	para = [[[NSMutableParagraphStyle alloc] init] autorelease];
	[para setLineBreakMode: NSLineBreakByWordWrapping ];
	
	NSDictionary* attr = [NSDictionary dictionaryWithObjectsAndKeys:
						  font_, NSFontAttributeName,
						  [NSColor whiteColor], NSForegroundColorAttributeName,
						  para,NSParagraphStyleAttributeName,
						  nil];
	
	NSSize s = [ ns_str sizeWithAttributes:attr ];
	
	outWidth  = s.width;
	outHeight = s.height;	
	return 0;
}

axStatus axFont::defaultFontFace( axIStringW &s, float size ) {
	if( size <= 0 )  {
		size = [NSFont systemFontSize] ;
	}
	NSFont *font = [NSFont systemFontOfSize: size ];
	NSString *str = [font fontName];	
	return s.set( [str UTF8String] );
}

#endif //axOS_MacOSX


#if 0
#pragma mark ============= iOS ==========
#endif
#if axOS_iOS

axFont::axFont() {
	font_ = nil;
}

void axFont::close() {
	if( font_ ) {
		[font_ release];
		font_ = nil;
	}
}

axStatus axFont::getFontSizeBy( float &out, const wchar_t* fontFace, const wchar_t* str, axVec2f size, float minFontSize ) {
	/*
	const float fs = 36;
	
	axStatus st;
	axFont font;
	st = font.create( fontFace, fs ); if(!st) return st;

	axVec2i s;
	st = font.getTextRect( s.x, s.y, str ); if(!st) return st;
	
	
	axVec2f scale;
	scale.x = (float)s.x / size.x;
	scale.y = (float)s.y / size.y;

	float m = ax_min( scale.x, scale.y );
		
	out = m * fs;
	
	return 0;
	
	//if( w >= s.x ) return h;
	*/
	

	axStatus st;
	axFont font;
	st = font.create( fontFace, size.y ); if(!st) return st;
	

	NSString* s = ax_toNSString( str );

	[ s sizeWithFont:font.font_ minFontSize:minFontSize actualFontSize: &out forWidth:size.x lineBreakMode: UILineBreakModeWordWrap];

	
	return 0;
}
	
	
axStatus axFont::create( const wchar_t* face, float size, bool bold, bool italic ) {
	close();
	axStatus st;
	
	axTempStringW tf;
	
	if( ax_strlen( face ) == 0 ) { 
		st = defaultFontFace( tf, size ); if(!st) return st;
	}else {
		st = tf.set( face ); if(!st) return st;	
	}
	
	NSString* f = ax_toNSString( tf );
	
	font_ = [ [UIFont fontWithName:f size:size] retain ];
	if( !font_ ) {
		ax_log( "error create font face {?}", face );
		return -1;
	}
	
	return 0;
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
	if( !font_ ) return -1;
	if( width <= 0 || height <= 0 ) return 0;

	axStatus	st;

	CGContextRef			cg; //CoreGraph
	CGColorSpaceRef			colorSpace;

	st = img.create( axColor::t_Ab, width, height );	if( !st ) return st;
	img.setAllByteZero();

	colorSpace = CGColorSpaceCreateDeviceGray();

	cg = CGBitmapContextCreate( img.pixelVoidPointer(), width, height, 8, width, colorSpace, kCGImageAlphaNone );
	CGColorSpaceRelease(colorSpace);

	//alignment UITextAlignmentLeft
			
	CGContextSetGrayFillColor(cg, 1, 1);
	
	//NOTE: NSString draws in UIKit referential i.e. renders upside-down compared to CGBitmapContext referential
	CGContextTranslateCTM(cg, 0, height );
	CGContextScaleCTM(cg, 1, -1);
	
	UIGraphicsPushContext(cg);
		
	NSString *ns_str = ax_toNSString( text );
	
	UITextAlignment ua = UITextAlignmentLeft; //default to left
	if( align.hasLeft() ) {
		ua = UITextAlignmentLeft; 
	}else if( align.hasRight() ) {
		ua = UITextAlignmentRight;
	}else if( align.hasCenterX() ) {
		ua = UITextAlignmentCenter;
	}
	
	UILineBreakMode ub = UILineBreakModeWordWrap;
	CGSize s = [ ns_str sizeWithFont:font_ constrainedToSize:CGSizeMake(width,height) lineBreakMode:ub ];
	
	float y = 0; //default to top
	if( align.hasTop() ) {
		y = 0;
	}else if( align.hasBottom() ) {
		y =  height - s.height;
	}else if( align.hasCenterY() ) {
		y = (height - s.height) /2; 
	}
	
	[ns_str drawInRect:CGRectMake( 0, y, width, height ) withFont:font_ lineBreakMode:ub alignment:ua];
	UIGraphicsPopContext();
	CGContextRelease(cg);
	return 0;	
}
	
axStatus axFont::getTextRect( int &outWidth, int &outHeight, const wchar_t* text ) {
	NSString *ns_str = ax_toNSString( text );

	UILineBreakMode ub = UILineBreakModeWordWrap;
	CGSize s = [ ns_str sizeWithFont:font_ forWidth: axTypeOf<float>::valueMax() lineBreakMode:ub ];	
	outWidth  = s.width;
	outHeight = s.height;
	return 0;
}	


axStatus axFont::defaultFontFace( axIStringW &s, float size ) {

	if( size <= 0 )  {
		size = [UIFont systemFontSize] ;
	}
	
	UIFont *font = [UIFont systemFontOfSize: size ];
	
	NSString *str = [font fontName];
	
	return s.set( [str UTF8String] );

}
	
	
#endif


#if 0
#pragma mark ============= X11 ==========
#endif

#if axX11

axFont::axFont() {
}

void   axFont::close() {
}

axStatus axFont::create( const wchar_t* face, float size, bool bold, bool italic ) {
//! \todo
	return axStatus::not_implemented;
}

axStatus axFont::makeImageAbInRect( axImage &img, const wchar_t* text, int width, int height, axAlignment align ) {
//! \todo
	return axStatus::not_implemented;
}

axStatus	axFont::getTextRect( int &outWidth, int &outHeight, const wchar_t* text ) {
	return axStatus::not_implemented;
}

#endif //else axUSE_FreeType2

#endif //axX11


