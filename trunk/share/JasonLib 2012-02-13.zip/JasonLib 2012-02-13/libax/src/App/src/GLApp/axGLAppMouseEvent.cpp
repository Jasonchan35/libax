#include <ax/App/GLApp/axGLAppMouseEvent.h>

axGLAppMouseEvent::axGLAppMouseEvent() {
	pos.set(0,0);
	lastPos.set(0,0);
	deltaPos.set(0,0);
	pressure = 0;
	scroll.set(0,0,0);
	eventButton = 0;
}
