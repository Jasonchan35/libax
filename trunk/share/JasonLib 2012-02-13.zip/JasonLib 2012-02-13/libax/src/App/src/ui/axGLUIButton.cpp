#include <ax/App/ui/axGLUIButton.h>


axGLUIButton::axGLUIButton() {

	cmdID_ = cmd_undefine;
	
	is_down_ = false;
}

void axGLUIButton::setCmd( int32_t id_ ) {
	cmdID_ = id_;
}

void axGLUIButton::onClick() {
	if( cmdID_ == cmd_undefine ) return;
	
	axGLUIClickEvent ev;
	onClickEvent( ev );
	
}
	

void axGLUIButton::onRender( axGLAppRenderRequest& req ) const {
	
	axRect2f rc = rect();
	rc.setPos( 0,0 );
	
	axGLDrawGradientY( rc, axColorRGBf(0.8f,0.8f,0.8f), axColorRGBf(0.4f,0.4f,0.4f) );		
	glColor3f( 0,0,0 );
	axGLDrawLine( rc );
	glColor3f( 1,1,1 );
}

void axGLUIButton::onTouchEvent( axGLAppTouchEvent &ev ) {
	
	//todo muti-touch
	
	if( ev.isDown() ) {
		is_down_ = true;
	}else if( ev.isUp() ) {
		if( is_down_ ) {
			onClick();
			//post event
			//ax_log( "Button {?} {?}", this, ev );		
		}
		is_down_ = false;		
		
	}
	
}

