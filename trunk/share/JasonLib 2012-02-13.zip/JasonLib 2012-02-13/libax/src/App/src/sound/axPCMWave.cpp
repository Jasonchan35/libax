#include <ax/App/sound/axPCMWave.h>
#include <ax/App/sound/axWaveFile.h>
#include <ax/core/file_system/axMemMap.h>

void axPCMWave::init() {
	freq = 0;
	ch = 0;
	bit = 0;
	sample = 0;
	buf_sample_size = 0;
}

void axPCMWave::destroy() {
	buf.clear();
	init();
}


axStatus axPCMWave::create( uint32_t buf_sample_size, int freq, int ch, int bit ) {
	this->freq = freq ;
	this->ch  = ch;
	this->bit = bit;
	return resize( buf_sample_size, false );
}

axStatus axPCMWave::resize( uint32_t buf_sample_size, bool keep_data) {
	if( !keep_data ) sample = 0;
	  else sample = ax_min ( sample, buf_sample_size );

	this->buf_sample_size = buf_sample_size;
	return buf.resize( buf_sample_size * ch * (bit >> 3), keep_data );
};


void axPCMWave::onTake( axPCMWave &src ) { 
	
	buf.onTake( src.buf );
	
	freq = src.freq;
	ch = src.ch;
	bit = src.bit;
	sample = src.sample;
	buf_sample_size = src.buf_sample_size;
	
	src.destroy();
}

axStatus  axPCMWave::copy( const axPCMWave &src ) { 
	axStatus st;
	st = buf.copy( src.buf );
	freq = src.freq;
	ch = src.ch;
	bit = src.bit;
	sample = src.sample;
	buf_sample_size = src.buf_sample_size;
	return 0;
}

bool axPCMWave::is_same_format( axPCMWave &c ){
	if( freq == c.freq &&
	ch  == c.ch &&
	bit == c.bit &&
	sample == c.sample ) return true;
	return false;
}

axStatus axPCMWave::load_file ( const wchar_t *filename ) {
	axStatus st;
	axMemMap f;
	st = f.openRead( filename ); if( !st ) return st;
	return load_wav_file( f );
}

axStatus axPCMWave::save_file ( const wchar_t *filename ) {
	axStatus st;
	axMemMap f;
	axSize len;
	st = axWaveFile::requireLength( len, *this ); if( !st ) return st;
	st = f.openWrite( filename, len ); if( !st ) return st;
	return save_wav_file( f );
}

axStatus axPCMWave::load_wav_file ( const axIByteArray &buf ) {
	return axWaveFile::readBuffer( buf, *this ); 
}

axStatus axPCMWave::save_wav_file ( axIByteArray &buf ) {
	return axWaveFile::writeBuffer( buf, *this );
}






