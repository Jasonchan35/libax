#include <ax/App/opengl/axGLTexture.h>
#include <ax/App/opengl/axGLContext.h>

void axGLTexture::init_() {
	id_ = 0;
	target_ = 0;
	width_ = height_ = 0;
	bufferWidth_ = bufferHeight_ = 0;
	time_ = 0;
}

void axGLTexture::destroy() {
	if( !id_ ) return;
	glDeleteTextures( 1, &id_ );
	init_();
}

void axGLTexture::bind() const {
	glEnable ( target_ );
	glBindTexture( target_, id_ );
}

void axGLTexture::unbind () const {
	glDisable ( target_ );
	glBindTexture( target_, 0 );
}

axStatus axGLTexture::format_( axColor::Type type, int &gl_internal_fmt, int &gl_src_fmt, int &gl_data_type ) {
	switch( type ) {
		case axColor::t_RGBb:
			gl_internal_fmt = GL_RGB;
			gl_src_fmt		= GL_RGB;
			gl_data_type	= GL_UNSIGNED_BYTE;
			return 0;

		case axColor::t_RGBAb:
			gl_internal_fmt = GL_RGBA;
			gl_src_fmt		= GL_RGBA;
			gl_data_type	= GL_UNSIGNED_BYTE;
			return 0;

		case axColor::t_Ab:
			gl_internal_fmt	= GL_ALPHA;
			gl_src_fmt		= GL_ALPHA;
			gl_data_type	= GL_UNSIGNED_BYTE;
			return 0;

		case axColor::t_Yb:
			gl_internal_fmt	= GL_LUMINANCE;
			gl_src_fmt		= GL_LUMINANCE;
			gl_data_type	= GL_UNSIGNED_BYTE;
			return 0;

		case axColor::t_YAb:
			gl_internal_fmt	= GL_LUMINANCE_ALPHA;
			gl_src_fmt		= GL_LUMINANCE_ALPHA;
			gl_data_type	= GL_UNSIGNED_BYTE;
			return 0;
	}
	return axStatus::GLTexture_unsupported_color_type;
}

axStatus axGLTexture::createFromFrameBuffer( const axRect2i &rect ) {
	destroy();
	axStatus st;
	if( rect.w == 0 || rect.h == 0 ) return 0;
	
	target_ = GL_TEXTURE_2D;
	
	int w = rect.w;
	int h = rect.h;
	
	if( needPow2_( rect.w, rect.h ) ) {
		w = ax_align_pow2( w );
		h = ax_align_pow2( h );
	}

	st = createId_( rect.w, rect.h, w, h );	if( !st ) return st;
	
	int old;
	glGet( GL_PACK_ALIGNMENT, old );
	glPixelStorei( GL_PACK_ALIGNMENT, 4 );
	glCopyTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, rect.x, rect.y, w, h, 0 );
	glPixelStorei( GL_PACK_ALIGNMENT, old );			
		
	unbind();
	return 0;
}

axStatus axGLTexture::subImageFromFrameBuffer( axVec2i offset, axRect2i rect ) {
	if( !id_ ) return -1;
	if( rect.w == 0 || rect.h == 0 ) return 0;

	axScope_GLTexture	scope_bind( *this );
	glCopyTexSubImage2D( target_, 0, offset.x, offset.y, rect.x, rect.y, rect.w, rect.h );

	return 0;
}

axStatus axGLTexture::loadFile ( const wchar_t* filename, bool gen_mipmap, int mi, int mx ) {
	destroy();
	axStatus st;
	axImage	img;
	st = img.loadFile( filename );		if( !st ) return st;
	return create( img, gen_mipmap, mi, mx );	
}

axStatus axGLTexture::loadFile( const char* filename, bool gen_mipmap, int mi, int mx  ) {
	destroy();
	axStatus st;
	axImage	img;
	st = img.loadFile( filename );		if( !st ) return st;
	return create( img, gen_mipmap, mi, mx );
}

bool	axGLTexture::needPow2_( int w, int h ) {
	bool b = ! ( ax_is_pow2(w) && ax_is_pow2(h) );
	if( !b ) return b;
#ifdef axUSE_OpenGL_ES 
	axGLContext* cx = axGLContext::getCurrent();
	if( cx->extension_GL_APPLE_texture_2D_limited_npot() ) {
		return false;
	}
#else
	if( GLEW_ARB_texture_non_power_of_two ) {
		return false;
	}
#endif		
	return true;
}

axStatus axGLTexture::create( const axImage &img, bool gen_mipmap, int mi, int mx ) {
	if( img.width() <= 0 || img.height() <= 0 ) {
		destroy();
		return 0;
	}
	
	axStatus st;
	target_ = GL_TEXTURE_2D;

	int gl_internal_fmt;
	int gl_src_fmt;
	int gl_data_type;
	
	st = format_( img.type(), gl_internal_fmt, gl_src_fmt, gl_data_type );
	if( !st ) { destroy(); return st; }

	if( needPow2_( img.width(), img.height() ) ) {
		int aw = ax_align_pow2( img.width() );
		int ah = ax_align_pow2( img.height() );
		
		if( bufferWidth_ != aw || bufferHeight_ != ah )  {
			st = createId_( img.width(), img.height(), aw, ah, gen_mipmap, mi, mx );
			if( !st ) return st;
			glTexImage2D( target_, 0, gl_internal_fmt, aw, ah, 0, gl_src_fmt, gl_data_type, NULL );
		}else{
			this->width_  = img.width();
			this->height_ = img.height();
		}		
		st = subImage( img );		if( !st ) return st;
	}else{
		st = createId_( img.width(), img.height(), img.width(), img.height(), gen_mipmap, mi, mx );
		if( !st ) return st;
		
		int unpack_align = 4;
		if( img.byteSizePerPixel() % 4 ) unpack_align = 1;
		
		int old_a;
		glGet( GL_UNPACK_ALIGNMENT, old_a );
		glPixelStorei( GL_UNPACK_ALIGNMENT, unpack_align );
		glTexImage2D( target_, 0, gl_internal_fmt, img.width(), img.height(), 0, gl_src_fmt, gl_data_type, img.pixelVoidPointer() );
		glPixelStorei( GL_UNPACK_ALIGNMENT, old_a );		
	}
	
	glTexParameteri( target_, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
	glTexParameteri( target_, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	unbind();
	return 0;
}
/*
axStatus axGLTexture::create_from_dds( const char *filename ) {
	axStatus st;
	FileStream fs;
	st = fs.open( filename );	if( !st ) return st;
	return create_from_dds( fs );
}

axStatus axGLTexture::create_cube_map_from_dds( const CubeMapFileName &filename ) {
	axStatus st;

	FileStream fs[cube_map_max];

	CubeMapStreamPtr s;
	s.resize_to_cap();;

	int i;
	for ( i=0; i<cube_map_max; i++ ) {
		st = fs->open( filename[i] );	if (!st) return st;
		s[i] = &fs[i];
	}
	return create_cube_map_from_dds( s );
}

axStatus axGLTexture::create_from_dds( Stream &s ) {
	if ( !GLEW_ARB_texture_compression ) return -1;

	axStatus st;
	DdsFile dds;
	DdsFile::DDSData buf;
	st = dds.open( s );				if (!st) return st;
	st = dds.read_pixels( buf );	if (!st) return st;

	bool is_cube_map = dds.is_cube_map();
	uint32_t ogltarget_, ogltarget__start, ogltarget__end;
	if ( is_cube_map ) {
		target_ = GL_TEXTURE_CUBE_MAP_ARB;
		ogltarget__start = GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB;
		ogltarget__end = GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB + axGLTexture::cube_map_max - 1;
	} else {
		target_ = GL_TEXTURE_2D;
		ogltarget__start = ogltarget__end = GL_TEXTURE_2D;
	}
	int gl_internal_fmt;
	int block_size;

	st = _get_gl_type( buf.fmt, gl_internal_fmt, block_size );			if (!st) return st;
	st = _createid_( buf.w, buf.w, buf.w, buf.w, !dds.has_mipmap() );	if (!st) return st;

	int offset = 0;
	for ( ogltarget_=ogltarget__start; ogltarget_<=ogltarget__end; ogltarget_++ ) {
		int w = buf.w;
		int h = buf.h;
		int lv, lv_max, size;
		lv_max = max( 1, buf.mipmap_count );
		for( lv=0; lv<lv_max; lv++ ) {
			if( w == 0 ) w = 1;
			if( h == 0 ) h = 1;

			size = ((w+3)/4) * ((h+3)/4) * block_size;

			glCompressedTexImage2DARB( ogltarget_, lv, gl_internal_fmt, w, h, 0, size, buf.data.ptr() + offset );

			offset += size;

			// Half the image size for the next mip-map level...
			w /= 2;
			h /= 2;
		}
	}

	unbind();
	return 0;
}

axStatus axGLTexture::create_cube_map_from_dds( CubeMapStreamPtr &s ) {
	if ( !GLEW_ARB_texture_compression ) return -1;
	target_ = GL_TEXTURE_CUBE_MAP_ARB;

	axStatus st;
	DdsFile dds;
	DdsFile::DDSData buf;
	int gl_internal_fmt;
	int block_size;
	int i;

	for ( i=0; i<cube_map_max; i++ ) {
		st = dds.open( *(s[i]) );			if (!st) { if (id_) unbind(); destroy(); return st; }
		st = dds.read_pixels( buf );	if (!st) { if (id_) unbind(); destroy(); return st; }
		st = _get_gl_type( buf.fmt, gl_internal_fmt, block_size );	if (!st) { if (id_) unbind(); destroy(); return st; }

		if ( buf.w != buf.h )	 { if (id_) unbind(); destroy(); return axStatus::invalid_param; }
		if ( dds.is_cube_map() ) { if (id_) unbind(); destroy(); return axStatus::invalid_param; }
		if ( i == 0 ) { // first target
			st = _createid_( buf.w, buf.h, buf.w, buf.h );			if (!st) return st;
		}

		int offset = 0;
		int w = buf.w;
		int h = buf.h;
		int lv, lv_max, size;
		lv_max = max( 1, buf.mipmap_count );
		for( lv=0; lv<lv_max; lv++ ) {
			if( w == 0 ) w = 1;
			if( h == 0 ) h = 1;

			size = ((w+3)/4) * ((h+3)/4) * block_size;

			glCompressedTexImage2DARB( GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB + i, lv, gl_internal_fmt, w, h, 0, size, buf.data.ptr() + offset );

			offset += size;

			// Half the image size for the next mip-map level...
			w /= 2;
			h /= 2;
		}
	}

	unbind();
	return 0;
}
*/

axStatus axGLTexture::createEmpty( int w, int h, GLint internal_format, GLenum format, bool gen_mipmap, int mi, int mx ) {
	axStatus	st;

	int buf_w = w;
	int buf_h = h;
	
	if( needPow2_(w,h) ) {
		buf_w = ax_align_pow2( w );
		buf_h = ax_align_pow2( h );
	}
	
	if( this->bufferWidth_ != buf_w || this->bufferHeight_ != buf_h || target_ != GL_TEXTURE_2D ) {
		target_ = GL_TEXTURE_2D;
		destroy();
		st = createId_( w, h, buf_w, buf_h, gen_mipmap, mi, mx ); if( !st ) return st;
		//bind(); //createId will bind already
	}else{
		bind();
	}

	glTexImage2D( GL_TEXTURE_2D, 0, internal_format, buf_w, buf_h, 0, format, GL_UNSIGNED_BYTE, NULL);
	unbind();
	return 0;
}

axStatus axGLTexture::subImage( const axImage &img, int x, int y, GLenum target ){
	axStatus st;

	axScope_GLTexture	scope_bind( *this );
	if( img.width() + x > bufferWidth_ || img.height() + y > bufferHeight_ ) {
		assert(false);
		return -1;
	}

	int unpack_align = 4;
	if( img.byteSizePerPixel() % 4 ) unpack_align = 1;

	int gl_internal_fmt;
	int gl_src_fmt;
	int gl_data_type;
	st = format_( img.type(), gl_internal_fmt, gl_src_fmt, gl_data_type );
	if( !st ) {
		unbind();
		return st;
	}

	int old_a;
	glGet( GL_UNPACK_ALIGNMENT, old_a );
	glPixelStorei( GL_UNPACK_ALIGNMENT, unpack_align );
	glTexSubImage2D( target, 0, x, y, img.width(), img.height(), gl_src_fmt, gl_data_type, img.pixelVoidPointer() );
	glPixelStorei( GL_UNPACK_ALIGNMENT, old_a );
	
	return 0;
}

#ifndef axUSE_OpenGL_ES	
	
axStatus axGLTexture::saveImage( axImage &img ) {
	if ( !isValid() ) return axStatus::not_initialized;
	if ( target_ != GL_TEXTURE_2D ) return axStatus::GLTexture_unsupported_color_type;

	axScope_GLTexture	scope_bind( *this );
	GLenum target = GL_TEXTURE_2D;
	axStatus st;
	GLint w, h, internal_fmt, fmt = 0;
	glGetTexLevelParameteriv( target, 0, GL_TEXTURE_WIDTH, &w );
	glGetTexLevelParameteriv( target, 0, GL_TEXTURE_HEIGHT, &h );
	glGetTexLevelParameteriv( target, 0, GL_TEXTURE_INTERNAL_FORMAT, &internal_fmt );

	axColor::Type	type = axColor::t_null;
	switch ( internal_fmt ) {
		case GL_RGB8:				type = axColor::t_RGBb;		fmt = GL_RGB;				break;
		case GL_RGBA8:				type = axColor::t_RGBAb;	fmt = GL_RGBA;				break;
		case GL_ALPHA8:				type = axColor::t_Ab;		fmt = GL_ALPHA;				break;
		case GL_LUMINANCE8:			type = axColor::t_Yb;		fmt = GL_LUMINANCE;			break;
		case GL_LUMINANCE8_ALPHA8:	type = axColor::t_YAb;		fmt = GL_LUMINANCE_ALPHA;	break;
		default:
			st = axStatus::GLTexture_unsupported_color_type;
	}
	if (!st) { unbind(); return st; }
	st = img.create( type, w, h );	if (!st) { unbind(); return st; }
	glGetTexImage( target, 0, fmt, GL_UNSIGNED_BYTE, img.pixelVoidPointer() );

	return 0;
}
	
axStatus axGLTexture::getColorType( axColor::Type &type ) const {
	if ( !id_ ) return axStatus::not_initialized;

	axScope_GLTexture	scope_bind( *this );
	GLint internal_fmt;
	glGetTexLevelParameteriv( target_, 0, GL_TEXTURE_INTERNAL_FORMAT, &internal_fmt );
	switch ( internal_fmt ) {
		case GL_RGB:				type = axColor::t_RGBb;	break;
		case GL_RGBA:				type = axColor::t_RGBAb;	break;
		case GL_ALPHA:				type = axColor::t_Ab;		break;
		case GL_LUMINANCE:			type = axColor::t_Yb;		break;
		case GL_LUMINANCE_ALPHA:	type = axColor::t_YAb;	break;
		default:
			unbind();
			return axStatus::GLTexture_unsupported_color_type;
	}
	return 0;
}
 
#endif //#ifndef axUSE_OpenGL_ES	

axStatus axGLTexture::createFromText( axFont &font, const wchar_t *text, bool gen_mipmap, int mi, int mx  ) {
	axStatus st;
	axImage img;
	st = img.createFromText( font, text );			if( !st ) return st;
	st = create( img, gen_mipmap, mi, mx );			if( !st ) return st;
	return 0;
}

axStatus axGLTexture::createFromTextInRect( axFont &font, const wchar_t *text, int width, int height, axAlignment align, bool gen_mipmap, int mi, int mx  ) {
	axStatus st;
	axImage img;
	st = img.createFromTextInRect( font, text, width, height, align );	if( !st ) return st;	
	st = create( img, gen_mipmap, mi, mx );							if( !st ) return st;
	return 0;
}
	
	
axStatus axGLTexture::createId_( int w, int h, int buf_w, int buf_h, bool gen_mipmap, int mi, int mx  ) {
	if( ! id_ ) glGenTextures( 1, &id_ );

	bind();

	this->width_ = w;
	this->height_ = h;
	this->bufferWidth_  = buf_w;
	this->bufferHeight_ = buf_h;

	if( mi == 0 ) {
		if( gen_mipmap ) { 
			mi = GL_LINEAR_MIPMAP_LINEAR;
		}else {
			mi = GL_LINEAR; //GL_NEAREST;
		}
	}
	if( mx == 0 ) {
		mx = GL_LINEAR;
	}
	
	switch( target_ ) {
		case GL_TEXTURE_2D:
			setGenMipmap( gen_mipmap, mi, mx );
			break;
		default:
			setMinMagFilter( mi, mx );
			break;
	}
	return 0;
}

axStatus axGLTexture::blt ( const axRect2f &v, const axRect2f &t, bool keep_aspect_ratio ) const {
	if( v.w == 0 || v.h == 0 ) return 0;
	if( t.w == 0 || t.h == 0 ) return 0;

	if( bufferWidth_ == 0 || bufferHeight_ == 0 ) return 0;

	switch( target_ ) {
		case GL_TEXTURE_2D: {
			axScope_GLTexture	scope_bind( *this );
			float tx = t.x / bufferWidth_;
			float ty = t.y / bufferHeight_;
			float tr = t.right()  / bufferWidth_;
			float tb = t.bottom() / bufferHeight_;

			axVec2f uv[4];
			uv[0].set( tx, ty );
			uv[1].set( tr, ty );
			uv[2].set( tr, tb );
			uv[3].set( tx, tb ); 
						
			axVec2f vtx[4];
			if( keep_aspect_ratio ) {
				float rw = v.w / t.w;
				float rh = v.h / t.h;
				float r = ax_min( rw, rh );

				axRect2f p;

				p.w = t.w * r;
				p.h = t.h * r;
				p.x = v.x + ( v.w - p.w ) / 2.0f;
				p.y = v.y + ( v.h - p.h ) / 2.0f;

				vtx[0].set( p.x,   p.y );
				vtx[1].set( p.right(), p.y );
				vtx[2].set( p.right(), p.bottom() );
				vtx[3].set( p.x,   p.bottom() );
			}else{
				vtx[0].set( v.x,   v.y );
				vtx[1].set( v.right(), v.y );
				vtx[2].set( v.right(), v.bottom() );
				vtx[3].set( v.x,   v.bottom() );
			}

			
			axScopeGLVertexPointer		vp( vtx );		
			axScopeGLTexCoordPointer	uvp( uv );	
			
			glDrawArrays( GL_TRIANGLE_FAN, 0, 4 );
		}break;	
	}//switch
	return 1;
}
	
axStatus axGLTexture::bltCenter ( float x, float y ) const {
	float w2 = (float)width_/2.0f;
	float h2 = (float)height_/2.0f;
	return blt( axRect2f( x-w2, y-h2, (float)width_, (float)height_ ) ); 
}
	
axStatus	axGLTexture::sprite3D( const axVec3f &pos, const axVec3f &euler_rotation, const axVec2f &scale ) {	
	axVec2f s = scale * 0.5f;
	
	axVec3f	vtx[4];
	vtx[0].set( -s.x,-s.y, 0 );
	vtx[1].set(  s.x,-s.y, 0 );
	vtx[2].set(  s.x, s.y, 0 );
	vtx[3].set( -s.x, s.y, 0 );

	float tx = 0.0f / bufferWidth_;
	float ty = 0.0f / bufferHeight_;
	float tr = (float)width_  / bufferWidth_;
	float tb = (float)height_ / bufferHeight_;
	
	axVec2f uv[4];
	uv[0].set( tx, ty );
	uv[1].set( tr, ty );
	uv[2].set( tr, tb );
	uv[3].set( tx, tb ); 	
		
	axMatrix4f	mat;
	mat.setRotateX( euler_rotation.x );
	mat.rotateY( euler_rotation.y );
	mat.rotateZ( euler_rotation.z );
	
	int i;
	for( i=0; i<4; i++ ) {
		vtx[i] = (vtx[i] * mat) + pos;
	}
	
	axScope_GLTexture	scope_bind( *this );
	
	axScopeGLVertexPointer		vp( vtx );
	axScopeGLTexCoordPointer	tp( uv );
	
	glDrawArrays( GL_TRIANGLE_FAN, 0, 4 );	
	return 0;
}


void axGLTexture::setMagFilter( int v )		{ glTexParameteri( target_, GL_TEXTURE_MAG_FILTER, v ); }
void axGLTexture::setMinFilter( int v )		{ glTexParameteri( target_, GL_TEXTURE_MIN_FILTER, v ); }

void axGLTexture::setWrap	( int s, int t ) { 
	glTexParameteri( target_, GL_TEXTURE_WRAP_S, s );
	glTexParameteri( target_, GL_TEXTURE_WRAP_T, t );
}

void axGLTexture::setEnvMode	( int v )					{ glTexEnvi ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, v ); }
void axGLTexture::setEnvColor	( const axColorRGBAf& v )	{ glTexEnvfv( GL_TEXTURE_ENV, GL_TEXTURE_ENV_COLOR, v.asPointer() ); }

void axGLTexture::setEnvCombine( int rgb_mode, int alpha_mode ) { 
	glTexEnvi( GL_TEXTURE_ENV, GL_COMBINE_RGB,   rgb_mode );
	glTexEnvi( GL_TEXTURE_ENV, GL_COMBINE_ALPHA, alpha_mode ); 
}

void axGLTexture::setEnvCombineSource( GLenum index, int rgb_src, int alpha_src, int rgb_op , int alpha_op ) {
	glTexEnvi( GL_TEXTURE_ENV, GL_SRC0_RGB		 + index, rgb_src );
	glTexEnvi( GL_TEXTURE_ENV, GL_OPERAND0_RGB   + index, rgb_op );
	glTexEnvi( GL_TEXTURE_ENV, GL_SRC0_ALPHA	 + index, alpha_src );
	glTexEnvi( GL_TEXTURE_ENV, GL_OPERAND0_ALPHA + index, alpha_op );
}


void axGLTexture::setGenMipmap( bool b, int mi, int mx  ) { 
	setMinMagFilter( mi, mx );
#ifndef axUSE_OpenGL_ES	
	if( b ) {
		glTexParameteri( target_, GL_GENERATE_MIPMAP_SGIS, 1 );
	}else{
		glTexParameteri( target_, GL_GENERATE_MIPMAP_SGIS, 0 ); 
	}
#else
	if( b ) {
		glTexParameteri( target_, GL_GENERATE_MIPMAP, 1 );
	}else{
		glTexParameteri( target_, GL_GENERATE_MIPMAP, 0 ); 
	}
#endif // not axUSE_OpenGL_ES
}


axStatus axGLTexture::onTake( axGLTexture &src ) {
	if( this == &src ) { assert( false ); return 0; }

	destroy();
	id_			  = src.id_;
	target_		  = src.target_;
	width_		  = src.width_;
	height_		  = src.height_;
	bufferWidth_  = src.bufferWidth_;
	bufferHeight_ = src.bufferHeight_;

	src.init_();
	return 0;
}
