#include <ax/App/opengl/axGLRenderBuffer.h>

axGLRenderBuffer::axGLRenderBuffer() {
	_id = 0;
}

axGLRenderBuffer::~axGLRenderBuffer() {
	destroy();
}
	
axStatus axGLRenderBuffer::create( int width, int height, GLenum internalFormat ) {
#ifndef axUSE_OpenGL_ES
	if( !GLEW_EXT_framebuffer_object ) return axStatus::opengl_unsupported_extension;
#endif
		
	destroy();
	glGenRenderbuffers(1, &_id);
	
	bind();
	glRenderbufferStorage( GL_RENDERBUFFER, internalFormat, width, height );
	unbind();
	
	return 0;
}

void axGLRenderBuffer::destroy() {
	if( _id ) {
		glDeleteRenderbuffers( 1, &_id );
		_id = 0;
	}
}

void axGLRenderBuffer::bind() {
	glBindRenderbuffer( GL_RENDERBUFFER, _id );
}

void axGLRenderBuffer::unbind() {
	glBindRenderbuffer( GL_RENDERBUFFER, 0 );
}

