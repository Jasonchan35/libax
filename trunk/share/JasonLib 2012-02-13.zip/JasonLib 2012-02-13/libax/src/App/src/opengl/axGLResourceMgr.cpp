#include <ax/App/opengl/axGLResourceMgr.h>

axGLTextureResNode::axGLTextureResNode() {
	ctx_ = NULL;
}

//virtual 
axGLTextureResNode::~axGLTextureResNode() {
	if( ctx_ ) {
		axGLResourceMgr::MD md( ctx_->md_ );
		md->textures.remove( this );
		ctx_ = NULL;
	}
}

axStatus	axGLResourceMgr::load( axGLTextureRes& res, const char* filename ) {
	axStatus st;
	uint32_t h = ax_string_hash( filename );

	MD	md( md_ );
	axGLTextureResNode* p_ = md->textures.getListHead( h );
	for( ; p_; p_=p_->next() ) {
		if( p_->filename_.equals( filename ) ) {
			res.ref( p_ );
			return 0;
		}
	}

	axGLTextureRes	r;
	
	st = r.newObject();						if( !st ) return st;		
	st = r->filename_.set( filename );		if( !st ) return st;
	st = r->loadFile( filename );			if( !st ) return st;

	md->textures.append( r.ptr() );
	r->ctx_ = this; //set ctx for auto remove in textures list
	
	res = r;
	return 0;
}

