/*  Filename = axGLApp.cpp / Project = awegame
 *  Created by Jason on 02/12/2009.
 *  Copyright 2009 Awenix. All rights reserved. */

#include <ax/App/GLApp/axGLApp.h>
#include <ax/App/GLApp/axGLAppMode.h>
#include <ax/core/system/axAndroid.h>

//static
axGLApp* axGLApp::getInstance () {
	static	axGLApp	app;
	return 	&app;
}

axGLApp::axGLApp() {
	expect_fps_ = 60;
	fps_time_ = 0;
	fps_frame_ = 0;	
	orientation_ = 0;
	autoOrientation_ = false;
	contentScaleFactor_ = 1;
	currentMode_ = NULL;
	enableAccelerometer_ = false;
	_os_ctor();
}

axGLApp::~axGLApp() {
	onDestroy_();
	_os_dtor();
}
		
//virtual 
axStatus	axGLApp::onCreate() {
	axPRINT_FUNC_NAME; 
	return 0;
}

//virtual 
void	axGLApp::onDestroy() {
	axPRINT_FUNC_NAME; 
}

axStatus axGLApp::onCreate_() {
	axStatus st;
		
	st = defaultUIFont_.create( NULL, 14 );	if( !st ) return st;
	st = onCreate();
	if( !st ) {
//		exit_msg_box( st, L"Cannot create application");
		return st;
	}
	return 0;
}

void axGLApp::setFrameRate	( float fps ) {
	expect_fps_ = fps;
	_os_setFrameRate();
}

void axGLApp::setTitleName ( const wchar_t* name ) {
	_os_setTitleName( name );
}

axStatus axGLApp::loadResource ( axGLTextureRes &out, const char* filename ) {
	return gl.resMgr_->load( out, filename );
}	
	
void axGLApp::onResize_( float w, float h ) {
	w *= contentScaleFactor_;
	h *= contentScaleFactor_;
	glViewport( axRect2f(0, 0, w, h) );
	onResize( w, h );
}

void axGLApp::onResize( float w, float h ) {
	axPRINT_FUNC_NAME;
	if( currentMode_ ) currentMode_->resize( w,h );
}

void	axGLApp::setWindowPos	( const axVec2f &pos  ) { _os_setWindowPos(pos); }
void	axGLApp::setWindowSize	( const axVec2f &size ) { _os_setWindowSize(size); }
void	axGLApp::setContentSize	( const axVec2f &size ) { _os_setContentSize(size); }

axVec2f axGLApp::windowPos		() const { return _os_windowPos(); }
axVec2f axGLApp::windowSize		() const { return _os_windowSize(); }
axVec2f axGLApp::contentSize	() const { return _os_contentSize(); }

axStatus axGLApp::setFullScreen	( bool b ) {
	return _os_setFullScreen(b);
}

axStatus axGLApp::createNextMode_( axGLAppMode* &new_mode, axGLAppMode* prevMode ) {
	new_mode = NULL;
	axStatus	st;
	axAutoPtr<axGLAppMode> p;
	p.ref( nextModeCreator_() );
	
	st = p->create( this, prevMode );	if( !st ) return st;	
	new_mode = p.unref();
	return 0;
}

void axGLApp::doPopMode_() {
	axGLAppMode *prevMode_ = currentMode_->prevMode_;
	currentMode_->onDestroy();
	delete currentMode_;
	currentMode_ = prevMode_;
	if( prevMode_ ) {
		prevMode_->onPoped();
	}
}

void axGLApp::onAccelerate_	( const axVec3f &a ) {
	renderRequest.acceleration_ = a;
}

void axGLApp::onKeyEvent( axGLAppKeyEvent &ev ) {
	if( currentMode_ ) currentMode_->onKeyEvent( ev );
}

void axGLApp::onKeyEvent_( int event, int keyCode, const char* characters, const char* charactersIgnoringModifiers ) {
	axGLAppKeyEvent	&ev = keyEvent;
	ev.event	  = event;
	ev.keyCode    = keyCode;
	ev.characters.set( characters );
	ev.charactersIgnoringModifiers.set( charactersIgnoringModifiers );
	
	onKeyEvent( keyEvent );
}

void axGLApp::onMouseEvent( axGLAppMouseEvent &ev ) {
	if( currentMode_ ) currentMode_->onMouseEvent( ev );
}

void axGLApp::onMouseEvent_( int event, axSize eventButton, const axVec2f& pos, const axVec3f& scroll, float pressure, double timestamp ) {
	axGLAppMouseEvent &t = mouseEvent;
	t.event = event;
	t.eventButton  = eventButton;
	t.lastPos = pos;
	t.pos = pos;
	t.deltaPos = pos - t.lastPos;

	t.scroll	= scroll;
	t.pressure	= pressure;
	t.eventTime	= timestamp;

	onMouseEvent( t );
}

void axGLApp::onTouchEvent( axGLAppTouchEvent &ev ) {
	if( currentMode_ ) currentMode_->onTouchEvent( ev );
}

void axGLApp::onTouchEvent_	( int event, axGLAppTouch::TouchId touchId, const axVec2f &pos, float pressure, double timestamp ) {
	axStatus st;
	axSize idx = -1;
	
	axVec2f scaledPos = pos;
	#if !axOS_MacOSX
		scaledPos *= contentScaleFactor_;
	#endif
	
	switch( event ) {
		case kEventDown: {
			st = touches.incSize(1);
			if( !st ) {
				ax_log("axGLApp::onTouchEvent_ error touchs.incSize ");
				return;
			}
			idx = touches.size() - 1;
			
			axGLAppTouch& t = touches[idx];			
			t.touchId = touchId;
			t.downTimestamp = timestamp;
		}break;
		default: {
			st = touches.getTouchIndexById( idx, touchId ); 
			if( !st )  {
				ax_log("axGLApp::onTouchEvent_ touchId({?}} not found", touchId );
				return;
			}
			#if axOS_MacOSX
				//the object will change in MacOSX, so we need update it
				axGLAppTouch& t = touches[idx];			
				t.touchId = touchId;
			#endif
		}
	}
		
	axGLAppTouch& t = touches[idx];	
	t.pos	    = scaledPos;	
	t.pressure	= pressure;

	axGLAppTouchEvent	touchEvent;
	
	touchEvent.event		= event;
	touchEvent.touchIndex	= idx;
	touchEvent.pos			= scaledPos;
	touchEvent.timestamp	= timestamp;
	
	switch( event ) {
		case kEventDown:
		case kEventUp:
		case kEventMove:
		case kEventCancel: {
			onTouchEvent( touchEvent );
		}break;
	}
	
	switch( event ) {
		case kEventUp:
		case kEventCancel: {
			touches.remove( idx );
		}break;
	}
}

axStatus axGLApp::onBecomeActive		()	{ 
	axPRINT_FUNC_NAME; 
	if( !currentMode_ ) return 0; 
	return currentMode_->onBecomeActive();
	
}
void axGLApp::onResignActive		()	{ 
	axPRINT_FUNC_NAME; 
	if( currentMode_ ) currentMode_->onResignActive();
}



void axGLApp::onFrame( axGLAppRenderRequest &req ) {
	if( currentMode_ ) currentMode_->doFrame( req );
}

void axGLApp::onFrame_() {
	axStatus st;
	if( needChangeMode_ ) {	
		switch( needChangeMode_ ) {
			case m_change_mode: {
				axGLAppMode *prevMode_ = NULL;
				if( currentMode_ ) {
					prevMode_ = currentMode_->prevMode_;
					currentMode_->onDestroy();
					delete	currentMode_;
				}
				axGLAppMode *new_mode = NULL;
				st = createNextMode_( new_mode, prevMode_ );
				if( !st ) {
					ax_log("axGLApp::changeMode  createNextMode error: {?}", st );
					assert(false);
					break;
				}else{
					currentMode_ = new_mode;
				}
			}break;
			
			case m_push_mode: {
				currentMode_->onPushed();				
				axGLAppMode *new_mode = NULL;
				st = createNextMode_( new_mode, currentMode_ );
				if( !st ) {
					ax_log("axGLApp::pushMode  createNextMode error: {?}", st );
					assert(false);
					break;
				}else{
					currentMode_ = new_mode;
				}
			}break;
			
			case m_pop_mode: {
				doPopMode_();
			}break;
		}
		frameTimer_.reset();
		needChangeMode_ = m_unchange;
	}
	
	if( ! currentMode_ ) {
		quit();
		return;
	}

	if( fps_time_ >= 1 ) {
		fps_ = fps_frame_ / fps_time_;
		fps_time_ = 0;
		fps_frame_ = 0;
	}
	
	renderRequest.frameTime_ = (float)frameTimer_.getAndReset();

	fps_frame_++;
	fps_time_ += renderRequest.frameTime();
	onFrame( renderRequest );
		
	if( ! contentSize().isAny(0) ) {
		gl.swapBuffers();
	}
	
}

void axGLApp::onDestroy_() {
	while( currentMode_ ) {
		doPopMode_();
	}
	onDestroy();
}

axStatus axGLApp::run_( const char* appName, ModeCreatorFunc m ) {
	axGLApp* app = getInstance();
	axStatus st;
	st = app->setAppName( appName );		if( !st ) return st;
	
	app->nextModeCreator_ = m;
	app->needChangeMode_ = m_change_mode;

	st = app->_os_run();	if( !st ) { assert( false ); return st; }

	if( !st ) {
		ax_log( "\n ==== program end - return:{?} ====", st );
	}
	return st;
}

void axGLApp::quit() {
	_os_quit();
}


axStatus	axGLApp::pushMode_ ( ModeCreatorFunc m ) {
	nextModeCreator_ = m;
	needChangeMode_ = m_push_mode;
	return 0;
}

axStatus axGLApp::changeMode_ ( ModeCreatorFunc m ) {
	nextModeCreator_ = m;
	needChangeMode_ = m_change_mode;
	return 0;
}

void axGLApp::popMode() {
	needChangeMode_ = m_pop_mode;
}

void	axGLApp :: setStatusBarVisible	  ( bool b,   bool animated ) {
	_os_setStatusBarVisible( b, animated );
}

void	axGLApp :: setOrientation( float  angle, bool animated ) {
	_os_setOrientation( angle, animated );
}

void	axGLApp::setAutoOrientation( bool b ) {
	if( b == autoOrientation_ ) return;
	autoOrientation_ = b;
	_os_setAutoOrientaton( b );
}
	
axStatus	axGLApp::enableAccelerometer( bool b ) {
	enableAccelerometer_ = b;
	return _os_enableAccelerometer( b );
}	
		
/*
void axGLApp::set2DMode() {
	gl_2D_mode();
}
 */
	
float	axGLApp::orientation() { return orientation_; }

#if 0
#pragma mark ================= MacOS X ====================
#endif
#ifdef axOS_MacOSX

@interface axGLApp_Window : NSWindow < NSWindowDelegate > {	
}
@end

@implementation axGLApp_Window
- (void)windowWillClose:(NSNotification *)notification {
	axGLApp::getInstance()->quit();
}
-(void) onTimer:(id)sender {
	axGLApp::getInstance()->onFrame_();
}
@end
//-----

@interface axGLApp_GLView : NSOpenGLView {
}
@end

@implementation axGLApp_GLView
- (BOOL)isFlipped {
    return YES;
}
- (BOOL)acceptsFirstResponder {
    return YES;
}

- (BOOL)becomeFirstResponder {
    return YES;
}

- (BOOL)resignFirstResponder {
    return YES;
}


- (void) reshape {
	axGLApp*	app = axGLApp::getInstance();
	axVec2f s = app->_os_contentSize();
	app->onResize_(s.x, s.y);
}

- (void)keyDown:(NSEvent *)theEvent {
	axGLApp::getInstance()->onKeyEvent_( axGLApp::kEventDown, [theEvent keyCode], [[theEvent characters] UTF8String], [[theEvent charactersIgnoringModifiers] UTF8String] );
}
- (void)keyUp:(NSEvent *)theEvent {	
	axGLApp::getInstance()->onKeyEvent_( axGLApp::kEventUp,   [theEvent keyCode], [[theEvent characters] UTF8String], [[theEvent charactersIgnoringModifiers] UTF8String] );
}

-(void)onMouseEvent:(NSEvent*)theEvent action:(int)action button:(NSInteger)button {
	axRect2f rect = [self bounds];
	axVec2f  pos = [theEvent locationInWindow];
	pos.y = rect.h - pos.y - 1;	
	axGLApp::getInstance()->onMouseEvent_( action, button, pos, axVec3f(0,0,0), [theEvent pressure], [theEvent timestamp] );
}

//---- move 
- (void)mouseMoved:			(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:0]; }
- (void)otherMouseMoved:	(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:[theEvent buttonNumber]-1]; }
- (void)rightMouseMoved:	(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:2]; }
//---- drag
- (void)mouseDragged:		(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:0]; }
- (void)otherMouseDragged:	(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:[theEvent buttonNumber]-1]; }
- (void)rightMouseDragged:	(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventMove button:2]; }
//---- down
- (void)mouseDown:			(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventDown button:0]; }
- (void)otherMouseDown:		(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventDown button:[theEvent buttonNumber]-1]; }
- (void)rightMouseDown:		(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventDown button:2]; }
//---- up
- (void)mouseUp:			(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventUp	button:0]; }
- (void)otherMouseUp:		(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventUp	button:[theEvent buttonNumber]-1]; }
- (void)rightMouseUp:		(NSEvent *)theEvent { [self onMouseEvent:theEvent action:axGLApp::kEventUp	button:2]; }
		
//--- touch

-(void) onTouchEventWithEvent:(NSEvent *)theEvent{
	/*
	NSSet* touches = [theEvent touchesMatchingPhase:NSTouchPhaseAny inView:self];	
	NSArray *ar = [touches allObjects];
	NSUInteger n  = [ar count];
	
	int action;
	axGLApp* app = axGLApp::getInstance();
	for( NSUInteger i=0; i<n; i++ ) {	
		NSTouch*	touchId = [ar objectAtIndex:i];
		switch( touchId.phase ) {
			case  NSTouchPhaseBegan:	  action = axGLApp::kEventDown;		break;
			case  NSTouchPhaseEnded:	  action = axGLApp::kEventUp;		break;
			case  NSTouchPhaseMoved:	  action = axGLApp::kEventMove;		break;
			case  NSTouchPhaseStationary: action = axGLApp::kEventNoChange;	break;
			case  NSTouchPhaseCancelled:  action = axGLApp::kEventCancel;	break;
			default:
				assert(false);
				continue;
		}
		axVec2f pos = [touchId normalizedPosition];
		pos.y = 1.0 - pos.y;
		pos *= [touchId deviceSize];
		app->onTouchEvent_( action, touchId, pos, 0, [theEvent timestamp] );
	}
	 */
}
- (void)touchesBeganWithEvent:		(NSEvent *)event { [ self onTouchEventWithEvent:event ]; [super touchesBeganWithEvent:event]; }
- (void)touchesEndedWithEvent:		(NSEvent *)event { [ self onTouchEventWithEvent:event ]; [super touchesEndedWithEvent:event];}
- (void)touchesMovedWithEvent:		(NSEvent *)event { [ self onTouchEventWithEvent:event ]; [super touchesMovedWithEvent:event];}
- (void)touchesCancelledWithEvent:	(NSEvent *)event { [ self onTouchEventWithEvent:event ]; [super touchesCancelledWithEvent:event];}

//------
- (id) initWithFrame:(NSRect)frameRect {
	axGLApp*	app = axGLApp::getInstance();
	axGLContext	&gl = app->gl;
	gl.create();
	
	self = [super initWithFrame:frameRect pixelFormat:gl.fmt_ ];
	if( !self ) return nil;

	[self setOpenGLContext:gl.ctx_];
	
	app->_os_setFrameRate();
	return self;
}
@end


//---------
@interface axGLApp_Delegate : NSObject < NSApplicationDelegate > {
	
}
@end

@implementation axGLApp_Delegate
- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
	axGLApp* app = axGLApp::getInstance();
	
	axGLApp_Window* win = [ axGLApp_Window  alloc ];
	app->win_ = win;
	
	[win setAcceptsMouseMovedEvents:YES];

	NSRect	contentRect = {{0,0},{640,480}};
	[win	initWithContentRect: contentRect 
			styleMask:	NSClosableWindowMask | NSResizableWindowMask | NSMiniaturizableWindowMask | NSTitledWindowMask
			backing:	NSBackingStoreBuffered  
			defer:		YES];
	[win setDelegate:win];
	[win setShowsResizeIndicator:true];
	[win setReleasedWhenClosed:true];
	[win center];
	
	axGLApp_GLView* glview = [ axGLApp_GLView alloc ];
	app->glview_ = glview;	
	
	[glview initWithFrame:contentRect];
	[glview setAcceptsTouchEvents:true];

	
//	[[win contentView] addSubview:glview];	
	[win setContentView:glview];
	[win makeKeyAndOrderFront:nil];
	
	app->_os_setFrameRate();
}

- (void)onFrame {
	axGLApp::getInstance()->onFrame_();
}

@end

void axGLApp::_os_setTitleName ( const wchar_t* name ) {
	[win_ setTitle:ax_toNSString(name) ];
}

axStatus	axGLApp::_os_run () {
	axScope_NSAutoreleasePool	pool;
	delegate_ = [[axGLApp_Delegate alloc] init];

	[NSApplication sharedApplication];
//	[NSBundle loadNibNamed:@"myMain" owner:NSApp];
	
	[NSApp setDelegate:delegate_];	
	[NSApp run];
//	NSApplicationMain(0,NULL);
//please don't add code below, since it will not run !!!	
	return 0;
}

void axGLApp::_os_ctor() {
	delegate_ = nil;
	_os_timer = nil;
}

void axGLApp::_os_dtor() {
	if( _os_timer ) {
		[_os_timer invalidate];
		_os_timer = nil;
	}
	if( delegate_ ) {
		[delegate_ release];
		delegate_ = nil;
	}
}

void	axGLApp::_os_quit		() {
	[NSApp stop:nil];
}

void	axGLApp ::_os_setFrameRate() {
	//!! Not use CVDisplayLink since the callback function will be call from other thread instead main thread
	if( _os_timer ) {
		[_os_timer invalidate];
		_os_timer = nil;
	}
	
	float fps = expect_fps_;
	if( fps <= 0 ) return; //stop animation
	
	_os_timer = [NSTimer scheduledTimerWithTimeInterval:(NSTimeInterval)(1.0/fps) target:win_ selector:@selector(onTimer:) userInfo:nil repeats:TRUE];
}

axStatus	axGLApp::_os_setFullScreen	( bool  b ) {
	return axStatus::not_implemented;
}

void	axGLApp :: _os_setWindowPos( const axVec2f & size ) {
	NSRect	rect = [win_ frame];
	rect.origin.x = size.x;
	rect.origin.y = size.y;
	[win_ setFrame:rect display:true animate:false];	
}

void	axGLApp :: _os_setWindowSize( const axVec2f & size ) {
	NSRect	rect = [win_ frame];
	rect.size.width  = size.x;
	rect.size.height = size.y;
	[win_ setFrame:rect display:true animate:false];
}

void	axGLApp :: _os_setContentSize( const axVec2f & size ) {
	NSRect	rect = [win_ frame];
	rect.size.width  = size.x;
	rect.size.height = size.y;
	rect = [win_ frameRectForContentRect:rect];
	[win_ setFrame:rect display:true animate:false];
}

axVec2f	axGLApp::_os_windowPos() const {
	NSRect	rect = [win_ frame];
	return axVec2f( rect.origin );
}

axVec2f	axGLApp::_os_windowSize() const {
	NSRect	rect = [win_ frame];
	return axVec2f( rect.size );
}

axVec2f	axGLApp::_os_contentSize() const {
	return axVec2f( [glview_ bounds].size );
}

axStatus	axGLApp::_os_enableAccelerometer ( bool b ) {
	return axStatus::not_implemented;
}

void	axGLApp::_os_setStatusBarVisible ( bool b,     bool animated ) {
}

void	axGLApp::_os_setOrientation ( float  angle, bool animated ) {
}

void	axGLApp::_os_setAutoOrientaton( bool b ) {
}
	
	
#endif //aOS_MacOSX


#if 0
#pragma mark ================= iOS ====================
#endif

#ifdef axOS_iOS

//------------------
@interface axGLApp_Window : UIWindow {
}
@end

@implementation axGLApp_Window  
-(void)setFrame:(CGRect)frame {
	[super setFrame:frame];
	axGLApp::getInstance()->_os_onResize();
}
@end

@interface axGLApp_GLView : UIView {
}
@end


@implementation axGLApp_GLView
+ (Class)layerClass {
//this View has OpenGL layer
    return [CAEAGLLayer class];
}

- (void)layoutSubviews {
	axGLApp* app = axGLApp::getInstance();
	if ([self respondsToSelector: NSSelectorFromString(@"contentScaleFactor")]) {
		[self setContentScaleFactor:[[UIScreen mainScreen] scale]];
		app->contentScaleFactor_ = [[UIScreen mainScreen] scale];
	}	
	
	app->gl.makeCurrent();
	app->gl.createBuffers(); 
}

-(void) onTouchEvent:(NSSet *)touches withEvent:(UIEvent *)event withAction:(int)action {
	NSArray *ar = [touches allObjects];
	unsigned n  = [ar count];
	
	axGLApp* app = axGLApp::getInstance();
	for( unsigned i=0; i<n; i++ ) {
		id	touchId = [ar objectAtIndex:i];
		UITouch*	touch = touchId;
		app->onTouchEvent_( action, touchId, axVec2f( [touch locationInView:self] ), 0, touch.timestamp );
	}
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event { 
	[ self onTouchEvent:touches withEvent:event withAction:axGLApp::kEventDown ];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event { 
	[ self onTouchEvent:touches withEvent:event withAction:axGLApp::kEventUp ];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event { 
	[ self onTouchEvent:touches withEvent:event withAction:axGLApp::kEventMove ];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event { 
	[ self onTouchEvent:touches withEvent:event withAction:axGLApp::kEventCancel ];
}

@end  

//-----------------------------

@interface axGLApp_Delegate : NSObject < UIApplicationDelegate, UIAccelerometerDelegate > {
	float _roll;
	float _pitch;
}
@end

@implementation axGLApp_Delegate
-(void)applicationDidFinishLaunching:(UIApplication *)application {  
	_roll = 0;
	_pitch = 0;
    application.idleTimerDisabled = YES; // we don't want the screen to sleep during our game 
	
	axStatus st;

	axGLApp* app = axGLApp::getInstance();
	
	axGLApp_Window* win = [axGLApp_Window alloc];
	app->win_ = win;
	
	UIView* rotate_view = [UIView alloc];
	app->rotate_view_ = rotate_view;
	
	axGLApp_GLView* glview = [axGLApp_GLView alloc];
	
	[glview setMultipleTouchEnabled:YES];
	app->glview_ = glview;
	
	[win init];
	[rotate_view init];
	[glview init];

	[win addSubview: rotate_view];
	[rotate_view addSubview: glview];
	
	st = app->gl.create( glview );
	if( !st ) {
		ax_log( "cannot create OpenGL context" );
		assert(false);
	}
	
	[win makeKeyAndVisible];
	
	CGRect screen_rect = [[UIScreen mainScreen] bounds];

	[ [win superview] setNeedsDisplayInRect:screen_rect]; 
	[win setFrame: screen_rect];
	[win setNeedsDisplay];

	app->onCreate_();
	[self applicationWillEnterForeground:nil];		
}

- (void)accelerometer:(UIAccelerometer *)meter didAccelerate:(UIAcceleration *)acc {
	axGLApp::getInstance()->onAccelerate_( axVec3f( acc.x, acc.y, acc.z ) );
}	

- (void) didRotate:(NSNotification *)notification {	
	UIDeviceOrientation o = [UIDevice currentDevice].orientation;
	switch( o ) {
		case  UIDeviceOrientationUnknown: return;
		case UIDeviceOrientationPortrait:			_roll  = 0;		break;
		case UIDeviceOrientationPortraitUpsideDown: _roll  = 180;	break;
		case UIDeviceOrientationLandscapeLeft:		_roll  = 90;	break;
		case UIDeviceOrientationLandscapeRight:		_roll  = 270;	break;
		case UIDeviceOrientationFaceUp:				_pitch = 90;	break;
		case UIDeviceOrientationFaceDown:			_pitch = -90;	break;
	}
	axGLApp::getInstance()->_os_onOrientationDidChange( _roll, _pitch );
}

- (void)onFrame {
	axGLApp::getInstance()->onFrame_();
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
	axGLApp* app = axGLApp::getInstance();
	app->display_link_ = [CADisplayLink displayLinkWithTarget:self selector: @selector(onFrame) ];
	[app->display_link_ addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
	app->onBecomeActive();
}

- (void)applicationWillResignActive:(UIApplication *)application {
	axGLApp *app = axGLApp::getInstance();
	if( app->display_link_ ) {
		[app->display_link_ invalidate];
		app->display_link_ = nil;
	}
	app->onResignActive();
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
	axGLApp::getInstance()->onEnterBackground();
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
	axGLApp::getInstance()->onEnterForeground();
}

- (void)applicationWillTerminate:(UIApplication *)application {
	[self applicationWillResignActive:nil];
}
@end  

void axGLApp::_os_ctor() {
	glview_ = nil;
	rotate_view_ = nil;
	win_ = nil;
	display_link_ = nil;
}

void axGLApp::_os_dtor() {
	gl.destroy();

	if( glview_ ) {
		[glview_ release];
		glview_ = nil;
	}

	if( rotate_view_ ) {
		[rotate_view_ release];
		rotate_view_ = nil;
	}

	if( win_ ) {
		[win_ release];
		win_ = nil;
	}
}

void axGLApp::_os_quit() {
	//noting can do in iOS
}

axStatus axGLApp :: _os_run() {
	axScope_NSAutoreleasePool pool;
	[UIApplication sharedApplication];
	setCurrentDir( [[[NSBundle mainBundle ] resourcePath] UTF8String] );	
	
	axStatus st;
	UIApplicationMain( 0, NULL, @"UIApplication",@"axGLApp_Delegate" );
//please don't add code below, since it will not be run !!!
	return 0;
}

axStatus	axGLApp :: _os_enableAccelerometer( bool b ) {
	if( b ) {
		axGLApp_Delegate* d = (axGLApp_Delegate*) [UIApplication sharedApplication].delegate;
		[[UIAccelerometer sharedAccelerometer] setDelegate: d ];
	}else{
		[[UIAccelerometer sharedAccelerometer] setDelegate: NULL ];
	}
//	[[UIAccelerometer sharedAccelerometer] setUpdateInterval: interval_in_sec ];
	return 0;
}

axStatus axGLApp::_os_setFullScreen( bool b ) {
	return axStatus::not_supported;
}

void axGLApp::_os_setTitleName( const wchar_t* name ) {
}
	
void	axGLApp ::_os_setStatusBarVisible	  ( bool b,   bool animated ) {
	[ [UIApplication sharedApplication] setStatusBarHidden:(!b) withAnimation: UIStatusBarAnimationFade ];
	_os_onResize();
}

void	axGLApp ::_os_setOrientation( float  angle, bool animated ) {
	UIInterfaceOrientation ori;
	if( !rotate_view_ ) return;	
	angle = ax_angle_normalize_360( angle );
	
	if( angle < 45 ) {
		ori = UIInterfaceOrientationPortrait;
	}else if( angle < 90+45 ) {
		ori = UIInterfaceOrientationLandscapeRight;
	}else if( angle < 180+45 ) {
		ori = UIInterfaceOrientationPortraitUpsideDown;
	}else if( angle < 270+45 ) {
		ori = UIInterfaceOrientationLandscapeLeft;
	}else{
		ori = UIInterfaceOrientationPortrait;
	}
	[[UIApplication sharedApplication] setStatusBarOrientation:ori	animated:animated];	
	_os_onOrientationDidChange( angle, 0 );
}
	
void	axGLApp::_os_setAutoOrientaton( bool b ) {
	if( b ) {
		[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
		[[NSNotificationCenter defaultCenter] addObserver:[UIApplication sharedApplication].delegate 
											  selector:@selector(didRotate:) 
											  name:@"UIDeviceOrientationDidChangeNotification" 
											  object:nil];	
	}else{
		[[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];		
	}
}	

void	axGLApp::_os_onOrientationDidChange( float roll, float pitch ) {	
	if( roll < 45 ) {
		CGAffineTransform t = {	1, 0, 0, 1, 0,  0 };
		rotate_view_.transform = t;
	}else if( roll < 90+45 ) {
		CGAffineTransform t = {	0, 1, -1, 0, 0,  0 };
		rotate_view_.transform = t;
	}else if( roll < 180+45 ) {
		CGAffineTransform t = {	-1, 0, 0, -1, 0, 0 };
		rotate_view_.transform = t;
	}else if( roll < 270+45 ) {
		CGAffineTransform t = {	0, -1, 1, 0, 0,  0 };
		rotate_view_.transform = t;
	}else{
		CGAffineTransform t = {	1, 0, 0, 1, 0,  0 };
		rotate_view_.transform = t;
	}
	_os_onResize();	
}

void	axGLApp :: _os_setFrameRate() {
		
}
	
void	axGLApp :: _os_setWindowSize( const axVec2f & size ) {
	//no meaning in iOS
}

void	axGLApp :: _os_setContentSize( const axVec2f & size ) {
	//no meaning in iOS
}

void	axGLApp :: _os_setWindowPos( const axVec2f & size ) {
	//no meaning in iOS
}

axVec2f	axGLApp :: _os_windowPos() const {
	if( ! win_ ) return axVec2f(0,0);
	return axVec2f(win_.frame.origin) * contentScaleFactor_;
}

axVec2f	axGLApp :: _os_windowSize() const {
	if( ! win_ ) return axVec2f(0,0);
	return axVec2f(win_.frame.size) * contentScaleFactor_;
}

axVec2f	axGLApp :: _os_contentSize() const {
	if( ! glview_ ) return axVec2f(0,0);
	return axVec2f( glview_.bounds.size ) * contentScaleFactor_;
}

void	axGLApp::_os_onResize() {
	CGRect bounds = [win_ convertRect: win_.bounds  toView:rotate_view_];
	
	if( bounds.size.width == 0 || bounds.size.height == 0 ) return;
	
	bounds.origin.x = 0;
	bounds.origin.y = 0;
	rotate_view_.bounds = bounds;
	rotate_view_.center = win_.center;
	
	UIApplication* app = [UIApplication sharedApplication];
	bool bar_hidden = app.statusBarHidden;

	if( rotate_view_ ) {
		[rotate_view_ setFrame: win_.frame ];
	}

	axRect2f rc( rotate_view_.bounds );

	if( ! bar_hidden ) {
		CGRect bar_rc = app.statusBarFrame;
		float h = ax_min( bar_rc.size.width, bar_rc.size.height ); //depends on statusBarOrientation
		rc.y += h;
		rc.h -= h;
		if( rc.h < 0 ) rc.h = 0;
//		log_info( L" rc={?}" ) % rc;
	}

	if( glview_ ) {
		CGRect view_rc;		rc.to( view_rc );
		[glview_ setFrame: view_rc];
		[glview_ setNeedsLayout];
	}
	
	onResize_( glview_.bounds.size.width, glview_.bounds.size.height );
	[win_ setNeedsDisplay];
}

#endif //axOS_iOS

#if 0
#pragma mark ================= Windows ====================
#endif
#ifdef axOS_WIN

void axGLApp::_os_ctor() {
	hwnd_ = NULL;
}

void axGLApp::_os_dtor() {
}

void axGLApp::_os_quit() {
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	switch( message ) {
		case WM_DESTROY: {
			PostQuitMessage(0);
		}break;
		case WM_PAINT: {
			PAINTSTRUCT	ps;
			BeginPaint( hwnd, &ps );
			axGLApp::getInstance()->onFrame_();
			EndPaint( hwnd, &ps );
		}break;

		case WM_LBUTTONDOWN:  {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventDown, 0, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;
		case WM_MBUTTONDOWN: {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventDown, 1, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;
		case WM_RBUTTONDOWN: {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventDown, 2, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;

		case WM_LBUTTONUP:  {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventUp, 0, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;
		case WM_MBUTTONUP:  {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventUp, 1, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;
		case WM_RBUTTONUP: {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventUp, 2, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;

		case WM_MOUSEMOVE: {
			short x = (short)LOWORD( lParam );
			short y = (short)HIWORD( lParam );
			axGLApp::getInstance()->onMouseEvent_( 
				axGLApp::kEventMove, 0, axVec2f(x,y), axVec3f(0,0,0), 0, GetTickCount() / 1000.0 );
		}break;
	}

	return DefWindowProc(hwnd, message, wParam, lParam);
}

axStatus	axGLApp::_os_run() {
	axStatus st;

	const wchar_t* szWindowClass = L"axGLApp";

	HINSTANCE	hInstance = GetModuleHandle( NULL );
	WNDCLASS	wc;

    wc.style			= CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc		= (WNDPROC) WndProc;
    wc.cbClsExtra		= 0;
    wc.cbWndExtra		= 0;
    wc.hInstance		= hInstance;
    wc.hIcon			= NULL;
    wc.hCursor			= LoadCursor( NULL, IDC_ARROW );
    wc.hbrBackground	= NULL; //(HBRUSH) GetStockObject(WHITE_BRUSH);
    wc.lpszMenuName		= 0;
    wc.lpszClassName	= szWindowClass;

	if( RegisterClass(&wc) == 0 ) return -1;

	int screen_w = 640; 
	int screen_h = 480;

	DWORD	style = WS_OVERLAPPEDWINDOW;

	hwnd_ = CreateWindowEx ( WS_EX_ACCEPTFILES, szWindowClass, L"axGLApp", style,
								CW_USEDEFAULT, CW_USEDEFAULT, screen_w, screen_h, 
								NULL, NULL, hInstance, NULL);
	if( ! hwnd_ ) return -1;

	RECT rc, cc;
	GetWindowRect( hwnd_, &rc );
	GetClientRect( hwnd_, &cc );
	MoveWindow( hwnd_, rc.left, rc.top, (screen_w - cc.right) + screen_w, screen_h -cc.bottom + screen_h, false );

	st = gl.create( hwnd_ );		if( !st ) return st;

	ShowWindow( hwnd_, SW_SHOW );

//msg loop	
	MSG	msg;
	for(;;) {
        if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) ) {
			if( msg.message == WM_QUIT ) break;
            TranslateMessage( &msg );
            DispatchMessage( &msg );
		} else {
			onFrame_();
		}
    }
	return 0;
}

axVec2f    axGLApp::_os_windowPos	() const {
	if( ! hwnd_ ) return axVec2f(0,0);
	RECT rect;
	GetWindowRect( hwnd_, &rect );
	axRect2f a( rect );
	return a.pos();
}
axVec2f    axGLApp::_os_windowSize	() const {
	if( ! hwnd_ ) return axVec2f(0,0);
	RECT rect;
	GetWindowRect( hwnd_, &rect );
	axRect2f a( rect );
	return a.size();
}
axVec2f    axGLApp::_os_contentSize () const {
	if( ! hwnd_ ) return axVec2f(0,0);
	RECT rect;
	GetClientRect( hwnd_, &rect );
	axRect2f a( rect );
	return a.size();
}

void axGLApp::_os_setWindowPos( const axVec2f& pos ) {
}
void	axGLApp::_os_setWindowSize	( const axVec2f& size ) {
	RECT rc;
	GetWindowRect( hwnd_, &rc );
	int w = (int)size.x;
	int h = (int)size.y;
	MoveWindow( hwnd_, rc.left, rc.top,  w, h, true );
}

void axGLApp::_os_setContentSize( const axVec2f& size ) {
	RECT rc, cc;
	GetWindowRect( hwnd_, &rc );

	int w = (int)size.x;
	int h = (int)size.y;
	MoveWindow( hwnd_, rc.left, rc.top,  w, h, false );

	GetClientRect( hwnd_, &cc );
	MoveWindow( hwnd_, rc.left, rc.top, (w - cc.right) + w, h -cc.bottom + h, false );
}

axStatus axGLApp::_os_setFullScreen( bool b ) {
	return axStatus::not_implemented;
}

void axGLApp::_os_setFrameRate() {
}

void axGLApp::_os_setTitleName( const wchar_t* name ) {
	SetWindowText( hwnd_, name );
}

void axGLApp::_os_setStatusBarVisible( bool  b,     bool animated ) {
}

void axGLApp::_os_setOrientation( float angle, bool animated ) {
}

void axGLApp::_os_onOrientationDidChange	( float roll,  float pitch ) {
}

void  axGLApp::_os_setAutoOrientaton		( bool  b ) {
}

axStatus	axGLApp::_os_enableAccelerometer ( bool b ) {
	return axStatus::not_implemented;
}

#endif //axOS_WIN

#if 0
#pragma mark ================= Android ====================
#endif

#ifdef axOS_Android


void axGLApp::_os_ctor() {
}

void axGLApp::_os_dtor() {
}

void axGLApp::_os_quit() {
	axAndroid* an = axAndroid::getInstance();
	an->jni->CallVoidMethod( an->jni_Activity, an->jni_Activity_finish );
}

axStatus	axGLApp::_os_create		() {
	axStatus	st;


	return 0;
}

axVec2f	axGLApp ::_os_windowPos() const {
	return axVec2f(0,0);
}

axVec2f    axGLApp::_os_windowSize() const {
	return axVec2f(0,0);
}

axVec2f    axGLApp::_os_contentSize() const {
	return axVec2f(0,0);
}

void	axGLApp::_os_setWindowPos	( const axVec2f& size ) {
}

void	axGLApp::_os_setWindowSize	( const axVec2f& size ) {
}

void	axGLApp::_os_setContentSize	( const axVec2f& size ) {
}


void	axGLApp::_os_setTitleName( const wchar_t* name ) {

}

axStatus	axGLApp::_os_setFullScreen( bool b ) {
	return -1;
}

void	axGLApp::_os_setFrameRate() {
}

void        axGLApp::_os_setStatusBarVisible	( bool  b,     bool animated ) {
}

void        axGLApp::_os_setOrientation			( float angle, bool animated ) {

}

void        axGLApp::_os_onOrientationDidChange	( float roll,  float pitch ) {
}

void        axGLApp::_os_setAutoOrientaton		( bool  b ) {
}

axStatus	axGLApp::_os_setAccelerometer        ( float interval ) {
	return axStatus::not_implemented;
}

extern "C" {

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnCreate	( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnCreate");
	ax_log("axGLApp_onRun");
	axGLApp_onRun();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnDidCreateOpenGL ( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnDidCreateOpenGL");
	axGLApp::getInstance()->gl.create();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnDestroy	( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnDestroy");
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnEnterForeground ( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnEnterForeground");
	axGLApp::getInstance()->onEnterForeground();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnBecomeActive ( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnBecomeActive");
	axGLApp::getInstance()->onBecomeActive();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnResignActive ( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnResignActive");
	axGLApp::getInstance()->onResignActive();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnEnterBackground ( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
	ax_log("jniOnEnterBackground");
	axGLApp::getInstance()->onEnterBackground();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnFrame		( JNIEnv* env, jobject obj ) {
	axAndroid::jni = env;
//	ax_log("jniOnFrame");
	axGLApp::getInstance()->onFrame_();
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnResize	( JNIEnv* env, jobject obj, int width, int height ) {
	axAndroid::jni = env;
	axGLApp::getInstance()->onResize_( width, height );
}

JNIEXPORT void Java_com_awenix_libax_axGLApp_jniOnTouchEvent( JNIEnv* env, jobject obj, int action, int touchId, float x, float y, float pressure, int64_t timestamp ) {
	axAndroid::jni = env;
	double ts = (double) timestamp / 1000.0;
	axGLApp::getInstance()->onTouchEvent_( action, touchId, axVec2f(x,y), pressure, ts );
}

} //extern "C"


#endif //axOS_Android
