#include <ax/App/openal/axALBuffer.h>
#include <ax/App/openal/axALContext.h>
#include <ax/App/sound/axWaveFile.h>


#ifdef axUSE_OpenAL

axALBuffer::axALBuffer() { _id = 0; }
axALBuffer::~axALBuffer() { destroy(); }

void axALBuffer::destroy() {
	if( _id ) {
		alDeleteBuffers( 1, &_id );
		_id = 0;
	}
}

axStatus axALBuffer::create( ALenum format, const ALvoid *data, ALsizei size, ALsizei freq ) {
	/*	format format type from among the following:
				AL_FORMAT_MONO8
				AL_FORMAT_MONO16
				AL_FORMAT_STEREO8
				AL_FORMAT_STEREO16
		data pointer to the audio data
		size the size of the audio data in bytes
		freq the frequency of the audio data */

	if( !_id ) {
		alGenBuffers( 1, &_id );
		printf("axALBuffer::create _id = %d\n", _id);
	}
	
	alBufferData( _id, format, data, size, freq );
		
	print_openal_if_error( __FUNCTION__ );
	
	return 0;
}

axStatus axALBuffer::onTake( axALBuffer &src ) {
	
	if( this == &src ) return 0;
	destroy();
	_id = src._id;
	src._id = 0;
	return 0;
}

	
	
ALint get_format( const axWaveFile::Header &hdr ) {
	
	int bit = hdr.bit_rate;
	int ch = hdr.channels;
	//int sample_rate = hdr.sample_rate;
	
	if( ch == 1 ) {
		if( bit == 8 ) return AL_FORMAT_MONO8;
		if( bit == 16 ) return  AL_FORMAT_MONO16;
	}
	
	if( ch == 2 ) {
		if( bit == 8 ) return AL_FORMAT_STEREO8;
		if( bit == 16 ) return AL_FORMAT_STEREO16;	
	}	
	
	return 0;
}


axStatus axALBuffer::loadWav( const wchar_t *filename ) {
	
	axStatus st;
	
	axWaveFile::Header hdr;
	
	st = _buf.openRead( filename ); if( !st ) return st;
	
	axDeserializer ds( _buf );
	st = ds.io( hdr ); if( !st ) return st;
	
	ALint format = get_format( hdr );
	if( format == 0 ) return -1;
	
	if( !_id ) {
		alGenBuffers( 1, &_id );
	}
	
#ifdef axOS_iOS
	if( _alBufferDataStatic ) {
		_alBufferDataStatic( _id, format, (ALvoid*) ds.r_, ds.remainSize(), hdr.sample_rate );
	}else {
		alBufferData( _id, format, (ALvoid*) ds.r_, ds.remainSize(), hdr.sample_rate );
	}
#else
	alBufferData( _id, format, (ALvoid*) ds.r_, (ALsizei) ds.remainSize(), hdr.sample_rate );
#endif
		
	return 0;
}


#endif //#axUSE_OpenAL

