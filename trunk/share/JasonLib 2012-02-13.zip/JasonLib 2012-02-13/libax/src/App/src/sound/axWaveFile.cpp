#include <ax/App/sound/axWaveFile.h>

void axWaveFile::Header::set( int ch, int freq, int bit ) {
	
	riff_id = ax_char4( 'R', 'I', 'F', 'F' );
	total_bytes = 0 ; //will fill in at final()
	wave = ax_char4('W','A','V','E');

	fmt = ax_char4('f','m','t',' ');
	sc_len = 16;
	uncompressed = 1;

	channels = ch;
	sample_rate = freq;
	bytes_per_second = freq * ch * (bit / 8);

	block_alignment = ch * (bit / 8);
	bit_rate = bit;
	data_chunk_id =	ax_char4('d','a','t','a');

	data_bytes = 0; //will be fill  at last
}

//static
axStatus axWaveFile::readBuffer( const axIByteArray &buf, axPCMWave &wave  ) {
	
	axStatus st;
	
	Header hdr;
	
	axDeserializer ds( buf );
	st = ds.io( hdr ); if( !st ) return st;
	
	int bit = hdr.bit_rate;
	int chl = hdr.channels;
	int sample_rate = hdr.sample_rate;
	int sample_size = hdr.data_bytes / chl / (bit>>3);
	

	st = wave.create( sample_size, sample_rate, chl, bit ); if( !st ) return st;
	st = ds.io_raw( wave.buf.ptr(), wave.buf.byteSize() ); if( !st ) return st;
	
	wave.sample = sample_size;
	
	return 0;
}

//static
axStatus axWaveFile::writeBuffer( axIByteArray &buf, const axPCMWave &wave ) {
	axStatus st;
	
	axSize byte_len;	
	st = requireLength( byte_len, wave ); if( !st ) return st;
				 	
	Header hdr;	
	hdr.set( wave.ch, wave.freq, wave.bit );
	
	hdr.total_bytes = (uint32_t) ( byte_len + sizeof( Header ) - 8 );
	hdr.data_bytes  = (uint32_t) byte_len;
	
	st = buf.resize( byte_len, false ); if( !st ) return st;
	
	axSerializer s(buf);
	st = s.io( hdr ); if( !st ) return st;
	st = s.io_raw( wave.buf.ptr(), wave.buf.size() ); if( !st ) return st;
	
	return 0;
}
	
//static
axStatus axWaveFile::requireLength( axSize &out_len, const axPCMWave &wave ) {
	axStatus st;
	axLenSerializer ls;
	Header hdr;
	st = ls.io( hdr ); if( !st ) return st;
	st = ls.io_raw( wave.buf.ptr(), wave.buf.size() ); if( !st ) return st;
	if( ls.usedSize() <= UINT_MAX ) return -1;
	out_len = ls.usedSize();
	return 0;
}
	

