#include <ax/App/sound/axPCMWave.h>
#include <ax/App/openal/axALBufferedSource.h>

#ifdef axUSE_OpenAL

axALBufferedSource::axALBufferedSource() {
}

axALBufferedSource::~axALBufferedSource() {
	destroy();
}


axStatus axALBufferedSource::query( const wchar_t *file, bool is_play_now ) {
	axStatus st;
	if( !is_created() ) { 
		st = create(); if( !st ) return st;
	}
	
	Buf *b = _get_avail_buffer(); if( !b ) return -1;
	st = b->al_buf.loadWav( file ); if( !st ) return st;
	
	st = _query_buffer( b ); if( !st ) return st;
	
	if( is_play_now ) keep_play();
	/*
	axStatus st;

	PCMWave wave;
	st = wave.load_file( file ); if( !st ) return st;
	st = query( wave, is_play_now ); if( !st ) return st;
	*/
	return 0;
}

void axALBufferedSource::destroy() {
	stop();

	for( ;; ) {
		Buf *b = ls_query.head();
		if( !b ) break;
		ls_query.remove( b );
		if( b->al_buf._id ) 
			unquery( b->al_buf );
		ls_avail.append( b );
	}

	axALSource::destroy();
	ls_avail.clear();
}

axStatus axALBufferedSource::create( size_t buf_count ) {
	destroy();
	axStatus st;

	size_t i;
	for( i=0; i<buf_count; i++ ) {
		Buf *p = new Buf;
		if( !p ) return axStatus::not_enough_memory;
		ls_avail.append( p );
	}
	
	st = axALSource::create();	if( !st ) return st;
	return 0;
}

size_t axALBufferedSource::avail_count() {
	int p = processed_buf();

	int i;
	for( i=0; i<p; i++ ) {
		Buf *b = ls_query.head();
		if( !b ) break;
		ls_query.remove( b );
		if( b->al_buf._id ) unquery( b->al_buf );
		ls_avail.append( b );
	}
	return ls_avail.size();
}

// return 1 if enqueried, 0 if buf is not available this moment
axStatus axALBufferedSource::query( ALenum format, const ALvoid *data, size_t size, ALsizei freq, bool is_play_now ) {
	assert( size < INT_MAX );
	
	axStatus st;
	if( !is_created() ) { 
		st = create(); if( !st ) return st;
	}
	
	Buf *b = _get_avail_buffer(); if( !b ) return -1;
	st = b->al_buf.create( format, data, (int)size, freq ); if( !st ) return st;
	
	st = _query_buffer( b ); if( !st ) return st;
	
	if( is_play_now ) keep_play();
	
	
	return 1;
}

axALBufferedSource::Buf* axALBufferedSource::_get_avail_buffer() {	
	avail_count(); //update
	return ls_avail.head();
}

axStatus axALBufferedSource::_query_buffer( Buf *b ) {	
	axStatus st;
	
	st = B::query( b->al_buf ); if( !st ) return st;
	
	ls_avail.remove( b );
	ls_query.append( b );
	
	return 0;

}

axStatus axALBufferedSource::query( const axPCMWave &wave, bool is_play_now ) {
	
	if( wave.ch == axPCMWave::ch_mono && wave.bit == 8 ) {
		return query( AL_FORMAT_MONO8, wave.ptr(), wave.byte_size(), wave. freq, is_play_now );
	}
	if( wave.ch == axPCMWave::ch_mono && wave.bit == 16 ) {
		return query( AL_FORMAT_MONO16, wave.ptr(), wave.byte_size(), wave. freq, is_play_now );
	}
	
	if( wave.ch == axPCMWave::ch_stereo && wave.bit == 8 ) {
		return query( AL_FORMAT_STEREO8, wave.ptr(), wave.byte_size(), wave. freq, is_play_now );
	}
	if( wave.ch == axPCMWave::ch_stereo && wave.bit == 16 ) {
		return query( AL_FORMAT_STEREO16, wave.ptr(), wave.byte_size(), wave. freq, is_play_now );
	}
	
	
	return axStatus::not_found;
}
	
#endif //# axUSE_OpenAL

