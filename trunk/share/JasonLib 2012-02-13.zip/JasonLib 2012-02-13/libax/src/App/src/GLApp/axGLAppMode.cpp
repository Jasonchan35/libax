/*  Filename = axGLAppMode.cpp / Project = libax
 *  Created by Jason on 02/12/2009.
 *  Copyright 2009 Awenix. All rights reserved. */

#include <ax/App/GLApp/axGLAppMode.h>
	
axGLAppMode::axGLAppMode() {
	prevMode_ = NULL;
	app_ = NULL;
}

axGLAppMode::~axGLAppMode() {

}

axStatus axGLAppMode::create( axGLApp* app, axGLAppMode* prevMode ) {
	app_ = app;
	prevMode_ = prevMode;

	axStatus st;
	st = rootView.newObject();		if( !st ) return st;
	rootView->setFizedSize( app->contentSize() );
	
	return onCreate();
}

void axGLAppMode::resize( float w, float h ) {
	rootView->setFizedSize( axVec2f(w,h) );
	onResize( w,h );
}

void axGLAppMode::quitMode() {
	app().popMode();
}

void axGLAppMode::doFrame( axGLAppRenderRequest &req ) {
	onFrame( req );
	rootView->doLayout();
	rootView->render( req );
}

void axGLAppMode::onTouchEvent ( axGLAppTouchEvent &ev ) {
	rootView->doTouchEvent( ev );
}

void axGLAppMode::onMouseEvent ( axGLAppMouseEvent &ev ) {
	rootView->doMouseEvent( ev );
}

void axGLAppMode::onKeyEvent ( axGLAppKeyEvent &ev ) {
	rootView->doKeyEvent( ev );
}

