#include <ax/App/ui/axGLUIVBox.h>

axGLUIVBox::axGLUIVBox() {
	spacing_ = 0;
}

void	axGLUIVBox :: setSpacing( float s ) {
	spacing_ = s;
	layoutNeeded();
}

void	axGLUIVBox :: onLayout() {
	float totalPropotion = 0;
	
	float fixed = 0;
	
	
	axVec2f content_size = contentSize();
	
	float y = padding_.top;
	float w = content_size.x;
	float h = content_size.y;
	
	h -= spacing_ * (float)(child_.size()-1);
	h  = ax_max( h, 0.0f );

	
	// calac hight fixed and every child margin, totalPropotion, and reset propotion size
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
		if( c->proportion_.y > 0 ) {
			totalPropotion += c->proportion_.y;			
			c->rect_.h = 0;
		}else{
			fixed += c->rect_.h;
		}
		
		fixed += c->margin_.totalHeight();
	}
	

	// if the proportion bigger then max size, make it fixed
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
				 
		if( c->proportion().y > 0 && c->rect_.h == 0 ) { 
			float p = h * ( c->proportion_.y / totalPropotion );

			if( p >= c->maxRequireSize_.y ) {
				c->rect_.h = c->maxRequireSize_.y;
				totalPropotion -= c->proportion_.y;	
				fixed += c->rect_.h;
			}
		 }
	}
				

	// if the proportion smaller then min size, make it fixed
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
				 
		if( c->proportion().y > 0 ) { 
			float p = h * ( c->proportion_.y / totalPropotion );
			if( p <= c->minRequireSize_.y ) {
				c->rect_.h = c->minRequireSize_.y;
				totalPropotion -= c->proportion_.y;	
				fixed += c->rect_.h;
			}
		 }
	}


	h -= fixed;
	
	axVec2f fractional(0,0);
	
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
		
		if( c->proportion_.x > 0 ) {
			c->rect_.w = w * c->proportion_.x;
			ax_clamp_it( c->rect_.w, c->minRequireSize_.x, c->maxRequireSize_.x );
			
		}
		
		if( c->proportion_.y > 0 && c->rect_.h == 0 ) {
			c->rect_.h = h * ( c->proportion_.y / totalPropotion );
			ax_clamp_it( c->rect_.h, c->minRequireSize_.y, c->maxRequireSize_.y );
		
		}
		
		//
		float fractpart, intpart;
		
		fractpart = ax_modf( c->rect_.w, &intpart );
		fractional.x += fractpart;
		c->rect_.w = intpart;
		
		
		fractpart = ax_modf( c->rect_.h, &intpart );		
		fractional.y += fractpart;
		c->rect_.h = intpart;
		
	}	
	
	
	
	fractional.round();
	
	for( axSize i=0; i<child_.size(); i++ ) {
		size_t p = child_.size()/2 + ( i%2?(i+1)/2*-1:(i+1)/2 );
		axGLUIView* c = child_[ p ];
		//ax_log( "p = {?}" , p);
		
		if( fractional.x > 0 ) {
			if( c->rect_.w < c->maxRequireSize_.x ) {
				c->rect_.w++;
				fractional.x--;
			}
		}
		
		if( fractional.y > 0 ) {
		
			if( c->rect_.h < c->maxRequireSize_.y ) {
				c->rect_.h++;
				fractional.y--;
			}
		}
		
		if( fractional.isAll( 0 ) ) break;
			
	}
		
		
	
	for( axSize i=0; i<child_.size(); i++ ) {
		axGLUIView* c = child_[i];
				
		//float cw = w - c->margin_.totalWidth() - rc.w ;
		
		c->setPos( c->layoutPosBySize( w, c->rect_.h ) );
		//rc.x = ( c->align_.x + 1.0f ) * cw / 2 + (  c->margin_.left ) + padding_.left;
		c->rect_.x += padding_.left;
		c->rect_.y += y + c->margin_.top;
				
		y += c->rect_.h + spacing_ + c->margin_.totalHeight();
		

	}

		
	//ax_log("totalPropotion {?} fractional {?}", totalPropotion, fractional );
	
}



//virtual	
const axVec2f axGLUIVBox::minRequireSize	() const { 
	axVec2f r(0,0);
	for( axSize i=0; i<child_.size(); i++ ) {
		const axGLUIView* c = child_[i];
		r += c->minRequireSize();
	}
	return r;
}

//virtual	
const axVec2f axGLUIVBox::maxRequireSize	() const { 
	axVec2f r(0,0);
	for( axSize i=0; i<child_.size(); i++ ) {
		const axGLUIView* c = child_[i];
		r += c->maxRequireSize();
	}
	return r;
}
	
	
	
	
