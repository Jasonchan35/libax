#include <ax/App/ui/axGLUIText.h>
#include <ax/core/System/axSystem.h>

axGLUIText::axGLUIText() {
	textDirty_ = false;
	fontSize_ = -1; 
	fontAlignment_ = axAlignment::kCenterXY;
	fontProportion_ = 0.9f;
}

void axGLUIText::setFontAlignment( axAlignment a ) {
	fontAlignment_ = a;
}

void axGLUIText::onRender( axGLAppRenderRequest& req ) const {

	glColor4f(1,0,0,1 );
	texText_.blt(0,0);
}

void axGLUIText::onLayout() {

	axStatus st;
	B::onLayout();
	
	if( textDirty_ ) {
	
		axFont font;
	
		if( fontSize_ <= 0 )  {
			font.getFontSizeBy( fontSize_, fontFace_, text_,  axVec2f( rect_.w * fontProportion_, rect_.h) , 20  );		
		}

		st = font.create( fontFace_, fontSize_ ); if(!st) return;					
		//ax_log("axFont::fontSize_ {?} fontFace_ {?}", fontSize_, fontFace_ );
						
		st = texText_.createFromTextInRect( font, text_, (int)rect_.w, (int)rect_.h, fontAlignment_ ); if(!st) return;
						
		textDirty_ = false;
	}
	
}

axStatus axGLUIText::setText( const char *sz ) {
	axStatus st;
	axTempStringW str;
	st = str.set( sz ); if(!st) return st;
	return setText( str );
}
	

axStatus axGLUIText::setText( const wchar_t *sz ) {
	axStatus st;
	st = text_.set( sz ); if( !st ) return st;
	textDirty_ = true;
	return 0;
}
	
	
void axGLUIText::setFontSize( float size ) {

	fontSize_ = size;
	textDirty_ = true;
}


axStatus axGLUIText::setFontFace( const wchar_t *sz ) {
	axStatus st;
	st = fontFace_.set( sz ); if( !st ) return st;
	textDirty_ = true;
	return 0;
}