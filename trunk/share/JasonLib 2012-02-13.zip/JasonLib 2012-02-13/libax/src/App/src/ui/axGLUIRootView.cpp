#include <ax/App/ui/axGLUIRootView.h>



//virtual 
void axGLUIRootView::setFizedSize( const axVec2f& size ) {
	fixedSize = size;
	layoutNeeded();
}

 
void axGLUIRootView :: onLayout() { 
	
	setSize( fixedSize );
	axRect2f rc;
	
	
	rc.x = margin_.left;
	rc.y = margin_.top;	
	
	rc.w = fixedSize.x - margin_.totalWidth();
	rc.h = fixedSize.y - margin_.totalWidth();
	
	
	setRect( rc );
	
	B::onLayout();
}

