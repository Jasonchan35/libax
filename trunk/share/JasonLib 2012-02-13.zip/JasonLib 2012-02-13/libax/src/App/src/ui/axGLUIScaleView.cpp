//
//  axGLUIScaleView.cpp
//  ax
//
//  Created by Jason on 08/07/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include <ax/App/ui/axGLUIScaleView.h>


axGLUIScaleView::axGLUIScaleView() {
	translate_.set( 0,0 );
	virtualContentSize_.set( 0,0 );
	alignTranslate_.set( 0,0 );
	
	scale_.set( 1, 1 );
	keepAspectRatio_ = true;
}

	
void	axGLUIScaleView::setTranslate( const axVec2f& s ) { translate_ = s; }
void	axGLUIScaleView::setTranslate( float x, float y ) { setTranslate( axVec2f(x,y) ); }
 
void	axGLUIScaleView::setVirtualContentSize		( const axVec2f& size ) { virtualContentSize_ = size; }
void	axGLUIScaleView::setVirtualContentSize		( float w, float h ) { setVirtualContentSize( axVec2f(w,h ) ); }


/*
axVec2f	 axGLUIScaleView::pointFromParent( const axVec2f& pt ) {
	return ( pt - pos() ) / scale_;	
}*/

//virtual	
void	axGLUIScaleView::onLayout	() {
	recalcScale_();
	
	axVec2f old_size = size();
	setSize( virtualContentSize_ );
	B::onLayout();
	setSize( old_size );

}


void axGLUIScaleView::recalcScale_() {
	
	scale_.set(1,1);
	
	if( !parent_ ) return;
	if( virtualContentSize_.x == 0 || virtualContentSize_.y == 0 ) return;

	scale_.x = rect_.w / virtualContentSize_.x;
	scale_.y = rect_.h / virtualContentSize_.y;
	
	if( keepAspectRatio_ ) {
		float scale_min = ax_min( scale_.x, scale_.y );
		scale_.set( scale_min, scale_min );
	}
	
 
	
	axVec2f client_size;
	
	client_size = size() - (virtualContentSize_*scale_);
	alignTranslate_ = ( alignTranslate_ + 1.0f ) * client_size / 2;
		
 
	
}


void axGLUIScaleView::onTouchEvent( axGLAppTouchEvent &ev ) {
	
	ev.pos /= scale_;
	ev.pos += alignTranslate_ + translate_;
	B::onTouchEvent( ev );
}


void axGLUIScaleView::render( axGLAppRenderRequest& req ) const {
	axScopeGLPushMatrix pm;
	glTranslate( rect_.pos() + translate_ + alignTranslate_ );
	
	onRender( req );
	
	//const axVec2f s = scale_();
	//glScale( s.x, 1, s.y );
	
	glScale( scale_ );
	
	
	renderChild_( req );
}

void axGLUIScaleView::onRender( axGLAppRenderRequest& req ) const {
/*
	if( req.ui.showLayout ) {
		axRect2f rc = rect();
		rc.setPos( 0,0 );
		glColor3f( 1,0,0 );
		glDrawLine( rc );	
		glColor3f( 1,1,1 );
	}
	*/
}

