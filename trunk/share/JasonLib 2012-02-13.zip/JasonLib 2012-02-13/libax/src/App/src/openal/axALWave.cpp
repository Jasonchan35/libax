#include <ax/App/openal/axALWave.h>

#ifdef axUSE_OpenAL

axALWave::axALWave(){
	format=0;
}

axStatus axALWave::create( int format, uint32_t buf_sample_size, int freq ) {
	this->format = format;
	switch( format ) {
		case AL_FORMAT_MONO8:	 return axPCMWave::create( buf_sample_size, freq, ch_mono, 8 );
		case AL_FORMAT_MONO16:	 return axPCMWave::create( buf_sample_size, freq, ch_mono, 16 );
		case AL_FORMAT_STEREO8:	 return axPCMWave::create( buf_sample_size, freq, ch_stereo, 8 );
		case AL_FORMAT_STEREO16: return axPCMWave::create( buf_sample_size, freq, ch_stereo, 16 );
	}
	return -1;
}

axStatus axALWave::create_mono8( uint32_t buf_sample_size, int freq ) {
	return create( AL_FORMAT_MONO8, buf_sample_size, freq );
}

axStatus axALWave::create_mono16( uint32_t buf_sample_size, int freq ) {
	return create( AL_FORMAT_MONO16, buf_sample_size, freq );
}

axStatus axALWave::create_stereo8( uint32_t buf_sample_size, int freq ) {
	return create( AL_FORMAT_STEREO8, buf_sample_size, freq );
}

axStatus axALWave::create_stereo16( uint32_t buf_sample_size, int freq ) {
	return create( AL_FORMAT_STEREO16, buf_sample_size, freq );
}

#endif //axUSE_OpenAL
