#include <ax/core/net/axSockAddr.h>
#include <ax/core/net/axSocket.h>

axStatus axSockAddr::toStringFormat( axStringFormat &f ) {
	return f.format( "{?}.{?}.{?}.{?}:{?}",  
						(uint8_t)p_.sa_data[2],
						(uint8_t)p_.sa_data[3],
						(uint8_t)p_.sa_data[4],
						(uint8_t)p_.sa_data[5],
						ntohs( *( (uint16_t*) p_.sa_data ) ) );
}

axSockAddr::axSockAddr() {
	ax_memzero( p_ );
}

axStatus axSockAddr::set( const char* hostname_and_port ) {
	axStatus st;
	axStringA_<256>	hostname;
	uint16_t		port = 0;
	
	if ( !hostname_and_port ) return axStatus::invalid_parameter;
	
	const char	*p = ax_strchr ( hostname_and_port, ':');
	if( ! p ) return -1;	
	if( ! p[1] ) return -2;		
	st = ax_str_to( p+1, port );	if( !st ) return st;
	st = hostname.setWithLength( hostname_and_port, p - hostname_and_port );		if( !st ) return st;
	return set( hostname, port );
}

axStatus axSockAddr::set( const char* hostname, uint16_t port ) {
	axSocket::platformInit();
	
	hostent *h = ::gethostbyname ( hostname );
	if ( !h ) return -3;
	
	p_.sa_family = AF_INET;
	*(uint16_t*) (p_.sa_data)   = htons( port );
	*(uint32_t*) (p_.sa_data+2) = *((uint32_t*) h->h_addr );
	return 0;
}

