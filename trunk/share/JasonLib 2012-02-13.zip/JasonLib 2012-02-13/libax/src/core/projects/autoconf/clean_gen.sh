rm -Rf configure \
       Makefile.in \
       config.log \
       depcomp \
       config.guess \
       config.sub \
       INSTALL \
       COPYING \
       axSRC_file_list \
       Makefile \
       config.status \
       autom4te.cache \
       missing \
       Makefile.am \
       axHEADER_file_list \
       aclocal.m4 \
       install-sh \
	.deps \
	include \
	src

