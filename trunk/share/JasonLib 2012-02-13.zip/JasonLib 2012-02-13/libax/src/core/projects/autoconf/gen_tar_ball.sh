./clean_gen.sh

svn export ../../src src

mkdir -p include/ax
svn export ../../../../include/ax/ax_base.h	include/ax/ax_base.h
svn export ../../../../include/ax/base		include/ax/base

svn export ../../../../include/ax/ax_core.h	include/ax/ax_core.h
svn export ../../../../include/ax/core		include/ax/core

mkdir -p include/ax/external
svn export ../../../../include/ax/external/glew	include/ax/external/glew


find src 	>  axSRC_file_list
find include 	>  axHEADER_file_list

sed -e "s|@axSRC@|`paste -s axSRC_file_list`|g" \
    -e "s|@axHEADER@|`paste -s axHEADER_file_list`|g" \
	 Makefile.am.in > Makefile.am

if ! aclocal; then exit; fi;
if ! autoconf; then exit; fi;
if ! automake -a; then exit; fi;
if ! ./configure; then exit; fi;

make dist

