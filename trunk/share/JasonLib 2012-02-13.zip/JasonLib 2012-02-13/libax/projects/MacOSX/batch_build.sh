#!/bin/sh

function _my_build {
	echo .
	echo ==== build project $1 $2 $3 =====
	echo ==== build project $1 $2 $3 ===== >> batch_build.log
	my_cmd="/Developer/usr/bin/xcodebuild -project $1 -configuration $2 -sdk $3 clean build"
	echo $my_cmd
	$my_cmd >> batch_build.log
	ret=$?
	if [ "$ret" -ne "0" ]; then 
		echo "return $ret"
		exit 1
	fi
}

function my_build {
	echo ==== build project $1 ======
	_my_build $1 Debug   macosx
	_my_build $1 Release macosx
}

rm batch_build.log
my_build  "../../src/core/projects/MacOSX/libax.xcodeproj"

echo "== done =="
