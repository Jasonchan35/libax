//
//  libax_testAppDelegate.m
//  libax_test
//
//  Created by Jason on 18/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "libax_testAppDelegate.h"

@implementation libax_testAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
	// Insert code here to initialize your application
}

@end
