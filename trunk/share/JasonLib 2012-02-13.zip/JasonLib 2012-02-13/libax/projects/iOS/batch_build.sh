#!/bin/sh

function _my_build {
	echo .
	echo ==== build project $1 $2 $3 =====
	echo ==== build project $1 $2 $3 ===== >> batch_build.log
	my_cmd="/Developer/usr/bin/xcodebuild -project $1 -configuration $2 -sdk $3 clean build"
	echo $my_cmd
	$my_cmd >> batch_build.log
	ret=$?
	if [ "$ret" -ne "0" ]; then 
		echo "return $ret"
		exit 1
	fi
}

function my_build {
	echo ==== build project $1 ======
	_my_build $1 Debug   iphoneos4.3
	_my_build $1 Release iphoneos4.3
	_my_build $1 Debug   iphonesimulator4.3
	_my_build $1 Release iphonesimulator4.3
}

rm batch_build.log
my_build  "../../src/core/projects/iOS/libax.xcodeproj"
my_build  "../../src/axSQLite3/projects/iOS/axSQLite3.xcodeproj"
my_build  "../../src/App/projects/iOS/ax_App.xcodeproj"


echo "== done =="
