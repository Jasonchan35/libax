
#include <ax/ax_core.h>

class Data : public axHashTableNode<Data> {
public:
    int a;
    
    uint32_t    hashTableValue() { return a; }
};


int main(int argc, char *argv[]) {
	
    {
        axHashTable< Data > t;
        t.setTableSize( 5 );
		
		for( axSize i=0; i<50; i++ ) {
			Data *p = new Data;
			p->a = i;
			t.append( p );
		}

        t.setTableSize( 6 );
		
		axSize count = 0;
		axHashTable< Data > :: It	it( t );
		for( ; it; it.goNext() ) {
			ax_log( "{?}", it->a );
			count++;
		}
		
		ax_log( "count={?}\n", count );
    }
    
    
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
