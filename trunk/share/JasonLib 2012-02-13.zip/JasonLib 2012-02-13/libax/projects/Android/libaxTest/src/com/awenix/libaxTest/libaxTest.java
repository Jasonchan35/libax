package com.awenix.libaxTest;

import com.awenix.libax.*;

public class libaxTest extends axGLApp {
	static {
		System.loadLibrary("axtest");
	}	
}