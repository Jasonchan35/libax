===  Eclipse ===
- install Eclipse
- Android ADT plugin for Eclipse
- Android NDK
- C/C++ development Tool ( CDT )
- Eclipse preference > C/C++ > build > Add Env. variable for "NDK_PATH"

=== create project ===
- create Android Project
- switch to C/C++ prespective
- convert project to C/C++ project
- copy "Makefile"
- create file "jni/Android.mk"
- project property, project reference to libax for Java Lib