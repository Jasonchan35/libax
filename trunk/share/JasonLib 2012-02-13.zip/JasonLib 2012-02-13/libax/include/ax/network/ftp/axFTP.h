#ifndef __axFTP_h__
#define __axFTP_h__

#include <ax/base/time/axDateTime.h>
#include <ax/core/file_system/axFile.h>
#include <ax/core/net/axSocket.h>


class axFTP {
public:

	enum{ 
		ftp_timeout = 5,
	};

	enum{ 

		ftp_err_connect = -14000,  
		ftp_incomplete_reply,
		ftp_username_or_password_not_correct,
		ftp_err_quit,
		ftp_err_pwd,
		ftp_err_settype,
		ftp_err_list,
		ftp_err_enter_passive,

		ftp_err_delete_file,
		ftp_err_rename_file,

		ftp_err_remove_dir,
		ftp_err_change_dir,
		ftp_err_make_dir,
		ftp_err_cdup,
		ftp_err_syst,
		ftp_err_site,
		ftp_err_file_size,
		ftp_err_file_mod_date,
		ftp_err_paassive_send_data,
		
		ftp_err_cannot_parser_dir_entry,
		//ftp_err_get_dir,
		ftp_get_file_time_out,

	};

	axFTP();
	~axFTP();

	axStatus connect( const char *host );
	axStatus login( const char *user, const char *pass );
	axStatus quit();
	
	//handy function 

	class DirectoryEntry : public axNonCopyable {
	public:

		DirectoryEntry();


		bool		isDir()				{ return dir_; }
		axSize		size()				{ return size_; }

		const char*		name()			{ return name_.c_str(); }
		//const char*		modifyDate()	{ return modify_date_.c_str(); }

		axDateTime&		modifyDate()	{ return modify_date_; }

		axStatus toStringFormat ( axStringFormat &f ) const;
		axStatus onTake( DirectoryEntry & src );

		axStatus set( axIStringA &str );

	private:

		axStringA_<256> name_;
		axDateTime		modify_date_;

		axSize			size_;
		bool			dir_;


	};

	axStatus makeDir( const char *dir )												{ return mkd( dir ); }
	axStatus removeDir( const char *dir )											{ return rmd( dir ); }
	axStatus changeDir( const char *dir )											{ return cwd( dir ); }

	axStatus getDirectoryList( axIArray<DirectoryEntry> &entries, const char* path = "" );
	axStatus getDirectory( const char* local_path, const char* remote_path );



	axStatus getFile( axIByteArray &buf, const char* filename );
	axStatus getFile( axFile &file, const char* filename, axSize size );

	axStatus putFile( axIByteArray &buf, const char* filename )						{ return stor( buf, filename ); }
	axStatus appendFile( axIByteArray &buf, const char*filename )					{ return appe( buf, filename ); }
	axStatus deleteFile( const char *filename )										{ return dele(filename ); }
	axStatus renameFile( const char *oldname, const char *newname );

	
	axStatus fileModifyDate( axDateTime &dt, const char *filename );
	axStatus fileModifyDate( axIStringA &str, const char *filename )				{ return mdtm( str, filename ); };
	axStatus fileSize( axSize &file_size, const char *filename )					{ return size( file_size, filename); }

	axStatus siteCommand( const char *cmd_ )										{ return site( cmd_ ); }
	

	axStatus featureList( axStringA_Array &dir )									{ return feat( dir ); }
	axStatus systemType( axIStringA &str )											{ return syst( str ); }


private:

	//raw command

	//! Returns information of a file or directory if specified, else information of the current working directory is returned. ( unix atrtib format )
	axStatus list( axStringA_Array &dir ); 

	//! Returns a list of file names in a specified directory. ( without attrib )
	axStatus nlst( axStringA_Array &dir ); 

	//! Lists the contents of a directory if a directory is named. ( ini attrib )
	axStatus mlsd( axStringA_Array &dir ); 
	
	//! Change to Parent Directory.
	axStatus cdup();
	
	//! Print working directory. Returns the current directory of the host.
	axStatus pwd( axIStringA &path );
	axStatus dele( const char *filename ); 

	axStatus rnfr( const char *str );
	axStatus rnto( const char *str );
	
	//! This is the raw interface, you must know the size and reserve before call this function
	axStatus retr( axIByteArray &buf, const char* filename );
	axStatus retr( axFile &file, const char* filename );

	axStatus stor( axIByteArray &buf, const char* filename );
	axStatus appe( axIByteArray &buf, const char*filename );

	axStatus mdtm( axIStringA &str, const char *filename );

	axStatus size( axSize &file_size, const char *filename );
	axStatus mkd( const char *dir );
	axStatus rmd( const char *dir );
	axStatus cwd( const char *dir );
	
	//! Sends site specific commands to remote server.
	axStatus site( const char *cmd_ );

	//! Get the feature list implemented by the server.
	axStatus feat( axStringA_Array &dir );
	axStatus syst( axIStringA &str );

	axStatus setTypeA_();
	axStatus setTypeI_();

	//=================

	axStringA_Array respond;

	bool		isSuccess_( int code, int expected_response_group );

	axStatus	getLine_( axStringA &str, axSocket &s );


	axStatus	sendPassiveData_( axIByteArray &buf );
	axStatus	getPassiveData_( axIByteArray &buf );
	axStatus	getPassiveData_( axFile &file, axSize size );
	axStatus	getPassiveTextRespond_( axStringA_Array &arr );
	axStatus	getTextRespond_( int &ret_code );
	
	axStatus	sendCommand_( const char *command );
	axStatus	sendCommand_( const char *command, int &ret_code );

	axStatus	connectPassive_();	


	static axStatus	strToDateTime_( const char *sz, axDateTime &dt );



	axByteArray		buf_;
	axSocket		sock_, sock_passive_;
	axSockAddr		passiveAddr_;

	
};


inline axStatus axFTP::renameFile( const char *oldname, const char *newname ) {
	axStatus st;
	st = rnfr( oldname ); if( !st ) return st;
	st = rnto( oldname ); if( !st ) return st;
	return 0;
}


/*
Ref: http://en.wikipedia.org/wiki/File_Transfer_Protocol

Support :

APPE	Append.
CDUP	Change to Parent Directory.
CWD		Change working directory.
DELE	Delete file.
FEAT	RFC 2389	Get the feature list implemented by the server.
LIST	Returns information of a file or directory if specified, else information of the current working directory is returned.
MDTM	RFC 3659	Return the last-modified time of a specified file.
MKD		Make directory.
MLSD	RFC 3659 Lists the contents of a directory if a directory is named.
MODE	Sets the transfer mode (Stream, Block, or Compressed).
NLST	Returns a list of file names in a specified directory.
PASS	Authentication password.
PASV	Enter passive mode.
PWD		Print working directory. Returns the current directory of the host.
QUIT	Disconnect.
RETR	Transfer a copy of the file
RNFR	Rename from.
RNTO	Rename to.
RMD		Remove a directory.
SITE	Sends site specific commands to remote server.
SIZE	RFC 3659	Return the size of a file.
STOR	Accept the data and to store the data as a file at the server site
SYST	Return system type.
TYPE	Sets the transfer mode (ASCII/Binary).
USER	Authentication username.

Not Support :

ABOR	Abort an active file transfer.
ACCT	Account information.
ADAT	RFC 2228	Authentication/Security Data
ALLO	Allocate sufficient disk space to receive a file.
AUTH	RFC 2228	Authentication/Security Mechanism
CCC		RFC 2228	Clear Command Channel
CONF	RFC 2228	Confidentiality Protection Command
ENC		RFC 2228	Privacy Protected Channel
EPRT	RFC 2428	Specifies an extended address and port to which the server should connect.
EPSV	RFC 2428	Enter extended passive mode.

LANG	RFC 2640	Language Negotiation
LPRT	RFC 1639	Specifies a long address and port to which the server should connect.
LPSV	RFC 1639	Enter long passive mode.
MIC		RFC 2228	Integrity Protected Command
MLST	RFC 3659	Provides data about exactly the object named on its command line, and no others.
NOOP	No operation (dummy packet; used mostly on keepalives).
OPTS	RFC 2389	Select options for a feature.
PBSZ	RFC 2228	Protection Buffer Size
PORT	Specifies an address and port to which the server should connect.
PROT	RFC 2228	Data Channel Protection Level.
REIN	Re initializes the connection.
REST	Restart transfer from the specified point.

SMNT	Mount file structure.
STAT	Returns the current status.

STOU	Store file uniquely.
STRU	Set file transfer structure.

*/


 

#endif //__axFTP_h__

