#ifndef __axHttpMIME_h__
#define __axHttpMIME_h__
 

class axMIME {
public :
	
	static const char* getType( const char* ext );

};


#endif // __axHttpMIME_h__
