#ifndef __axHttpHeader_h__
#define __axHttpHeader_h__

#include <ax/core/net/axSocket.h>

class axHttpHeader {
public :
 
	enum{	k_method_null =0,
			k_method_get,
			k_method_post,
	};

	axHttpHeader();


	axStatus set( axSocket &s );
	axStatus set( const char* hdr );
	
	const char* c_str() { return h_.c_str(); }

	bool isGet()	{ return method_ == k_method_get; }
	bool isPost()	{ return method_ == k_method_post; }

	bool isUrlencoded();
	bool isMultipart();

	
	axStatus getRequestUrl( axIStringA &str );

	template <class T> 
	axStatus getValue( const char* name, T &r );

	axStatus getUrlencodedData( axIStringA &str, axSocket &s );
	axStatus getMultipartData( axIByteArray &buf, axSocket &s );



	axStatus onTake( axHttpHeader &src );
private:


	axStatus	checkHeader_();

	axTempStringA		h_;
	uint8_t				method_;
};


#endif //axHttpHeader
