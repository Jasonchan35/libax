#ifndef __axHttpStatus_h__
#define __axHttpStatus_h__
 

class axHttpStatus {
public :

	static const char* getCodeTitle( int code );
	static const char* getMIMEType( const char* ext );

};


#endif //__axHttpStatus_h__
