#ifndef __axSimpleHttpServer_h__
#define __axSimpleHttpServer_h__

#include <ax/core/thread/axThreadPool.h>
#include <ax/core/net/axSocket.h>

#include "axHttpStatus.h"
#include "axHttpHeader.h"


class axSimpleHttpServer : private axThreadPool {
public :

	enum{ k_default_port = 80, };

	axSimpleHttpServer();

	axStatus	start( int port = 80, 
							const char*	doc_folder = "www", 
							const char* host = "0.0.0.0", 
							const char* server_address = "localhost" ,
							const char* server_name = "axSimpleHttpServer" );
	void		stop();

			axStatus setServerName( const char* str );
	virtual	axStatus onRequest( bool &is_process, axSocket &s, axHttpHeader &hdr ) { return 0; }
	

	axStatus sendError_( axSocket &s, int code, const char* msg=NULL, const char* extra_header=NULL );

	axStatus sendFile_( axSocket &s, const char* szfile );
	axStatus sendHtml_( axSocket &s, const char* str );
			

private:
	
		
	virtual void onThreadProc	( axThread* thread );
	
	axStatus processClient_( axSocket &s );

	axStatus OnRequestDefault( axSocket &s, axHttpHeader &hdr );

	axStatus sendHeader_( axSocket &s, int code, axSize content_len=0, const char* mime_type="text/html", const char* extra_header=NULL );
	

	//sendFile
 
	


	int port_;
	axTempStringA serverHost_, serverAddress_, serverName_;
	axTempStringA docFolder_;

	axSocket sock_;
	axSocket client_sock_;

};


#endif // __axSimpleHttpServer_h__s
