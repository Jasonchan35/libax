#pragma once
#ifndef __ax_common_h__
#define __ax_common_h__

#include "axStatus.h"
#include "ax_utility.h"
#include "ax_byteorder.h"
#include "ax_macro.h"

#endif //__ax_common_h__
