#ifndef __ax_os_freebsd_h__
#define __ax_os_freebsd_h__

#ifdef axOS_FreeBSD

#include <sys/types.h>
#include <machine/atomic.h>

#endif //axOS_FreeBSD

#endif //__ax_os_freebsd_h__
