//
//  ax_wxWidgets.h
//  libax
//
//  Created by Jason on 27/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef libax_ax_wxWidgets_h
#define libax_ax_wxWidgets_h

#include "ax_App.h"

#if axOS_MacOSX
	#define __WXOSX_COCOA__				1
#endif

#include <wx/defs.h>
#include <wx/wx.h>

template<> inline axStatus axStringFormat_out( axStringFormat &f, const wxSize  &value ) { return f.format("<{?}, {?}>", value.x, value.y ); }
template<> inline axStatus axStringFormat_out( axStringFormat &f, const wxPoint &value ) { return f.format("<{?}, {?}>", value.x, value.y ); }

template<> inline axStatus axStringFormat_out( axStringFormat &f, const wxRealPoint &value ) { return f.format("<{?}, {?}>", value.x, value.y ); }

inline	wxColor to_wxColor( const axColorRGBb & s ) { return wxColor( s.r, s.g, s.b ); }
inline	wxColor to_wxColor( const axColorRGBf & s ) { return to_wxColor( axColorRGBb(s) ); }

inline	axColorRGBb	to_axColorRGBb(	const wxColor & s ) { return axColorRGBb( s.Red(), s.Green(), s.Blue() ); }
inline	axColorRGBf	to_axColorRGBf(	const wxColor & s ) { return axColorRGBb( s.Red(), s.Green(), s.Blue() ); }

template<> inline
axStatus axStringFormat_out( axStringFormat &f, const wxString & value ) { 
	return f.put( value.wc_str() );
}

inline axVec2f to_axVec2f( const wxPoint &pt ) { return axVec2f(pt.x,pt.y); }
inline axVec2d to_axVec2d( const wxPoint &pt ) { return axVec2d(pt.x,pt.y); }

class wxVBoxSizer : public wxBoxSizer {
public: 
	wxVBoxSizer() : wxBoxSizer( wxVERTICAL ) {}
};

class wxHBoxSizer : public wxBoxSizer {
public: 
	wxHBoxSizer() : wxBoxSizer( wxHORIZONTAL ) {}
};


#endif
