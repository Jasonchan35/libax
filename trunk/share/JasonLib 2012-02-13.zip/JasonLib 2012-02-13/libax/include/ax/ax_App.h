//
//  ax_glApp.h
//  ax
//
//  Created by Jason on 25/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __ax_glApp_h__
#define __ax_glApp_h__

#include "App/opengl/ax_opengl_def.h"
#include "ax_core.h"

//app
#include "App/GLApp/axGLApp.h"
#include "App/GLApp/axGLAppMode.h"
#include "App/GLApp/axGLAppMouseEvent.h"
#include "App/GLApp/axGLAppRenderRequest.h"
#include "App/GLApp/axGLAppTouchEvent.h"

//ui
#include "App/ui/axGLUIButton.h"
#include "App/ui/axGLUIView.h"
#include "App/ui/axGLUIVBox.h"
#include "App/ui/axGLUIScaleView.h"
#include "App/ui/axGLUIText.h"
#include "App/ui/axGLUIForm.h"
#include "App/ui/axGLUIClickEvent.h"



#include "App/sound/all_sound.h"
#include "App/openal/all_openal.h"
#include "App/opengl/all_opengl.h"

#ifdef axCOMPILER_VC
	#pragma comment( lib, "ax_App.lib" )
#endif


#endif //__ax_glApp_h__

