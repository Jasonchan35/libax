#ifndef __ax_all_lang_table_h__
#define __ax_all_lang_table_h__

#include "axLangTable.h"


#endif //__ax_all_lang_table_h__
