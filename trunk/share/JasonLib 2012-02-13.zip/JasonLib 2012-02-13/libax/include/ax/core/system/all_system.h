#ifndef __ax_all_system_h__
#define __ax_all_system_h__

#include "axApp.h"
#include "ax_poll.h"
#include "axSystem.h"
#include "axSharedLibrary.h"


#endif //__ax_all_system_h__
