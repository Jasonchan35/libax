#ifndef AXALIGNMENT_H
#define AXALIGNMENT_H

#include "../../ax_base.h"

class axAlignment {
public:
	axAlignment()			{ a_ = kUnknown; }
	axAlignment( int a )	{ a_ = a; }

	bool	hasLeft		() const	{ return ( a_ & kLeft    ) != 0; }
	bool	hasRight	() const	{ return ( a_ & kRight   ) != 0; }
	bool	hasCenterX	() const	{ return ( a_ & kCenterX ) != 0; }

	bool	hasTop		() const	{ return ( a_ & kTop     ) != 0; }
	bool	hasBottom	() const	{ return ( a_ & kBottom  ) != 0; }
	bool	hasCenterY	() const	{ return ( a_ & kCenterY ) != 0; }

	operator	uint8_t&()			{ return a_; }

	enum {
		kUnknown		= 0,
		//-----------
		kLeft			= 0x01,
		kRight			= 0x02,
		kCenterX		= 0x04,
		//------------
		kTop			= 0x10,
		kBottom			= 0x20,
		kCenterY		= 0x40,
		//------------
		kTopLeft		= kTop     | kLeft,
		kTopRight		= kTop     | kRight,
		kTopCenter		= kTop     | kCenterX,
		//------------
		kBottomLeft		= kBottom  | kLeft,
		kBottomRight	= kBottom  | kRight,
		kBottomCenter	= kBottom  | kCenterX,
		//------------
		kCenterLeft		= kCenterY | kLeft,
		kCenterRight	= kCenterY | kRight,
		kCenterXY		= kCenterY | kCenterX
	};

private:
	uint8_t	a_;
};

#endif // AXALIGNMENT_H
