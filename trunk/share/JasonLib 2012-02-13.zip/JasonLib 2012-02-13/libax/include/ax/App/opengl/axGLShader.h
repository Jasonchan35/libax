/*  Filename = OpenGLShader.h /  Project= awecore
 *  Created by Jason on 18/05/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#ifndef __axGLShader_h__
#define __axGLShader_h__

#include "ax_opengl_def.h"

#ifdef axUSE_OpenGL_ShadingProgram

class axGLShader : public axNonCopyable {
public:
	axGLShader();
	~axGLShader();
	
	void	destroy			();
		
	GLuint	id			()		{ return _id; }
	GLenum	type		()		{ return _type; }
	
	void	info_log	();

protected:
	axStatus	create			( GLenum shaderType, const char* glsl );
	
private:
	GLuint	_id;
	GLenum	_type;
};

// ===================
class axOpenGLVertexShader : public axGLShader {
	typedef axGLShader	B;
public:
	axStatus	create( const char* glsl )	{ return B::create( GL_VERTEX_SHADER, glsl ); }
};

// ===================
class axOpenGLFragmentShader : public axGLShader {
	typedef axGLShader	B;
public:
	axStatus	create( const char* glsl )	{ return B::create( GL_FRAGMENT_SHADER, glsl ); }
};
	
#endif //axUSE_OpenGL_ShadingProgram

#endif //__axGLShader_h__

