#ifndef __axGLUIButton_h__
#define __axGLUIButton_h__

#include "axGLUIView.h"
#include "axGLUIClickEvent.h"


class axGLUIButton : public axGLUIView {
public:

	enum{ cmd_undefine = -1, };
	
	
	axGLUIButton();
	
	virtual	void		onRender( axGLAppRenderRequest& req ) const;
	virtual void		onTouchEvent( axGLAppTouchEvent &ev );	


	virtual void		onClick();	
	

	
	
			void		setCmd( int32_t id_ );
			
	
	
private: 

	int32_t cmdID_;	
	bool	is_down_;				

	
};

typedef axSharedPtr< axGLUIButton > axGLUIButtonRef;

#endif //__axGLUIButton_h__
