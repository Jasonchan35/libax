/*  Filename = axGLApp.h /  Project= awegame
 *  Created by Jason on 02/12/2009.
 *  Copyright 2009 Awenix. All rights reserved. */

#ifndef __axGLApp_h__
#define __axGLApp_h__

#include "../../core/system/axApp.h"

#include "axGLAppRenderRequest.h"
#include "axGLAppTouchEvent.h"
#include "axGLAppMouseEvent.h"
#include "axGLAppKeyEvent.h"
#include "../ui/axGLUIMgr.h"

class axGLAppMode;

class axGLApp : public axApp, public axGLAppCommon {
public:
	axGLApp();
	virtual ~axGLApp();

			void        quit();
					
	virtual axStatus	onCreate			();
	virtual axStatus	onEnterForeground	()	{ axPRINT_FUNC_NAME; return 0; }
	virtual	void		onEnterBackground	()	{ axPRINT_FUNC_NAME; }
	
	virtual axStatus	onBecomeActive		();
	virtual	void		onResignActive		();
	
	virtual void        onDestroy			();
		
	virtual void        onResize			( float width, float height );

			void		setContentRect		( const axRect2f &rect );
			axRect2f	contentRect			() const;

			void		setWindowPos		( const axVec2f & pos );
			void		setWindowPos		( float w, float h ) { setWindowPos( axVec2f(w,h) ); }
	
			void		setWindowSize		( const axVec2f & size );	//!< window size including title bar, border ... etc
			void		setWindowSize		( float w, float h ) { setWindowSize( axVec2f(w,h) ); }
	
			void		setContentSize		( const axVec2f & size );
			void		setContentSize		( float w, float h ) { setContentSize( axVec2f(w,h) ); }
	
			axVec2f		windowPos			() const;
			axVec2f		windowSize			() const;
			axVec2f		contentSize			() const;

			axStatus	setFullScreen		( bool b );
	
			void		setFrameRate		( float fps );
	
	static	axGLApp* 	getInstance			();
                
	template< class T > 
	static	axStatus	_run ( const char* appName )	{ return run_(  appName, modeCreatorFunc_<T> ); }
	
	template< class T > 
			axStatus	pushMode	()			{ return pushMode_  ( modeCreatorFunc_<T> ); }
			void		popMode		();
	template< class T > 
			axStatus	changeMode	()			{ return changeMode_( modeCreatorFunc_<T> ); }
           
    virtual	void        onFrame                 ( axGLAppRenderRequest &req );
	virtual	void		onTouchEvent			( axGLAppTouchEvent &ev );
    virtual void		onMouseEvent			( axGLAppMouseEvent &ev );
	virtual void		onKeyEvent				( axGLAppKeyEvent	&ev );

            void        setStatusBarVisible     ( bool b,   bool animated = true );

            //! angle: 0 90 180 270
            void        setOrientation			( float angle, bool animated = true );
            
            float       orientation             ();
            void        setAutoOrientation      ( bool b );

            //void        set2DMode               ();
            
            axStatus	enableAccelerometer		( bool b );
            axStatus	loadResource			( axGLTextureRes &out, const char* filename );
	
			axGLContext	gl;	
			void		setTitleName			( const wchar_t* name );

//----- internal ---------
//private:

	typedef axGLAppMode* (*ModeCreatorFunc)();
	template< class T >	static inline axGLAppMode* modeCreatorFunc_()	{ return new T; }

	static	axStatus	run_			( const char* appName, ModeCreatorFunc m );
			axStatus	pushMode_		( ModeCreatorFunc m );
			axStatus	changeMode_		( ModeCreatorFunc m );
			void		doPopMode_		();
			

			axStatus	onCreate_		();
			void        onDestroy_		();
			void        onFrame_		();
			void        onResize_		( float w, float h );
			void		onTouchEvent_	( int action, axGLAppTouch::TouchId touchId, const axVec2f& pos, float pressure, double timestamp );
			void		onMouseEvent_	( int action, axSize eventButton, const axVec2f& pos, const axVec3f& scoll, float pressure, double timestamp );
			void		onKeyEvent_		( int action, int key, const char* characters, const char* charactersIgnoringModifiers );
			void		onAccelerate_	( const axVec3f& a );
	
			float       orientation_;
			bool        autoOrientation_;
			float       contentScaleFactor_;
	
			float		contentScaleFactor() { return contentScaleFactor_; }	

//--- os ----	
	void        _os_ctor		();
	void        _os_dtor		();
	void        _os_quit		();
	axStatus	_os_run			();

	axVec2f		_os_windowPos	() const;
	axVec2f		_os_windowSize	() const;
	axVec2f		_os_contentSize	() const;
	
	void		_os_setFrameRate			();
	
	void		_os_setWindowPos			( const axVec2f & pos );
	void		_os_setWindowSize			( const axVec2f & size );
	void		_os_setContentSize			( const axVec2f & size );
	
	void        _os_setStatusBarVisible		( bool  b,     bool animated );
	void        _os_setOrientation			( float angle, bool animated );
	void        _os_onOrientationDidChange	( float roll,  float pitch );
	void        _os_setAutoOrientaton		( bool  b );
	axStatus	_os_setFullScreen			( bool  b );
	axStatus	_os_enableAccelerometer     ( bool  b );
	void		_os_setTitleName			( const wchar_t* name );
	
// ----------
	bool		enableAccelerometer_;
	float       expect_fps_;
	axStopWatch frameTimer_;

	float       fps_time_;
	int         fps_frame_;
    float       fps_;
	
	axFont      defaultUIFont_;
    
	axGLUIMgr*	uimgr() { return axGLUIMgr::getInstance(); }
	
//	axGLUIMgr	uiMgr;
//	agSoundMgr  snd_mgr;

	ModeCreatorFunc		nextModeCreator_;
	axStatus			createNextMode_( axGLAppMode* &new_mode, axGLAppMode* prevMode );
	
	enum {
		m_unchange,
		m_change_mode,
		m_push_mode,
		m_pop_mode,
	};
	int						needChangeMode_;
	axGLAppMode*			currentMode_;

	axGLAppRenderRequest	renderRequest;
	axGLAppTouches			touches;
	axGLAppMouseEvent		mouseEvent;
	axGLAppKeyEvent			keyEvent;
	
#if axOS_iOS
	UIWindow*			win_;
	UIView*				rotate_view_;
	UIView*				glview_;
	CADisplayLink*		display_link_;
	void	_os_onResize();
#endif

#if axOS_MacOSX
	NSWindow*			win_;
	NSOpenGLView*		glview_;
	id					delegate_;
	NSTimer*			_os_timer;
	
#endif

#if axOS_WIN
	HWND	hwnd_;
#endif

};

#if axOS_Android
	axStatus axGLApp_onRun();
	#define axGLApp_program_main( AppName,FirstMode ) \
		axStatus axGLApp_onRun() { axGLApp::_run<FirstMode>( AppName ); }
#elif axOS_WIN
	#define axGLApp_program_main( AppName,FirstMode ) \
		int main() { axGLApp::_run<FirstMode>( AppName ); } \
		int CALLBACK WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) { axGLApp::_run<FirstMode>( AppName ); }
#else
	#define axGLApp_program_main( AppName, FirstMode ) \
		int main() { axGLApp::_run<FirstMode>( AppName ); }
#endif

#endif //__axGLApp_h__

