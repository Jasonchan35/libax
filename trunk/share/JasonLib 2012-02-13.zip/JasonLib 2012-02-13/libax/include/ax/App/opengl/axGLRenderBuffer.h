#ifndef __axGLRenderBuffer_h__
#define __axGLRenderBuffer_h__

#include "ax_opengl_def.h"

//! OpenGL Render Buffer Object
class axGLRenderBuffer : public axNonCopyable {
public:
	axGLRenderBuffer();
	~axGLRenderBuffer();

	//! internalFormat = GL_DEPTH_COMPONENT, GL_RGB, GL_RGBA
	axStatus	create( int width, int height, GLenum internalFormat );
#ifdef axUSE_OpenGL_ES
	axStatus	createRGBA ( int width, int height )	{ return create( width, height, GL_RGBA8_OES ); }
	axStatus	createDepth( int width, int height )	{ return create( width, height, GL_DEPTH_COMPONENT16 ); }
#else	
	axStatus	createRGBA ( int width, int height )	{ return create( width, height, GL_RGBA ); }
	axStatus	createDepth( int width, int height )	{ return create( width, height, GL_DEPTH_COMPONENT ); }
#endif
	void	destroy();

	bool	isValid() { return _id != 0; }
	GLuint	id() { return _id; }

	void bind();
	void unbind();

private:
	GLuint	_id;
};
	

#endif //__axGLRenderBuffer_h__

