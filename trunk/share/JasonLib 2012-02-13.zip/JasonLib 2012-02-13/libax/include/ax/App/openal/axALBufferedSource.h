#ifndef __axALBufferedSource_h__
#define __axALBufferedSource_h__


#include "axALSource.h"
#include "axALBuffer.h"

#include "../sound/axPCMWave.h"

#include "../../base/data_structure/axArray.h"
#include "../../base/data_structure/axDList.h"

#ifdef axUSE_OpenAL

class axALBufferedSource : private axALSource {
typedef axALSource B;
public:

	axALBufferedSource();
	~axALBufferedSource();

	void		destroy();
	axStatus	create( size_t buf_count = 2 );
	size_t		avail_count();

	//! return 1 if enqueried, 0 if buf is not available this moment
	axStatus	query( ALenum format, const ALvoid *data, size_t size, ALsizei freq, bool playnow );
	axStatus	query( const axPCMWave &wave, bool is_play_now );
	axStatus	query( const wchar_t *file, bool is_play_now );
	

	void	keep_play()		{ B::keep_play(); }
	void	play()			{ B::play(); }
	bool	is_playing()	{ return B::is_playing(); };

	
	bool	is_created() { return B::is_created(); }
	
	
private:
		
	class Buf : public axDListNode< Buf > {
	public:
		Buf() { setOwnedByList( true ); }
		axALBuffer al_buf;
	};
	axDList<Buf> ls_query, ls_avail;
	
	
	Buf*	_get_avail_buffer();
	axStatus  _query_buffer( Buf *b );
	
};

#endif // axUSE_OpenAL

#endif // __axALBufferedSource_h__


