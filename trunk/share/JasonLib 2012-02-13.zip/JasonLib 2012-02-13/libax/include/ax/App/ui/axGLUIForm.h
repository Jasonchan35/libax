//
//  axGLUIForm.h
//  ax
//
//  Created by Tony on 29/07/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __axGLUIForm_h__
#define __axGLUIForm_h__

#include "axGLUIView.h"

class axGLUIForm : public axGLUIView {
public:
	
		
	virtual	void onClickEvent( axGLUIClickEvent &ev ) { };
	
	
};

typedef axSharedPtr< axGLUIForm > axGLUIFormRef;

#endif //__axGLUIForm_h__
