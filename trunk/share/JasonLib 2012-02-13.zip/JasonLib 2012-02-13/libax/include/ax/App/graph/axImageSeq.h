#ifndef __axImageSequence_h__
#define __axImageSequence_h__

#include "axImage.h"

class axImageSeq : public axNonCopyable {
public:
	axImageSeq();
	~axImageSeq();

			void		clear();
			axStatus	loadFile		( const char* filename );
			axStatus	loadGif			( axIByteArray &buf );

			bool		getIndexByTime	( axSize &out_index, float time ) const;
			axImage&	getFrame		( axSize index )			{ return frames_[index]; }
	const	axImage&	getFrame		( axSize index ) const		{ return frames_[index]; }
			axImage&	getFrameByTime	( float in_time )			{ axSize idx; getIndexByTime( idx, in_time ); return frames_[idx]; } 
	const	axImage&	getFrameByTime	( float in_time ) const		{ axSize idx; getIndexByTime( idx, in_time ); return frames_[idx]; } 
	
			axStatus	setFrameCount( axSize n )			{ return frames_.resize(n); }

			axSize		frameCount	() const	{ return frames_.size(); }
			int			maxLoop		() const	{ return max_loop_; }
			
			int			width		() const	{ return frameCount() ? frames_[0].width()  : 0; }
			int			height		() const	{ return frameCount() ? frames_[0].height() : 0; }
private:
	int max_loop_; //!< 0 means infinite	
	axArray< axImage > frames_;
};


#endif // __axImageSequence_h__
