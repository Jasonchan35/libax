#ifndef __ax_openal_def_h__
#define __ax_openal_def_h__

#include "../../base/common/axStatus.h"

#ifdef axOS_MinGW
	#include <al.h>
	#include <alc.h>
	#define axUSE_OpenAL
#elif  axOS_MacOSX
	#include <OpenAL/al.h>
	#include <OpenAL/alc.h>
	#define axUSE_OpenAL
#elif  axOS_iOS
	#include <OpenAL/al.h>
	#include <OpenAL/alc.h>
	#include <OpenAL/oalStaticBufferExtension.h>
	#define axUSE_OpenAL
#elif axOS_WIN
	#include <ax/external/AL/al.h>
	#include <ax/external/AL/alc.h>
	#define axUSE_OpenAL
	#if axCOMPILER_VC
	//	#pragma comment( lib, "OpenAL.lib" )
	#endif

#endif

#ifdef axUSE_OpenAL

inline 
const char* openal_error_string( ALenum err ) {
	switch( err ) {
		case AL_NO_ERROR:			return "AL_NO_ERROR";
		case AL_INVALID_NAME:		return "AL_INVALID_NAME";
		case AL_INVALID_ENUM:		return "AL_INVALID_ENUM";
		case AL_INVALID_VALUE:		return "AL_INVALID_VALUE";
		case AL_INVALID_OPERATION:	return "AL_INVALID_OPERATION";
		case AL_OUT_OF_MEMORY:		return "AL_OUT_OF_MEMORY";
		default: return "Unknown Error";
	}
}

inline 
void print_openal_error( ALenum err, const char* msg, FILE* stream = stdout ) {
	fprintf( stream, "OpenAL error %d: (%s) %s\n", err, openal_error_string(err), msg );
}

inline 
bool print_openal_if_error( const char* msg, FILE* stream = stdout ) {
	ALenum err = alGetError();
	if( err == AL_NO_ERROR )
		return false;
	print_openal_error( err, msg, stream );
	return true;
}

#endif // axUSE_OpenAL

#endif //__ax_openal_def_h__

