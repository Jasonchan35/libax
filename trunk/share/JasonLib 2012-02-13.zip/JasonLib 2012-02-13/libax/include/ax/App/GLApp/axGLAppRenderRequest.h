#ifndef __axGLAppRenderRequest_h__
#define __axGLAppRenderRequest_h__

#include "../opengl/axGLContext.h"
#include "../opengl/axGLTexture.h"
#include "../opengl/axGLResourceMgr.h"

class axGLAppRenderRequest : public axNonCopyable {
public:
	axGLAppRenderRequest();

	const	axMatrix4f&	projectionMatrix		()			{ return projectionMatrix_; }
	const	axMatrix4f&	modelViewMatrix			()			{ return modelViewMatrix_; }

	const	axMatrix4f&	inverseProjectionMatrix	()			{ computeInverseMatrix();	return inverseProjectionMatrix_; }
	const	axMatrix4f&	inverseModelViewMatrix	()			{ computeInverseMatrix();	return inverseModelViewMatrix_; }

				void	setMatrix				( const axMatrix4f &projection, const axMatrix4f &modelView );
				void	computeInverseMatrix	();

			axRay3f		getRay					( const axVec2f &pointFromScreen );
	const	axRect2f&	region					()			{ return region_; }
				float	frameTime				()			{ return frameTime_; }
	
	const	axVec3f&	acceleration			()			{ return acceleration_; }
	
	class Statistic {
	public:
		Statistic();
		void		clear();
		axSize		triangles;
	};
	Statistic statistic;

	class	UI {
	public:
		UI();
		bool	showLayout;
	};
	
	UI	ui;

friend class axGLApp;
protected:
	float		frameTime_;
	axRect2f	region_;

	axMatrix4f	projectionMatrix_;
	axMatrix4f	modelViewMatrix_;

	axMatrix4f	inverseProjectionMatrix_;
	axMatrix4f	inverseModelViewMatrix_;
	
	axVec3f		acceleration_;

	bool		needComputeInverseMatrix_;
};

#endif //__axGLAppRenderRequest_h__

