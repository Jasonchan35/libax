#ifndef __ax_opengl_def_h__
#define __ax_opengl_def_h__

#include "../../ax_base.h"
#include "../../core/system/axLog.h"
#include "../../App/graph/axColor.h"
#include "../../core/math/all_math.h"
#include "../../core/data_structure/axSharedPtr.h"

#if axOS_WIN
	#include "../../external/glew/glew.h"
	#include <GL/gl.h>
	#include <GL/glu.h>
	#define	axUSE_OpenGL	1
#endif //axOS_WIN

#if axOS_MacOSX
// include in ax_os_mac.h
//	#include "../../external/glew/glew.h"

	#define	axUSE_OpenGL        1
	#define	axUSE_OpenGL_ShadingProgram		1
	#include <OpenGL/gl.h>
	#include <OpenGL/glu.h>
#endif //axOS_MacOSX

#if axOS_Linux
	#if axOS_Android
		#define axUSE_OpenGL		1
		#define axUSE_OpenGL_ES		1
		#include <GLES/gl.h>
		#include <GLES/glext.h>
	#else
		#define axOS_X11            1
		#define	axUSE_OpenGL        1
		#if axUSE_OpenGL
			#include "../../external/glew/glew.h"
		#endif
	#endif
#endif //axOS_Linux

#if axOS_FreeBSD

#define axOS_X11            1
	#define	axUSE_OpenGL    1
	#if axUSE_OpenGL
		#include "../../external/glew/glew.h"
	#endif
#endif


#if axUSE_OpenGL

#if axOS_X11
    #include <X11/Xlib.h>
    #include <GL/glx.h>
#endif

#if axUSE_OpenGL_ES
    inline void glColor3f  ( float r, float g, float b ) { ::glColor4f(r,g,b,1); }
    inline void glColor3fv ( const float* p )			 { ::glColor4f ( p[0], p[1], p[2], 1 ); } 
    inline void glColor4fv ( const float* p )			 { ::glColor4f ( p[0], p[1], p[2], p[3] ); } 
    inline void glColor3bv ( const GLbyte* p )			 { ::glColor4f ( (uint8_t)p[0]/255.0f, (uint8_t)p[1]/255.0f, (uint8_t)p[2]/255.0f, 1 ); }
    inline void glColor4bv ( const GLbyte* p )			 { ::glColor4f ( (uint8_t)p[0]/255.0f, (uint8_t)p[1]/255.0f, (uint8_t)p[2]/255.0f, (uint8_t)p[3]/255.0f ); }
    inline void glOrtho	   ( float left, float right, float bottom, float top, float zNear, float zFar )  { glOrthof( left, right, bottom, top, zNear, zFar ); }
#else 
	inline void glDrawElements	( GLenum mode, GLsizei count, const uint32_t* p )	{ ::glDrawElements( mode, count, GL_UNSIGNED_INT,   p );  }
	inline void glDrawElements	( GLenum mode, const axIArray<uint32_t> &a )		{ ::glDrawElements( mode, (GLsizei)a.size(), GL_UNSIGNED_INT,   a.ptr() );  }

	inline void glVertexPointer  ( const axVec2d *ptr, GLsizei stride=0 )	{ ::glVertexPointer(2,GL_DOUBLE,stride,ptr); }
	inline void glVertexPointer  ( const axVec3d *ptr, GLsizei stride=0 )	{ ::glVertexPointer(3,GL_DOUBLE,stride,ptr); }
	inline void glVertexPointer  ( const axVec4d *ptr, GLsizei stride=0 )	{ ::glVertexPointer(4,GL_DOUBLE,stride,ptr); }

	inline void glNormalPointer  ( const axVec3d *ptr, GLsizei stride=0 )	{ ::glNormalPointer(GL_DOUBLE,stride,ptr); }

#endif //axUSE_OpenGL_ES


inline void glScissor	( const axRect2i &rc )			{ ::glScissor ( rc.x, rc.y, rc.w, rc.h ); }
inline void glScissor	( const axRect2f &rc )			{ ::glScissor ( (int)rc.x, (int)rc.y, (int)rc.w, (int)rc.h ); }
inline void glOrtho		( const axRect2f &rc, float zNear=-1, float zFar=1  )  { glOrtho( rc.x, rc.right(), rc.bottom(), rc.y, zNear, zFar ); }
inline void glLogError	( FILE* s = stdout )			{ ax_log( "glGetError = {?}\n", (int) ::glGetError() ); }

inline void glGet		( GLenum pname, bool	&p )	{ GLboolean b;  glGetBooleanv( pname, &b ); p=b?true:false; }
inline void glGet		( GLenum pname, int		&p )	{ glGetIntegerv( pname, (GLint*)&p ); }
inline void glGet		( GLenum pname, float	&p )	{ glGetFloatv  ( pname, &p ); }

inline void glGet		( GLenum pname, axRect2f &p )	{ glGetFloatv( pname, p.asPointer() ); }
inline void glGet		( GLenum pname, axRect2i &p )	{ glGetIntegerv( pname, p.asPointer() ); }

inline void glGetV		( GLenum pname, int		*p )	{ glGetIntegerv( pname, (GLint*)p ); }
inline void glGetV		( GLenum pname, float	*p )	{ glGetFloatv  ( pname, p ); }	
	
inline void glGetModelViewMatrix	( axMatrix4f &m  )	{ glGetFloatv ( GL_MODELVIEW_MATRIX, m.asPointer() ); }
inline void glGetProjectionMatrix	( axMatrix4f &m  )	{ glGetFloatv ( GL_PROJECTION_MATRIX, m.asPointer() ); }
inline void glGetViewport			( axRect2f   &rc )	{ glGetFloatv ( GL_VIEWPORT, &rc.x ); }

//-------------- float ------------------------
inline void glColor   ( const axColorRGBf &v )  { glColor3fv( v.asPointer() ); }
inline void glColor   ( const axColorRGBAf &v ) { glColor4fv( v.asPointer() ); }

inline void glColorPointer   ( const axColorRGBf  *ptr, GLsizei stride=0 ) { ::glColorPointer (3,GL_FLOAT,stride,ptr); }
inline void glColorPointer   ( const axColorRGBAf *ptr, GLsizei stride=0 ) { ::glColorPointer (4,GL_FLOAT,stride,ptr); }

inline void glVertexPointer  ( const axVec2f *ptr, GLsizei stride=0 )	{ ::glVertexPointer(2,GL_FLOAT,stride,ptr); }
inline void glVertexPointer  ( const axVec3f *ptr, GLsizei stride=0 )	{ ::glVertexPointer(3,GL_FLOAT,stride,ptr); }
inline void glVertexPointer  ( const axVec4f *ptr, GLsizei stride=0 )	{ ::glVertexPointer(4,GL_FLOAT,stride,ptr); }

inline void glNormalPointer  ( const axVec3f *ptr, GLsizei stride=0 )	{ ::glNormalPointer(GL_FLOAT,stride,ptr); }

inline void glTexCoordPointer( const axVec2f *ptr, GLsizei stride=0 )	{ ::glTexCoordPointer(2,GL_FLOAT,stride,ptr); }
inline void glTexCoordPointer( const axVec3f *ptr, GLsizei stride=0 )	{ ::glTexCoordPointer(3,GL_FLOAT,stride,ptr); }
inline void glTexCoordPointer( const axVec4f *ptr, GLsizei stride=0 )	{ ::glTexCoordPointer(4,GL_FLOAT,stride,ptr); }

inline void glLoadMatrix	( const axMatrix4f &m )									{ ::glLoadMatrixf( &m[0][0] ); }
inline void glMultMatrix	( const axMatrix4f &m )									{ ::glMultMatrixf( &m[0][0] ); }

inline void glTranslate		( float x, float y, float z = 0 )						{ ::glTranslatef( x, y, z ); }
inline void glTranslate		( const axVec3f &v )									{ ::glTranslatef( v.x, v.y, v.z ); }
inline void glTranslate		( const axVec2f &v )									{ ::glTranslatef( v.x, v.y, 0   ); }

inline void glEulerRotate	( const axVec3f & r )									{ axEulerRotation3f e(r); glMultMatrix( e.to_Matrix4() ); }
inline void glEulerRotate	( float x, float y, float z )							{ glEulerRotate( axVec3f(x,y,z) ); }

inline void glRotate		( float angle_in_deg, const axVec3f &v )				{ ::glRotatef( angle_in_deg, v.x, v.y, v.z ); }
inline void glRotate		( float angle_in_deg, float x, float y, float z )		{ ::glRotatef( angle_in_deg, x,y,z ); }

inline void glScale			( float x, float y, float z = 1 )						{ ::glScalef( x,y,z ); }
inline void glScale			( const axVec3f &v )									{ ::glScalef( v.x, v.y, v.z ); }
inline void glScale			( const axVec2f &v )									{ ::glScalef( v.x, v.y, 1   ); }
inline void glScale			( float v )												{ ::glScalef( v,v,v ); }

inline void glClearColor	( const axColorRGBf  &v )								{ ::glClearColor( v.r, v.g, v.b, 1.0f ); }
inline void glClearColor	( const axColorRGBAf &v )								{ ::glClearColor( v.r, v.g, v.b, v.a  ); }

//-------------- byte ------------------------
inline void glColor			( const axColorRGBb  &v )								{ ::glColor3bv( (GLbyte*)v.asPointer() ); }
inline void glColor			( const axColorRGBAb &v )								{ ::glColor4bv( (GLbyte*)v.asPointer() ); }
inline void glColorPointer	( const axColorRGBAb *ptr, GLsizei stride=0 )			{ ::glColorPointer (4,GL_BYTE,stride,ptr); }

inline void glTranslate		( int x, int y, int z = 0 )								{ ::glTranslatef( (float)x, (float)y, (float)z ); }

//----------------------- Rect ------------------------

inline void glViewport		( const axRect2i &rc )									{ ::glViewport( rc.x, rc.y, rc.w, rc.h ); }
inline void glViewport		( const axRect2f &rc )									{ ::glViewport( (int)rc.x, (int)rc.y, (int)rc.w, (int)rc.h ); }

//-------------

inline void glClearBuffers	( GLbitfield mask = GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT ) { glClear(mask); }

inline void glDrawElements	( GLenum mode, GLsizei count, const uint8_t*  p ) { ::glDrawElements( mode, count, GL_UNSIGNED_BYTE,  p );  }
inline void glDrawElements	( GLenum mode, GLsizei count, const uint16_t* p ) { ::glDrawElements( mode, count, GL_UNSIGNED_SHORT, p );  }

inline void glDrawElements	( GLenum mode, const axIArray<uint8_t > &a ) { ::glDrawElements( mode, (GLsizei)a.size(), GL_UNSIGNED_BYTE,  a.ptr() );  }
inline void glDrawElements	( GLenum mode, const axIArray<uint16_t> &a ) { ::glDrawElements( mode, (GLsizei)a.size(), GL_UNSIGNED_SHORT, a.ptr() );  }

class axScopeGLPushMatrix {
public:
	axScopeGLPushMatrix()	{ glPushMatrix(); }
	~axScopeGLPushMatrix()	{ glPopMatrix(); }
};

class axScopeGLPushProjectionMatrix {
public:
	axScopeGLPushProjectionMatrix() {
		glMatrixMode( GL_PROJECTION );
		glPushMatrix();
		glMatrixMode( GL_MODELVIEW );
	}

	~axScopeGLPushProjectionMatrix() {
		glMatrixMode( GL_PROJECTION );
		glPopMatrix(); 
		glMatrixMode( GL_MODELVIEW );
	}
};

class axScopeGLMultMatrix : axScopeGLPushMatrix {
public:
	axScopeGLMultMatrix( const axMatrix4f &m ) { glMultMatrix(m); }
};

class axScopeGLEnable {
public:
	axScopeGLEnable( GLenum cap )	{ _cap = cap; _prev = glIsEnabled( cap ); if( !_prev) glEnable( cap ); }
	~axScopeGLEnable()				{ if( !_prev ) glDisable( _cap ); }
private:
	GLenum		_cap;
	GLboolean	_prev;
};

class axScopeGLDisable {
public:
	axScopeGLDisable( GLenum cap )	{ _cap = cap; _prev = glIsEnabled( cap ); if( _prev ) glDisable( cap ); }
	~axScopeGLDisable()				{ if( _prev ) glEnable( _cap ); }
private:
	GLenum		_cap;
	GLboolean	_prev;
};

class axScopeGLEnableClientState {
public:
	axScopeGLEnableClientState ( GLenum a )	{ _a = a;	glEnableClientState( a ); }
	~axScopeGLEnableClientState()				{ glDisableClientState( _a );	}
private:
	GLenum _a;
};
		
class axScopeGLScissor {
public:
	template< class Rect >
	axScopeGLScissor( const Rect &rc ) { 
		glGet( GL_SCISSOR_BOX, old );
		glScissor( rc );
		glEnable( GL_SCISSOR_TEST );
	}
	
	~axScopeGLScissor() { 
		glScissor( old ); 
		glDisable( GL_SCISSOR_TEST );		
	}
	axRect2i	old;
};	

class axScopeGLLineWidth {
public:
	axScopeGLLineWidth( float f )	{ glLineWidth(f); }
	~axScopeGLLineWidth()			{ glLineWidth(1); }
};

class axScopeGLPointSize {
public:
	axScopeGLPointSize( float f )	{ glPointSize(f); }
	~axScopeGLPointSize()			{ glPointSize(1); }
};

class axScopeGLColor {
public:
	template< class Color >
	axScopeGLColor( Color &col )	{ glColor(col); }
	~axScopeGLColor()				{ glColor3f(1,1,1); }
};

class axScopeGLVertexPointer {
public:
	template< class T >
	axScopeGLVertexPointer ( const T* ptr, GLsizei stride=0 )	{ glVertexPointer( ptr, stride ); glEnableClientState( GL_VERTEX_ARRAY ); }
	~axScopeGLVertexPointer()									{ glDisableClientState( GL_VERTEX_ARRAY ); }
};

class axScopeGLColorPointer {
public:
	template< class T >
	axScopeGLColorPointer ( const T* ptr, GLsizei stride=0 )		{ glColorPointer( ptr, stride ); glEnableClientState( GL_COLOR_ARRAY ); }
	~axScopeGLColorPointer()									{ glDisableClientState( GL_COLOR_ARRAY ); }
};

class axScopeGLTexCoordPointer {
public:
	template< class T >
	axScopeGLTexCoordPointer ( const T* ptr, GLsizei stride=0 )	{ glTexCoordPointer( ptr, stride ); glEnableClientState( GL_TEXTURE_COORD_ARRAY ); }
	~axScopeGLTexCoordPointer()									{ glDisableClientState( GL_TEXTURE_COORD_ARRAY ); }
};

class axScopeGLNormalPointer {
public:
	template< class T >
	axScopeGLNormalPointer ( const T* ptr, GLsizei stride=0 )	{ glNormalPointer( ptr, stride ); glEnableClientState( GL_NORMAL_ARRAY ); }
	~axScopeGLNormalPointer()									{ glDisableClientState( GL_NORMAL_ARRAY ); }
};


void ax_gl2DMode( bool upside_down=true );
void ax_gl3DMode( float fov_y_in_deg = 60, float zNear=0.01, float zFar=1000 ); 

class	axScopeGL2DMode {
public:
	axScopeGL2DMode( bool upside_down=true ) : depthTest_( GL_DEPTH_TEST ) { 
		ax_gl2DMode( upside_down ); 
	}
private:
	axScopeGLDisable				depthTest_;
	axScopeGLPushProjectionMatrix	proj_;
	axScopeGLPushMatrix				pm_;
};

bool ax_glTransformVertex( axVec2f & out, const axVec3f &v, const axMatrix4f & modelview, const axMatrix4f &projection, const axRect2f & viewport );

#endif //axUSE_OpenGL

#endif //__ax_opengl_def_h__

