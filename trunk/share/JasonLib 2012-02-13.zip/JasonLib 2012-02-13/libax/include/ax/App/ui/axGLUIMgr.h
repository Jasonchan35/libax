//
//  axGLUIMgr.h
//  ax
//
//  Created by Jason on 25/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __axGLUIMgr_h__
#define __axGLUIMgr_h__

#include "../opengl/ax_gl_draw.h"

class axGLUIMgr : public axNonCopyable {
public:
	axGLUIMgr();
	
	static	axGLUIMgr* 	getInstance	();
	
	void	render();
};


#endif //__axGLUIMgr_h__
