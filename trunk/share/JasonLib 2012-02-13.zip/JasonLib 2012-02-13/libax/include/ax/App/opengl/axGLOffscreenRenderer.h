/*  Filename = axGLOffscreenRenderer.h /  Project= awecore
 *  Created by Jason on 21/07/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#ifndef __axGLOffscreenBuffer_h__
#define __axGLOffscreenBuffer_h__

#include "axGLRenderBuffer.h"
#include "axGLFrameBuffer.h"

class axGLOffscreenRenderer : public axNonCopyable {
public:
	axGLOffscreenRenderer();
	~axGLOffscreenRenderer();
	
	
	axStatus	create( int width, int height );
	void		destroy();
	
	void		bind();
	void		unbind();
	
private:
	GLuint		_old_fbo;
	axRect2f	_old_viewport;
	bool		_binding;
	bool		_created;
	
	int _w, _h;
	
	axGLRenderBuffer	color_buf;
	axGLRenderBuffer	depth_buf;
	axGLFrameBuffer		fbo;
};


#endif //__axGLOffscreenBuffer_h__

