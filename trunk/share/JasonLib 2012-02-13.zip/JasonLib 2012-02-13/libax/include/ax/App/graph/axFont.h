#ifndef __axFont_h__
#define __axFont_h__

#include "axAlignment.h"
#include "../../core/math/axRect2.h"
#include "../../core/system/axLog.h"

#include "axColor.h"


#ifdef axOS_Android
	#include "../system/axAndroid.h"
//	#define axUSE_FreeType2		1
#endif

#ifdef axUSE_FreeType2
	class axFreeType2_Face;
#endif

class axImage;

class axFont : public axNonCopyable {
public:
	axFont();
	~axFont();

	//! face = NULL for default font
	axStatus	create				( const wchar_t* face, float size, bool bold=false, bool italic=false );
	void		close				();

	axStatus	makeImageAb			( axImage  &img, const wchar_t* text );
	axStatus	makeImageAbInRect	( axImage  &img, const wchar_t* text, int width, int height, axAlignment align );
	
	axStatus	getTextRect			( int &outWidth, int &outHeight, const wchar_t* text );
	

	//float				getFontSizeBy( const wchar_t* str, int w );
	//static float		getFontSizeBy( const wchar_t* fontFace, const wchar_t* str, float w, float h, float minFontSize=10 );
	static axStatus		getFontSizeBy( float &out, const wchar_t* fontFace, const wchar_t* str, axVec2f size, float minFontSize );

	static axStatus		defaultFontFace( axIStringW &s, float size );


private:
#ifdef axUSE_FreeType2
	axFreeType2_Face*	font_;
#elif axOS_Android
	jobject		font_;

	static	axTHREAD_LOCAL	jclass 			jni_class;
	static	axTHREAD_LOCAL	jmethodID		jni_init;
	static	axTHREAD_LOCAL	jmethodID		jni_create;
	static	axTHREAD_LOCAL	jmethodID		jni_getTextRect;
	static	axTHREAD_LOCAL	jmethodID		jni_makeImageInRect;
#elif axOS_WIN
	HFONT			font_;
#elif axOS_iOS
	UIFont*			font_;
#elif axOS_MacOSX
	NSFont*			font_;
#endif

};

#endif //__axFont_h__
