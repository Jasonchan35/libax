#ifndef __axALWave_h__
#define __axALWave_h__

#include "ax_openal_def.h"
#include "../sound/axPCMWave.h"

#ifdef axUSE_OpenAL

class axALWave : public axPCMWave {
public:
	
	int format;

	axALWave();

	axStatus create( int format, uint32_t buf_sample_size = 0, int freq = 44100 );

	axStatus create_mono8		( uint32_t buf_sample_size = 0, int freq = 44100 );
	axStatus create_mono16		( uint32_t buf_sample_size = 0, int freq = 44100 );
	axStatus create_stereo8		( uint32_t buf_sample_size = 0, int freq = 44100 );
	axStatus create_stereo16	( uint32_t buf_sample_size = 0, int freq = 44100 );

private:
	axALWave& operator=( const axALWave& src );

};

#endif //axUSE_OpenAL

#endif //__axALWave_h__


