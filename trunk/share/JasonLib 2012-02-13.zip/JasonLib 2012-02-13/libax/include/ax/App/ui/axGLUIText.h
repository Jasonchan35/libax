#ifndef __axGLUIText_h__
#define __axGLUIText_h__


#include "axGLUIView.h"

class axGLUIText : public axGLUIView {
	typedef axGLUIView	B;	
public:

	axGLUIText();
	virtual	void onLayout();	
	void onRender( axGLAppRenderRequest& req ) const;


	axStatus setText( const char *sz );	
	axStatus setText( const wchar_t *sz );
	axStatus setFontFace( const wchar_t *sz );
	
	
	void setFontProportion( float p );	
	void setFontSize( float size );	



	void setFontAlignment( axAlignment a );
	
private:

	axGLTexture texText_;

	float fontSize_;
	float fontProportion_;
	axAlignment fontAlignment_;
	
	axStringW	text_, fontFace_;
	bool textDirty_: 1;

};

typedef axSharedPtr< axGLUIText >	axGLUITextRef;



#endif //__axGLUIText_h__

