/*  Filename = axAudioPlayer.h /  Project= libax
 *  Created by Tony on 25/07/2011.
 *  Copyright 2009 Awenix. All rights reserved. */

#ifndef __axAudioPlayer_h__
#define __axAudioPlayer_h__

#include "../../base/common/axStatus.h"
#include "../../base/common/ax_utility.h"
#include "../../base/platform/ax_platform.h"

class axAudioPlayer : public axNonCopyable {
public:
		
	axAudioPlayer();
	virtual ~axAudioPlayer();
		
	void close();
	
	
	virtual void callbackFinshPlaying( bool is_success ) {};
	virtual void callbackBeginInterruption(){};
	virtual void callbackEndInterruption(){};
	
	
	axStatus init( const char* file_path );
	
	axStatus play();
	axStatus playAtTime( float v );
	
	void	 resume();
	void	 pause();
	void	 stop();
	
	
	void	setVolume( float v );
	void	setLoop( int v );
	
	float	volume();
	bool	is_playing();
	
	
	
#if axOS_iOS
	
	AVAudioPlayer		*player_;
	id					delegate_;

#endif
 
 
};


#endif //__axAudioPlayer_h__

