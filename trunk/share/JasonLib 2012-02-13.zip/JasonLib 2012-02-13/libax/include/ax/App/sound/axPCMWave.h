#pragma once
#ifndef __axPCMWave_h__
#define __axPCMWave_h__

#include "../../ax_base.h"

class axPCMWave : public axNonCopyable
{
public:
	int		freq; //! also know as sample_rate

	enum {
		ch_mono   = 1,
		ch_stereo = 2,
	};
	
	int			ch;

	int			bit;
	uint32_t	sample; //sample in buf
	uint32_t	buf_sample_size;
	axByteArray	buf;


	axPCMWave()	 { init(); }
	~axPCMWave()	{ destroy(); }

	void init();
	void destroy();
	
	
	axStatus load_file ( const wchar_t *filename );
	axStatus save_file ( const wchar_t *filename );	
	
	axStatus load_wav_file ( const axIByteArray &buf );
	axStatus save_wav_file ( axIByteArray &buf );	
	
	axStatus create( uint32_t buf_sample_size, int freq, int ch, int bit ); 
	axStatus resize( uint32_t buf_sample_size, bool keep_data = true );

	const  uint8_t* ptr() const { return buf.ptr(); }
	size_t byte_size() const { return sample * ch * (bit>>3); }


	void onTake( axPCMWave &src );
	axStatus copy( const axPCMWave &src );

	bool is_same_format( axPCMWave &c );
/*
private:
	PCMWave& operator=( const PCMWave& src );
*/

	
};



#endif //__axPCMWave_h__

