//
//  axGLUIScaleView.h
//  ax
//
//  Created by Jason on 08/07/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#ifndef __axGLUITransformView_h__
#define __axGLUITransformView_h__

#include "axGLUIView.h"

//! scale content
class axGLUIScaleView : public axGLUIView {
	typedef axGLUIView	B;
public:
	axGLUIScaleView();
	
	//virtual	axVec2f		pointFromParent( const axVec2f& pt );
	
	virtual void				render( axGLAppRenderRequest& req ) const;
	virtual	void				onRender( axGLAppRenderRequest& req ) const;
	virtual	void				onTouchEvent( axGLAppTouchEvent &ev );
	virtual	void				onLayout	();	

			
			void		setTranslate( const axVec2f& s );
			void		setTranslate( float x, float y );		
	
			void		setVirtualContentAlign		( float x, float y ) { virtualContentAlign_.set( x,y ); }
			
			void		setVirtualContentSize		( const axVec2f& size );
			void		setVirtualContentSize		( float w, float h );
 
	
			void		setKeepAspectRatio( bool b ) { keepAspectRatio_ = b; }
			bool		isKeepAspectRatio() { return keepAspectRatio_; }
	
	
	const	axVec2f&	scale() const				 { return scale_; }
	const	axVec2f&	virtualContentSize() { return virtualContentSize_; }
	
	


private:

	axVec2f		alignTranslate_;	
	axVec2f		translate_;	
	axVec2f		scale_;
	
	bool		keepAspectRatio_;
	
	axVec2f		virtualContentSize_;
	axVec2f		virtualContentAlign_;
	
	void		recalcScale_();
	
};

typedef axSharedPtr< axGLUIScaleView >	axGLUIScaleViewRef;


#endif //__axGLUITransformView_h__

