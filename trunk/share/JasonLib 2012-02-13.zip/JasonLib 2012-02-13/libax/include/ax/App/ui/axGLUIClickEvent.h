#ifndef __axGLUIClickEvent_h__
#define __axGLUIClickEvent_h__

class	axGLUIClickEvent {
public:
	
			
	int32_t cmdID;

};


#endif //__axGLUIClickEventt_h__
