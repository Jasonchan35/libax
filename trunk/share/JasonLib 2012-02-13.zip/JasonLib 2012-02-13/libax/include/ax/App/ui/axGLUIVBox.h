//
//  axGLUIVBox.h
//  ax
//
//  Created by Jason on 28/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __axGLUIVBox_h__
#define __axGLUIVBox_h__

#include "axGLUIView.h"

class axGLUIVBox : public axGLUIView {
public:	
	axGLUIVBox();

	virtual	void	onLayout();
			void	setSpacing( float s );
			
			
	virtual	const axVec2f		minRequireSize	() const;
	virtual	const axVec2f		maxRequireSize	() const;
	
							
private:
	float	spacing_;
};

typedef axSharedPtr< axGLUIVBox >	axGLUIVBoxRef;


#endif //__axGLUIVBox_h__

