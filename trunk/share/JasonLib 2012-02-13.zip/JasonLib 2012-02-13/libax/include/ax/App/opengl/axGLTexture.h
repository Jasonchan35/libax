#ifndef __axGLTexture_h__
#define __axGLTexture_h__

#include "ax_opengl_def.h"
#include "../../core/math/axRect2.h"
#include "../graph/axImage.h"
#include "../graph/axFont.h"

//! Opengl texture
class axGLTexture : public axNonCopyable {
public:
	float time;
	enum { //cube map
		cube_map_x_pos = 0, 
		cube_map_x_neg,
		cube_map_y_pos, 
		cube_map_y_neg,
		cube_map_z_pos, 
		cube_map_z_neg,
		cube_map_max
	};

	class CubeMapImage : public axLocalArray<axImage, cube_map_max>	 {
	public:
		CubeMapImage() { resizeToCapacity(); }
	};

	axGLTexture		() { init_();	}
	~axGLTexture	() { destroy(); }

	bool		isValid			() const { return id_ != 0; }
	GLuint		getId			() const { return id_; }

	// GL_TEXTURE_2D, GL_TEXTURE_RECTANGLE, GL_TEXTURE_CUBE_MAP
	GLuint		target			() const { return target_; }

	axStatus	create			( const axImage &img,		bool gen_mipmap=false, int mi=0, int mx=0 );
	axStatus	loadFile		( const char* filename,		bool gen_mipmap=false, int mi=0, int mx=0 );
	axStatus	loadFile		( const wchar_t* filename,	bool gen_mipmap=false, int mi=0, int mx=0 );
	
	axStatus	createFromText			( axFont &font, const wchar_t *text, bool gen_mipmap=false, int mi=0, int mx=0 );
	axStatus	createFromTextInRect	( axFont &font, const wchar_t *text, int width, int height, axAlignment align = axAlignment::kTopLeft, bool gen_mipmap=false, int mi=0, int mx=0 );

	axStatus	createFromFrameBuffer	( const axRect2i &rect );

	axStatus	createCubeMap	( const char* filename[ cube_map_max ],	bool gen_mipmap=false, int mi=0, int mx=0 );
	axStatus	createCubeMap	( const CubeMapImage &image,				bool gen_mipmap=false, int mi=0, int mx=0 );

	//! for depth texture: internal_format = GL_DEPTH_COMPONENT32 [with] format = GL_DEPTH_COMPONENT
	axStatus	createEmpty		( int w, int h, GLint internal_format = GL_RGBA, GLenum format=GL_RGBA, bool gen_mipmap=false, int mi=0, int mx=0 );

	//! release the texture resource from display card
	void		destroy			();

	axStatus	subImageFromFrameBuffer	( axVec2i offset, axRect2i rect );

	axStatus	subImage		( const axImage  &img, int x=0, int y=0, GLenum target = GL_TEXTURE_2D );
	axStatus	saveImage		( axImage &img );

	axStatus	getColorType	( axColor::Type &type ) const;

			int			width		() const	{ return width_; }
			int			height		() const	{ return height_; }
		
			axVec2i		size		() const	{ return axVec2i(width_,height_); }
		
			int			bufferWidth	() const	{ return bufferWidth_; }
			int			bufferHeight() const	{ return bufferHeight_; }
			axVec2i		bufferSize	() const	{ return axVec2i(bufferWidth_, bufferHeight_); }
	
			void		bind		() const;
			void		unbind		() const;

			axStatus	blt			( const axRect2f &v, const axRect2f &t, bool keep_aspect_ratio = false ) const;
			axStatus	blt			( const axRect2f &v, bool  keep_aspect_ratio = false ) const { return blt( v, axRect2f(0, 0, (float)width_, (float)height_), keep_aspect_ratio ); }
			
			axStatus	blt			( const axVec2f &v ) const			{ return blt( v.x, v.y ); }
			axStatus	blt			( const axVec2i &v ) const			{ return blt( v.x, v.y ); }
			axStatus	blt			( int   x, int   y ) const			{ return blt( axRect2f( (float)x, (float)y, (float)width_,   (float)height_),   false ); }
			axStatus	blt			( float x, float y ) const			{ return blt( axRect2f(        x,        y, (float)width_,   (float)height_),   false ); }
			axStatus	bltScale	( float x, float y, float s ) const { return blt( axRect2f( (float)x, (float)y, (float)width_*s, (float)height_*s), false ); }

			axStatus	bltCenter	( float x, float y ) const;
			axStatus	bltCenter	( const axVec2f &pt  ) const		{ return bltCenter(pt.x,pt.y); }
		
			axStatus	sprite3D	( const axVec3f &pos, const axVec3f &euler_rotation, const axVec2f &scale );

// all set_xxxx() use when bind 
	
	static	void		activeUnit( GLenum unit );

			// GL_NEAREST  GL_LINEAR  
			void		setMagFilter( int v );

			// GL_NEAREST  GL_LINEAR 
			// GL_NEAREST_MIPMAP_NEAREST GL_LINEAR_MIPMAP_NEAREST 
			// GL_NEAREST_MIPMAP_LINEAR  GL_LINEAR_MIPMAP_LINEAR 
			void		setMinFilter( int v );
			void		setMinMagFilter( int mi, int mx ) { setMinFilter(mi), setMagFilter(mx); }

			// mipmap generate ( using GL_SGIS_generate_mipmap extension )
			void		setGenMipmap( bool b, int mi, int mx  );
	
			// GL_CLAMP GL_REPEAT GL_CLAMP_TO_EDGE
			void		setWrap( int s, int t );

		
	// GL_MODULATE, GL_DECAL, and GL_BLEND,  ext: GL_COMBINE
	static void setEnvMode( int v );
	
	static void setEnvColor( const axColorRGBAf& v );
	
	//! only work if env_mode is set to GL_COMBINE
	//	GL_REPLACE, GL_MODULATE, GL_ADD, GL_ADD_SIGNED, GL_INTERPOLATE, GL_SUBTRACT		
	static void setEnvCombine( int mode ) { setEnvCombine( mode, mode ); }
	static void setEnvCombine( int rgb_mode, int alpha_mode );
	
	/*! src: GL_TEXTURE (current unit), 
	 GL_TEXTURE0 + unit, 
	 GL_CONSTANT
	 GL_PRIMARY_COLOR
	 GL_PREVIOUS
	 
	 op:  GL_SRC_COLOR,		- only for rgb_op
	 GL_ONE_MINUS_SRC_COLOR	- only for rgb_op
	 GL_SRC_ALPHA			
	 GL_ONE_MINUS_SRC_ALPHA     */
	static void setEnvCombineSource( GLenum index, int rgb_src, int alpha_src, int rgb_op = GL_SRC_COLOR , int alpha_op = GL_SRC_ALPHA );
	static void setEnvCombineSource( GLenum index, int src ) { setEnvCombineSource( index, src, src ); }

	axStatus onTake( axGLTexture &src );	
private:
	axStatus	createId_	( int src_w, int src_h, int tex_w, int tex_h, bool gen_mipmap = false, int mi=0, int mx=0 );
	axStatus	format_		( axColor::Type type, int &gl_internal_fmt, int &gl_src_fmt, int &gl_data_type );
	bool		needPow2_	( int w, int h );
	
	GLuint	id_;
	GLenum	target_;

	int		width_;
	int		height_;
	int		bufferWidth_;
	int		bufferHeight_;
	
	void	init_();
	
friend class axGLTextureSeq;
protected:
	float	time_;
};


class axScope_GLTexture	{
public:
	axScope_GLTexture	( const axGLTexture &tex ) : tex_(tex)	{ tex_.bind(); };
	~axScope_GLTexture	()										{ tex_.unbind(); };
private:
	const axGLTexture	&tex_;
};


// ----- inline functions ----- //

inline void axGLTexture::activeUnit( GLenum unit ) {
	glActiveTexture( GL_TEXTURE0 + unit );
	glClientActiveTexture( GL_TEXTURE0 + unit ); // Vertex arrays (tex coord) are client-side GL resources, which are selected by the glClientActiveTexture routine.
}
	

#endif //__axGLTexture_h__
