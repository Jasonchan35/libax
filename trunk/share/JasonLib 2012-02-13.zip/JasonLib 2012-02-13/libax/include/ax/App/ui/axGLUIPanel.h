//
//  axGLUIPanel.h
//  ax
//
//  Created by Jason on 25/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#ifndef __axGLUIPanel_h__
#define __axGLUIPanel_h__

#include "axGLUIView.h"

class axGLUIPanel : public axGLUIView {
public:
};

typedef axSharedPtr< axGLUIPanel >	axGLUIPanelRef;

#endif //__axGLUIPanel_h__
