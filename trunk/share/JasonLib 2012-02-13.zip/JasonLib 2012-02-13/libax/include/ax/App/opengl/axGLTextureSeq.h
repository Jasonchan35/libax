#ifndef __axGLTextureSeq_h__
#define __axGLTextureSeq_h__

#include "axGLTexture.h"
#include "../../App/graph/axImageSeq.h"

//! Opengl texture Seq
class axGLTextureSeq : public axNonCopyable {
public:	
	axGLTextureSeq();
	
	axStatus	create	( const axImageSeq &img_seq );
	void		destroy	();

	axStatus	loadFile( const char*		filename );

	//axStatus create( const char* dir, const char *name );
	//axStatus create( const wchar_t* filename, const wchar_t*name );

	int			width  () const	{ return frameCount() ? frames_[0].width() : 0; }
	int			height () const	{ return frameCount() ? frames_[0].height() : 0; }

		  axGLTexture& operator[] ( axSize i )			{ return frames_[i]; }
	const axGLTexture& operator[] ( axSize i ) const	{ return frames_[i]; }

	axSize		frameCount	() const					{ return frames_.size(); }

	void		clear		()							{ frames_.clear(); }
	axStatus	setFrameCount ( axSize i )				{ return frames_.resize(i); }

	//== copy from axGLTexture
	axStatus	blt			( const axRect2f &v, const axRect2f &t, bool keep_aspect_ratio = false ) const;
	axStatus	blt			( const axRect2f &v, bool keep_aspect_ratio = false ) const	{ return blt( v, axRect2f(0, 0, (float)width(), (float)height()), keep_aspect_ratio ); }
	axStatus	blt			( const axVec2f &v ) const			{ return blt( v.x, v.y ); }
	axStatus	blt			( const axVec2i &v ) const			{ return blt( v.x, v.y ); }
	
	axStatus	blt			( int   x, int   y ) const			{ return blt( axRect2f( (float)x, (float)y, (float)width(),   (float)height()),   false ); }
	axStatus	blt			( float x, float y ) const			{ return blt( axRect2f(        x,        y, (float)width(),   (float)height()),   false ); }
	axStatus	bltScale	( float x, float y, float s ) const	{ return blt( axRect2f(        x,        y, (float)width()*s, (float)height()*s), false ); }

	void		setCurrentTime	( float time )		{ currentTime_ = time;  }
	void		advanceTime		( float time )		{ currentTime_ += time; }
	
	bool		getIndexByTime	( axSize &out_index, float time ) const;
	//===============

	// GL_NEAREST  GL_LINEAR  
	void		setMagFilter	( int v );
	// GL_NEAREST  GL_LINEAR 
	// GL_NEAREST_MIPMAP_NEAREST GL_LINEAR_MIPMAP_NEAREST 
	// GL_NEAREST_MIPMAP_LINEAR  GL_LINEAR_MIPMAP_LINEAR 
	void		setMinFilter	( int v );
	void		setMinMagFilter	( int mi, int mx ) { setMinFilter(mi), setMagFilter(mx); }
	// mipmap generate ( using GL_SGIS_generate_mipmap extension )
	void		setGenMipmap	( bool b, int mi, int mx );
	// GL_CLAMP GL_REPEAT GL_CLAMP_TO_EDGE
	void		setWrap			( int s, int t );
	
	bool		isValid	() const { 
		if( frames_.size() == 0 ) return false;
		return frames_[0].isValid();
	}
	
	axStatus	onTake( axGLTextureSeq &src )	{
		currentTime_ = src.currentTime_;
		max_loop_ = src.max_loop_;
		return frames_.onTake( src.frames_ ); 
	}
	
private:
	axArray< axGLTexture > frames_;
	int			max_loop_;
	float		currentTime_;
};


#endif //__axGLTextureSeq_h__
