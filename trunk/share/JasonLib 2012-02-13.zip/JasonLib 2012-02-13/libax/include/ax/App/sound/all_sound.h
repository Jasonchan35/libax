#ifndef __ax_all_sound_h__
#define __ax_all_sound_h__

#include "axAudioPlayer.h"
#include "axAudioSession.h"
#include "axPCMWave.h"
#include "axWaveFile.h"


#endif //__ax_all_sound_h__
