#ifndef __axGLResourceMgr_h__
#define __axGLResourceMgr_h__

#include "axGLFontTexture.h"

class axGLResourceMgr;

class axGLTextureResNode : public axHashTableNode< axGLTextureResNode > , public axGLTexture, public axSharedPte {
public:
	axGLTextureResNode();
	virtual ~axGLTextureResNode();

	uint32_t	hashTableValue() { return ax_string_hash(filename_); }

friend class axGLResourceMgr;
protected:
	axStringA           filename_;
	axGLResourceMgr*	ctx_;
};

class axGLTextureRes : protected  axSharedPtr< axGLTextureResNode > {
public:

friend class axGLResourceMgr;
};

//-------------------------------------------

class axGLResourceMgr : public axSharedPte {
public:
	axGLResourceMgr() {
		MD	md( md_ );
		md->textures.setTableSize( 1024 );
	}

	axStatus	load( axGLTextureRes& res, const char* filename );

	class MD_ {
	public:
		axHashTable< axGLTextureResNode >	textures;
	};
    typedef axMutexProtected< MD_ >    MD;
    MD::Data    md_;

};

#endif //__axGLResourceMgr_h__

