#ifndef __axColor_h__
#define __axColor_h__

#include "../../core/math/axVec2.h"
#include "../../core/math/axVec3.h"
#include "../../core/math/axVec4.h"

class axColorAb;
class axColorYb;
class axColorYAb;
class axColorRGBb;
class axColorRGBf;
class axColorRGBAb;
class axColorRGBAf;
class axColorBGRb;
class axColorBGRAb;
class axColorARGBb;
class axColorABGRb;	
class axColorYUVb;
class axColorHSVf;
class axColorR5G6B5;

class axColor {
public:
	typedef uint8_t Type;
	enum _Type{
		t_null = 0,
		t_Ab,		//!< alpha in uint8_t
		t_Yb,		//!< luminance  in uint8_t
		t_YAb,		//!< monochrome with alpha in uint8_t
		t_RGBb,		//!< RGB  in uint8_t
		t_RGBf,		//!< RGB  in float
		t_RGBAb,	//!< RGBA in uint8_t
		t_RGBAf,	//!< RGBA in float
		t_R5G6B5,	//!< R5 G6 B5
		t_BGRb,
		t_YUVb,
		t_HSVf,
		t_DXT1,
		t_DXT3,
		t_DXT5,
	};

	static axSize  get_pixel_size( Type t );

	template<class T> static Type get_type();
};

template<> inline axColor::Type axColor::get_type<axColorAb>   () { return t_Ab; }
template<> inline axColor::Type axColor::get_type<axColorYb>   () { return t_Yb; }
template<> inline axColor::Type axColor::get_type<axColorYAb>  () { return t_YAb; }
template<> inline axColor::Type axColor::get_type<axColorRGBb> () { return t_RGBb; }
template<> inline axColor::Type axColor::get_type<axColorRGBAb>() { return t_RGBAb; }
template<> inline axColor::Type axColor::get_type<axColorRGBf> () { return t_RGBf; }
template<> inline axColor::Type axColor::get_type<axColorRGBAf>() { return t_RGBAf; }
template<> inline axColor::Type axColor::get_type<axColorYUVb> () { return t_YUVb; }

class axColorFloat;

//! color as uint8_t 0 ~ 255
class axColorByte {
public:
	axColorByte();
	axColorByte( const axColorByte  &v );
	axColorByte( axColorFloat v );

	axColorByte( uint8_t	  v );
	axColorByte( int		  v );
	axColorByte( unsigned	  v );

	operator	   uint8_t&();
	operator const uint8_t&() const;

	uint8_t		value()		const;
	uint8_t&	value();

	float		to_float()	const;
	axColorByte	invert()	const;

private:
	uint8_t _v;
};

//! color as float ( 0.0 ~ 1.0 )
class axColorFloat {
public:
	axColorFloat();
	axColorFloat( const axColorFloat &v );
	axColorFloat( axColorByte  v );

	axColorFloat( float      v );

	operator	   float&();
	operator const float&() const;

	float		value()		const;
	float&		value();

	uint8_t         to_byte()	const;
	axColorFloat    invert()	const;

private:
	float _v;
};

//! axColor in Luminance
class axColorYb {
public:
	axColorByte	y;

	axColorYb();
	axColorYb ( const axColorYb    &src );
	axColorYb ( axColorByte  src );
	void set  ( axColorByte  src );

	axColorYb( const axColorAb     &src );
	axColorYb( const axColorYAb    &src );
	axColorYb( const axColorRGBb   &src );
	axColorYb( const axColorRGBAb  &src );
	axColorYb( const axColorYUVb   &src );
};

class axColorAb {
public:
	axColorByte	a;

	axColorAb();
	axColorAb( const axColorAb     &src );
	axColorAb ( axColorByte aa );
	void set( axColorByte aa );

	axColorAb( const axColorYb     &src );
	axColorAb( const axColorRGBb   &src );

	axColorAb( const axColorYAb    &src );
	axColorAb( const axColorRGBAb  &src );
};

class axColorYAb : public axColorYb {
public:
	axColorByte a;

	axColorYAb();
	axColorYAb( const axColorYAb    &src );
	axColorYAb( axColorByte yy, axColorByte aa );
	void set( axColorByte yy, axColorByte aa );

	axColorYAb( const axColorYb     &src, axColorByte aa = 0xff );
	axColorYAb( const axColorRGBb   &src, axColorByte aa = 0xff );
	axColorYAb( const axColorYUVb   &src, axColorByte aa = 0xff );

	axColorYAb( const axColorAb     &src );
	axColorYAb( const axColorRGBAb  &src );

		  axColorYb& asColorYb()		{ return *(axColorYb*)this; }
	const axColorYb& asColorYb() const	{ return *(axColorYb*)this; }

		  axVec2b& asVec2b()			{ return *(axVec2b*)this; }
	const axVec2b& asVec2b() const		{ return *(axVec2b*)this; }
}; //class axColorYAb

class axColorRGBb {
public:
	axColorByte	r,g,b;

	axColorRGBb();
	axColorRGBb( const axColorRGBb	 &src );
	axColorRGBb( axColorByte rr, axColorByte gg, axColorByte bb );
	void set ( axColorByte rr, axColorByte gg, axColorByte bb );

	axColorRGBb( const axColorRGBf   &src );

	axColorRGBb( const axColorYb     &src );
	axColorRGBb( const axColorR5G6B5 &src );
	axColorRGBb( const axColorYUVb   &src );

	axColorRGBb( const axColorAb	 &src );
	axColorRGBb( const axColorYAb    &src );
	axColorRGBb( const axColorRGBAb  &src );

			axVec3b&	asVec3b()			{ return *((axVec3b*)this); }
	const	axVec3b&	asVec3b() const		{ return *((axVec3b*)this); }

		  uint8_t* asPointer()				{ return (uint8_t*)this; }
	const uint8_t* asPointer() const		{ return (uint8_t*)this; }

	axColorByte	luminance() const;

	axStatus	onTake( axColorRGBb &b )				{ *this = b; return 0; }

};

class axColorRGBf {
public:
	axColorFloat	r,g,b;

	axColorRGBf();
	axColorRGBf( const axColorRGBf &src );
	axColorRGBf( axColorFloat rr, axColorFloat gg, axColorFloat bb );
	void set ( axColorFloat rr, axColorFloat gg, axColorFloat bb );

	axColorRGBf( const axColorRGBb &src );
	axColorRGBf( const axColorHSVf &src );

			axVec3f&	asVec3f()			{ return *((axVec3f*)this); }
	const	axVec3f&	asVec3f() const		{ return *((axVec3f*)this); }

	axColorFloat	average() const			{ return (r+g+b)/3.0f; }

		  float* asPointer()				{ return (float*)this; }
	const float* asPointer() const			{ return (float*)this; }

	axColorRGBf	operator+( axColorFloat v ) { return axColorRGBf( r+v,g+v,b+v ); }
	axColorRGBf	operator-( axColorFloat v ) { return axColorRGBf( r-v,g-v,b-v ); }
	axColorRGBf	operator*( axColorFloat v ) { return axColorRGBf( r*v,g*v,b*v ); }
	axColorRGBf	operator/( axColorFloat v ) { return axColorRGBf( r/v,g/v,b/v ); }

	axColorRGBf	operator+( const axColorRGBf &v ) { return axColorRGBf( r+v.r,g+v.g,b+v.b ); }
	axColorRGBf	operator-( const axColorRGBf &v ) { return axColorRGBf( r-v.r,g-v.g,b-v.b ); }
	axColorRGBf	operator*( const axColorRGBf &v ) { return axColorRGBf( r*v.r,g*v.g,b*v.b ); }
	axColorRGBf	operator/( const axColorRGBf &v ) { return axColorRGBf( r/v.r,g/v.g,b/v.b ); }

	bool		operator==	( const axColorRGBf &v ) const		{ return ( r == v.r && g == v.g && b == v.b ); }
	bool		operator!=	( const axColorRGBf &v ) const		{ return ( r != v.r || g != v.g || b != v.b ); }

	axColorFloat	luminance() const;

	axStatus	onTake( axColorRGBf &b )				{ *this = b; return 0; }
};

//-----------------------------------------

class axColorRGBAb : public axColorRGBb {
public:
	axColorByte	a;

	axColorRGBAb();
	axColorRGBAb( const axColorRGBAb  &src );
	axColorRGBAb( axColorByte rr, axColorByte gg, axColorByte bb, axColorByte aa );
	void set  ( axColorByte rr, axColorByte gg, axColorByte bb, axColorByte aa );

	axColorRGBAb( const axColorRGBAf  &src );
	axColorRGBAb( const axColorAb     &src );
	axColorRGBAb( const axColorYb     &src );
	axColorRGBAb( const axColorYAb    &src );
	axColorRGBAb( const axColorRGBb	  &src );
	axColorRGBAb( const axColorR5G6B5 &src );
	axColorRGBAb( const axColorYUVb   &src );
	axColorRGBAb( const axColorARGBb  &src );
	axColorRGBAb( const axColorABGRb  &src );
	axColorRGBAb( const axColorBGRAb  &src );
	
	
			axColorRGBb&	asColorRGBb()		{ return *((axColorRGBb*)this); }
	const	axColorRGBb&	asColorRGBb() const { return *((axColorRGBb*)this); }

		  axVec4b&		asVec4b()				{ return *((axVec4b*)this); }
	const axVec4b&		asVec4b() const			{ return *((axVec4b*)this); }

		  uint8_t* asPointer()					{ return (uint8_t*)this; }
	const uint8_t* asPointer() const			{ return (uint8_t*)this; }

	axStatus	onTake( axColorRGBAb &b )				{ *this = b; return 0; }

};

class axColorRGBAf : public axColorRGBf {
public:
	axColorFloat a;

	axColorRGBAf();
	axColorRGBAf( const axColorRGBAf &src );
	axColorRGBAf( axColorFloat rr, axColorFloat gg, axColorFloat bb, axColorFloat aa );
	void set  ( axColorFloat rr, axColorFloat gg, axColorFloat bb, axColorFloat aa );

	axColorRGBAf( const axColorRGBf  &v, axColorFloat aa=1.0f );
	axColorRGBAf( const axColorRGBb  &v, axColorByte  aa=0xff );

	axColorRGBAf( const axColorRGBAb &v );

			axColorRGBf&	asColorRGBf()		 { return *((axColorRGBf*)this); }
	const	axColorRGBf&	asColorRGBf() const { return *((axColorRGBf*)this); }

			axVec4f&		asVec4f()			{ return *(axVec4f*)this; }
	const	axVec4f&		asVec4f() const	{ return *(axVec4f*)this; }

		  float* asPointer()		 { return (float*)this; }
	const float* asPointer() const { return (float*)this; }

	axStatus	onTake( axColorRGBAf &b )				{ *this = b; return 0; }

};

//-----------------------------------------

class axColorBGRb {
public:
	axColorByte b,g,r;

	axColorBGRb();
	axColorBGRb( const axColorBGRb &src );
	axColorBGRb( axColorByte bb, axColorByte gg, axColorByte rr );
	void set ( axColorByte bb, axColorByte gg, axColorByte rr );

	axColorBGRb( const axColorRGBb &src );

			axVec3b& as_Vec3b()		{ return *((axVec3b*)this); }
	const	axVec3b& as_Vec3b() const	{ return *((axVec3b*)this); }

	axStatus	onTake( axColorBGRb &b )				{ *this = b; return 0; }

};
	
class axColorBGRAb : public axColorBGRb {
public:
	axColorByte a;
};

//-------------------
class axColorARGBb {
public:
	axColorByte a,r,g,b;
};

class axColorABGRb {
public:
	axColorByte a,b,g,r;		
};	
//-------------------
class axColorR5G6B5 {
public:
	uint16_t	c;

	axColorR5G6B5();
	axColorR5G6B5( const axColorR5G6B5 &src );
	axColorR5G6B5( axColorByte rr, axColorByte gg, axColorByte bb );
	void set   ( axColorByte rr, axColorByte gg, axColorByte bb );

	axColorR5G6B5( const axColorRGBb &src );

	uint8_t get_r() const { return (c & 0xF800) >> 8; }
	uint8_t get_g() const { return (c & 0x07E0) >> 3; }
	uint8_t get_b() const { return (c & 0x001F) << 3; }

	void set_r( uint8_t v ) { c = (c & 0x07FF) | (((uint16_t)v & 0xF8 ) << 11 ); }
	void set_g( uint8_t v ) { c = (c & 0xF81F) | (((uint16_t)v & 0xFC ) << 5  ); }
	void set_b( uint8_t v ) { c = (c & 0xFFE0) | (((uint16_t)v & 0xF8 )       ); }
};

//-----------------------------------------
class axColorYUVb {
public:
	axColorByte y,u,v;

	axColorYUVb();
	axColorYUVb( const axColorYUVb &src );
	axColorYUVb( axColorByte yy, axColorByte uu, axColorByte vv );
	void set ( axColorByte yy, axColorByte uu, axColorByte vv );

	axColorYUVb( const axColorRGBb &src );

			axVec3b& asVec3b()			{ return *((axVec3b*)this); }
	const	axVec3b& asVec3b() const	{ return *((axVec3b*)this); }
};

//-----------------------------------------
class axColorHSVf {
public:
	axColorFloat	h,s,v;

	axColorHSVf();
	axColorHSVf( const axColorHSVf & src );
	axColorHSVf( axColorFloat hh, axColorFloat ss, axColorFloat vv );
	void set ( axColorFloat hh, axColorFloat ss, axColorFloat vv );

			axVec3f& asVec3f()			{ return *((axVec3f*)this); }
	const	axVec3f& asVec3f() const	{ return *((axVec3f*)this); }
};

//-----------------------------------------
template<class S> inline axStatus ax_serialize_io( S &s, axColorRGBAb &v )	{ return s.io( v.asVec4b()  ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorRGBAf &v )	{ return s.io( v.asVec4f() ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorHSVf  &v )	{ return s.io( v.asVec3f()  ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorYUVb  &v )	{ return s.io( v.asVec3b()  ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorRGBb &v )	{ return s.io( v.asVec3b()  ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorRGBf &v )	{ return s.io( v.asVec3f() ); }
template<class S> inline axStatus ax_serialize_io( S &s, axColorYAb &v )	{ return s.io( v.asVec2b() ); }


inline axSize axColor::get_pixel_size( Type t ) {
	switch( t ) {
		case t_null:	return 0;
		case t_Ab:		return sizeof( axColorAb );
		case t_Yb:		return sizeof( axColorYb );
		case t_YAb:		return sizeof( axColorYAb );
		case t_RGBb:	return sizeof( axColorRGBb );
		case t_RGBf:	return sizeof( axColorRGBf );
		case t_RGBAb:	return sizeof( axColorRGBAb );
		case t_RGBAf:	return sizeof( axColorRGBAf );
		case t_YUVb:	return sizeof( axColorYUVb );
		case t_HSVf:	return sizeof( axColorHSVf );
		case t_BGRb:    return sizeof( axColorBGRb );
		case t_R5G6B5:  return 0;
		case t_DXT1:    return 0;
		case t_DXT3:    return 0;
		case t_DXT5:    return 0;
	}
	return 0;
}


//----- inline -----------
inline axColorByte::axColorByte() {}
inline axColorByte::axColorByte( const axColorByte &v ){ *this = v; }
inline axColorByte::axColorByte( axColorFloat   v )	{ _v=v.to_byte(); }
inline axColorByte::axColorByte( uint8_t		  v )	{ _v=v; }
inline axColorByte::axColorByte( int		  v )	{ _v=v; }
inline axColorByte::axColorByte( unsigned	  v )	{ _v=v; }

inline axColorByte::operator uint8_t&()				{ return _v; }
inline axColorByte::operator const uint8_t&() const	{ return _v; }
inline uint8_t  axColorByte::value() const			{ return _v; }
inline uint8_t& axColorByte::value()     			{ return _v; }

inline float axColorByte::to_float()	const		{ return (float)_v/255.0f; }
inline axColorByte axColorByte::invert() const		{ return 0xff-_v; }

//-------------------------------------------------------
inline axColorFloat::axColorFloat()	{}
inline axColorFloat::axColorFloat( const axColorFloat &v ){ *this=v; }
inline axColorFloat::axColorFloat( axColorByte  v )		{ _v=v.to_float(); }
inline axColorFloat::axColorFloat( float      v )		{ _v=v; }

inline axColorFloat::operator float&()				{ return _v; }
inline axColorFloat::operator const float&() const	{ return _v; }
inline float  axColorFloat::value() const				{ return _v; }
inline float& axColorFloat::value()   				{ return _v; }

inline uint8_t  axColorFloat::to_byte()	const			{ return (uint8_t)( ax_clamp( _v, 0.0f, 1.0f ) * 255.0f ); }
inline axColorFloat axColorFloat::invert() const		{ return 1.0f-_v; }

//-------------------------------------------------------
inline axColorAb::axColorAb() {}
inline axColorAb::axColorAb( const axColorAb  &src ) {	*this = src; }
inline axColorAb::axColorAb ( axColorByte aa ) : a(aa) {}
inline void axColorAb::set( axColorByte aa ) { a=aa; }

inline axColorAb::axColorAb( const axColorYb     &src ) {}
inline axColorAb::axColorAb( const axColorRGBb   &src ) {}

inline axColorAb::axColorAb( const axColorYAb    &src ) {	a = src.a; }
inline axColorAb::axColorAb( const axColorRGBAb  &src ) {	a = src.a; }

//-------------------------------------------------------
inline axColorYb::axColorYb() {}
inline axColorYb::axColorYb( const axColorYb     &src ) {	*this = src; }
inline axColorYb::axColorYb( axColorByte yy ) : y(yy) {}
inline void axColorYb::set( axColorByte yy ) { y=yy; }

inline axColorYb::axColorYb( const axColorAb     &src ) { y = 0;	   }
inline axColorYb::axColorYb( const axColorYAb    &src ) {	y = src.y; }
inline axColorYb::axColorYb( const axColorRGBb   &src ) { y = src.luminance(); }
inline axColorYb::axColorYb( const axColorRGBAb  &src ) { y = src.luminance(); }
inline axColorYb::axColorYb( const axColorYUVb   &src ) {	y = src.y; }

//-----------------------------------------------------------
inline axColorRGBb::axColorRGBb() {}
inline axColorRGBb::axColorRGBb( const axColorRGBb &src ) { *this=src; }
inline axColorRGBb::axColorRGBb( axColorByte rr, axColorByte gg, axColorByte bb ) : r(rr), g(gg), b(bb) {}
inline void axColorRGBb::set ( axColorByte rr, axColorByte gg, axColorByte bb ) { r=rr; g=gg; b=bb; }

inline axColorRGBb::axColorRGBb( const axColorRGBf  &v ) { r=v.r; g=v.g; b=v.b; }

inline axColorRGBb::axColorRGBb( const axColorAb	 &src ) {}

inline axColorRGBb::axColorRGBb( const axColorYb     &src ) {
	unsigned l = src.y * 10000;
	set( l / 3086, l / 6094, l / 820 );
}

inline axColorRGBb::axColorRGBb( const axColorYAb    &src ){
	unsigned l = src.y * 10000;
	set( l / 3086, l / 6094, l / 820 );
}

inline axColorRGBb::axColorRGBb( const axColorRGBAb  &src ) { *this = src.asColorRGBb(); }
inline axColorRGBb::axColorRGBb( const axColorYUVb &src ) {
	int c = (src.y - 16) * 298 +128;
	int d = src.u - 128;
	int e = src.v - 128;

	r = ax_clamp(( c           + 409 * e) >> 8 , 0, 255);
	g = ax_clamp(( c - 100 * d - 208 * e) >> 8 , 0, 255);
	b = ax_clamp(( c + 516 * d          ) >> 8 , 0, 255);
}

inline axColorRGBb::axColorRGBb( const axColorR5G6B5 &src ) {
	r = src.get_r();
	g = src.get_g();
	b = src.get_b();
}

inline axColorByte axColorRGBb::luminance() const {
	unsigned y = (unsigned)r * 3086U + (unsigned)g * 6094U + (unsigned)b * 820U;
	return ax_clamp( y/10000 ,0U, 255U );
}

//----------------------------------------
inline axColorRGBf::axColorRGBf() {}
inline axColorRGBf::axColorRGBf( const axColorRGBf &src ) { *this = src; }
inline axColorRGBf::axColorRGBf( axColorFloat rr, axColorFloat gg, axColorFloat bb ) :r(rr),g(gg),b(bb) {}
inline void axColorRGBf::set ( axColorFloat rr, axColorFloat gg, axColorFloat bb ) { r=rr; g=gg; b=bb; }

inline axColorRGBf::axColorRGBf( const axColorRGBb  &v ) { r=v.r; g=v.g; b=v.b; }

inline axColorFloat axColorRGBf::luminance() const {
	return r*0.3086f + g*0.6094f + b*0.0820f;
}

//---------------------------------------------------------
inline axColorRGBAb::axColorRGBAb() {}
inline axColorRGBAb::axColorRGBAb( const axColorRGBAb  &src ) { *this = src; }
inline axColorRGBAb::axColorRGBAb( axColorByte rr, axColorByte gg, axColorByte bb, axColorByte aa ) : axColorRGBb(rr,gg,bb), a(aa) {}
inline void axColorRGBAb::set	 ( axColorByte rr, axColorByte gg, axColorByte bb, axColorByte aa ) { r=rr; g=gg; b=bb; a=aa; }

inline axColorRGBAb::axColorRGBAb( const axColorRGBAf  &v )   { r=v.r; g=v.g; b=v.b; a=v.a;  }

inline axColorRGBAb::axColorRGBAb( const axColorAb      &src ) { a = src.a; }
inline axColorRGBAb::axColorRGBAb( const axColorYb      &src ) { asColorRGBb() = src;	a = 0xff;  }
inline axColorRGBAb::axColorRGBAb( const axColorYAb     &src ) { asColorRGBb() = src; a = src.a; }
inline axColorRGBAb::axColorRGBAb( const axColorRGBb	&src ) { asColorRGBb() = src; a = 0xff;  }
inline axColorRGBAb::axColorRGBAb( const axColorYUVb    &src ) { asColorRGBb() = src;	a = 0xff;  }
inline axColorRGBAb::axColorRGBAb( const axColorR5G6B5  &src ) { asColorRGBb() = src; a = 0xff;  }
inline axColorRGBAb::axColorRGBAb( const axColorBGRAb   &src ) { r=src.r; g=src.g; b=src.b; a=src.a; }
inline axColorRGBAb::axColorRGBAb( const axColorARGBb   &src ) { r=src.r; g=src.g; b=src.b; a=src.a; }
inline axColorRGBAb::axColorRGBAb( const axColorABGRb   &src ) { r=src.r; g=src.g; b=src.b; a=src.a; }

//----------------------------------------
inline axColorRGBAf::axColorRGBAf() {}
inline axColorRGBAf::axColorRGBAf( const axColorRGBAf &src ) { *this = src; }
inline axColorRGBAf::axColorRGBAf( axColorFloat rr, axColorFloat gg, axColorFloat bb, axColorFloat aa ) : axColorRGBf(rr,gg,bb),a(aa) {}
inline void axColorRGBAf::set  ( axColorFloat rr, axColorFloat gg, axColorFloat bb, axColorFloat aa ) { r=rr; g=gg; b=bb; a=aa; }

inline axColorRGBAf::axColorRGBAf( const axColorRGBf  &v, axColorFloat aa ) { r=v.r; g=v.g; b=v.b; a=aa; }
inline axColorRGBAf::axColorRGBAf( const axColorRGBb  &v, axColorByte  aa ) { r=v.r; g=v.g; b=v.b; a=aa; }

inline axColorRGBAf::axColorRGBAf( const axColorRGBAb &v ) { r=v.r; g=v.g; b=v.b; a=v.a;  }

//------------------------------------------------------
inline axColorYAb::axColorYAb() {}
inline axColorYAb::axColorYAb( const axColorYAb    &src ) { *this = src; }
inline axColorYAb::axColorYAb( axColorByte yy, axColorByte aa ) : axColorYb(yy), a(aa) {}
inline void axColorYAb::set( axColorByte yy, axColorByte aa ) { y=yy; a=aa; }

inline axColorYAb::axColorYAb( const axColorRGBb   &src, axColorByte aa ) : axColorYb(src.luminance()), a(aa) {}
inline axColorYAb::axColorYAb( const axColorYb     &src, axColorByte aa ) : axColorYb(src.y), a(aa) {}
inline axColorYAb::axColorYAb( const axColorYUVb   &src, axColorByte aa ) : axColorYb(src.y), a(aa) {}

inline axColorYAb::axColorYAb( const axColorAb	 &src ) : a(src.a) {}
inline axColorYAb::axColorYAb( const axColorRGBAb  &src ) : axColorYb(src.luminance()), a(src.a) {}

//----------------------------------------------------
inline axColorYUVb::axColorYUVb() {}
inline axColorYUVb::axColorYUVb( const axColorYUVb &src ) { *this = src; }
inline axColorYUVb::axColorYUVb( axColorByte yy, axColorByte uu, axColorByte vv ) : y(yy), u(uu), v(vv) {}
inline void axColorYUVb::set ( axColorByte yy, axColorByte uu, axColorByte vv ) { y=yy; u=uu; v=vv; }

inline axColorYUVb::axColorYUVb( const axColorRGBb &src ) {
	y = ((( 66 * src.r + 129 * src.g +  25 * src.b + 128) >> 8) + 16);
	u = (( -38 * src.r -  74 * src.g + 112 * src.b + 128) >> 8) + 128;
	v = (( 112 * src.r -  94 * src.g -  18 * src.b + 128) >> 8) + 128;
}
//-------------------------------------------
inline axColorHSVf::axColorHSVf	() {}
inline axColorHSVf::axColorHSVf	( const axColorHSVf & src ) { *this = src; }
inline axColorHSVf::axColorHSVf	( axColorFloat hh, axColorFloat ss, axColorFloat vv ) : h(hh), s(ss), v(vv) {}
inline void  axColorHSVf::set ( axColorFloat hh, axColorFloat ss, axColorFloat vv ) { h=hh; s=ss; v=vv; }


//-------------------------------------------
inline axColorR5G6B5::axColorR5G6B5() {}
inline axColorR5G6B5::axColorR5G6B5( const axColorR5G6B5 &src ) { *this = src; }

inline axColorR5G6B5::axColorR5G6B5( axColorByte rr, axColorByte gg, axColorByte bb ) {
	set( rr,gg,bb );
}

inline void axColorR5G6B5::set( axColorByte rr, axColorByte gg, axColorByte bb ) {
	c = ( (uint16_t)rr & 0xF8 ) << 11
	  | ( (uint16_t)gg & 0xFC ) << 5
	  | ( (uint16_t)bb & 0xF8 );
}

inline axColorR5G6B5::axColorR5G6B5( const axColorRGBb &src ) {
	set( src.r, src.g, src.b );
}



axStatus ax_str_to( const char* sz, axColorRGBb &v );
axStatus ax_str_to( const char* sz, axColorRGBf &v );
axStatus ax_str_to( const char* sz, axColorRGBAb &v );
axStatus ax_str_to( const char* sz, axColorRGBAf &v );


axStatus ax_str_to( const wchar_t* sz, axColorRGBb &v );
axStatus ax_str_to( const wchar_t* sz, axColorRGBf &v );
axStatus ax_str_to( const wchar_t* sz, axColorRGBAb &v );
axStatus ax_str_to( const wchar_t* sz, axColorRGBAf &v );


#endif //__axColor_h__
