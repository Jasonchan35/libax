#ifndef __ax_all_openal_h__
#define __ax_all_openal_h__

#include "ax_openal_def.h"
#include "axALBuffer.h"
#include "axALBufferedSource.h"
#include "axALContext.h"
#include "axALSource.h"
#include "axALWave.h"
#include "axALCapture.h"


#endif //__ax_all_openal_h__
