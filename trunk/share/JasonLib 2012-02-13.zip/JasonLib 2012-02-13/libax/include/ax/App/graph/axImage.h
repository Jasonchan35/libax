#ifndef __axImage_h__
#define __axImage_h__

#include "../../ax_base.h"
#include "../../core/math/axRect2.h"
#include "../../core/file_system/axFileStream.h"
#include "../../core/file_system/axMemMap.h"
#include "axColor.h"
#include "axFont.h"

//! image
class axImage : public axNonCopyable {
public:
	axStatus	create		( axColor::Type	type,   int width, int height );
	axStatus	create		( axColorAb*	pixels, int width, int height );
	axStatus	create		( axColorYb*	pixels, int width, int height );
	axStatus	create		( axColorYAb*	pixels, int width, int height );
	axStatus	create		( axColorRGBb*	pixels, int width, int height );
	axStatus	create		( axColorRGBAb*	pixels, int width, int height );

	axStatus	createFromText		( axFont &font, const wchar_t *text );
	axStatus	createFromTextInRect( axFont &font, const wchar_t *text, int width, int height, axAlignment align = axAlignment::kTopLeft );

	axStatus	convert		( const axImage& img, axColor::Type type );
	axStatus	copy		( const axImage& img )		{ return convert(img, axColor::t_null); }

	void		destroy		();

	axColor::Type type		() const			{ return type_; }

	axStatus	loadFile	( const char* filename,		axColor::Type type = axColor::t_null );
	axStatus	loadFile	( const wchar_t* filename,	axColor::Type type = axColor::t_null );
	
	axStatus	loadPng		( axIByteArray &buf, axColor::Type type = axColor::t_null );
	axStatus	loadJpeg	( axIByteArray &buf, axColor::Type type = axColor::t_null );
	axStatus	loadDds		( axIByteArray &buf, axColor::Type type = axColor::t_null );
	axStatus	loadGif		( axIByteArray &buf, axColor::Type type = axColor::t_null );

	axStatus	saveFile	( const char* filename );
	axStatus	saveMem		( axIByteArray &buf, const char* file_ext );

	axStatus	savePng		( axIByteArray &buf );
	axStatus	saveJpeg	( axIByteArray &buf );
	axStatus	saveDds		( axIByteArray &buf );
	
#if axOS_iOS
	axStatus	create		( UIImage *src );
	//! not work for opengl view
	axStatus	captureUIView	( UIView  *view );
	UIImage*	saveUIImage		();
#endif	

#if axOS_MacOSX
	axStatus	captureNSView	( NSView  *view );
#endif

	axImage();
	~axImage()	{ destroy(); }
	
	bool		isEmpty		() const					{ return width_ == 0 || height_ == 0; }
	int			width		() const					{ return width_; }
	int			height		() const					{ return height_; }

	axSize		byteSizePerPixel	() const				{ return byteSizePerPixel_; }
	axSize		bufferByteSize	() const				{ return pixelData_.size(); }

	bool		isInside	( int x, int y ) const;
	bool		isSizePow2	() const;

	void*		pixelVoidPointer()			{ return pixelData_.ptr(); }
	const void* pixelVoidPointer() const	{ return pixelData_.ptr(); }
	
	void*		pixelVoidPointer( int x, int y );
	const void* pixelVoidPointer( int x, int y ) const;

	template<class Color>	void		pixelPointer( Color* &ptr );
	template<class Color>	void		pixelPointer( Color* &ptr, int x, int y ) ;

	template<class Color>	void		pixelPointer( const Color* &ptr ) const;
	template<class Color>	void		pixelPointer( const Color* &ptr, int x, int y ) const;

	axStatus	setAll	( const axColorAb    &v );
	axStatus	setAll	( const axColorYb    &v );
	axStatus	setAll	( const axColorYAb   &v );
	axStatus	setAll	( const axColorRGBb  &v );
	axStatus	setAll	( const axColorRGBAb &v );
	
	void		setAllByteZero();

	axStatus	setPixels( const axColorAb*    pixels, int w, int h );
	axStatus	setPixels( const axColorYb*    pixels, int w, int h );
	axStatus	setPixels( const axColorYAb*   pixels, int w, int h );
	axStatus	setPixels( const axColorRGBb*  pixels, int w, int h );
	axStatus	setPixels( const axColorRGBAb* pixels, int w, int h );

	axStatus	getPixels( axColorAb*    pixels, int w, int h ) const;
	axStatus	getPixels( axColorYb*    pixels, int w, int h ) const;
	axStatus	getPixels( axColorYAb*   pixels, int w, int h ) const;
	axStatus	getPixels( axColorRGBb*  pixels, int w, int h ) const;
	axStatus	getPixels( axColorRGBAb* pixels, int w, int h ) const;
	
	void		setPixel( const axColorAb&    color, int x, int y );
	void		setPixel( const axColorYb&    color, int x, int y );
	void		setPixel( const axColorYAb&   color, int x, int y );
	void		setPixel( const axColorRGBb&  color, int x, int y );
	void		setPixel( const axColorRGBAb& color, int x, int y );
	
	axStatus	flip	( bool horizontal, bool vertical );
	
	axStatus	subImage( const axImage& src, const axRect2i &src_rc, int x, int y );
	
	float time_;

	axStatus take( axImage &b );

	template<class S> axStatus on_serialize( S &s ) {
		axStatus st;
		st = s.io( width_ );			if( !st ) return st;
		st = s.io( height_ );			if( !st ) return st;
		st = s.io( type_ );				if( !st ) return st;
		st = s.io( byteSizePerPixel_ );	if( !st ) return st;
		st = s.io( pixelData_ );		if( !st ) return st;
		return 0;
	}	

	axStatus	onTake( axImage &b );

protected:
	int				width_; //width
	int				height_; //height
	axColor::Type	type_;
	axSize			byteSizePerPixel_;
	axByteArray		pixelData_;
}; // class axImage

#ifdef axOS_iOS	
	UIImage*	axUIImage_resize	( UIImage* src, float w, float h );
	UIImage*	axUIImage_crop		( UIImage* src, const axRect2f& rc );
#endif		
	
//----------- inline --------------------
inline 
void* axImage::pixelVoidPointer( int x, int y ) {
	if( ! isInside( x,y ) ) return NULL;
	return &pixelData_[( y * width_ + x ) * byteSizePerPixel_ ];
}

inline 
const void* axImage::pixelVoidPointer( int x, int y ) const {
	if( ! isInside( x,y ) ) return NULL;
	return &pixelData_[( y * width_ + x ) * byteSizePerPixel_ ];
}

inline
bool axImage :: isInside( int x, int y ) const {
	if( x < 0 || x >= width_ ) return false;
	if( y < 0 || y >= height_ ) return false;
	return true;
}

template<class Color> inline
void axImage :: pixelPointer( Color* &ptr ) {
	assert( sizeof(Color) == byteSizePerPixel_ );
	ptr = (Color*) pixelVoidPointer();
}	
template<class Color> inline
void axImage :: pixelPointer( Color* &ptr, int x, int y ) {
	assert( sizeof(Color) == byteSizePerPixel_ );
	ptr = (Color*) pixelVoidPointer(x,y);
}	

template<class Color> inline
void axImage :: pixelPointer( const Color* &ptr ) const {
	assert( sizeof(Color) == byteSizePerPixel_ );
	ptr = (Color*) pixelVoidPointer();
}	
template<class Color> inline
void axImage :: pixelPointer( const Color* &ptr, int x, int y ) const {
	assert( sizeof(Color) == byteSizePerPixel_ );
	ptr = (Color*) pixelVoidPointer(x,y);
}

inline
bool axImage::isSizePow2() const	 { 
	return ax_is_pow2(width_) && ax_is_pow2(height_); 
}


#endif //__axImage_h__

