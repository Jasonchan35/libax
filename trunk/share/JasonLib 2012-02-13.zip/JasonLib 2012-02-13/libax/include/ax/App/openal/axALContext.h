#ifndef __axALContext_h__
#define __axALContext_h__

#include "../../base/common/ax_utility.h"
#include "ax_openal_def.h"

#ifdef axUSE_OpenAL

class axALContext : public axNonCopyable {
public:
	ALCdevice  *device;
	ALCcontext *ctx;

	axALContext();
	~axALContext();

	void destroy();
	axStatus create( const char* device_name = NULL );
	void make_current() { alcMakeContextCurrent(ctx);	}
	static const char* device_list() { return alcGetString( NULL, ALC_DEVICE_SPECIFIER ); }


};

#ifdef axOS_iOS
extern alBufferDataStaticProcPtr _alBufferDataStatic;
#endif

#endif //axUSE_OpenAL

#endif // __axALContext_h__

