#ifndef __axGLFrameBuffer_h__
#define __axGLFrameBuffer_h__

#include "axGLTexture.h"
#include "axGLRenderBuffer.h"


//! OpenGL Frame Buffer Object
class axGLFrameBuffer : public axNonCopyable {
public:
	axGLFrameBuffer();
	~axGLFrameBuffer();
	
	axStatus	create();
	void		destroy();
	
	bool		isReady();	//!ready to render, attached required buffer.. etc
	
	GLenum		checkStatus();
	const char* checkStatusString();
	
	static	GLuint	currentBindingId();
	
	void	bind();
	void	unbind();
	
	void	attachColor	( axGLTexture &tex, unsigned index=0 );
	void	detachColor	( axGLTexture &tex, unsigned index=0 );
	
	void	attachColor	( axGLRenderBuffer& rbo, unsigned index=0 );
	void	detachColor	( axGLRenderBuffer& rbo, unsigned index=0 );
	
	void	attachDepth	( axGLTexture &tex );
	void	detachDepth	( axGLTexture &tex );
	
	void	attachDepth	( axGLRenderBuffer& rbo );	
	void	detachDepth	( axGLRenderBuffer& rbo );	
	
	GLuint	id() const { return _id; }
	bool	isValid() { return _id != 0; }
private:
	GLuint	_id;
};
	
#endif //__axGLFrameBuffer_h__

