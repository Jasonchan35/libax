#pragma once
#ifndef __axWaveFile_h__
#define __axWaveFile_h__

#include "axPCMWave.h"
#include "../../base/common/ax_utility.h"


class axWaveFile : public axNonCopyable {
public:	
	class Header {
	public:
		
		uint32_t	riff_id;			// "RIFF"
		uint32_t	total_bytes;		// total filesize-8
		uint32_t	wave;				// "WAVE"
		
		uint32_t	fmt;				// "fmt "
		uint32_t	sc_len;			// length of sub_chunk, =16
		uint16_t	uncompressed;		// 1 if PCM
		
		uint16_t	channels;			// 1 = mono  2 = stereo
		uint32_t	sample_rate;		// sample-rate
		uint32_t	bytes_per_second;	// sample-rate * channels *  (bitrate/8)
		
		uint16_t	block_alignment;	// channels * (bitrate/8)
		uint16_t	bit_rate;			// bit_rate, ( 8, 12 or 16 bit )
		uint32_t	data_chunk_id;		// "data"
		
		uint32_t	data_bytes;		// total size of sample-data
		
		void set( int ch, int freq, int bit );
		void final( size_t s );
		
	};
	
	static axStatus readBuffer ( const axIByteArray &buf,       axPCMWave &wave );
	static axStatus writeBuffer(	   axIByteArray &buf, const axPCMWave &wave );
	
	static axStatus requireLength( axSize &out_len, const axPCMWave &wave );
};

	
template<class S> inline axStatus ax_serialize_io( S &s, axWaveFile::Header &v ) {
	axStatus st;
	
	st = s.io_be( v.riff_id );				if( !st ) return st;
	st = s.io_le( v.total_bytes );			if( !st ) return st;
	st = s.io_be( v.wave );					if( !st ) return st;
	st = s.io_be( v.fmt );					if( !st ) return st;
	st = s.io_le( v.sc_len );				if( !st ) return st;
	st = s.io_le( v.uncompressed );			if( !st ) return st;
	st = s.io_le( v.channels );				if( !st ) return st;
	st = s.io_le( v.sample_rate );			if( !st ) return st;
	st = s.io_le( v.bytes_per_second );		if( !st ) return st;
	st = s.io_le( v.block_alignment );		if( !st ) return st;
	st = s.io_le( v.bit_rate );				if( !st ) return st;	
	st = s.io_be( v.data_chunk_id );		if( !st ) return st;
	st = s.io_le( v.data_bytes );			if( !st ) return st;	
	return 0;
}
	


#endif //__axWaveFile_h__

