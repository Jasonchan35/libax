#ifndef __axGLVertexBuffer_h__
#define __axGLVertexBuffer_h__

#include "ax_opengl_def.h"

//! OpenGL Array Buffer
class axGLArrayBuffer : public axNonCopyable {
public:
	axGLArrayBuffer();
	~axGLArrayBuffer();

	void destroy();

	axStatus create	( const axIArray<axVec2f>		&data, GLenum usage = GL_STATIC_DRAW );
	axStatus create	( const axIArray<axVec3f>		&data, GLenum usage = GL_STATIC_DRAW );

	axStatus create	( const axIArray<axColorRGBb>	&data, GLenum usage = GL_STATIC_DRAW );
	axStatus create	( const axIArray<axColorRGBf>	&data, GLenum usage = GL_STATIC_DRAW );
	axStatus create	( const axIArray<axColorRGBAb>	&data, GLenum usage = GL_STATIC_DRAW );
	axStatus create	( const axIArray<axColorRGBAf>	&data, GLenum usage = GL_STATIC_DRAW );

	//! for element index
	axStatus create	( const axIArray<uint16_t>		&data, GLenum usage = GL_STATIC_DRAW );
	
#ifndef axUSE_OpenGL_ES
	axStatus create	( const axIArray<uint32_t>		&data, GLenum usage = GL_STATIC_DRAW );
#endif

	void	bind	()			{ glBindBuffer( target_, id_ ); }
	void	unbind	()			{ glBindBuffer( target_, 0   ); }

	bool	isValid	() const	{ return id_ != 0; }
	GLuint	getId	() const	{ return id_; }

	//! take the content from source object to this instance and reset the source
	axStatus onTake( axGLArrayBuffer &src );

	GLenum	type		()		{ return type_;		}
	GLint	elementSize	()		{ return elementSize_; }
	
private:
	GLuint id_;
	GLenum target_;
	GLenum type_;
	GLint  elementSize_;

	void createId_	( GLenum target, GLenum type, GLint ele_size );
	void reset_		();
};

inline void glVertexPointer		( axGLArrayBuffer &o )	{ o.bind();  glVertexPointer	( o.elementSize(), o.type(), 0, NULL );  o.unbind(); }
inline void glTexCoordPointer	( axGLArrayBuffer &o )	{ o.bind();  glTexCoordPointer	( o.elementSize(), o.type(), 0, NULL );  o.unbind(); }
inline void glColorPointer		( axGLArrayBuffer &o )	{ o.bind();  glColorPointer		( o.elementSize(), o.type(), 0, NULL );  o.unbind(); }
inline void glNormalPointer		( axGLArrayBuffer &o )	{ o.bind();  glNormalPointer	( o.type(), 0, NULL );  o.unbind(); }

#ifndef axUSE_OpenGL_ES
/*
inline void glVertexAttribPointer ( GLint attr_index, axGLArrayBuffer &o )	{ 
	o.bind();  
	glVertexAttribPointer ( attr_index, o.elementSize(), o.type(), GL_FALSE, 0, NULL );  
	o.unbind(); 
}
 */
#endif
	
#endif //__axGLVertexBuffer_h__

