#ifndef __axGLFontTexture_h__
#define __axGLFontTexture_h__

#include "axGLTexture.h"

class	axGLFontTexture {
public:
	axGLFontTexture();

	bool		isValid			() const { return tex_.isValid(); }

	axStatus	createASCII( axFont & font );
	axStatus	drawText( const axVec3f &pos, const char* text );

private:
	axGLTexture	tex_;
	struct Character {
		axRect2i	rect;
		axStatus	onTake( Character &src ) { *this = src; return 0; }
	};
	int	chHeight_;
	axArray<Character>	characters_;
	int	chStart_;
};


#endif //__axGLFontTexture_h__

