//
//  axGLElementArrayBuffer.h
//  ax
//
//  Created by Jason on 25/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __axGLElementArrayBuffer_h__
#define __axGLElementArrayBuffer_h__

#include "ax_opengl_def.h"

class axGLElementArrayBuffer : public axNonCopyable {
public:
	axGLElementArrayBuffer();
	~axGLElementArrayBuffer();
	
	void destroy();
	
	axStatus create	( const axIArray<uint16_t> &data, GLenum usage = GL_STATIC_DRAW );	
#ifndef axUSE_OpenGL_ES
	axStatus create	( const axIArray<uint32_t> &data, GLenum usage = GL_STATIC_DRAW );
#endif
	
	void bind()				{ glBindBuffer( target_, id_ ); }
	void unbind()			{ glBindBuffer( target_, 0 ); }
			
	bool	isValid()	const { return id_ != 0; }
	GLuint	getId()		const { return id_; }
	
	//! take the content from source object to this instance and reset the source
	axStatus onTake	( axGLElementArrayBuffer &src );
	
	GLenum	type		()		{ return type_;		}
	GLint	elementSize	()		{ return elementSize_; }
	
private:
	GLuint id_;
	GLenum target_;
	GLenum type_;
	GLint  elementSize_;
	
	void createId_	( GLenum target, GLenum type, GLint ele_size );
	void reset_		();
};


#endif //__axGLElementArrayBuffer_h__

