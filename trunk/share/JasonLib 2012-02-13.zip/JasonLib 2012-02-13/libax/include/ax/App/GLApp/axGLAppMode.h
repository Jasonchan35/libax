/*  Filename = axGLAppMode.h /  Project= Awenix
 *  Created by Jason on 02/12/2009.
 *  Copyright 2009 Awenix. All rights reserved. */

#ifndef __axGLAppMode_h__
#define __axGLAppMode_h__

#include "axGLApp.h"
#include "../ui/axGLUIRootView.h"

class axGLAppMode : public axNonCopyable {
public:
	axGLAppMode();
	virtual ~axGLAppMode();
	
	virtual axStatus	onCreate		() { return 0; }
	virtual void		onDestroy		() { }
	
	virtual void		onPushed		() { }
	virtual void		onPoped			() { }

	virtual void		onResize		( float w, float h ) { }
	
	virtual	void		onTouchEvent	( axGLAppTouchEvent		&ev  );
	virtual	void		onMouseEvent	( axGLAppMouseEvent		&ev  );
	virtual	void		onKeyEvent		( axGLAppKeyEvent		&ev  );
	
	virtual void		onFrame			( axGLAppRenderRequest	&req ) {}

	virtual axStatus	onBecomeActive		()	{ return 0; }
	virtual	void		onResignActive		()	{ }
	
	
			void		quitMode		();

		axGLApp&		app				() { return *app_; }
	
		axGLUIRootViewRef	rootView;
	
friend class axGLApp;
protected:
	axStatus			create	( axGLApp* app, axGLAppMode* prevMode );	
	void				resize	( float w, float h );
	void				doFrame	( axGLAppRenderRequest	&req );

private:
	axGLAppMode*		prevMode_; //for popMode;
	axGLApp*			app_;
};
	
#endif //__axGLAppMode_h__

