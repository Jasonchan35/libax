#ifndef __axGLAppCommon_h__
#define __axGLAppCommon_h__

#include "../../ax_base.h"
#include "../../core/math/axVec2.h"
#include "../../core/math/axVec3.h"


class axGLAppCommon {
public:
	enum {
		kEventNull		= 0,
		kEventDown		= 1,
		kEventUp		= 2,
		kEventMove		= 3,
		kEventCancel	= 4,
		kEventNoChange	= 5,
	};	
	
	static	const	char*	_eventName		( int event );
	static			double	systemEventTime	();
};

#endif //__axGLAppCommon_h__
