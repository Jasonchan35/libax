/*  Filename = axAudioSession.h /  Project= libax
 *  Created by Tony on 25/07/2011.
 *  Copyright 2009 Awenix. All rights reserved. */

#ifndef __axAudioSession_h__
#define __axAudioSession_h__

#include "../../base/common/axStatus.h"
#include "../../base/common/ax_utility.h"

class axAudioSession : public axNonCopyable {
public:
		
	axAudioSession();
	virtual ~axAudioSession();
		
	void close();
	
	virtual void callbackBeginInterruption() {};
	virtual void callbackEndInterruption() {};
	virtual void callbackInputIsAvailableChanged( bool b ) {};

	
	axStatus init( bool is_solo = true );
	
	
#if axOS_iOS || axOS_MacOSX
	
	id					delegate_;

#endif
 
 
};


#endif //__axAudioSession_h__

