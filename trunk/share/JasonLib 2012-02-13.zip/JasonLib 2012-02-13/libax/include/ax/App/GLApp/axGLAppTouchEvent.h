#ifndef __axGLAppTouchEvent_h__
#define __axGLAppTouchEvent_h__

#include "axGLAppCommon.h"


class	axGLAppTouch {
public:

#if	axOS_iOS
	typedef	UITouch*	TouchId;
#elif axOS_MacOSX
	typedef	NSTouch*	TouchId;
#elif axOS_Android
	typedef	int			TouchId;
#else
	typedef	int			TouchId;
#endif
	
	
#if axOS_MacOSX
	axNSObject<TouchId>	touchId;
#else
	TouchId			touchId;
#endif
	
	axVec2f		pos;
	float		pressure;	
	double		downTimestamp;
		
	axStatus	toStringFormat ( axStringFormat &f ) const {
		return f.format( "\n  pos={?}, pressure={?}", pos, pressure ); 
	}
	
	axStatus	onTake( axGLAppTouch &src ) { *this=src; return 0; }
};

class axGLAppTouches : public axLocalArray< axGLAppTouch, 16 > {
public:
	//! return < 0 when not found
	axStatus	getTouchIndexById	( axSize &index, axGLAppTouch::TouchId touchId );		
};

class axGLAppTouchEvent : public axGLAppCommon {
public:
	axGLAppTouchEvent();
	
	int		event;
	const	char*	eventName() const { return _eventName( event ); }
	
	axSize	touchIndex;	
	axVec2f	pos;
	double	timestamp;
		
	bool	isDown	() const	{ return event == kEventDown; }
	bool	isUp	() const	{ return event == kEventUp; }
	bool	isMove	() const	{ return event == kEventMove; }
	
	axStatus	toStringFormat( axStringFormat &f ) const {
		return f.format( "event={?} touch={?} pos={?}", eventName(), touchIndex, pos );
	}
	
};


#endif //__axGLAppTouchEvent_h__
