//
//  axGLUIRootView.h
//  ax
//
//  Created by Tony on 29/07/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __axGLUIRootView_h__
#define __axGLUIRootView_h__

#include "axGLUIView.h"

class axGLUIRootView : public axGLUIView {
	typedef axGLUIView	B;	
public:
	
	virtual void setFizedSize ( const axVec2f& size );
	virtual	void onLayout();
		
private:
	
	axVec2f fixedSize;
	
};

typedef axSharedPtr< axGLUIRootView >	axGLUIRootViewRef;

#endif //__axGLUIRootView_h__
