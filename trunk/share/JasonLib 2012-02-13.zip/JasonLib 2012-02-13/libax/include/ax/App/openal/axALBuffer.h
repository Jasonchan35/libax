#ifndef __axALBuffer_h__
#define __axALBuffer_h__

#include "ax_openal_def.h"
#include "../../core/file_system/axMemMap.h"

#ifdef axUSE_OpenAL

class axALBuffer : public axNonCopyable {
public:
	
	ALuint _id;

	axALBuffer();
	~axALBuffer();

	void destroy();
	
	axStatus create( ALenum format, const ALvoid *data, ALsizei size, ALsizei freq );
	
	axStatus loadWav( const wchar_t *filename ); 
	
	axStatus onTake( axALBuffer &src );
	
private:
	axMemMap _buf;
};

#endif //axUSE_OpenAL

#endif //__axALBuffer_h__
