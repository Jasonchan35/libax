#ifndef __axGLUIView_h__
#define __axGLUIView_h__

#include "axGLUIMgr.h"
#include "../GLApp/axGLAppTouchEvent.h"
#include "../GLApp/axGLAppMouseEvent.h"
#include "../GLApp/axGLAppKeyEvent.h"
#include "../GLApp/axGLAppRenderRequest.h"

#include "axGLUIClickEvent.h"


class axGLUIView;
typedef	axSharedPtr< axGLUIView >	axGLUIViewRef;

class axGLUIView : public axSharedPte {
public:
	axGLUIView();
	virtual	~axGLUIView();
	
	
			const	axVec2f&		pos			() const		{ return rect_.pos();  }
			const	axVec2f&		size		() const		{ return rect_.size(); }
			const	axRect2f&		rect		() const		{ return rect_; }
			
			const	axVec2f&		align			() const;
			const	axVec2f&		proportion		() const;
			const	axBorder2f&		margin			() const;
			const	axBorder2f&		padding			() const;	
			

			virtual	axVec2f			contentSize	() const;
	
					axColorRGBAf	color_;
			
	
	// =================== Event ===================
	
	virtual	void		onClickEvent( axGLUIClickEvent &ev );
	
	// ================================================
	
			void		setAlign		( float x, float y );
	
			void		setMargin		( float top, float bottom, float left, float right );
			void		setMargin		( float m );
			void		setPadding		( float top, float bottom, float left, float right );
			void		setPadding		( float m );
	
	//	these function will be disable auto layout
	
	virtual void		setFizedSize		( const axVec2f& size );
			void		setFizedSize		( float w, float h ) { setFizedSize( axVec2f(w,h) ); };

	
	// only affect by autolayout view like VBox HBox and disable fixed size
	
			void				setProportion	( float x, float y );
			
	virtual	const axVec2f		minRequireSize	() const { return minRequireSize_; }
	virtual	const axVec2f		maxRequireSize	() const { return maxRequireSize_; }
		
			void				setMinRequireSize	( float w, float h ) { setMinRequireW(w); setMinRequireH(h); }
	
			void				setMinRequireW		( float w ) { minRequireSize_.x = w; layoutNeeded(); }
			void				setMinRequireH		( float h ) { minRequireSize_.y = h; layoutNeeded(); }
	
	
			void				setMaxRequireSize	( float w, float h ) { setMaxRequireW(w); setMaxRequireH(h); }
			void				setMaxRequireW		( float w ) { maxRequireSize_.x = w; layoutNeeded(); }
			void				setMaxRequireH		( float h ) { maxRequireSize_.y = h; layoutNeeded(); }
	
	
	//
	
	// ================================================
	

			void		doTouchEvent( axGLAppTouchEvent &ev );
			void		doMouseEvent( axGLAppMouseEvent &ev );
			void		doKeyEvent	( axGLAppKeyEvent	&ev );

	
	virtual	void		render		( axGLAppRenderRequest& req ) const;
	virtual	void		onRender	( axGLAppRenderRequest& req ) const;
	
	virtual void		onTouchEvent( axGLAppTouchEvent &ev );
	virtual void		onMouseEvent( axGLAppMouseEvent &ev );
	virtual void		onKeyEvent	( axGLAppKeyEvent	&ev );

	virtual	axVec2f		pointFromParent( const axVec2f& pt );
		
		
	virtual void		onResize	( float w, float h );
	
			void		doLayout	();
	virtual	void		onLayout	();
			void		layoutNeeded();

	
	
	template<class T>
			axStatus	createChild	( T &sp );
	
protected:
friend class axGLUIVBox;
friend class axGLUIHBox;
friend class axGLUIScaleView;
	//users should not able to set positon 
	void		setRect		( const axRect2f &rect );		
	void		setRect		( float x, float y, float w, float h )	{ setRect( axRect2f(x,y,w,h) ); }
	
	void		setPos		( const axVec2f& pos  );
	void		setPos		( float x, float y )					{ setPos( axVec2f(x,y) ); }

	
	void		setSize		( const axVec2f& size );
	void		setSize		( float w, float h )					{ setSize( axVec2f(w,h) ); }
	
	
	
	axVec2f		layoutPosBySize( const axVec2f& size );
	axVec2f		layoutPosBySize( float w, float h )					{ return layoutPosBySize( axVec2f(w,h) ); }
	
	
	
	axStatus	appendChild	( axGLUIView* c );
	axStatus	removeChild	( axGLUIView* c );
	
	
	void		renderChild_( axGLAppRenderRequest& req ) const;
	
	
	
	//! don't make this function virtual, because it will be called by dtor
	void		removeAllChild();
	void		removeFromParent();
	
	
	axRect2f				rect_;
	
	axGLUIView*				parent_;
	axArray<axGLUIViewRef>	child_;
	bool					layoutNeeded_;
	axVec2f					proportion_;
	axVec2f					align_;
	axBorder2f				margin_;
	axBorder2f				padding_;
	
	
	axVec2f					minRequireSize_, maxRequireSize_;
	
	
	
	
};



//-----------------
template<class T> inline
axStatus	axGLUIView::createChild	( T &sp )	{ 
	axStatus st;
	st = sp.newObject();	if( !st ) return st;
	st = appendChild( sp );	if( !st ) return st;
	return 0;
}


#endif //__axGLUIView_h__
