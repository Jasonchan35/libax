#ifndef __axGLContext_h__
#define __axGLContext_h__

#include "ax_opengl_def.h"
#include "axGLResourceMgr.h"

class axGLContext : public axNonCopyable {
public:
	axGLContext();
	~axGLContext();

	void        destroy         ();
	void        swapBuffers     ();
	void        makeCurrent     ();
	
	static		axGLContext*	getCurrent();
    
	axStatus    printInfo       ();
    axStatus    getInfoString   ( axIStringA &str );
    
	void		setVerticalSync	( bool b );


    struct MemInfo {
        axSize avail;
        axSize total;
        axSize vir_avail;
        axSize vir_total;
    };
	void		getMemoryInfo( MemInfo &info );
	bool		isSupportExtension( const char* ext_name );
	
	bool		extension_GL_APPLE_texture_2D_limited_npot	() const { return extension_GL_APPLE_texture_2D_limited_npot_; }
	bool		extension_GL_ARB_texture_non_power_of_two	() const { return extension_GL_ARB_texture_non_power_of_two_; }
	
	int			maxTextureSize	() const		{ return maxTextureSize_;  }
	int			maxTextureUnits	() const		{ return maxTextureUnits_; }
	
//---------	
	int			maxTextureSize_;
	int			maxTextureUnits_;
	bool		extension_GL_APPLE_texture_2D_limited_npot_;
	bool		extension_GL_ARB_texture_non_power_of_two_;
	
#ifdef axOS_WIN
	axStatus	create( HWND win, axGLContext* share_with = NULL );

	HDC		dc_;		//Device Context
	HGLRC	rc_;		//Render Context
	HWND	win_;
//	void swap_ctl( int interval )	{ ::wglSwapIntervalEXT( interval ); }

#elif axOS_iOS
	axStatus	create      ( UIView* view, axGLContext* share_with = NULL );

	axStatus	createBuffers   (); //!< only called when resize
	void        destroyBuffers  ();
	
	EAGLContext*	ctx_;
	UIView*			view_;
	
    GLuint  viewRenderbuffer_;
    GLuint  viewFramebuffer_;
    GLuint  depthRenderbuffer_;
	
#elif axOS_MacOSX
	axStatus	create( axGLContext* share_with = NULL );
	
	NSOpenGLContext*		ctx_;
	NSOpenGLPixelFormat*	fmt_;
	
#elif axOS_Android
	axStatus	create( axGLContext* share_with = NULL );
	
#elif axX11
    Display*    display_;
    GLXDrawable window_;
    GLXContext  ctx_;
    
    axStatus create( Window win, Display *dis, axGLContext* share_with );
#endif
	axSharedPtr< axGLResourceMgr >	resMgr_;
	void		_setAsCurrent();

	axStatus	_createGL( axGLContext* share_with );

	void		_os_ctor();

	static		axGLContext* & currentPtr_();
};

#endif //__axGLContext_h__

