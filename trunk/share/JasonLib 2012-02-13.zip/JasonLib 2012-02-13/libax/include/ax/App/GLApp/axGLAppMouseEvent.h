#ifndef __axGLAppMouseEvent_h__
#define __axGLAppMouseEvent_h__

#include "axGLAppCommon.h"

class axGLAppMouseEvent : public axGLAppCommon, public axNonCopyable {
public:
	axGLAppMouseEvent();
	
	int			event;
	const char*	eventName() const	{ return _eventName( event ); }

	axVec2f		pos;
	axVec2f		lastPos;
	axVec2f		deltaPos;

	axVec3f		scroll;
	
	float		pressure;

	double		eventTime;
	double		downEventTime;
	
	axSize		eventButton;
	int			modifierFlags; //ctrl, shift, atl

	
	class	Button {
	public:
		bool	down;
		double	downTime;
		
		axStatus	onTake( Button &src ) { *this=src; return 0; }
	};
	axArray<Button,3>	buttons;
	
	double		holdTime() const { return eventTime - downEventTime; }
		
			bool	isAnyDown	() const	{ return event == kEventDown; }
			bool	isAnyUp		() const	{ return event == kEventUp;   }
			bool	isAnyMove	() const	{ return event == kEventMove; }
			bool	isAnyCancel	() const	{ return event == kEventCancel; }
	
			bool	isDown	( axSize button ) const	{ return event == kEventDown && button == eventButton; }
			bool	isUp	( axSize button ) const	{ return event == kEventUp   && button == eventButton; }
			bool	isMove	( axSize button ) const	{ return event == kEventMove && button == eventButton; }
		
	axStatus	toStringFormat ( axStringFormat &f ) const {
		return f.format( "event={?:5}:{?} pos={?} scroll={?}", eventName(), eventButton, pos, scroll );
	}
};



#endif //__axGLAppMouseEvent_h__
