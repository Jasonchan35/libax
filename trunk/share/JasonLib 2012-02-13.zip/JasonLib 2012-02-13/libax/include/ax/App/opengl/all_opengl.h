//
//  all_opengl.h
//  ax
//
//  Created by Jason on 18/06/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#ifndef __ax_all_opengl_h__
#define __ax_all_opengl_h__


#include "ax_opengl_def.h"
#include "ax_gl_draw.h"
#include "axGLContext.h"
#include "axGLFrameBuffer.h"
#include "axGLOffscreenRenderer.h"
#include "axGLProgram.h"
#include "axGLRenderBuffer.h"
#include "axGLResourceMgr.h"
#include "axGLShader.h"
#include "axGLTexture.h"
#include "axGLTextureSeq.h"
#include "axGLFontTexture.h"
#include "axGLArrayBuffer.h"

#endif //__ax_all_opengl_h__
