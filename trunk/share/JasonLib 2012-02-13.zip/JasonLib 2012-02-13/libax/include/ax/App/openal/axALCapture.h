#ifndef __axALCapture_h__
#define __axALCapture_h__

#include "../../base/common/ax_utility.h"
#include "axALWave.h"

#ifdef axUSE_OpenAL

class axALContext;

class axALCapture :public axNonCopyable {
	
	ALenum	format;
	int		freq;
	ALCdevice *device;
public:

	axALCapture( axALContext &oal );
	~axALCapture() { destroy(); }

	void destroy();
	axStatus start();
	axStatus stop();
	axStatus create( const axALWave &wave,  const char* device_name = NULL );
	axStatus create( ALenum format, int freq, const char* device_name = NULL );

	axStatus poll( axALWave &w, bool wait_max_sample = true, uint32_t max_sample = 4410 );
	int capture_sample(); //The number of capture samples available.
	static const char* device_list() { return alcGetString( NULL, ALC_CAPTURE_DEVICE_SPECIFIER ); }

private:
	axALCapture& operator=( const axALCapture& src );

};

#endif //axUSE_OpenAL

#endif //__axALCapture_h__
