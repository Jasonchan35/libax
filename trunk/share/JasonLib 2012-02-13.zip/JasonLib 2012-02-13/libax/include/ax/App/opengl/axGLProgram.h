/*  Filename = axGLProgram.h /  Project= awecore
 *  Created by Jason on 18/05/2010.
 *  Copyright 2010 Awenix. All rights reserved. */

#ifndef __axGLProgram_h__
#define __axGLProgram_h__

#include "ax_opengl_def.h"

#ifdef axUSE_OpenGL_ShadingProgram

class axGLShader;
	
class axGLProgram : public axNonCopyable {
public:
	axGLProgram();
	~axGLProgram();
	
	axStatus	create	();
	void	destroy	();
	
	bool	isValid()		{ return _id != 0; }
	
	axStatus	attach_shader( axGLShader	&s );

	axStatus	link	();
	void	info_log();
	
	void	bind	();
	void	unbind	();
private:
	GLuint	_id;
};

#endif //axUSE_OpenGL_ShadingProgram

#endif //__axGLProgram_h__

