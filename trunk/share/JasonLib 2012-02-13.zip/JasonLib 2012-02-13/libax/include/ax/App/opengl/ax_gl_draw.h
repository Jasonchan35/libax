#ifndef __ax_gl_draw_h__
#define __ax_gl_draw_h__

#include "ax_opengl_def.h"

void axGLDrawAxis( float scale = 1.0f );
void axGLDrawGridXZ( int n=10, float dis = 1 );
void axGLDrawGridXY( int n=10, float dis = 1 );

void axGLDrawPoint	( const axVec3f &point );
void axGLDrawPoints	( const axIArray< axVec3f > &point );
	
void axGLDraw		( const axBBox3f &box );
void axGLDraw		( const axFrustum3f &fr );

void axGLDraw		( const axRay3f		&r,	float scale = 1.0f );
void axGLDraw		( const axPlane3f	&p, float scale = 1.0f );
void axGLDraw		( const axRect2f	&rc );

void axGLDrawFill	( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2 );
void axGLDrawFill	( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2, const axVec3f &p3 );
void axGLDrawFill	( const axIArray< axVec3f > &v );

void axGLDrawLine	( const axVec3f &p0, const axVec3f &p1 );
void axGLDrawLine	( const axRect2f &rc );
void axGLDrawLine	( const axBBox3f &box );

void axGLDrawLine	( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2 );
void axGLDrawLine	( const axVec3f &p0, const axVec3f &p1, const axVec3f &p2, const axVec3f &p3 );
void axGLDrawLine	( const axIArray< axVec3f > &v );

void axGLDrawArrow	( float length, float arrow_length, float arrow_width );

void axGLDrawGradient( const axRect2f &rc, 
					  const axColorRGBAf &color0,  const axColorRGBAf &color1,
					  const axColorRGBAf &color2,  const axColorRGBAf &color3 );

template< class Color > inline
void axGLGrawGradient( const axRect2f &rc, 
					  const Color &color0,  const Color &color1,
					  const Color &color2,  const Color &color3 ) 
{
	axGLGrawGradient( rc, axColorRGBAf(color0),axColorRGBAf(color1),
						axColorRGBAf(color2),axColorRGBAf(color3) );
}

template< class Color > inline
void axGLDrawGradientX( const axRect2f &rc, const Color &color0,  const Color &color1 )  {
	axGLDrawGradient( rc, axColorRGBAf(color0),axColorRGBAf(color1),
					    axColorRGBAf(color0),axColorRGBAf(color1) );
}

template< class Color > inline
void axGLDrawGradientY( const axRect2f &rc, const Color &color0,  const Color &color1 )  {
	axGLDrawGradient( rc, axColorRGBAf(color0),axColorRGBAf(color0),
						axColorRGBAf(color1),axColorRGBAf(color1) );
}



#endif //__ax_gl_draw_h__
