#ifndef __axGLAppKeyEvent_h__
#define __axGLAppKeyEvent_h__

#include "axGLAppCommon.h"

class axGLAppKeyEvent : public axGLAppCommon, public axNonCopyable {
public:
	int				event;
	const char*		eventName() const	{ return _eventName( event ); }
	
	int				keyCode;
	axStringW_<4>	characters;
	axStringW_<4>	charactersIgnoringModifiers;
	
	axStatus	toStringFormat ( axStringFormat &f ) const {
		return f.format( "event={?} key={?} ch={?} ch2={?}", eventName(), keyCode, characters, charactersIgnoringModifiers );
	}
	
};

#endif //__axGLAppKeyEvent_h__

