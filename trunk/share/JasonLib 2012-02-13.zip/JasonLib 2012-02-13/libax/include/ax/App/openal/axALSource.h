#ifndef __axALSource_h__
#define __axALSource_h__

#include "ax_openal_def.h"
#include "axALBuffer.h"
#include "../../base/common/ax_utility.h"
#include "../../base/common/axStatus.h"

#ifdef axUSE_OpenAL

class axALSource : public axNonCopyable {
public:
	ALuint _id;

	axALSource();
	~axALSource();

	void destroy();
	axStatus create();

	axStatus bind( axALBuffer &buf );
	axStatus query( axALBuffer &buf );
	axStatus unquery( axALBuffer &buf );
	ALint state();

	void play();
	void keep_play();

	void stop();
	bool is_playing();

	int processed_buf();
	
	bool is_created();
};

#endif //axUSE_OpenAL

#endif //__axALSource_h__

