#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_MeshModifier &an, MObject o ) {
	axStatus	st;
	MStatus		ms;


	return 0;
}