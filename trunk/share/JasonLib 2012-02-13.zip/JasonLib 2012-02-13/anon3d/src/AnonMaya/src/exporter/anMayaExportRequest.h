#ifndef __anMayaExportRequest_h__
#define __anMayaExportRequest_h__

class	anMayaExportRequest : public axNonCopyable {
public:
	anMayaExportRequest();

	axStatus		doExport( const char* filename );

	bool			isPublicNode		( MObject o );
	bool			isNodeExported		( MObject o );
	bool			isNodeInSelectionList	( MObject o );

	axStatus		getNodeName			( MObject o, axIStringA &out );
	axStatus		getNodeType			( MObject o, anNodeType &out );
	axStatus		getAttrName			( MPlug & plug, axIStringA &out );

	axStatus		getInputConnectedPlug	( MPlug &out, const MPlug &dst );
	axStatus		getInputConnectedPlug	( MPlug &out, MObject &node, const MString &attr );

	MSelectionList	selectionList;

//----
			axStatus	exportNode						( MObject o );
			axStatus	writeNode						( anNode &node );

			template<class T> axStatus	exportNode_T	( MObject o, const char* nodeName );
			template<class T> axStatus	doExportNode_T	( T &an, MObject o );

			template<class ATTR>
			axStatus	exportAttr		( ATTR &attr, MObject o, const char* attrName, bool willExportConnection = true );

			template<class ATTR>
			axStatus	exportAttr		( ATTR &attr, MPlug & plug, bool willExportConnection = true );

			axStatus	exportConnection ( anAttr &attr, MPlug & plug, const char* overridePlugName = NULL );
			axStatus	exportConnection ( anAttr &attr, MObject o,    const char* attrName, const char* overridePlugName = NULL );

			axStatus	newConnection		  ( anAttr &attr, MObject o,    const char* attrName );

			template<class ATTR>
			axStatus	doExportAttr_Primitive( ATTR &attr, MPlug & plug, bool willExportConnection = true );

			axStatus	doExportAttr	( anAttr_int		&attr, MPlug &plug, bool willExportConnection = true );
			axStatus	doExportAttr	( anAttr_int64		&attr, MPlug &plug, bool willExportConnection = true );
			axStatus	doExportAttr	( anAttr_float		&attr, MPlug &plug, bool willExportConnection = true );
			axStatus	doExportAttr	( anAttr_double		&attr, MPlug &plug, bool willExportConnection = true );
			axStatus	doExportAttr	( anAttr_bool		&attr, MPlug &plug, bool willExportConnection = true );

			axStatus	doExportAttr	( anAttr_CVec3f		&attr, MPlug &plug, bool willExportConnection = true );
			axStatus	doExportAttr	( anAttr_Mesh3f		&attr, MPlug &plug, bool willExportConnection = true );


			axStatus	doExportNode	( anNode				&an, MObject o );
			axStatus	doExportNode	( anNode_DAG			&an, MObject o );
			axStatus	doExportNode	( anNode_Transform		&an, MObject o );
			axStatus	doExportNode	( anNode_AnimCurve		&an, MObject o );
			axStatus	doExportNode	( anNode_Shape			&an, MObject o );
			axStatus	doExportNode	( anNode_Mesh			&an, MObject o );
			axStatus	doExportNode	( anNode_MeshModifier	&an, MObject o );
			axStatus	doExportNode	( anNode_Deformer		&an, MObject o );
			axStatus	doExportNode	( anNode_BlendShape		&an, MObject o );

private:
	axAutoPtr<anScene>	scene_;
	MSelectionList		selectionList_;
	MObjectArray		exportedNodes_;
	axArray< axAutoPtr< anAttrConnection > >	connections_;
};


//----

template<> inline
axStatus anMayaExportRequest::doExportNode_T< anNode >( anNode &an, MObject o ) { 
	return doExportNode( an, o );
}

template<class T> inline
axStatus anMayaExportRequest::doExportNode_T( T &an, MObject o ) {
	axStatus st;
	st = doExportNode_T<typename T::_BASE_CLASS>( an, o );		if( !st ) return st;
	return doExportNode( an, o );
}

template<class T> inline
axStatus	anMayaExportRequest::exportNode_T ( MObject o, const char* nodeName ) {
	axStatus st;
	MStatus	ms;

	T* an;
	st = scene_->createNode( an, nodeName );
	if( !st ) return st;
	ms = exportedNodes_.append( o );	if( !ms ) return axStatus::not_enough_memory;

//	csvFile.formatWrite( "{?},{?},{?},{?},{?}\n", nodeId, nodeName, an->typeName(), (int)o.apiType(), o.apiTypeStr() );
	st = doExportNode_T<T>( *an, o );		if( !st ) return st;
//	return writeNode( *an );
	return 0;
}

template<class T> inline
axStatus	anMayaExportRequest::exportAttr ( T &attr, MObject o, const char* attrName, bool willExportConnection ) {
	axStatus	st;
	MStatus		ms;
	MFnDependencyNode fn( o );
	MPlug plug = fn.findPlug( attrName, &ms );
	if( !ms ) {
		MGlobal::displayError( MString("exportAttr(): node=" ) + fn.name() + " attr=" + attrName + " not found" );
		return -1;
	}

	return exportAttr( attr, plug, willExportConnection );
}

template<class T> inline
axStatus	anMayaExportRequest::exportAttr ( T &attr, MPlug & plug, bool willExportConnection ) {
	return doExportAttr( attr, plug, willExportConnection );
}

#endif //__anMayaExportRequest_h__
