#include "anMayaExportRequest.h"

typedef	anMesh3f::Index		Index;

static
axStatus	convertIndexArray ( axArray<uint32_t> & dst, const MIntArray & src ) {
	axStatus st;
	axSize n = src.length();
	st = dst.resize( n );	if( !st ) return st;
	for( unsigned i=0; i<n; i++ ) {
		dst[i] = src[i];
	}
	return 0;
}

static
axStatus	appendIndexArray ( axArray<uint32_t> & dst, const MIntArray & src ) {
	axStatus st;
	axSize o = dst.size();
	axSize n = src.length();
	st = dst.incSize( n );	if( !st ) return st;
	for( unsigned i=0; i<n; i++ ) {
		dst[o+i] = src[i];
	}
	return 0;
}

static
axStatus getFaceTriangleVertexIndex( MItMeshPolygon &face, MIntArray &tri_vi ) {
	MStatus ms;
	//get obj base vertex index of this face

	MIntArray	obj_vi;
	ms = face.getVertices( obj_vi );			if( !ms ) return -1;

	//get triangle vertex index
	MPointArray	points;
	ms = face.getTriangles( points, tri_vi );	if( !ms ) return -1;

	//convert vertex from obj base to local base
	unsigned i,j;
	for( i=0; i<tri_vi.length(); i++ ) {
		for( j=0; j<obj_vi.length(); j++ ) {
			if( tri_vi[i] == obj_vi[j] ) {
				tri_vi[i] = j;
				break;
			}
		}
	}
	return 0;
}

static
axStatus	numMeshTriangles( unsigned &out, MFnMesh & fn ) {
	MIntArray	face_tri_counts;
	MIntArray	tri_vi;
	MStatus ms;
	ms = fn.getTriangles( face_tri_counts, tri_vi );		if( !ms ) return -1;
	out = tri_vi.length();
	return 0;
}

axStatus	anMayaExportRequest::doExportAttr	( anAttr_Mesh3f &attr, MPlug &plug, bool willExportConnection ) {
	MStatus		ms;
	axStatus	st;
	MObject		o;

	ms = plug.getValue( o );
	if( ms ) {
//		MGlobal::displayError( plug.name() + " attr is not a mesh object");
//		return -1;

		MFnMesh		fn( o, &ms );		
		if( !ms ) {
			MGlobal::displayError( plug.name() + " attr is not a mesh");
			return -1;
		}
		anMesh3f	mesh;

		{	//vertices
			int n = fn.numVertices();
			if( n > 0 ) {
				const float* p = fn.getRawPoints( &ms );	if( !ms ) return -1; 
				axExternalArray< axVec3f >		arr( (axVec3f*)p, n );
				st = mesh.setVertices( arr );	if( !st ) return st;

				MIntArray	_vertexCount;
				MIntArray	_vertexList;
				ms = fn.getVertices( _vertexCount, _vertexList );			if( !ms ) return -1;

				axArray<Index>	vertexCounts;
				axArray<Index>	vertexIndices;

				st = convertIndexArray( vertexCounts,	_vertexCount );		if( !st ) return st;
				st = convertIndexArray( vertexIndices,	_vertexList  );		if( !st ) return st;

				st = mesh.setFaceVertices( vertexCounts, vertexIndices );	if( !st ) return st;
			}
		}
	/*
		{ // triangle index
			MIntArray	tri_local_vi;
			MUintArray	face_tri_vtx_start;
			MUintArray	face_tri_vtx_count;

			unsigned numTri;
			st = numMeshTriangles( numTri, fn );		if( !st ) return st;

			unsigned current_tri_vtx_count = 0;

			MItMeshPolygon face( o, &ms );						if( !ms ) return -1;
			ms = face_tri_vtx_start.setLength( face.count() );	if( !ms ) return -1;
			ms = face_tri_vtx_count.setLength( face.count() );	if( !ms ) return -1;

			axArray<uint32_t>	triVertexIndices;
			st = triVertexIndices.reserve( numTri * 3 );		if( !st ) return st;
			
			axArray<uint32_t>	faceVertexIndices;

			MIntArray	tmpIntArray;

			for( unsigned i=0; i<face.count(); i++, face.next() ) {
				face_tri_vtx_start[i] = current_tri_vtx_count;
				face_tri_vtx_count[i] = 0;

				ms = face.getVertices( tmpIntArray );		if( !ms ) return -1;
				st = appendIndexArray( faceVertexIndices, tmpIntArray );		if( !st ) return st;

				st = getFaceTriangleVertexIndex( face, tri_local_vi );			if( !st ) return st;

				for( unsigned k=0; k<tri_local_vi.length(); k++ ) {
					int v = tri_local_vi[k];
					//vertex
	//				st = ao.tri_vi.append( face.vertexIndex(v) );
					st = triVertexIndices.append( face.vertexIndex(v) );
					if( !st ) return st;

					//normal
					st = ao.tri_ni.append( face.normalIndex(v) );
					if( !st ) return st;

					// uv
					int ti;
					for( u=0; u<ao.tri_ti.size(); u++ ) {
						ms = face.getUVIndex( v, ti, &uv_sets[u] );		if( !ms ) return -1;
						st = ao.tri_ti[u].append( ti );					if( !st ) return st;
					}

					face_tri_vtx_count[i]++;
				}

				current_tri_vtx_count += face_tri_vtx_count[i];
			}

	//		st = mesh.setTriangleVertexIndices( triVertexIndices );		if( !st ) return st;
		}
	*/
		st = attr.setValue( mesh );								if( !st ) return st;
	}

	if( willExportConnection ) {
		st = exportConnection( attr, plug );			if( !st ) return st;
	}
	return 0;
}