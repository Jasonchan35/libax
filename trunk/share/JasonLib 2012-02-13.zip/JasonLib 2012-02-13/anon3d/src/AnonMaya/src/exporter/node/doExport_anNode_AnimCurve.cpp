#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_AnimCurve &an, MObject o ) {
	axStatus	st;
	MStatus		ms;

	st = exportAttr( an.input(),  o, "input"  );		if( !st ) return st;
	st = exportAttr( an.output(), o, "output" );		if( !st ) return st;

	MFnAnimCurve fn( o, &ms );		if( !ms ) return -1;

	if( fn.isTimeInput() ) {
		scene_->sceneRoot()->currentTime().connect( an.input() );
	}

	if( fn.isWeighted() ) {
		axStringA	name;
		getNodeName( o, name );
		MGlobal::displayError( MString("AnimCurve ") + name + ": weighted tangent currently not support" );
		return -1;
	}

	an.setPreInfinityType	( fn.preInfinityType() );
	an.setPostInfinityType	( fn.postInfinityType() );

	axArray< anNode_AnimCurve::Key >		keys;
	st = keys.resize( fn.numKeys() );		if( !st ) return st;

	axVec2f tangent;
	axVec2f tmp;
	unsigned i;
	for (i = 0; i < fn.numKeys(); i++) {
		anNode_AnimCurve::Key & key = keys[i];

		key.time  = (float)fn.time (i, &ms).as(MTime::kSeconds);	if (!ms) return -2;
		key.value = (float)fn.value(i, &ms);						if (!ms) return -3;

		key.inTangentType  = fn.inTangentType(i, &ms);				if (!ms) return -4;
		ms = fn.getTangent( i, key.inTangent.x, key.inTangent.y, true );
		if (!ms) return -5;

		key.outTangentType = fn.outTangentType(i, &ms);				if (!ms) return -4;
		ms = fn.getTangent( i, key.outTangent.x, key.outTangent.y, false );
		if (!ms) return -5;
	}

	st = an.setKeys( keys );		if( !st ) return st;
	return 0;
}