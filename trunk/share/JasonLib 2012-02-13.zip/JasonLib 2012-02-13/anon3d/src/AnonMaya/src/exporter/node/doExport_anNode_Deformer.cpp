#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_Deformer &an, MObject o ) {
	axStatus	st;
	MStatus		ms;


	return 0;
}