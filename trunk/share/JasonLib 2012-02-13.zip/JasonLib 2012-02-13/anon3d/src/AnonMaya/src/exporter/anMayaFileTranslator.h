#ifndef __anMayaFileTranslator_h__
#define __anMayaFileTranslator_h__

#include "anMayaExportRequest.h"

class anMayaFileTranslator : public MPxFileTranslator {
public:
			anMayaFileTranslator();

	virtual MStatus		writer ( const MFileObject& fileObject, const MString& optionsString, MPxFileTranslator::FileAccessMode mode );
	virtual bool		haveWriteMethod	() const;
	virtual bool		haveReadMethod	() const;
	virtual	bool		canBeOpened		() const;

	virtual MString		defaultExtension() const;
	virtual MString		filter() const;


	static	axStatus	registerPlugin	( MFnPlugin &plugin );
	static	axStatus	deregisterPlugin( MFnPlugin &plugin );
	static	void*		creator();

private:
	anContext			ctx_;
};

#endif //__anMayaFileTranslator_h__

