#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_BlendShape &an, MObject o ) {
	axStatus	st;
	MStatus		ms;

	MFnBlendShapeDeformer fn( o );

	MFnGeometryFilter gf( o );

	MObjectArray oa;
	gf.getInputGeometry(oa);
	if( oa.length() != 1 ) {
		MGlobal::displayError( "input geometry not equal 1" );
		return -4;
	}

//	st = exportAttrByName( an.inMesh(), oa[0], "outMesh" );		if( !st ) return st;
	st = newConnection( an.inMesh(), oa[0], "outMesh" );		if( !st ) return st;

	MPlug weight = fn.findPlug( "weight", &ms );				if( !ms ) return -1;
	MPlug inputTarget = fn.findPlug( "inputTarget", &ms );		if( !ms ) return -1;

	if( inputTarget.numElements() < 1 ) return -1;

	MPlug inputTargetGroup = inputTarget[0].child(0);

	unsigned numTarget = inputTargetGroup.numElements();

	anAttr_Array< anAttr_BlendShapeTarget > & target = an.target();

	st = target.setNumElements( numTarget );		if( !st ) return st;

	for( unsigned i=0; i<numTarget; i++ ) {	
		MPlug inputTargetItem  = inputTargetGroup[i].child(0);
		if( inputTargetItem .numElements() < 1 ) return -1;
		MPlug inputGeomTarget = inputTargetItem [0].child(0);

//		st = exportConnection( req, target[i].mesh(), inputGeomTarget );	if( !st ) return st;

		st = exportAttr( target[i].mesh(), inputGeomTarget );	if( !st ) return st;
		st = exportAttr( target[i].weight(), weight[i] );		if( !st ) return st;
	}

/*
	MPlug it = fn.findPlug( "inputTarget", &ms );
	if( !ms ) {
		MGlobal::displayError( MString("fill ( aoBlendShape ): node=" ) + fn.name() + " can not found inputTarget " );
		return -1;
	}

	StringW	node_name;
	size_t c=0;
	for( i=0; i<it.numElements(); i++ ) {
		MPlug p_it = it[i];
		if( !p_it.isCompound() ) continue; // return Status::invalid_param;

		MPlug p_itg = p_it.child(0);
		if( !p_itg.isCompound() ) continue; // return Status::invalid_param;

		for( j=0; j<p_itg.numElements(); j++ ) {
			MPlug p_iti = p_itg[j].child(0);
			if( !p_iti.isCompound() ) continue; // return Status::invalid_param;
			MPlug igt = p_iti[0].child(0);

			if( c > ao.it.size() ) return Status::invalid_param;

			MObject	shape;
			if( !get_src_connected_node( shape, igt ) ) return Status::invalid_param;

			st = export_node( shape );	if( !st ) return st;

			st = get_node_name( node_name, shape );	if( !st ) return st;

			aoAttrName	a;
			st = a.format( L"itg[{?}]") % j;	if( !st ) return st;
			st = ao.add_src_connection( node_name, L"msg", a );
			if( !st ) return st;

			c++;
		}
	}
*/
	return 0;
}
