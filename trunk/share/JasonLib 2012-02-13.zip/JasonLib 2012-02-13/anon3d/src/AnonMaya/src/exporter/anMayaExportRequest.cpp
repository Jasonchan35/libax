#include "anMayaExportRequest.h"

anMayaExportRequest::anMayaExportRequest() {
}

bool anMayaExportRequest::isNodeInSelectionList ( MObject o ) {
	return selectionList_.hasItem(o);
}

bool anMayaExportRequest::isNodeExported( MObject o ) {
	unsigned n = exportedNodes_.length();
	for( unsigned i=0; i<n; i++ ) {
		if( exportedNodes_[i] == o ) return true;
	}
	return false;
}

bool anMayaExportRequest::isPublicNode ( MObject o ) {
	MStatus ms;
	MFnDependencyNode fn( o, &ms );					if( !ms ) return false;
	MPlug p = fn.findPlug( "anon_public", &ms );	if( !ms ) return false;
	bool b;
	ms = p.getValue(b);		if( !ms ) return false;
	return b;
}

axStatus anMayaExportRequest::getNodeName( MObject o, axIStringA &out ) {
	MStatus ms;
	MFnDagNode	dag( o, &ms );
	if( ms ) {
//		return out.set( dag.fullPathName().asUTF8() );
		return out.set( dag.partialPathName().asUTF8() );
	}

	MFnDependencyNode  node( o, &ms );
	if( ms ) {
		return out.set( node.name().asUTF8() );
	}

	return -1;
}

static axStatus _getAttrName( MPlug & plug, axIStringA &out ) {
	axStatus st;
	MStatus ms;

	MString _name = plug.partialName( false, false, false, true, false, true );
	const char* name = _name.asUTF8();

	MPlug parent = plug.parent( &ms );
	if( ms ) {
		st = _getAttrName( parent, out );	if( !st ) return st;
		st = out.append( "." );				if( !st ) return st;

		MString _parentName = parent.partialName( false, false, false, true, false, true );
		const char* parentName = _parentName.asUTF8();

		size_t l = ax_strlen( parentName );
		if( ax_strncmp( parentName, name, l ) == 0 ) {
			name = _name.toLowerCase().asUTF8() + l;
		}
	}

	st = out.append( name );		if( !st ) return st;
	return 0;
}

axStatus anMayaExportRequest::getAttrName ( MPlug & plug, axIStringA &out ) {
	out.resize(0);

	MString name = plug.partialName( false, false, false, false, true, true );
//	ax_log("attr name = {?}", name );

//re-map maya attr name to anAttr name
	MObject o = plug.node();
	switch( o.apiType() ) {
		case MFn::kDagNode: {
			if( name == "visibility" ) {
				out.set("visible");
				return 0;
			}
		}break;
	}

	return _getAttrName( plug, out );
}

axStatus	anMayaExportRequest::getNodeType ( MObject o, anNodeType &out ) {

	switch( o.apiType() ) {
		case MFn::kTransform:	out = anNodeType_Transform;	return 0;
		case MFn::kMesh:		out = anNodeType_Mesh;		return 0;

/*
		case MFn::kJoint:		return exportNode_T< aoJoint >    ( req, o, nodeName );
		case MFn::kLocator:		return exportNode_T< aoLocator >  ( req, o, nodeName );
		case MFn::kCamera:		return exportNode_T< aoCamera >   ( req, o, nodeName );
		case MFn::kLodGroup:	return exportNode_T< aoLodGroup > ( req, o, nodeName );
		case MFn::kHsvToRgb:	return exportNode_T< aoHsvToRgb > ( req, o, nodeName );
		case MFn::kUnitConversion:	return exportNode_T< aoUnitConversion > (req, o, nodeName );
*/
//deformer
		case MFn::kBlendShape:			out = anNodeType_BlendShape;	return 0;
//		case MFn::kSkinClusterFilter:	return exportNode_T< aoSkinCluster >	( req, o, nodeName );

//		case MFn::kHistorySwitch:
//		case MFn::kNCloth:
//			return exportNode_T< aoGeoCache >		( req, o, nodeName );
/*
//Shader
		case MFn::kLambert:			return exportNode_T< aoLambert >			( req, o, nodeName );
		case MFn::kPhong:			return exportNode_T< aoPhong >			( req, o, nodeName );
		case MFn::kBlinn:			return exportNode_T< aoBlinn >			( req, o, nodeName );
		case MFn::kSurfaceShader:	return exportNode_T< aoSurfaceShader >	( req, o, nodeName );
		case MFn::kShadingEngine:	return exportNode_T< aoShadingEngine >	( req, o, nodeName );

		case MFn::kFileTexture:		return exportNode_T< aoFileTexture >		( req, o, nodeName );
		case MFn::kEnvCube:			return exportNode_T< aoEnvCube >			( req, o, nodeName );
		case MFn::kLayeredTexture:	return exportNode_T< aoLayeredTexture >	( req, o, nodeName );
		case MFn::kPlace2dTexture:	return exportNode_T< aoPlace2dTexture >	( req, o, nodeName );
		case MFn::kPlace3dTexture:	return exportNode_T< aoPlace3dTexture >	( req, o, nodeName );
		case MFn::kUvChooser:		return exportNode_T< aoUVChooser >		( req, o, nodeName );

//Light
		case MFn::kAmbientLight:	return exportNode_T< aoAmbientLight >	( req, o, nodeName );
		case MFn::kDirectionalLight:return exportNode_T< aoDirectionalLight >( req, o, nodeName );
		case MFn::kPointLight:		return exportNode_T< aoPointLight >		( req, o, nodeName );
		case MFn::kSpotLight:		return exportNode_T< aoSpotLight >		( req, o, nodeName );

		case MFn::kCharacter:		return exportNode_T< aoCharacterSet >	( req, o, nodeName );
		case MFn::kClip:			return exportNode_T< aoAnimClip >		( req, o, nodeName );
*/
//AnimCurve
		case MFn::kAnimCurve:
		case MFn::kAnimCurveTimeToAngular:
		case MFn::kAnimCurveTimeToDistance:
		case MFn::kAnimCurveTimeToTime:
		case MFn::kAnimCurveTimeToUnitless:
		case MFn::kAnimCurveUnitlessToAngular:
		case MFn::kAnimCurveUnitlessToDistance:
		case MFn::kAnimCurveUnitlessToTime:
		case MFn::kAnimCurveUnitlessToUnitless:
			out = anNodeType_AnimCurve; return 0;

//our custom  Plugin Node
		case MFn::kPluginDependNode:
		case MFn::kPluginShape:
		case MFn::kPluginHwShaderNode: {
			/*
			MFnDependencyNode	n( o );
			switch( n.typeId().id() ) {
				case maya_type_aoShaderWidget:			return exportNode< aoShaderWidget >( nodeName,o );
			}
			*/
		}break;
	}

	return axStatus_Anon_invalid_node_type;
}

axStatus anMayaExportRequest::getInputConnectedPlug( MPlug &out, MObject &node, const MString &attr  ) {
	MStatus ms;
	MFnDependencyNode fn( node, &ms );	if( !ms ) return -1;
	MPlug p = fn.findPlug( attr, &ms );	if( !ms ) return -1;
	return getInputConnectedPlug( out, p );
}

axStatus anMayaExportRequest::getInputConnectedPlug( MPlug &out, const MPlug &plug ) {
	MStatus ms;
	MPlugArray	pa;
	plug.connectedTo( pa, true, false, &ms );	if( !ms ) return -1;
	if( pa.length() == 0 ) return -1;
	out = pa[0];
	return 0;
}

axStatus	anMayaExportRequest::exportNode( MObject o ) {
	axStatus	st;
	MStatus		ms;

	if( isNodeExported(o) ) return 0;

	axStringA	nodeName;
	st = getNodeName( o, nodeName );	if( !st ) return st;

	MGlobal::displayInfo( MString("export_node \"") + nodeName.c_str() + "\" type "+ o.apiType() +":"+ o.apiTypeStr() );

	anNodeType t;
	st = getNodeType(o, t);		
	if( !st ) {
        MGlobal::displayWarning( MString("unsupported node type \"") + nodeName + "\" ("+ o.apiType() +":"+ o.apiTypeStr()+")" );
		t = anNodeType_Node;
		return st;
	}

	switch( t ) {
		#define	anNodeType_enum( TYPE )	\
			case anNodeType_##TYPE: st = exportNode_T< anNode_##TYPE > ( o, nodeName );	break;
		//----
			#include "../../../../include/libanon/node/anNodeType_enum.h"
		#undef anNodeType_enum
	}

	if( !st ) {
		MGlobal::displayError( MString("export node \"") + nodeName.c_str() + "\" type "+ o.apiType() +":"+ o.apiTypeStr() );
		return st;
	}

	return 0;
}

axStatus anMayaExportRequest::exportConnection ( anAttr &attr, MObject o,  const char* attrName, const char* overridePlugName ) {
	axStatus	st;
	MStatus		ms;
	MFnDependencyNode fn( o );
	MPlug plug = fn.findPlug( attrName, &ms );
	if( !ms ) {
		MGlobal::displayError( MString("exportConnection(): node=" ) + fn.name() + " attr=" + attrName + " not found" );
		return -1;
	}
	return exportConnection( attr, plug, overridePlugName );
}

axStatus anMayaExportRequest::exportConnection( anAttr &attr, MPlug & plug, const char* overridePlugName ) {
	MStatus		ms;
	axStatus	st;

	MPlug inputPlug;
	if( ! getInputConnectedPlug( inputPlug, plug ) ) return 0; //no connection

	if( attr.type() == anAttrType_Mesh3f ) {
		for(;;) { //Mesh Input
//			MGlobal::displayInfo( MString("input type ") + inputPlug.node().apiTypeStr() );
			switch( inputPlug.node().apiType() ) {
				case MFn::kGroupParts: {
					st = getInputConnectedPlug( inputPlug, inputPlug.node(), "inputGeometry" );	if( !st ) return st;
					continue;
				}break;

				case MFn::kTweak: {
					st = getInputConnectedPlug( inputPlug, inputPlug.node(), "inputGeometry" );	if( !st ) return st;
					continue;
				}break;

				case MFn::kMesh:
				case MFn::kBlendShape:
				case MFn::kSkinClusterFilter: {
					st = newConnection( attr, inputPlug.node(), "outMesh" );		if( !st ) return st;
					return 0;		
				}break;

				//default:	MGlobal::displayWarning( MString("unknown inMesh type ") + inputPlug.node().apiTypeStr() );
			}
			break; //break the for(;;)
		}
	}

	if( overridePlugName ) {
		st = newConnection( attr, inputPlug.node(), overridePlugName );	if( !st ) return st;
	}else{
		axTempStringA	attrName;
		st = getAttrName( inputPlug, attrName );							if( !st ) return st;
		st = newConnection( attr, inputPlug.node(), attrName );			if( !st ) return st;
	}

	return 0;
}

axStatus anMayaExportRequest::newConnection( anAttr &attr, MObject srcNode, const char* srcAttr ) {
	axStatus st;

	if( ! isPublicNode( srcNode ) ) {	// public node will not be export automatically
		st = exportNode( srcNode );		
		if( st.code() == axStatus_Anon_invalid_node_type ) return 0;
		if( !st ) return st;
	}

	axTempStringA	nodeName;
	anNodeType		nodeType;

	st = getNodeName( srcNode, nodeName );		if( !st ) return st;
	st = getNodeType( srcNode, nodeType );		if( !st ) return st;

	st = attr.newInputConnection( nodeType, nodeName, srcAttr );		if( !st ) return st;

//	ax_log("Conn: {?}", *attr.inputConnection() );

	return 0;
}

template<class ATTR>
axStatus anMayaExportRequest::doExportAttr_Primitive( ATTR &attr, MPlug & plug, bool willExportConnection ) {
	axStatus	st;
	MStatus		ms;

	ATTR::VALUE value;
	ms = plug.getValue( value );
	if( !ms ) {
		MGlobal::displayError("error getValue from MPlug \"" + plug.partialName(true,true,true,false,true,true)+"\"" );
		return -1;
	}

	st = attr.setValue( value );									if( !st ) return st;

//	ax_log("get attr {?} value {?}", attr, value );

	if( willExportConnection ) {
		st = exportConnection( attr, plug );	if( !st ) return st;
	}
	return 0;
}

axStatus anMayaExportRequest::doExportAttr ( anAttr_int		&attr, MPlug & plug, bool willExportConnection ) { return doExportAttr_Primitive( attr, plug, willExportConnection ); }
axStatus anMayaExportRequest::doExportAttr ( anAttr_float	&attr, MPlug & plug, bool willExportConnection ) { return doExportAttr_Primitive( attr, plug, willExportConnection ); }
axStatus anMayaExportRequest::doExportAttr ( anAttr_double	&attr, MPlug & plug, bool willExportConnection ) { return doExportAttr_Primitive( attr, plug, willExportConnection ); }
axStatus anMayaExportRequest::doExportAttr ( anAttr_bool	&attr, MPlug & plug, bool willExportConnection ) { return doExportAttr_Primitive( attr, plug, willExportConnection ); }

axStatus anMayaExportRequest::doExportAttr ( anAttr_CVec3f	&attr, MPlug & plug, bool willExportConnection ) { 
	axStatus st;
	if( plug.numChildren() != 3 ) {
		MGlobal::displayError("error getValue from MPlug \"" + plug.partialName(true,true,true,false,true,true)+"\"" );
		return -1;
	}

	st = exportAttr( attr.x(), plug.child(0), willExportConnection );	if( !st ) return st;
	st = exportAttr( attr.y(), plug.child(1), willExportConnection );	if( !st ) return st;
	st = exportAttr( attr.z(), plug.child(2), willExportConnection );	if( !st ) return st;

	if( willExportConnection ) {
		st = exportConnection( attr, plug );		if( !st ) return st;
	}
	return 0;
}

axStatus	anMayaExportRequest::doExport( const char* filename ) {
	axStatus st;
	st = scene_.newObject();	if( !st ) return st;

	MGlobal::getActiveSelectionList( selectionList_ );

	MObject	o;
	MStatus	ms;

	{MItSelectionList	it( selectionList_ );
		for( ; ! it.isDone(); it.next() ) {
			ms = it.getDependNode( o );	if( !ms ) return -1;
			st = exportNode( o );
			if( !st ) return st;
		}
	}

//	ax_log("{?}", scene_ );

	st = scene_->saveFile(filename);		if( !st ) return st;
	return 0;
}
