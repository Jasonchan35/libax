#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_Shape &an, MObject o ) {
	axStatus	st;

	return 0;
}