#include "anMayaFileTranslator.h"

anMayaFileTranslator::anMayaFileTranslator() {
	ctx_.create();
}

axStatus anMayaFileTranslator::registerPlugin( MFnPlugin &plugin ) {
	MStatus ms;
	ms =  plugin.registerFileTranslator("AnonScene",
										"",
										creator,
										"",
										"",
										true);
	if (!ms) { ms.perror("registerFileTranslator");	return -1; }
	return 0;
}

axStatus anMayaFileTranslator::deregisterPlugin( MFnPlugin &plugin ) {
	MStatus ms =  plugin.deregisterFileTranslator("AnonScene");
	return 0;
}

void*	anMayaFileTranslator::creator() {
	return new anMayaFileTranslator();
}

MStatus		anMayaFileTranslator::writer (const MFileObject& fileObject, const MString& optionsString, MPxFileTranslator::FileAccessMode mode) {
	ax_log("==== export ====");

	axStatus	st;
	MSelectionList backup_selection;
	MGlobal::getActiveSelectionList( backup_selection );

	if (MPxFileTranslator::kExportAccessMode == mode) {
		MGlobal::executeCommand( "select -all;" );
	} else if (MPxFileTranslator::kExportActiveAccessMode == mode) {
		MGlobal::executeCommand( "select -hierarchy;" );
	} else {
		return MStatus::kFailure;
	}

	anMayaExportRequest	exporter;
	st = exporter.doExport( fileObject.fullName().asUTF8() );

	MGlobal::setActiveSelectionList( backup_selection );

	if( !st ) {
		MGlobal::displayInfo( MString("Export to ") + fileObject.fullName() + " failure!");
		return MStatus::kFailure;
	}

	MGlobal::displayInfo( MString("Export to ") + fileObject.fullName() + " successful!");
	return MStatus::kSuccess;
}

bool		anMayaFileTranslator::haveWriteMethod	() const { return true;  }
bool		anMayaFileTranslator::haveReadMethod	() const { return false; }
bool		anMayaFileTranslator::canBeOpened		() const { return true;  }

MString		anMayaFileTranslator::defaultExtension () const {
	return MString("AnonScene");
}

MString		anMayaFileTranslator::filter() const {
	return MString("*.AnonScene");
}
