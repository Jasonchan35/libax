#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_Transform &an, MObject o ) {
	axStatus	st;
	st = exportAttr( an.translate(),	o, "translate"	);	if( !st ) return st;
	st = exportAttr( an.rotate(),		o, "rotate"		);	if( !st ) return st;
	st = exportAttr( an.scale(),		o, "scale"		);	if( !st ) return st;

	return 0;
}