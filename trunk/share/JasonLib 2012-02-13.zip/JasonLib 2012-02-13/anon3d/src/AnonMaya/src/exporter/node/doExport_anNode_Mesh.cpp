#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_Mesh &an, MObject o ) {
	axStatus	st;
	MStatus		ms;

	st = exportConnection( an.inMesh(), o, "inMesh" );	if( !st ) return st;
	//using outMesh as result other than tweak
	st = exportAttr( an.inMesh(), o, "outMesh", false );	if( !st ) return st;

//	st = exportAttr( an.inMesh(), o, "inMesh" );	if( !st ) return st;

	return 0;
}