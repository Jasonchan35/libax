#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode_DAG &an, MObject o ) {
	axStatus	st;
	MStatus		ms;
	st = exportAttr( an.visible(), o, "visibility" );		if( !st ) return st;

	MFnDagNode	dag( o, &ms );	if( !ms ) return -1;

	unsigned j;
	for( j=0; j<dag.parentCount(); j++ ) {
		MObject	po = dag.parent( j );
	
		if( po.apiType() == MFn::kWorld ) {
			an.setParentName( anNode_SceneRoot::kName );
		}else{
			axTempStringA	tmp;
			st = getNodeName( po, tmp );		if( !st ) return st;
			st = an.setParentName( tmp );		if( !st ) return st;
		}
		break; //only export first parent
	}

	return 0;
}
