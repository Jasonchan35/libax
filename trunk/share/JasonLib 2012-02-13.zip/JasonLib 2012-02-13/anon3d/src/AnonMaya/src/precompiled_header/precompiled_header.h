

#include "../../../../include/libanon/libanon.h"

/*
#if axOS_MacOSX
	#define _BOOL
	#define OSMac_ 
	#define OSMac_MachO_
	#define MAC_PLUGIN 
	#define REQUIRE_IOSTREAM	
	#define MAXPATHLEN 4096
#endif
*/

#include <iostream>

#include <maya/MGlobal.h>

#include <maya/MFnPlugin.h>

#include <maya/MAnimControl.h>
#include <maya/MPxFileTranslator.h>
#include <maya/MSelectionList.h>
#include <maya/MDagPath.h>
#include <maya/MMatrix.h>
#include <maya/MMaterial.h>
#include <maya/MDagPathArray.h>
#include <maya/MFnMatrixData.h>
#include <maya/MHardwareRenderer.h>

#include <maya/MItSelectionList.h>
#include <maya/MItMeshPolygon.h>
#include <maya/MItGeometry.h>

#include <maya/MPlug.h>
#include <maya/MPlugArray.h>

#include <maya/MUintArray.h>
#include <maya/MPointArray.h>
#include <maya/MFloatPointArray.h>
#include <maya/MFloatVectorArray.h>
#include <maya/MHWShaderSwatchGenerator.h>
#include <maya/MHwTextureManager.h>
#include <maya/MTextureEditorDrawInfo.h>

#include <maya/MFnDependencyNode.h>
#include <maya/MFnDagNode.h>
#include <maya/MFnAnimCurve.h>
#include <maya/MFnClip.h>
#include <maya/MFnMesh.h>
#include <maya/MFnMeshData.h>
#include <maya/MFnBlendShapeDeformer.h>
#include <maya/MFnGeometryFilter.h>
#include <maya/MFnSkinCluster.h>
#include <maya/MFnSingleIndexedComponent.h>

#include <maya/MFnTypedAttribute.h>
#include <maya/MFnNumericAttribute.h>
#include <maya/MFnCompoundAttribute.h>
#include <maya/MFnMessageAttribute.h>
#include <maya/MFnEnumAttribute.h>
#include <maya/MFnCharacter.h>

#include <maya/MDrawData.h>
#include <maya/MDrawRequest.h>

#include <maya/MPxSurfaceShape.h>
#include <maya/MPxSurfaceShapeUI.h>
#include <maya/MPxHwShaderNode.h>
#include <maya/MPxObjectSet.h>
#include <maya/MPxDragAndDropBehavior.h>


template<> inline
axStatus axStringFormat_out( axStringFormat &f, const MString &value ) {
	return f.format("{?}", value.asUTF8() );
}