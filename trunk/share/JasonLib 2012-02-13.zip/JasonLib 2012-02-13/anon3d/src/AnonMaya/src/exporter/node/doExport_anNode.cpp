#include "../anMayaExportRequest.h"

axStatus	anMayaExportRequest::doExportNode( anNode &an, MObject o ) {
//	axPRINT_FUNC_NAME
	return 0;
}
