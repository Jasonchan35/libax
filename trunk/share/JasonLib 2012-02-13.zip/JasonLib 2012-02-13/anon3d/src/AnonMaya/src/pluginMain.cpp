//
// Copyright (C)  
// 
// File: pluginMain.cpp
//
// Author: Maya Plug-in Wizard 2.0
//

#include "exporter/anMayaFileTranslator.h"

MStatus initializePlugin( MObject obj ) { 
	axStatus	st;

#ifdef _DEBUG
	MFnPlugin plugin( obj, "Anon", "1.0 debug (build on "__DATE__" "__TIME__")", "Any");
#else
	MFnPlugin plugin( obj, "Anon", "1.0 (build on "__DATE__" "__TIME__")", "Any");
#endif

	// Add plug-in feature registration here
	//

	st = anMayaFileTranslator::registerPlugin( plugin );
	if( !st ) return MStatus::kFailure;

	return MStatus::kSuccess;
}

MStatus uninitializePlugin( MObject obj ) {
	axStatus	st;
	MFnPlugin	plugin( obj );

	// Add plug-in feature deregistration here
	//

	st = anMayaFileTranslator::deregisterPlugin( plugin );
	if( !st ) return MStatus::kFailure;

	return MStatus::kSuccess;
}
