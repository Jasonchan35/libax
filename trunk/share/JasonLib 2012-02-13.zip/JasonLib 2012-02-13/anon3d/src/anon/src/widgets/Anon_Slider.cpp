//
//  Anon_Slider.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-07.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_Slider.h"

wxDEFINE_EVENT( wxEVT_ANON_SLIDER_BEGIN_CHANGE,	Anon_SliderEvent );
wxDEFINE_EVENT( wxEVT_ANON_SLIDER_CHANGING,		Anon_SliderEvent );
wxDEFINE_EVENT( wxEVT_ANON_SLIDER_CHANGED,		Anon_SliderEvent );

Anon_Slider :: Anon_Slider( wxWindow* parent, wxWindowID id, double value, double minValue, double maxValue, const wxPoint &pos, const wxSize &size, long style ) 
	: B(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, style )
{
	if( parent ) {
		SetBackgroundColour( parent->GetBackgroundColour() );
	}

	value_		= value;
	minValue_	= minValue;
	maxValue_	= maxValue;
	
	color_.Set( 192,192,192 );
	bgColor_.Set( 255,255,255 );
	SetMinSize( wxSize(0,8) );
	
	Bind( wxEVT_PAINT, 			&CLASS::onPaintEvent, 	this );
	
	Bind( wxEVT_LEFT_DOWN, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEFT_UP, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOUSEWHEEL, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOTION, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_ENTER_WINDOW, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEAVE_WINDOW, 	&CLASS::onMouseEvent, 	this );

}

void Anon_Slider::onMouseEvent ( wxMouseEvent & ev ) {
	wxSize size = GetSize();
	if( size.x <= 0 ) return; //avoid div 0
	
	bool	refineMode = false;
	double	refineMouseScale = 0.001;
		
	if( ev.ShiftDown() ) {
		refineMode = true;
		refineMouseScale *= 10.0;
	}else if( ev.ControlDown() || ev.RightIsDown() || ev.RightUp() ) {
		refineMode = true;
	}

	double value;
	double scale = maxValue_ - minValue_;

	if( ! refineMode ) {
		int x = ev.GetPosition().x;
		value = (double) x / size.x; 				
		value = value * scale + minValue_;

		startValue_		= value;
		virtualSlider_	= 0;
	}else{
		wxPoint d = ev.GetPosition() - lastMousePos_;
		virtualSlider_ += d.x * refineMouseScale * scale;
		value = startValue_ + virtualSlider_;
	}
	
	if( HasCapture() ) {
		if( ev.ButtonUp() ) { //check RightUp too, on Mac when [Ctrl] is holded and LeftUp will became RightUp
			ReleaseMouse();
			SetValue( value, false );
			Command_Changed();
			SetCursor( wxCURSOR_ARROW );
		}else if( ev.Dragging() ) {
			if( HasCapture() ) {
				if( value != value_ ) {
					SetValue( value, false );
					Command_Changing();
				}
			}
		}
	}else{
		if( ev.ButtonDown() ) { //check RightUp too, on Mac when [Ctrl] is holded and LeftDown will became RightDown
			SetFocus();
			CaptureMouse();
			SetCursor( wxCURSOR_SIZEWE );

			virtualSlider_ = 0;
			startValue_		= value_;

			if( ! refineMode ) {
				SetValue( value, false );
			}
			Command_BeginChange();
		}
	}

	lastMousePos_ = ev.GetPosition();
}

void Anon_Slider::onPaintEvent( wxPaintEvent & ev ) {
//	ax_log("value = {?} min={?} max={?}", value_, minValue_, maxValue_ );
    wxPaintDC dc(this);

	if( HasFlag( wxBORDER_NONE ) ) {
		dc.SetPen( *wxTRANSPARENT_PEN );
	}else{
		dc.SetPen( wxPen( wxColor(0,0,0), 1)  );
	}

	wxRect rc = GetClientRect();

// background
	dc.SetBrush( GetBackgroundColour() );
	dc.DrawRectangle( rc );	

// bar	
	if( minValue_ == maxValue_ ) return;
	
	double 	a = minValue_;
	double	b = maxValue_;
	if( a > b ) wxSwap( a, b );

	double 	d = b - a;

	double	w = ( value_ - a ) / d;
	w = wxClip( w, 0, 1 );

	wxRect barRect	 = rc;

	barRect.Deflate( 0, rc.height / 2.5 );
	wxRect barBGRect = barRect;

	barRect.width = w * GetSize().x;

	barBGRect.x = barRect.width;
	barBGRect.width = rc.width - barBGRect.x;

	wxColor	color0 = color_.ChangeLightness( 100 );
	wxColor	color1 = color_.ChangeLightness( 50 );

	dc.GradientFillLinear( barRect, color0, color1, wxDOWN );


	wxColor	bgColor0 = GetBackgroundColour().ChangeLightness( 0 );
	wxColor	bgColor1 = GetBackgroundColour().ChangeLightness( 100 );
	dc.GradientFillLinear( barBGRect, bgColor0, bgColor1, wxDOWN );
}

void	Anon_Slider::SetColor( const wxColor & color, const wxColor & bgColor ) {
	color_		= color;
	bgColor_	= bgColor;
	Refresh();
}

void	Anon_Slider::SetValue( double value, bool sendEvent ) {
	value_ = wxClip( value, minValue_, maxValue_ );
	Refresh();
	if( sendEvent ) {
		Command_Changed();
	}
}

double	Anon_Slider::GetValue() {
	return value_;
}

void	Anon_Slider::SetMinValue	( double minValue ) {
	minValue_ = minValue;
	Refresh();
}

void	Anon_Slider::SetMaxValue	( double maxValue ) {
	maxValue_ = maxValue;
	Refresh();
}

void	Anon_Slider::Command_BeginChange() {
	Anon_SliderEvent	ev( wxEVT_ANON_SLIDER_BEGIN_CHANGE, GetId() );
	ev.Set(this);
	Command( ev );
}

void	Anon_Slider::Command_Changing() {
	Anon_SliderEvent	ev( wxEVT_ANON_SLIDER_CHANGING, GetId() );
	ev.Set(this);
	Command( ev );
}

void	Anon_Slider::Command_Changed() {
	Anon_SliderEvent	ev( wxEVT_ANON_SLIDER_CHANGED, GetId() );
	ev.Set(this);
	Command( ev );
}

//==== Event 

Anon_SliderEvent::Anon_SliderEvent	( wxEventType commandType, int id ) : wxCommandEvent( commandType, id ) {
	_ctor();
}

Anon_SliderEvent::Anon_SliderEvent	( const Anon_SliderEvent& event ) : wxCommandEvent( event ) {
	_ctor();
}

void Anon_SliderEvent::_ctor() {
}

void Anon_SliderEvent::Set( wxObject *obj ) {
	SetEventObject( obj );
}

wxEvent* Anon_SliderEvent::Clone() const {
	return new Anon_SliderEvent(*this);
}

