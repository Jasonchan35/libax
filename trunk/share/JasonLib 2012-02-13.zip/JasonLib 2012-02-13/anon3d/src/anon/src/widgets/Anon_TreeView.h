//
//  Anon_TreeView.h
//  Anon
//
//  Created by Jason Chan on 2011-11-06.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_Anon_TreeView_h
#define Anon_Anon_TreeView_h

#include "../Anon_common.h"

class Anon_TreeView;
class Anon_TreeViewCell;
class Anon_TreeViewItem;
class Anon_TreeViewBody;

class Anon_TreeViewEvent : public wxCommandEvent {
public:
    Anon_TreeViewEvent	( wxEventType commandType, int id );
    Anon_TreeViewEvent	( const Anon_TreeViewEvent& event );
	
    virtual wxEvent* 	Clone	() const;

	Anon_TreeViewItem*	GetItem	() { return item_; }			
			void		Set( wxObject *obj, Anon_TreeViewItem* item );
private:
	void	_ctor();
	Anon_TreeViewItem*	item_;
};

class Anon_TreeViewCell : public wxControl {
	typedef 	wxControl B;
public:
	Anon_TreeViewCell( Anon_TreeViewItem* item );	
	wxBoxSizer*	sizer;
};

typedef void (wxEvtHandler::*Anon_TreeViewEventFunction)(Anon_TreeViewEvent&);

class Anon_TreeView : public wxControl {
	typedef wxControl	B;
public:
	Anon_TreeView (wxWindow* parent, wxWindowID id, const wxPoint & pos, const wxSize & size, long style );

						void	AppendColumn			( const wxString & label, int proportion = 1 );
						size_t	GetColumnCount			() const;

			Anon_TreeViewItem*	AppendItem				( Anon_TreeViewItem* parentId, const wxString & name );
			
						void	AddItemIcon				( Anon_TreeViewItem* item, const wxBitmap & icon );

			Anon_TreeViewItem*	GetRootItem				();
						size_t	GetItemChildCount		( Anon_TreeViewItem* item );
			Anon_TreeViewItem*	GetItemChild			( Anon_TreeViewItem* itme, size_t index );
	
			Anon_TreeViewCell*	GetCell					( Anon_TreeViewItem* item, unsigned col );
					wxWindow*	GetCellWindow 			( Anon_TreeViewItem* item, unsigned col, size_t index = 0 );						
						void	Clear					();
										
						void	ExpandItem				( Anon_TreeViewItem* item );
						void	CollaspeItem			( Anon_TreeViewItem* item );
						
						void	SetItemClientData		( Anon_TreeViewItem* item, wxClientData* data );
				wxClientData*	GetItemClientData		( Anon_TreeViewItem* item );

	wxBitmap			bmpNull_;
	wxBitmap			bmpExpand_;
	wxBitmap			bmpCollaspe_;
	
	Anon_TreeViewBody*	body				() { return body_; }
	
				int		GridLineWidth		() { return gridLineWidth_; }
				wxPoint	TextMargins			() { return textMargins_; }
		
				void	SetLabelTextColor	( const wxColor & color );
				void	SetLabelBGColor		( const wxColor & color );

				void	SetGridLineColor	( const wxColor & color );
				void	SetGridBGColor		( const wxColor & color );

				void	SetHeaderTextColor	( const wxColor & color );
				void	SetHeaderBGColor	( const wxColor & color );

				void	SetCellBGColor		( const wxColor & color );

	struct	ColorScheme {
		ColorScheme();
		wxColor			GridLineColor;
		wxColor			GridBGColor;

		wxColor			LabelTextColor;
		wxColor			LabelBGColor;

		wxColor			HeaderTextColor;
		wxColor			HeaderBGColor;

		wxColor			CellBGColor;
	};
	const ColorScheme &	GetColorScheme();

private:
	Anon_TreeViewCell*	CreateCell	( Anon_TreeViewItem* item, unsigned col );

	ColorScheme			colorScheme_;

	wxVBoxSizer*		sizer_;	
	Anon_TreeViewBody*	body_;
	
	int					gridLineWidth_;
	wxPoint				textMargins_;
};

#endif
