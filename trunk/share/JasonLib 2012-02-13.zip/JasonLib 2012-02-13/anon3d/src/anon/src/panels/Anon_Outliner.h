#ifndef __Anon_SceneTree_h__
#define __Anon_SceneTree_h__

#include "Anon_Panel.h"
#include "Anon_ToolBar.h"


class Anon_Outliner_ItemData;

class Anon_Outliner : public Anon_Panel {
	typedef	Anon_Outliner	CLASS;
	typedef Anon_Panel 		B;
	typedef Anon_Outliner_ItemData	ItemData;
public:
	Anon_Outliner( wxWindow* parent );
	void	myUpdate	();

	void	doDeleteSelectedNode();

private:
	void	onCommandEvent					( wxCommandEvent &ev );
	void	onTreeSelectChanged				( wxTreeEvent &ev );
	void	onTreeKeyDown					( wxTreeEvent &ev );
	void	onTreeItemRightClick			( wxTreeEvent &ev );


	Anon_Outliner_ItemData*	itemData_		(const wxTreeItemId& item);

	axStatus	addNode			( wxTreeItemId parent, anNode *node );
	axStatus	addNodeChildren	( wxTreeItemId parent, anNode *node );

	wxTreeCtrl*		tree_;
	Anon_ToolBar*	toolbar_;

};

#endif //__Anon_SceneTree_h__
