//
//  Anon_NumberCtrl.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-07.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_NumberCtrl.h"

wxDEFINE_EVENT( wxEVT_ANON_NUMBERCTRL_BEGIN_CHANGE,	Anon_NumberCtrlEvent );
wxDEFINE_EVENT( wxEVT_ANON_NUMBERCTRL_CHANGING,		Anon_NumberCtrlEvent );
wxDEFINE_EVENT( wxEVT_ANON_NUMBERCTRL_CHANGED,		Anon_NumberCtrlEvent );

Anon_NumberCtrlEvent::Anon_NumberCtrlEvent	( wxEventType commandType, int id ) : wxCommandEvent( commandType, id ) {
	_ctor();
}

Anon_NumberCtrlEvent::Anon_NumberCtrlEvent	( const Anon_NumberCtrlEvent& event ) : wxCommandEvent( event ) {
	_ctor();
}

void Anon_NumberCtrlEvent::_ctor() {
}

void Anon_NumberCtrlEvent::Set( wxObject *obj ) { 
	SetEventObject( obj ); 
}

wxEvent* Anon_NumberCtrlEvent::Clone() const { return new Anon_NumberCtrlEvent(*this); }


Anon_NumberCtrl :: Anon_NumberCtrl ( wxWindow* parent, wxWindowID id, double value, int precision, const wxPoint &pos, const wxSize &size, long style ) 
	: B(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, style )
{	
	B::SetBackgroundColour( wxColor(0,0,0) ); //slider or dial sepearate line color
	
	valueInvalid_ = true;

	dial_ 	= NULL;
	slider_ = NULL;

	precision_ = precision;
	trailingZeroes_ = false;
	thousandsSeparator_ = false;

	sizer_	= new  wxHBoxSizer;
	text_  = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize(0,0), wxBORDER_NONE | wxTE_PROCESS_ENTER );
	sizer_->Add( text_, 1, wxEXPAND );
	
	text_->SetFont( parent->GetFont() );
	
	wxSize m = text_->GetFont().GetPixelSize();
	m.x *= 7; // 7 digi
	m.y += 2;
	text_->SetMinSize( m );

	text_->Bind( wxEVT_COMMAND_TEXT_ENTER, 		&CLASS::_OnTextEnter, 		this );
	text_->Bind( wxEVT_KILL_FOCUS, 				&CLASS::_OnTextKillFocus,	this );
	text_->Bind( wxEVT_SET_FOCUS, 				&CLASS::_OnTextSetFocus,	this );

	addOnSizer_ = new wxHBoxSizer;
	sizer_->Add( addOnSizer_, 1, wxEXPAND );	

	SetSizer( sizer_ );
	SetValue( value, false );
	_UpdateValidator(false);
}

bool	Anon_NumberCtrl :: SetForegroundColour		( const wxColor & color ) {
	B::SetForegroundColour( color );
	if( dial_	) dial_->SetForegroundColour( color );
	if( slider_ ) slider_->SetForegroundColour( color );
	return text_->SetForegroundColour( color );
}

bool	Anon_NumberCtrl :: SetBackgroundColour		( const wxColor & color ) {
	B::SetBackgroundColour( color );
	if( dial_	) dial_->SetBackgroundColour( color );
	if( slider_ ) slider_->SetBackgroundColour( color );
	return text_->SetBackgroundColour( color );
}

bool 	Anon_NumberCtrl :: SetMargins (const wxPoint &pt) {
	return text_->SetMargins( pt );
}

bool 	Anon_NumberCtrl :: SetMargins (wxCoord left, wxCoord top) {
	return text_->SetMargins( left, top );
}

wxPoint Anon_NumberCtrl :: GetMargins () const {
	return text_->GetMargins();
}

void Anon_NumberCtrl :: SetPrecision			( int precision, bool sendEvent ) 	{ precision_ = precision;	_UpdateValidator(sendEvent); }
void Anon_NumberCtrl :: SetTrailingZeroes		( bool b ) 							{ trailingZeroes_ = b; 		_UpdateValidator(false); }
void Anon_NumberCtrl :: SetThousandsSeparator	( bool b ) 							{ thousandsSeparator_ = b; 	_UpdateValidator(false); }

void	Anon_NumberCtrl :: _UpdateValidator( bool sendEvent ) {
	int style = wxNUM_VAL_DEFAULT;
	if( thousandsSeparator_ ) style |= wxNUM_VAL_THOUSANDS_SEPARATOR;
	if( ! trailingZeroes_   ) style |= wxNUM_VAL_NO_TRAILING_ZEROES;
	
	text_->SetValidator( wxFloatingPointValidator<double>( precision_, NULL, style ) );
	
	wxAny	a = GetValue();
	
	double v;
	if( a.GetAs( &v ) ) {
		SetValue( v, sendEvent );
	}
}

wxString	Anon_NumberCtrl :: ToString( double value ) {
	int style = wxNumberFormatter::Style_None;
	if( thousandsSeparator_ ) style |= wxNumberFormatter::Style_WithThousandsSep ;
	if( ! trailingZeroes_   ) style |= wxNumberFormatter::Style_NoTrailingZeroes;
	return wxNumberFormatter::ToString( value, precision_, style );
}

bool	Anon_NumberCtrl :: IsValueEquals		( double value ) {
	if( valueInvalid_ ) return false;
	return ( value_ == value );
}

void	Anon_NumberCtrl :: SetValue			( double value, bool sendEvent ) {
	if( IsValueEquals( value ) ) return;
	valueInvalid_ = false;
	value_ = value;

	if( slider_ ) slider_->SetValue( value_, sendEvent );
	if( dial_   ) dial_->SetValue( value, sendEvent );
	
	if( sendEvent ) {
		Command_BeginChange();
		Command_Changed();
		text_->SetValue	( ToString(value) );
	}else{
		text_->ChangeValue( ToString(value) );
	}

	Update();
}

double	Anon_NumberCtrl :: GetValue () {
	return value_;
}

bool	Anon_NumberCtrl::_UpdateValueFromText	() {
	wxAny t = text_->GetValue();
	double value;
	if( ! t.GetAs( &value ) ) return false;
	if( IsValueEquals( value ) ) return false;
	
	SetValue( value, false );
	return true;
}

void	Anon_NumberCtrl::_OnTextKillFocus	( wxFocusEvent 	 & ev ) { 
	if( _UpdateValueFromText() ) {
		Command_BeginChange();
		Command_Changed();
	}
	ev.Skip();
}

void	Anon_NumberCtrl::_OnTextSetFocus	( wxFocusEvent & ev ) {
	ev.Skip();
}

void	Anon_NumberCtrl::_OnTextEnter		( wxCommandEvent & ev ) {
	if( _UpdateValueFromText() ) {
		Command_BeginChange();
		Command_Changed();
	}
	ev.Skip();
}

Anon_Slider* Anon_NumberCtrl :: AddSlider ( double minValue, double maxValue ) {
	if( slider_ ) slider_->Destroy();
	slider_ = new Anon_Slider( this, wxID_ANY, GetValue(), minValue, maxValue, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE );
	addOnSizer_->Add( slider_, 1, wxEXPAND | wxLEFT, 1 );
	
	slider_->Bind( wxEVT_ANON_SLIDER_BEGIN_CHANGE, 	&CLASS::_OnSliderBeginChange, 	this );
	slider_->Bind( wxEVT_ANON_SLIDER_CHANGING, 		&CLASS::_OnSliderChanging,		this );
	slider_->Bind( wxEVT_ANON_SLIDER_CHANGED, 		&CLASS::_OnSliderChanged, 		this );
	return slider_;
}

Anon_Slider* Anon_NumberCtrl :: Slider() { return slider_; }

Anon_Dial*	Anon_NumberCtrl :: AddDial ( double minValue, double maxValue, double step ) {
	if( dial_ ) dial_->Destroy();

	dial_ = new Anon_Dial( this, wxID_ANY, GetValue(), minValue, maxValue, step, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE );
	addOnSizer_->Add( dial_, 0, wxEXPAND );

	dial_->Bind( wxEVT_ANON_DIAL_BEGIN_CHANGE, 	&CLASS::_OnDialBeginChange, 	this );
	dial_->Bind( wxEVT_ANON_DIAL_CHANGING, 		&CLASS::_OnDialChanging,		this );
	dial_->Bind( wxEVT_ANON_DIAL_CHANGED, 		&CLASS::_OnDialChanged, 		this );
	return dial_;
}

Anon_Dial*	Anon_NumberCtrl :: Dial () { return dial_; }

void	Anon_NumberCtrl::_OnSliderBeginChange ( Anon_SliderEvent &ev ) {
	if( ! slider_ ) return;
	double v = slider_->GetValue();
	if( IsValueEquals( v ) ) return;
	SetValue( v, false );
	Command_BeginChange();
}

void	Anon_NumberCtrl::_OnSliderChanging ( Anon_SliderEvent &ev ) {
	if( ! slider_ ) return;
	double v = slider_->GetValue();
	if( IsValueEquals( v ) ) return;
	SetValue( v, false );
	Command_Changing();
}

void	Anon_NumberCtrl::_OnSliderChanged ( Anon_SliderEvent &ev ) {
	if( ! slider_ ) return;
	double v = slider_->GetValue();
	if( IsValueEquals( v ) ) return;
	SetValue( v, false );
	Command_Changed();
}

void	Anon_NumberCtrl::_OnDialBeginChange ( Anon_DialEvent &ev ) {
	Anon_Dial* dial = (Anon_Dial*) ev.GetEventObject();
	if( ! dial ) return;
	double v = dial->GetValue();
	SetValue( v, false );
	Command_BeginChange();
}

void	Anon_NumberCtrl::_OnDialChanging ( Anon_DialEvent &ev ) {
	Anon_Dial* dial = (Anon_Dial*) ev.GetEventObject();
	if( ! dial ) return;
	double v = dial->GetValue();
	SetValue( v, false );
	Command_Changing();
}

void	Anon_NumberCtrl::_OnDialChanged ( Anon_DialEvent &ev ) {
	Anon_Dial* dial = (Anon_Dial*) ev.GetEventObject();
	if( ! dial ) return;
	double v = dial->GetValue();
	SetValue( v, false );
	Command_Changed();
}

void	Anon_NumberCtrl::Command_BeginChange		() {
	Anon_NumberCtrlEvent	newEvent( wxEVT_ANON_NUMBERCTRL_BEGIN_CHANGE, GetId() );
	newEvent.Set( this );
	Command(newEvent);	
}

void	Anon_NumberCtrl::Command_Changing			() {
	Anon_NumberCtrlEvent	newEvent( wxEVT_ANON_NUMBERCTRL_CHANGING, GetId() );
	newEvent.Set( this );
	Command(newEvent);
}

void	Anon_NumberCtrl::Command_Changed			() {
	Anon_NumberCtrlEvent	newEvent( wxEVT_ANON_NUMBERCTRL_CHANGED, GetId() );
	newEvent.Set( this );
	Command(newEvent);	
}



