//
//  Anon_Dial.h
//  Anon
//
//  Created by Jason Chan on 2011-11-08.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_Anon_Dial_h
#define Anon_Anon_Dial_h

#include "../Anon_common.h"

class Anon_DialEvent : public wxCommandEvent {
public:
    Anon_DialEvent	( wxEventType commandType, int id );
    Anon_DialEvent	( const Anon_DialEvent & event );
 	
    virtual wxEvent* 	Clone	() const;
			void		Set( wxObject *obj );
private:
	void	_ctor();
};

typedef void (wxEvtHandler::*Anon_DialEventFunction)(Anon_DialEvent&);

wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_DIAL_BEGIN_CHANGE,	Anon_DialEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_DIAL_CHANGING,		Anon_DialEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_DIAL_CHANGED,		Anon_DialEvent );

class Anon_Dial : public wxControl {
	typedef	Anon_Dial	CLASS;
	typedef	wxControl 	B;
public:
	Anon_Dial( wxWindow* parent, wxWindowID id, double value, double minValue, double maxValue, double step,
				const wxPoint &pos=wxDefaultPosition, const wxSize &size=wxDefaultSize, long style=0 );
	
	void	SetValue	( double value, bool sendEvent = true );
	double	GetValue	();

	void	SetColor	( const wxColor & color, const wxColor & outlineColor );

protected:	
	virtual	wxSize DoGetBestSize	() const;
		
private:
	void	onKeyEvent		( wxKeyEvent	& ev );
	void	onMouseEvent	( wxMouseEvent  & ev );
	void	onPaintEvent	( wxPaintEvent	& ev );
	
	void	_CheckKey		(  wxKeyboardState & ev, bool rightIsDown );

	void	Command_BeginChange	();
	void	Command_Changing	();
	void	Command_Changed		();
	
	double	value_;
	double	step_;
	double	minValue_;
	double	maxValue_;


	double	startValue_;
	double	virtualSlider_;
	double	stepScale_;

	bool	usingX_ : 1;
	bool	usingY_ : 1;

	wxPoint	lastMousePos_;
	wxFont	font_;
		
	wxColor	color_;
	wxColor	outlineColor_;
};


#endif
