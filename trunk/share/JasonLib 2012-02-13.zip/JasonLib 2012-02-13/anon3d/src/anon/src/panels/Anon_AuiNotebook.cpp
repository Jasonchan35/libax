#include "Anon_AuiNotebook.h"

class Anon_AuiNotebookArt : public wxAuiSimpleTabArt {
public:
	Anon_AuiNotebookArt() {
		this->SetColour		 ( my_app->settings.editor.panelColor );
		this->SetActiveColour( my_app->settings.editor.buttonColor );
	}
};


Anon_AuiNotebook :: Anon_AuiNotebook( wxWindow* parent, wxWindowID id, const wxPoint & pos, const wxSize & size, long style ) 
: B( parent, id, pos, size, style )
{
	this->SetArtProvider(new Anon_AuiNotebookArt);
	this->SetForegroundColour( wxColor(255,0,0) );
}
