#include "Anon_MainToolBar.h"

Anon_MainToolBar::Anon_MainToolBar( wxWindow* parent ) : B( parent ) {
	AddToggleIcon( Anon_MainWindow::cmd_play, "icons/play.png", "Play" );
	AddLabel	( Anon_MainWindow::cmd_test_load, "Test" );
//	AddControl	( new wxTextCtrl(this, wxID_ANY, "testing"), "Label" );

	this->Realize();
}

