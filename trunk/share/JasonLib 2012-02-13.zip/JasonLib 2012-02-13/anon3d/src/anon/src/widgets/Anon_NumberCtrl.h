//
//  Anon_NumberCtrl.h
//  Anon
//
//  Created by Jason Chan on 2011-11-07.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_Anon_NumberCtrl_h
#define Anon_Anon_NumberCtrl_h

#include "Anon_Slider.h"
#include "Anon_Dial.h"


class Anon_NumberCtrlEvent : public wxCommandEvent {
public:
    Anon_NumberCtrlEvent	( wxEventType commandType, int id );
    Anon_NumberCtrlEvent	( const Anon_NumberCtrlEvent & event );
 	
    virtual wxEvent* 	Clone	() const;
			void		Set( wxObject *obj );
private:
	void	_ctor();
};

typedef void (wxEvtHandler::*Anon_NumberCtrlEventFunction)(Anon_NumberCtrlEvent&);

wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_NUMBERCTRL_BEGIN_CHANGE,	Anon_NumberCtrlEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_NUMBERCTRL_CHANGING,		Anon_NumberCtrlEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_NUMBERCTRL_CHANGED,		Anon_NumberCtrlEvent );

class Anon_NumberCtrl : public wxControl {
	typedef Anon_NumberCtrl CLASS;
	typedef wxControl B;
public:
	Anon_NumberCtrl( wxWindow* parent, wxWindowID id, double value, int precision = 15, 
					 const wxPoint &pos=wxDefaultPosition, const wxSize &size=wxDefaultSize, long style=0 );

			void	SetValue				( double value, bool sendEvent = true );
			double	GetValue				();

			void	SetPrecision			( int precision, bool sendEvent = true );
			void	SetTrailingZeroes		( bool b );
			void	SetThousandsSeparator	( bool b );

	Anon_Slider*	AddSlider				( double minValue, double maxValue );
	Anon_Slider*	Slider					();

	Anon_Dial*		AddDial					( double minValue, double maxValue, double step );
	Anon_Dial*		Dial					();

	virtual bool	SetForegroundColour		( const wxColor & color );
	virtual bool	SetBackgroundColour		( const wxColor & color );

			bool 	SetMargins (const wxPoint &pt);
			bool 	SetMargins (wxCoord left, wxCoord top=-1);

			wxPoint GetMargins () const;
private:
	void	_UpdateValidator		( bool sendEvent );

	void	_OnSliderBeginChange	( Anon_SliderEvent	& ev );
	void	_OnSliderChanging		( Anon_SliderEvent	& ev );
	void	_OnSliderChanged		( Anon_SliderEvent	& ev );

	void	_OnDialBeginChange		( Anon_DialEvent	& ev );
	void	_OnDialChanging			( Anon_DialEvent	& ev );
	void	_OnDialChanged			( Anon_DialEvent	& ev );

	void	_OnTextEnter			( wxCommandEvent	& ev );
	void	_OnTextKillFocus		( wxFocusEvent 		& ev );
	void	_OnTextSetFocus			( wxFocusEvent		& ev );

	bool	_UpdateValueFromText	();

	void	Command_BeginChange		();
	void	Command_Changing		();
	void	Command_Changed			();
	
	wxString	ToString			( double v );
	
	bool		IsValueEquals		( double value );

	int 	precision_;
	bool	trailingZeroes_ 	: 1;
	bool	thousandsSeparator_ : 1;
	bool	valueInvalid_		: 1;
	
	double			value_;
			
	wxBoxSizer*		sizer_;
	wxBoxSizer*		addOnSizer_;
	wxTextCtrl*		text_;
	Anon_Slider*	slider_;
	Anon_Dial*		dial_;
};

#endif
