#include "Anon_SceneViewer.h"
#include "../widgets/Anon_GLView.h"

class Anon_SceneViewer::GLView : public Anon_GLView {
	typedef Anon_GLView B;
	typedef Anon_SceneViewer::GLView CLASS;
public:	
	GLView( wxWindow* parent, Anon_SceneViewer* sceneViewer, wxWindowID wid = wxID_ANY );
	virtual ~GLView();
	
	enum {
		cmd_null,
		cmd_comp_object,
		cmd_comp_vertex,
		cmd_comp_edge,
		cmd_comp_face,
		cmd_split_polygon_tool,
	};

	virtual void	onPaint();

			void	cameraThumb	( const axVec2f &v );
			void	cameraPan	( const axVec2f &v );
			void	cameraDolly	( float v );

			void	onRenderNeeded	();

private:
	axEventFunc<CLASS,void>		hookRenderNeeded;

			void	onKeyEvent		( wxKeyEvent	& ev );
			void	onMouseEvent	( wxMouseEvent	& ev );
			void	onSetupMatrix_	( const axRect2f &region );
			void	render3D_();
			void	render2D_();

	Anon_SceneViewer*		sceneViewer_;
	Anon_CameraController	camCtrl_;
	
	axMatrix4f			viewMatrix_;
	axVec2f				lastMousePos_;
};


Anon_SceneViewer::GLView::GLView( wxWindow *parent, Anon_SceneViewer* sceneViewer, wxWindowID wid ) : B( parent,wid ) {
	sceneViewer_ = sceneViewer;	
	viewMatrix_.setLookAt( axVec3f(8,8,8),  axVec3f(0,0,0),   axVec3f(0,1,0)  );

	hookRenderNeeded.hook( my_app->evRenderNeeded, this, &CLASS::onRenderNeeded );
	
	Bind( wxEVT_LEFT_DOWN, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEFT_UP, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOUSEWHEEL, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOTION, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_ENTER_WINDOW, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEAVE_WINDOW, 	&CLASS::onMouseEvent, 	this );

	
	Bind( wxEVT_KEY_DOWN,		&CLASS::onKeyEvent,		this );
}
	
Anon_SceneViewer::GLView::~GLView() {
}

void	Anon_SceneViewer::GLView::onRenderNeeded() {
	Refresh();
	Update();
}

void	Anon_SceneViewer::GLView::onPaint() {
	glClearColor( my_app->settings.scene.bgColor );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );

	render3D_();
	render2D_();
}

void	Anon_SceneViewer::GLView::onKeyEvent( wxKeyEvent & ev ) {

}

void	Anon_SceneViewer::GLView::onMouseEvent( wxMouseEvent &ev ) {
	if( camCtrl_.checkMouseEvent( this, ev ) ) {
		cameraThumb	( camCtrl_.thumb * 0.01f );
		cameraPan	( camCtrl_.pan 	 * 0.02f );
		cameraDolly	( camCtrl_.dolly * 0.10f );	
	}
}

void	Anon_SceneViewer::GLView::cameraThumb( const axVec2f &v ) {
	viewMatrix_.rotateY( -v.x );
	axVec3f		up  (0,1,0);
	axVec3f		dir (0,0,1);
	axMatrix4f	inv  = viewMatrix_.inverse();
	axVec3f		side = ( (dir.mul3x3(inv) ) ^ (up.mul3x3(inv) ) ).normal();
	viewMatrix_.rotate( v.y, side );
	Refresh();
}

void	Anon_SceneViewer::GLView::cameraPan	( const axVec2f &v ) {
	axMatrix4f	inv  = viewMatrix_.inverse();
	axVec3f up   = ( axVec3f(0,1,0).mul3x3( inv ) ).normal();
	axVec3f side = ( axVec3f(1,0,0).mul3x3( inv ) ).normal();
	viewMatrix_.translate( up * v.y + side * -v.x );
	Refresh();
}

void	Anon_SceneViewer::GLView::cameraDolly( float v ) {
	axMatrix4f	inv  = viewMatrix_.inverse();
	axVec3f dir  = ( axVec3f(0,0,1).mul3x3( inv ) ).normal() * v;
	viewMatrix_.translate( dir );
	Refresh();
}


void	Anon_SceneViewer::GLView::render3D_() {
	wxSize	screen = GetClientSize();
	
	axRect2f	viewport ( 0, 0, screen.x, screen.y );
	
	glViewport( viewport );
	onSetupMatrix_( viewport );
	
	glEnable( GL_DEPTH_TEST );
	glDepthFunc( GL_LEQUAL );

	if( my_app->settings.scene.showGrid ) {
		int n = 10;
		float dis = 1;
		glColor3f( .4f, .4f, .4f );
		axGLDrawGridXZ( n, dis );
		
		glLineWidth( 2 );
		glColor3f( 0,0,0 );
		axGLDrawLine( axVec3f( n*dis, 0,0 ), axVec3f( -n*dis, 0,0 ) );
		axGLDrawLine( axVec3f( 0,0, n*dis ), axVec3f( 0,0, -n*dis ) );
		
		glLineWidth( 1 );
		glColor3f( 1,1,1 );
	}

	if( my_app->scene ) {
		my_app->scene->renderGL( my_app->renderReq );
	}
}

void	Anon_SceneViewer::GLView::render2D_() {
}


void Anon_SceneViewer::GLView::onSetupMatrix_( const axRect2f &region  ) {
	wxSize	viewSize = GetClientSize();
	if( viewSize.x == 0 || viewSize.y == 0 ) return;

	float fov = 37.8f; // 37.8 = 35mm lens

	axRect2f rc = region.absSize();
	if( rc.w == 0 || rc.h == 0 ) return;

	axRect2f viewport = axRect2f( rc.x, viewSize.y - rc.y, rc.w, -rc.h  ).absSize();
	glViewport( viewport );

	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();

	float aspect = (float)viewSize.x / (float)viewSize.y;

	axMatrix4f	proj;

	proj.setPerspective( ax_deg_to_rad(fov), aspect, 0.1f, 1000.0f );

	axVec2f	scale( viewSize.x / rc.w, viewSize.y / rc.h );
	proj.scale( scale );

//projection shear
	axVec2f	half_screen( (float)viewSize.x / 2.0f, (float)viewSize.y / 2.0f );

	axVec2f	offset = rc.center();
	offset.x = viewSize.x - offset.x;

	axVec2f	shear = ( half_screen - offset ) * scale / half_screen;

	proj.cz.x = shear.x;
	proj.cz.y = shear.y;

	glLoadMatrix( proj );

	glMatrixMode( GL_MODELVIEW );
	glLoadMatrix( viewMatrix_ );
}

//===============
Anon_SceneViewer::Anon_SceneViewer( wxWindow* parent ) : B( parent, wxID_ANY ) {
	this->SetBackgroundColour( my_app->settings.editor.panelColor );
	border_ = new wxPanel( this );
	
	wxBoxSizer *border_vbox = new wxBoxSizer( wxVERTICAL );

	SetAutoLayout( true );
	SetSize( 300, 300 );
	SetSizer( border_vbox );

	border_vbox->Add( border_, 1, wxEXPAND | wxALL, 3 );
	
	wxBoxSizer *vbox = new wxBoxSizer( wxVERTICAL );
	border_->SetAutoLayout( true );
	border_->SetSize( 300, 300 );
	border_->SetSizer( vbox );
	
//	Anon_ToolBar*	toolbar_ = new Anon_ToolBar( border_, wxID_ANY );
//	vbox->Add( toolbar_, 0, wxEXPAND | wxALL, 0 );

	glview_ = new GLView( border_, this );
	vbox->Add( glview_, 1, wxEXPAND | wxALL, 0 );
	
//	toolbar_->addBitmapToggleButton( cmd_show_grid, "/resources/icons/SceneView/show_grid.png", my_app->settings.scene.showGrid );	
//	toolbar_->add_bitmap_toggle_button( cmd_wireframe, L"View3D/wireframe.png", false  );	
}


void	Anon_SceneViewer::onCommandEvent ( wxCommandEvent &ev ) {
	/*
	switch( ev.GetId() ) {
		case cmd_wireframe:		{ view3d_ogl->b_wireframe = ( ev.GetInt() != 0 );	}break;
		case cmd_show_grid:		{ view3d_ogl->b_show_grid = ( ev.GetInt() != 0 );	}break;
	}
	*/
}
