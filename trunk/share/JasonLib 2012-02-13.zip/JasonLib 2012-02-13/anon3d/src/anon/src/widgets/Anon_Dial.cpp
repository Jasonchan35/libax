//
//  Anon_Dial.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-08.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

//
//  Anon_Dial.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-07.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_Dial.h"

wxDEFINE_EVENT( wxEVT_ANON_DIAL_BEGIN_CHANGE,	Anon_DialEvent );
wxDEFINE_EVENT( wxEVT_ANON_DIAL_CHANGING,		Anon_DialEvent );
wxDEFINE_EVENT( wxEVT_ANON_DIAL_CHANGED,		Anon_DialEvent );

Anon_DialEvent::Anon_DialEvent	( wxEventType commandType, int id ) : wxCommandEvent( commandType, id ) {
	_ctor();
}

Anon_DialEvent::Anon_DialEvent	( const Anon_DialEvent& event ) : wxCommandEvent( event ) {
	_ctor();
}

void Anon_DialEvent::_ctor() {
}

void Anon_DialEvent::Set( wxObject *obj ) {
	SetEventObject( obj );
}

wxEvent* Anon_DialEvent::Clone() const {
	return new Anon_DialEvent(*this);
}


Anon_Dial :: Anon_Dial( wxWindow* parent, wxWindowID id, double value, double minValue, double maxValue, double step,
						const wxPoint &pos, const wxSize &size, long style ) 
	: B(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, style )
{
	if( parent ) {
		SetForegroundColour	( parent->GetForegroundColour() );
		SetBackgroundColour	( parent->GetBackgroundColour() );
	}
	
	value_		= value;
	minValue_	= minValue;
	maxValue_	= maxValue;
	step_		= step;
	stepScale_  = 1;

	outlineColor_.Set( 0,0,0 );
	color_.Set( 192, 192, 192 );

	#ifdef _WIN32
		font_.Create( 6, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL );
	#else
		font_.Create( 8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL );
	#endif
	
	Bind( wxEVT_PAINT, 			&CLASS::onPaintEvent, 	this );
	
	Bind( wxEVT_LEFT_DOWN, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEFT_UP, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MIDDLE_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_DOWN, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_RIGHT_UP,	 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOUSEWHEEL, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_MOTION, 		&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_ENTER_WINDOW, 	&CLASS::onMouseEvent, 	this );
	Bind( wxEVT_LEAVE_WINDOW, 	&CLASS::onMouseEvent, 	this );
	
	Bind( wxEVT_KEY_DOWN,		&CLASS::onKeyEvent,		this );
	Bind( wxEVT_KEY_UP,			&CLASS::onKeyEvent,		this );
}

wxSize Anon_Dial :: DoGetBestSize	() const {
//	wxSize s = GetFont().GetPixelSize();
//	s.x = s.y + font_.GetPixelSize().x * step_.Length() + spacing_ * 3;
//	return s;
	return wxSize( 35,14 );
}

void	Anon_Dial::_CheckKey	( wxKeyboardState & ev, bool rightIsDown ) {
	double s = 1;
	if( ev.ShiftDown() ) {
		s *= 10.0;
	}else if( ev.ControlDown() || rightIsDown ) {
		s /= 10.0;
	}

	if( stepScale_ != s ) { //scale changed
		startValue_		= value_;
		virtualSlider_	= 0;
		stepScale_ = s;
		Refresh();
	}
}

void Anon_Dial::onKeyEvent ( wxKeyEvent & ev ) {
	if( HasCapture() ) {
		_CheckKey(ev,false);
	}
}

void Anon_Dial::onMouseEvent ( wxMouseEvent & ev ) {
	if( step_ == 0 ) return;
	
	if( ev.Entering() ) {
		SetCursor( wxCURSOR_HAND );
		return;
	}
	
	if( ev.Leaving() ) {
		SetCursor( wxCURSOR_ARROW );
		return;
	}

	if( HasCapture() ) {
		if( ev.ButtonUp() ) { //check RightUp too, on Mac when [Ctrl] is holded and LeftUp will became RightUp
			stepScale_ = 1;
			Refresh();
			if( HasCapture() ) ReleaseMouse();
			Command_Changed();
		}else if( ev.Dragging() ) {
			_CheckKey(ev, ev.RightIsDown() );
			if( usingX_ || usingY_ ) {
				wxPoint d = ev.GetPosition() - lastMousePos_;
				lastMousePos_ = ev.GetPosition();
				
				if( usingX_ ) virtualSlider_ += d.x * stepScale_;
				if( usingY_ ) virtualSlider_ -= d.y / 5.0 * stepScale_;

				double	u = wxRound( virtualSlider_ / stepScale_ ) * stepScale_ * step_;
				double	value = startValue_ + u;
		
				SetValue( value, false );
				Command_Changing();

			}else{ //find direction
				wxPoint d = ev.GetPosition() - lastMousePos_;
				const int threshold = 4;
				int x = abs(d.x);
				int y = abs(d.y);
				if( x > y ) {
					if( x >= threshold ) {
						usingX_ = true;
						usingY_ = false;
						SetCursor( wxCURSOR_SIZEWE );
						lastMousePos_ = ev.GetPosition();
					}
				}else{
					if( y >= threshold ) {
						usingX_ = false;
						usingY_ = true;
						SetCursor( wxCURSOR_SIZENS );
						lastMousePos_ = ev.GetPosition();
					}
				}
			}
		}
	}else{
		if( ev.ButtonDown() ) { //check RightUp too, on Mac when [Ctrl] is holded and LeftDown will became RightDown
			SetFocus();
			CaptureMouse();
			_CheckKey(ev, ev.RightIsDown() );
			SetCursor( wxCURSOR_SIZING );

			usingX_ = false;
			usingY_ = false;

			virtualSlider_	= 0;
			startValue_		= value_;
			lastMousePos_	= ev.GetPosition();
			Command_BeginChange();
		}
	}
}

void Anon_Dial::SetColor	( const wxColor & color, const wxColor & outlineColor ) {
	color_ = color;
	outlineColor_ = outlineColor;
}

void Anon_Dial::onPaintEvent( wxPaintEvent & ev ) {
    wxPaintDC dc(this);

	wxGraphicsRenderer* render = wxGraphicsRenderer::GetDefaultRenderer();
	axAutoPtr<wxGraphicsContext>	gc; 
	gc.ref( render->CreateContext( dc ) );


	const int margin	= 0; 

	wxSize	size = GetSize();

	wxGraphicsBrush brush = gc->CreateLinearGradientBrush( 0, 0, 0, size.y, 
															color_, 
															color_.ChangeLightness(40) );

	gc->SetBrush( brush );

//	gc->SetBrush( color_ );
	gc->SetPen( wxPen( outlineColor_, 1 ) );


	wxRealPoint	center( size.y / 2.0, size.y / 2.0 );

//circle
	gc->DrawEllipse( margin, margin, size.y - margin*2 -1, size.y - margin*2 -1 );

//pin
	double radius = size.y / 2.0 - margin - 2;

	double v = value_;
	if( step_ != 0 ) v /= step_;
	double angleDiv = 60;	
	double angle = v / angleDiv * 2 * M_PI; // rad to deg

	wxRealPoint	a( sin( angle ), -cos( angle ) );
	a = a * radius + center;

	gc->SetPen( wxPen( outlineColor_, 5 ) );
	gc->StrokeLine( a.x, a.y, center.x, center.y );

	gc->SetPen( wxPen( wxColor(240,240,240), 3 ) );
	gc->StrokeLine( a.x, a.y, center.x, center.y );

//text
	gc->SetFont( font_, GetForegroundColour() );
	wxSize fontSize = font_.GetPixelSize();

	const int text_spacing	= 2;

	double		s = step_ * stepScale_;
	wxString	str = wxString::Format("%g", s );
	if( str.Len() < 3 ) str += ".0";
	gc->DrawText( str, size.y + text_spacing, center.y - fontSize.y / 2 );
}

void	Anon_Dial::SetValue( double value, bool sendEvent ) {
	value_ = wxClip( value, minValue_, maxValue_ );	
	Refresh();

	if( sendEvent ) {
		Command_Changed();
	}
}

double	Anon_Dial::GetValue() {
	return value_;
}

void	Anon_Dial::Command_BeginChange() {
	Anon_DialEvent	ev( wxEVT_ANON_DIAL_BEGIN_CHANGE, GetId() );
	ev.Set(this);
	Command( ev );
}

void	Anon_Dial::Command_Changing() {
	Anon_DialEvent	ev( wxEVT_ANON_DIAL_CHANGING, GetId() );
	ev.Set(this);
	Command( ev );
}

void	Anon_Dial::Command_Changed() {
	Anon_DialEvent	ev( wxEVT_ANON_DIAL_CHANGED, GetId() );
	ev.Set(this);
	Command( ev );
}



