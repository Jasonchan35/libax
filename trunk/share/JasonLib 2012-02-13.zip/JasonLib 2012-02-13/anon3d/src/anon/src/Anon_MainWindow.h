#ifndef __Anon_MyFrame_h__
#define __Anon_MyFrame_h__

#include "Anon_common.h"

class Anon_Outliner;
class Anon_SceneViewer;
class Anon_Inspector;
class Anon_MainToolBar;
class Anon_GraphEditor;

class Anon_MainWindow : public wxFrame {
	typedef	Anon_MainWindow	CLASS;
	typedef wxFrame B;
public:
	enum {
		cmd_null,
	//File
		//New
		//Open
		//Save
		//Save As
		//Exit
	//Edit
		cmd_undo,
		cmd_redo,
		
	//Animation
		cmd_play,
		cmd_test_load,

	//Object
		cmd_object_create,
	//panel
		cmd_panel_saveLayout,

	//  ID_FirstPerspective = ID_CreatePerspective+1000
	};

    Anon_MainWindow( wxWindow* parent, wxWindowID wid, wxPoint position, wxSize size );
    ~Anon_MainWindow();

	void	onCommandEvent	( wxCommandEvent& ev );
	void	onTimerEvent	( wxTimerEvent &ev );
	void	test_load();
	
private:
	Anon_MainToolBar	*toolbar_;
	Anon_Outliner		*outliner_;
	Anon_SceneViewer	*sceneViewer_;
	Anon_Inspector		*inspector_;
	Anon_GraphEditor	*graphEditor_;
	
    wxAuiManager		aui_;
	wxTimer				*timer_;	
	axStopWatch			stopWatch_;
};

#endif //__Anon_MyFrame_h__
