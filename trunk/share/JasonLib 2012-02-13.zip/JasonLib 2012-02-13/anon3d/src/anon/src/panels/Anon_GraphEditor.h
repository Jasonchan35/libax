//
//  Anon_GraphEditor.h
//  Anon
//
//  Created by Jason Chan on 2011-11-13.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_GraphEditor_h
#define Anon_GraphEditor_h

#include "Anon_Panel.h"

class Anon_GraphEditor : public Anon_Panel {
	typedef	Anon_GraphEditor	CLASS;
	typedef Anon_Panel 		B;
public:
	Anon_GraphEditor( wxWindow* parent );

private:
	class	Graph;
	Graph*			graph_;
	wxBoxSizer*		sizer_;

};


#endif
