//
//  Anon_GraphEditor.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-13.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_GraphEditor.h"

#if 0
#pragma mark ========= Graph ============
#endif

class	Anon_GraphEditor::Graph : public wxControl {
	typedef	Graph CLASS;
	typedef	wxControl	B;
public:
	Graph( wxWindow* parent, wxWindowID id ) : B( parent, id ) {
		viewOffset_.set(0,0);
		viewScale_.set(100,30);
	
		Bind( wxEVT_PAINT, 			&CLASS::onPaintEvent, this );
		
		Bind( wxEVT_LEFT_DOWN, 		&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_LEFT_UP, 		&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_MIDDLE_DOWN, 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_MIDDLE_UP,	 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_RIGHT_DOWN, 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_RIGHT_UP,	 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_MOUSEWHEEL, 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_MOTION, 		&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_ENTER_WINDOW, 	&CLASS::onMouseEvent, 	this );
		Bind( wxEVT_LEAVE_WINDOW, 	&CLASS::onMouseEvent, 	this );

		
		Bind( wxEVT_KEY_DOWN,		&CLASS::onKeyEvent,		this );
		Bind( wxEVT_KEY_UP,			&CLASS::onKeyEvent,		this );
	}

	void	draw( anAttr attr, wxGraphicsContext *gc ) {
		axSize nElement = attr.numElements();
		if( nElement ) {
			for( axSize i=0; i<nElement; i++ ) {
				draw( attr.element(i), gc );
			}
		}

		axSize nChild = attr.numChildren();
		if( nChild ) {
			for( axSize i=0; i<nChild; i++ ) {
				draw( attr.child(i), gc );
			}
		}
				
		anAttrConnection *conn = attr.inputConnection();
		if( ! conn ) return;
		anNode* srcNode =conn->source.node();
		switch( srcNode->type() ) {
			case anNodeType_AnimCurve: {
				anNode_AnimCurve* curve = (anNode_AnimCurve*)srcNode;

				float v0, v1;
				int e = GetSize().x;

				curve->evaluate(v0, 0);
				for( int i=1; i<e; i++ ) {
					curve->evaluate(v1, i / viewScale_.x );
				
					axVec2f pt0 = axVec2f( i-1, v0 ) * viewScale_ + viewOffset_;
					axVec2f pt1 = axVec2f(  i , v1 ) * viewScale_ + viewOffset_;
						
					gc->StrokeLine( pt0.x, pt0.y, pt1.x, pt1.y ); 					
					v0 = v1;
				}				
			}break;
		}
	}

	void	onKeyEvent( wxKeyEvent & ev ) {
	}

	void	onMouseEvent( wxMouseEvent & ev ) {
		if( camCtrl_.checkMouseEvent( this, ev ) ) {
			viewOffset_ -= camCtrl_.pan;
			viewScale_  += camCtrl_.dolly;
			Refresh();
		}
	}
	
	void	onPaintEvent( wxPaintEvent & ev ) {
	    wxPaintDC dc(this);
		wxGraphicsRenderer* render = wxGraphicsRenderer::GetDefaultRenderer();
		axAutoPtr<wxGraphicsContext>	gc; 
		gc.ref( render->CreateContext( dc ) );
			
		gc->SetPen( wxPen( wxColor(255,0,0), 2 ) );
			
		const anSelectionList &list = my_app->ctx.selection();
		if( list.size() ) {
			const anSelection &sel = list.last();
			anNode* node =	sel.node;
		
			axSize n = node->numAttr();
			for( axSize i=0; i<n; i++ ) {
				draw( node->attr(i), gc );
			}
		}
	}
	
private:
	axVec2f		viewOffset_;
	axVec2f		viewScale_;

	Anon_CameraController	camCtrl_;
};

#if 0
#pragma mark ========= Anon_GraphEditor ============
#endif

Anon_GraphEditor::Anon_GraphEditor( wxWindow* parent ) : B( parent, wxID_ANY ) {
	sizer_ = new wxVBoxSizer;
	graph_ = new Graph( this, wxID_ANY );
	sizer_->Add( graph_, 1, wxEXPAND );
	
	SetSizer( sizer_ );
}

