#include "panels/all_panels.h"
#include "Anon_MainWindow.h"
#include "Anon_App.h"

void Anon_MainWindow::onCommandEvent( wxCommandEvent& ev ) {
	switch( ev.GetId() ) {
		default: ax_log( "{?} unhandled id={?}", axFUNC_NAME, ev.GetId() ); break;
		case wxID_CANCEL:	this->Destroy();

		case cmd_undo: {
			my_app->ctx.history.undo();
			my_app->evRenderNeeded();
		}break;

		case cmd_redo: {
			my_app->ctx.history.redo();
			my_app->evRenderNeeded();
		}break;

		case cmd_play: {
			if( ev.GetInt() ) {
				stopWatch_.reset();
				timer_->Start( 1000 / 60 );
			}else{
				timer_->Stop();
			}
		}break;

		case cmd_test_load: {
			test_load();
		}break;
/*
		case wxID_OPEN:			_on_command_open(ev);		break;
		case wxID_SAVE:			_on_command_save(ev,false);	break;
		case wxID_SAVEAS:		_on_command_save(ev,true ); break;
		case wxID_EXIT: 		Close();					break;
		//Mesh
			//Mesh > Create
			case cmd_create_cube: 	my_app->ao.run_js( "create_cube(\"cube\")" );	break;
			//Mesh > Display
			case cmd_mesh_display_face_normal:			my_app->ao.render_req.show_face_normal	 = ev.IsChecked();	break;
			case cmd_mesh_display_face_triangle: 		my_app->ao.render_req.show_face_triangle = ev.IsChecked();	break;
			case cmd_mesh_display_face_vertex_normal:	my_app->ao.render_req.show_face_vertex_normal = ev.IsChecked();	break;
			case cmd_mesh_display_component_id:			my_app->ao.render_req.show_component_id  = ev.IsChecked();	break;

		case cmd_split_polygon: my_app->set_current_tool( ToolBase::t_split_polygon_tool );	break;
		//Anon_Panel	
		case cmd_UVEditor:		show_panel(L"UVEditor");			break;
		case cmd_SchemaEditor:	show_panel(L"SchemaEditor");		break;
		case cmd_ScriptEditor:	show_panel(L"ScriptEditor");		break;
		case cmd_GraphEditor:	show_panel(L"GraphEditor ");		break;
		case cmd_ActionHistory: show_panel(L"ActionHistory");		break;
		*/
	}

//    show_SceneTree();
}

void Anon_MainWindow::test_load() {
	axStatus st;

	my_app->scene.newObject();
	anScene* scene = my_app->scene;

	axStopWatch	watch;

//	st = scene->loadFile("../../../../../test/scene/test.AnonScene");	

	st = scene->loadFile("/Users/jason/svn/anon3d/test/scene/test.AnonScene");
	
	if( !st ) {
		ax_log("loadFile failure {?}", st );
		return;
	}else{
		//ax_log("{?}", *scene );
		ax_log("loadFile done time = {?}", watch.get() );
	}

	my_app->evRenderNeeded();
	outliner_->myUpdate();
}


void Anon_MainWindow::onTimerEvent( wxTimerEvent &ev ) {
	double frame_time = stopWatch_.get();
	stopWatch_.resetToLastGet();

	if( my_app->scene ) {
		my_app->scene->advanceTime( frame_time );
	}
	my_app->evRenderNeeded();
}

Anon_MainWindow::Anon_MainWindow( wxWindow* parent, wxWindowID wid, wxPoint position, wxSize size  )
	: wxFrame( parent, wid, L"Anon3D", position, size, wxDEFAULT_FRAME_STYLE )
{
	SetBackgroundColour( my_app->settings.editor.panelColor );

    aui_.SetManagedWindow(this);
	aui_.SetFlags( wxAUI_MGR_DEFAULT );
	aui_.SetArtProvider( new Anon_AuiDockArt );

    // set frame icon
//    SetIcon(wxIcon(sample_xpm));

    // set up default notebook style
    long m_notebook_style = wxAUI_NB_DEFAULT_STYLE | wxAUI_NB_TAB_EXTERNAL_MOVE | wxNO_BORDER;

// create menu
	{	wxMenuBar*	menu_bar = new wxMenuBar;
		SetMenuBar(menu_bar);

		wxMenu*	menu 	 = NULL;
		wxMenu*	sub_menu = NULL;
	//menu file
		menu = new wxMenu;		    menu_bar->Append( menu,	wxGetTranslation( "File" ));
		menu->Append(wxID_NEW,		wxGetTranslation( "New"	    ),				wxGetTranslation( "Help:New") );
		menu->Append(wxID_OPEN,		wxGetTranslation( "Open"	)+"\tCtrl+O",	wxGetTranslation( "Help:Open") );
		menu->Append(wxID_SAVE,		wxGetTranslation( "Save"	)+"\tCtrl+S",	wxGetTranslation( "Help:Save") );
		menu->Append(wxID_SAVEAS,	wxGetTranslation( "Save As"	),				wxGetTranslation( "Help:Save As") );
		menu->AppendSeparator();		
		menu->Append(wxID_EXIT,		wxGetTranslation( "Quit"	    ),			wxGetTranslation( "Help:Quit") );

	//menu Edit
		menu = new wxMenu;		    menu_bar->Append( menu,	wxGetTranslation( "Edit" ));
		menu->Append(cmd_undo,		wxGetTranslation( "Undo"	)+"\tCtrl+Z",		wxGetTranslation( "Help:Undo") );
		menu->Append(cmd_redo,		wxGetTranslation( "Redo"	)+"\tCtrl+Shift+Z",	wxGetTranslation( "Help:Redo") );

	//menu object
		menu = new wxMenu;		    menu_bar->Append( menu,	wxGetTranslation( "Object" ));
		menu->Append( cmd_object_create,	wxGetTranslation( "Create") );

	//menu panel
		menu = new wxMenu;		    menu_bar->Append( menu,	wxGetTranslation( "Panel" ));
		menu->Append( cmd_panel_saveLayout,	wxGetTranslation( "Save Layout") );
		
	//menu help
		menu = new wxMenu;		    menu_bar->Append( menu,	wxGetTranslation( "Help") );
		menu->Append( wxID_ABOUT,	wxGetTranslation( "About..." ) );
	}

	Bind( wxEVT_COMMAND_MENU_SELECTED, &CLASS::onCommandEvent, this );

//Status Bar
	{	wxStatusBar* status_bar = CreateStatusBar();
		//status_bar->SetForegroundColour( my_app->settings.editor.textColor );
		status_bar->SetBackgroundColour( my_app->settings.editor.panelColor );
		//status_bar->SetStatusText( "Ready" );

		// min size for the frame itself isn't completely done.
		// see the end up wxAuiManager::Update() for the test
		// code. For now, just hard code a frame minimum size
		SetMinSize(wxSize(400,300));

		// prepare a few custom overflow elements for the toolbars' overflow buttons

		wxAuiToolBarItemArray prepend_items;
		wxAuiToolBarItemArray append_items;
		wxAuiToolBarItem item;
		item.SetKind(wxITEM_SEPARATOR);
		append_items.Add(item);
		item.SetKind(wxITEM_NORMAL);
	//    item.SetId(ID_CustomizeToolbar);
		item.SetLabel(_("Customize..."));
		append_items.Add(item);
	}

//add some pane
	aui_.SetDockSizeConstraint( 0.5, 0.5 );

	toolbar_ = new Anon_MainToolBar( this );
	aui_.AddPane( toolbar_, wxAuiPaneInfo().Name( L"Tools" ).Caption( wxGetTranslation( L"Tools")		)
								.Top().CaptionVisible(false).DockFixed(true).Floatable(false).Layer(10) );
/*
	graphEditor_ = new Anon_GraphEditor( this );
	aui_.AddPane( graphEditor_, wxAuiPaneInfo().Name( L"GraphEditor" ).Caption( wxGetTranslation( "GraphEditor") )
											.Bottom().BestSize( 400, 200 ) );
*/
	inspector_ = new Anon_Inspector ( this );
	aui_.AddPane( inspector_, wxAuiPaneInfo().Name( "Inspector"	 ).Caption( wxGetTranslation( "Inspector")	)
											.Right().BestSize( 250, 600 ).Layer(10) );

	outliner_ = new Anon_Outliner( this );
	aui_.AddPane( outliner_, wxAuiPaneInfo().Name( "Outliner"	 ).Caption( wxGetTranslation( "Outliner")	)
											.Right().BestSize( 250, 200 ).Layer(10) );

/*
	aui.AddPane( new TimeSlider ( this ), wxAuiPaneInfo().Name( L"TimeSlider"	 ).CaptionVisible( false )
											.Bottom().BestSize( 300, 26 ).DockFixed(true) );
*/

	Anon_AuiNotebook* notebook = new Anon_AuiNotebook(this, wxID_ANY,  wxPoint(0,0), wxSize(0,0), m_notebook_style );
	aui_.AddPane( notebook, wxAuiPaneInfo().Name( "Notebook" ).CenterPane() );

	sceneViewer_ = new Anon_SceneViewer( notebook );
	notebook->AddPage( sceneViewer_ , "SceneViewer", true );

    aui_.Update();
	timer_ = new wxTimer( this );
	Bind( wxEVT_TIMER, &CLASS::onTimerEvent, this );
}

Anon_MainWindow::~Anon_MainWindow() {
	timer_->Stop();
    aui_.UnInit();
}
