//
//  Anon_ViewMouse.h
//  Anon
//
//  Created by Jason Chan on 2011-11-13.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef __Anon_CameraController_h__
#define __Anon_CameraController_h__

#include "Anon_common.h"

class	Anon_CameraController {
public:
	Anon_CameraController();

	bool	checkMouseEvent( wxWindow* win, wxMouseEvent & ev );

	axVec2f		pan;
	axVec2f		thumb;
	float		dolly;
	float		zoom;

private:
	void		_reset();
	axVec2f		lastMousePos_;
};

#endif //__Anon_CameraController_h__
