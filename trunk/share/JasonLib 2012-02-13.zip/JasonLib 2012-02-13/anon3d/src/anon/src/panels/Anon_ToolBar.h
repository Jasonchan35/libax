#ifndef __Anon_ToolBar_h__
#define __Anon_ToolBar_h__

#include "Anon_Panel.h"

class Anon_ToolBar : public wxAuiToolBar {
	typedef wxAuiToolBar B;
public:
    Anon_ToolBar( wxWindow* parent );

	wxAuiToolBarItem * 	AddIcon		(	int tool_id, const wxString & image_filename,
										const wxString & short_help_string = wxEmptyString,
										const wxString & long_help_string  = wxEmptyString,
										wxObject *client_data = NULL );

	wxAuiToolBarItem * 	AddToggleIcon(	int tool_id, const wxString & image_filename,
										const wxString & short_help_string = wxEmptyString,
										const wxString & long_help_string  = wxEmptyString,
										wxObject *client_data = NULL );
};


#endif //__Anon_ToolBar_h__
