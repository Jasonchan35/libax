#ifndef __Anon_common_h__
#define __Anon_common_h__

#include <ax/ax_wxWidgets.h>
#include <ax/ax_App.h>

#define	WXDLL_ANON	//dll import/export


#include <libanon/libanon.h>

#include <wx/defs.h>

#include <wx/sharedptr.h>

#include <wx/wx.h>
#include <wx/menu.h>

#include <wx/wupdlock.h>	//wxWindowUpdateLocker
#include <wx/valnum.h>		//wxNumValidator
#include <wx/numformatter.h>

#include <wx/app.h>
#include <wx/aui/aui.h>
#include <wx/treectrl.h>
#include <wx/gbsizer.h>

#include <wx/glcanvas.h>
#include <wx/toolbar.h>
#include <wx/log.h>

#include <wx/button.h>
#include <wx/tglbtn.h>		//wxToggleButton
#include <wx/sysopt.h>		//System Option
#include <wx/dcbuffer.h>	//wxBufferedPaintDC
#include <wx/scrolwin.h>	//wxScrolledWindow
#include <wx/graphics.h>

//notebook
#include <wx/listbook.h>
#include <wx/treebook.h>
#include <wx/toolbook.h>
#include <wx/choicebk.h>

//prop grid
#include <wx/propgrid/manager.h>
#include <wx/propgrid/advprops.h>

#if !wxUSE_GLCANVAS
    #error "OpenGL required: set wxUSE_GLCANVAS to 1 and rebuild the library"
#endif

#endif //__Anon_common_h__
