#include "Anon_Panel.h"


BEGIN_EVENT_TABLE( Anon_Panel, Anon_Panel::B )

END_EVENT_TABLE()


Anon_Panel :: Anon_Panel( wxWindow* parent, wxWindowID wid ) : B( parent, wid, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) {
}

