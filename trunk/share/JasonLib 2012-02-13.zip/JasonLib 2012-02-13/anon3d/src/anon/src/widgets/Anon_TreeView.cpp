//
//  Anon_TreeView.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-06.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_TreeView.h"

wxDEFINE_EVENT( wxEVT_ANON_TREEVIEW_CELL_BEGIN_CHANGE, 	Anon_TreeViewEvent );
wxDEFINE_EVENT( wxEVT_ANON_TREEVIEW_CELL_CHANGING, 		Anon_TreeViewEvent );
wxDEFINE_EVENT( wxEVT_ANON_TREEVIEW_CELL_CHANGED, 		Anon_TreeViewEvent );


class Anon_TreeView;
class Anon_TreeViewItem;
class Anon_TreeViewItem_Head;
class Anon_TreeViewItem_Label;

class Anon_TreeViewItem_Sizer : public wxHBoxSizer {
	typedef	wxHBoxSizer B;
public:
	virtual void 	RecalcSizes ();
	Anon_TreeView*	tree;		
};

class Anon_TreeViewHeader : public wxPanel {
	typedef	wxPanel	B;
public:
	Anon_TreeViewHeader( wxWindow* parent, const wxString & name, Anon_TreeView* tree ) 
		: B( parent, wxID_ANY )
	{
		this->SetWindowVariant( tree->GetWindowVariant() );
		this->SetBackgroundColour( tree->GetColorScheme().GridLineColor );

		tree_  = tree;
		sizer_ = new wxHBoxSizer;
		text_  = new wxStaticText( this, wxID_ANY, name );
		text_->SetForegroundColour( tree->GetColorScheme().HeaderTextColor );
		text_->SetBackgroundColour( tree->GetColorScheme().HeaderBGColor );
		text_->SetFont( tree->GetFont() );

		sizer_->Add( text_, 1, wxEXPAND );
		SetSizer( sizer_ );
	}

private:
	wxBoxSizer*		sizer_;
	wxStaticText*	text_;
	Anon_TreeView*	tree_;
};


class Anon_TreeViewItem : public wxWindow {
public:
	enum {
		s_null,
		s_collaspe,
		s_expand,
	};

	Anon_TreeViewItem	( wxWindow* parent, Anon_TreeView* tree );
	
				void	AppendColumn();
				void	createLabel	( Anon_TreeView* tree, const wxString & label );
				
				void	Expand		();
				void	Collaspe	();
				void	AddIcon		( const wxBitmap & icon );
	
				size_t	GetChildCount() { return childSizer->GetItemCount(); }

	Anon_TreeViewItem* 	GetChild	( size_t index ) {
							if( index >= GetChildCount() ) return NULL;
							wxSizerItem* s = childSizer->GetItem( index );
							if( !s ) return NULL;
							return (Anon_TreeViewItem*) s->GetWindow();							
						}
	
	void	SetClientData ( wxClientData* data ) {
		if( clientData ) delete clientData; 
		clientData = data;
	}
	
	wxClientData* GetClientData() { return clientData; }

	
	int								state;
	int								level;
	Anon_TreeViewItem_Label*		labelCtrl;
	
	wxBoxSizer*					sizer;
	Anon_TreeViewItem_Sizer*	cellSizer;	
	wxBoxSizer*					childSizer;
	
	Anon_TreeView*				tree;
	wxClientData*				clientData;
};

class Anon_TreeViewBody : public wxScrolledWindow {
public:
	Anon_TreeViewBody( Anon_TreeView* tree ) 
		: wxScrolledWindow( tree, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE | wxRETAINED ) 
	{
//		this->SetDoubleBuffered( true );
		this->SetBackgroundColour( tree->GetColorScheme().GridBGColor );

		sizer = new wxVBoxSizer;

		header_ = new wxWindow( this, wxID_ANY );
		sizer->Insert( 0, header_, 0, wxEXPAND );
		header_->SetBackgroundColour( tree->GetColorScheme().GridLineColor );
		header_->SetMaxSize( wxSize(-1, 1) );

		headerSizer_ = new wxHBoxSizer;
		header_->SetSizer( headerSizer_ );	

		root = new Anon_TreeViewItem( this, tree );
		sizer->Add( root, 0, wxEXPAND );

		SetScrollRate(0, 1);
		SetSizer( sizer );
	}
	
	wxWindow*			header_;	
	wxBoxSizer*			headerSizer_;

	Anon_TreeViewItem*	root;
	wxBoxSizer*			sizer;
};

class Anon_TreeViewItem_Expander : public wxControl {
	DECLARE_EVENT_TABLE();
	typedef wxStaticBitmap B;
public:
	Anon_TreeViewItem_Expander ( wxWindow* parent, Anon_TreeViewItem* item ) 
		: wxControl( parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) 
	{
		item_ = item;
		int d = item->tree->GetFont().GetPixelSize().y;
		SetMinSize( wxSize(d,d) );
	}
	
	void	onMouseEvent ( wxMouseEvent  & ev ) {
		if( ev.LeftDown() || ev.LeftDClick() ) {
			switch( item_->state ) {
				case Anon_TreeViewItem::s_collaspe:	item_->Expand	();	break;
				case Anon_TreeViewItem::s_expand:	item_->Collaspe	();	break;
			}
		}
	}
	
	void onPaintEvent( wxPaintEvent& ev ) {
	    wxPaintDC dc(this);
		if( ! item_ ) return;

		wxGraphicsRenderer* render = wxGraphicsRenderer::GetDefaultRenderer();
		wxGraphicsContext*	gdc = render->CreateContext( dc );

		wxRect rc = GetClientRect();
//		dc.SetPen  ( wxColor(0,0,0) );
//		dc.SetBrush( wxColor(0,255,0) );
//		dc.DrawRectangle( rc );
		
		int m = 2;
		int d = 2;
	
		rc.Deflate( m, m );
		rc.Offset( 0, m );

		//center
		wxSize c  = wxSize( rc.width / 2 + rc.x, rc.height / 2 + rc.y );

		wxPoint pos  = rc.GetPosition();
		wxSize  size = rc.GetSize();

		switch( item_->state ) {
			case Anon_TreeViewItem::s_expand: {				
				gdc->SetPen  ( wxColor(0,0,0) );
				gdc->SetBrush( wxColor(255,255,255) );	
				gdc->DrawRectangle( pos.x, pos.y, size.x, size.y );
				gdc->StrokeLine( rc.GetLeft() +d, c.y, rc.GetRight() -d +1, c.y );
			}break;
			
			case Anon_TreeViewItem::s_collaspe: {
				gdc->SetPen  ( wxColor(0,0,0) );
				gdc->SetBrush( wxColor(255,255,255) );
				gdc->DrawRectangle( pos.x, pos.y, size.x, size.y );
				gdc->StrokeLine( rc.GetLeft() +d, c.y, rc.GetRight() -d +1, c.y );
				gdc->StrokeLine( c.x, rc.GetTop() +d, c.x, rc.GetBottom() -d +1);
			}break;
		}		

		delete gdc;
	}
	
private:
	Anon_TreeViewItem*	item_;
};

BEGIN_EVENT_TABLE( Anon_TreeViewItem_Expander, Anon_TreeViewItem_Expander::B )
	EVT_MOUSE_EVENTS( Anon_TreeViewItem_Expander::onMouseEvent )
	EVT_PAINT		( Anon_TreeViewItem_Expander::onPaintEvent )
END_EVENT_TABLE()

class Anon_TreeViewItem_Icon : public wxControl {
	DECLARE_EVENT_TABLE();
	typedef	wxControl B;
public:

	Anon_TreeViewItem_Icon ( wxWindow* parent, Anon_TreeViewItem* item, const wxBitmap &bitmap ) 
		: wxControl( parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) 
	{
		item_ = item;
		if( bitmap.IsOk() ) {
			SetMinSize( bitmap.GetSize() );
		}
	}
	
	void	onMouseEvent ( wxMouseEvent  & ev ) {
		if( ev.LeftDown() || ev.LeftDClick() ) {
		}
	}
	
	void onPaintEvent( wxPaintEvent& ev ) {
	    wxPaintDC dc(this);
		if( ! item_ ) return;
		if( bmp_.IsOk() ) {
			dc.DrawBitmap( bmp_, 0, 0, true );
		}
	}

	wxBitmap			bmp_;
	Anon_TreeViewItem*	item_;
};

BEGIN_EVENT_TABLE( Anon_TreeViewItem_Icon, Anon_TreeViewItem_Icon::B )
	EVT_MOUSE_EVENTS( Anon_TreeViewItem_Icon::onMouseEvent )
	EVT_PAINT		( Anon_TreeViewItem_Icon::onPaintEvent )
END_EVENT_TABLE()

class Anon_TreeViewItem_Label : public wxControl {
public:
	Anon_TreeViewItem_Label( wxWindow* parent, Anon_TreeViewItem* item, const wxString &label ) 
		: wxControl( parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) 
	{
		SetBackgroundColour( item->tree->GetColorScheme().LabelBGColor );
		item_  = item;
		sizer_ = new wxHBoxSizer;
		text_ = new wxStaticText( this, wxID_ANY, label );

		text_->SetFont( item->tree->GetFont() );
		text_->SetWindowVariant( item->tree->GetWindowVariant() );
		text_->SetForegroundColour( item->tree->GetColorScheme().LabelTextColor );
		text_->SetBackgroundColour( item->tree->GetColorScheme().LabelBGColor );

		int d = item->tree->GetFont().GetPixelSize().x;
		int indent = 0;
		if( item->level >= 1 ) {
			indent = (item->level-1) * d * 2; // 2 char width
		}

		expander_ = new Anon_TreeViewItem_Expander ( this, item );
		expander_->SetBackgroundColour( item->tree->GetColorScheme().LabelBGColor );

		icon_	  = new Anon_TreeViewItem_Icon ( this, item_, wxBitmap() );			
		icon_->SetBackgroundColour( item->tree->GetColorScheme().LabelBGColor );

		sizer_->AddSpacer( item->tree->TextMargins().x );
		sizer_->Add( expander_, 0, wxBOTTOM | wxALIGN_CENTER, item->tree->GridLineWidth() );
		sizer_->AddStretchSpacer(1);
		sizer_->Add( icon_, 0 );
		sizer_->Add( text_, 0, wxEXPAND );
		sizer_->AddSpacer( item->tree->TextMargins().x );

		SetSizer( sizer_ );
	}

	void	AddIcon( const wxBitmap & icon ) {
		icon_->bmp_ = icon;
		if( icon.IsOk() ) {
			icon_->SetMinClientSize( icon.GetSize() );
		}else{
			icon_->SetMinClientSize( wxSize(0,0) );
		}
		icon_->Refresh();
	}
	
	wxBoxSizer*					sizer_;
	Anon_TreeViewItem_Expander*	expander_;
	Anon_TreeViewItem_Icon*		icon_;
	wxStaticText*				text_;
	Anon_TreeViewItem*			item_;
};

#if 0
#pragma mark ========= Implementation ============
#endif

void Anon_TreeView::SetLabelTextColor	( const wxColor & color ) { colorScheme_.LabelTextColor = color; }
void Anon_TreeView::SetLabelBGColor		( const wxColor & color ) { colorScheme_.LabelBGColor   = color; }

void Anon_TreeView::SetHeaderTextColor	( const wxColor & color ) { colorScheme_.HeaderTextColor = color; }
void Anon_TreeView::SetHeaderBGColor	( const wxColor & color ) { colorScheme_.HeaderBGColor   = color; }

void Anon_TreeView::SetCellBGColor		( const wxColor & color ) { colorScheme_.CellBGColor   = color; }
void Anon_TreeView::SetGridLineColor	( const wxColor & color ) { colorScheme_.GridLineColor = color; }

void Anon_TreeView::SetGridBGColor		( const wxColor & color ) { 
	colorScheme_.GridBGColor   = color;
	this->SetBackgroundColour( color );
	body_->SetBackgroundColour( color );
	Refresh();
}

void Anon_TreeViewEvent::Set( wxObject *obj, Anon_TreeViewItem* item ) {
	SetEventObject( obj );
	item_  = item;
}

Anon_TreeViewCell::Anon_TreeViewCell( Anon_TreeViewItem* item ) 
: B( item, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) 
{
	sizer = new wxHBoxSizer;
	SetBackgroundColour( item->tree->GetColorScheme().CellBGColor );
	SetSizer( sizer );
}

Anon_TreeViewItem::Anon_TreeViewItem( wxWindow* parent, Anon_TreeView* tree ) 
	: wxWindow( parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ) 
{
	SetBackgroundColour( tree->GetColorScheme().GridLineColor );

	clientData = NULL;
	level	= 0;
	this->tree	= tree;
	state	= s_null;
	sizer	= new wxVBoxSizer;

	cellSizer = new Anon_TreeViewItem_Sizer;
	sizer->Add( cellSizer, 0, wxEXPAND );
	cellSizer->tree = tree;

	childSizer = new wxVBoxSizer;
	sizer->Add( childSizer, 0, wxEXPAND );

	SetSizer( sizer );
}

void Anon_TreeViewItem::createLabel( Anon_TreeView* tree, const wxString & label ) {
	state = s_null;

	labelCtrl = new Anon_TreeViewItem_Label( this, this, label );	
	labelCtrl->SetFont( tree->GetFont() );
	labelCtrl->SetWindowVariant( tree->GetWindowVariant() );
		
	cellSizer->Add( labelCtrl, 1, wxEXPAND );
}

void Anon_TreeViewItem::AppendColumn() {
	Anon_TreeViewCell * cell = new Anon_TreeViewCell( this );
	cellSizer->Add( cell, 0, wxEXPAND | wxBOTTOM, tree->GridLineWidth() );
}

void	Anon_TreeViewItem::Expand	() {
	state = Anon_TreeViewItem::s_expand;

	size_t n = childSizer->GetItemCount();
	for( size_t i=0; i<n; i++ ) {
		childSizer->Show(i);
	}
	tree->Layout();
}

void	Anon_TreeViewItem::Collaspe	() {
	state = Anon_TreeViewItem::s_collaspe;
	size_t n = childSizer->GetItemCount();
	for( size_t i=0; i<n; i++ ) {
		childSizer->Hide(i);
	}
	tree->Layout();
}

void	Anon_TreeViewItem::AddIcon ( const wxBitmap & icon ) {
	labelCtrl->AddIcon( icon );
}

Anon_TreeView::ColorScheme::ColorScheme() {
	GridLineColor.Set( 0,0,0 );
	GridBGColor		= wxColor( 255,255,255 );
	CellBGColor		= wxColor( 255,255,255 );
	
	LabelTextColor	= wxSystemSettings::GetColour( wxSYS_COLOUR_BTNTEXT );
	LabelBGColor	= wxSystemSettings::GetColour( wxSYS_COLOUR_BTNFACE );

	HeaderTextColor	= wxSystemSettings::GetColour( wxSYS_COLOUR_BTNTEXT );
	HeaderBGColor	= wxSystemSettings::GetColour( wxSYS_COLOUR_BTNFACE );
}

Anon_TreeView::Anon_TreeView (wxWindow* parent, wxWindowID id, const wxPoint & pos, const wxSize & size, long style ) 
	: B (parent, id, pos, size, style ) 
{
	gridLineWidth_ = 1;
	textMargins_ = wxPoint( 4, -1 );
	
	sizer_ = new wxVBoxSizer;

//-- body	
	body_   = new Anon_TreeViewBody( this );
	sizer_->Add( body_, 1, wxEXPAND );

	SetSizer(sizer_);
}

size_t Anon_TreeView::GetColumnCount() const {
	return body_->headerSizer_->GetItemCount();
}

const Anon_TreeView::ColorScheme & Anon_TreeView::GetColorScheme() {
	return colorScheme_;
}

void	Anon_TreeView::SetItemClientData ( Anon_TreeViewItem* item, wxClientData* data ) {
	if( ! item ) return;
	item->SetClientData( data );
}

wxClientData*	Anon_TreeView::GetItemClientData ( Anon_TreeViewItem* item ) {
	if( ! item ) return NULL;
	return item->GetClientData();
}

void	Anon_TreeView::AppendColumn ( const wxString & label, int proportion ) {
	Anon_TreeViewHeader* p = new Anon_TreeViewHeader ( body_->header_, label, this );
	int flag = wxEXPAND | wxBOTTOM;
	if( GetColumnCount() ) flag |= wxLEFT;
	body_->headerSizer_->Add( p, proportion, flag, GridLineWidth() );
	body_->root->AppendColumn();
}

Anon_TreeViewItem*	Anon_TreeView::GetRootItem	() {
	return body_->root;
}

size_t	Anon_TreeView::GetItemChildCount ( Anon_TreeViewItem* item ) {
	if( ! item ) return 0;
	return item->GetChildCount();
}

Anon_TreeViewItem*	Anon_TreeView::GetItemChild	( Anon_TreeViewItem* item, size_t index ) {
	if( ! item ) return NULL;
	return item->GetChild( index );
}

Anon_TreeViewItem*	Anon_TreeView::AppendItem	 ( Anon_TreeViewItem* parent, const wxString & label ) {
	if( parent ) {
		parent->state = Anon_TreeViewItem::s_expand;
	}else{
		parent = body_->root;
	}

	Anon_TreeViewItem* item = new Anon_TreeViewItem( parent, this );
	parent->childSizer->Add( item, 0, wxEXPAND );

	item->level = parent->level + 1;
	item->createLabel( this, label );
	
	size_t n = GetColumnCount();
	for( size_t i=0; i<n; i++ ) {
		item->AppendColumn();
	}	
	return item;
}

void Anon_TreeView::AddItemIcon ( Anon_TreeViewItem* item, const wxBitmap & icon ) {
	if( !item ) return;
	item->AddIcon( icon );
}

void	Anon_TreeView::Clear() {
	body_->root->DestroyChildren();
}

Anon_TreeViewCell*	Anon_TreeView::GetCell ( Anon_TreeViewItem* item, unsigned col ) {
	if( !item ) return NULL;
	col += 1; // cell 0 is sizerItem[1] (0:label)

	unsigned cellCount = item->cellSizer->GetItemCount();
	if( col >= cellCount ) return NULL;

	wxSizerItem* sizerItem = item->cellSizer->GetItem( col );	if( !sizerItem ) return NULL;
	return (Anon_TreeViewCell*) sizerItem->GetWindow();
}

wxWindow*	Anon_TreeView::GetCellWindow ( Anon_TreeViewItem* item, unsigned col, size_t index ) {
	Anon_TreeViewCell* cell = GetCell( item, col );
	if( !cell ) return NULL;
	if( index >= cell->sizer->GetItemCount() ) return NULL;
	wxSizerItem* s = cell->sizer->GetItem(index);
	if( !s ) return NULL;
	return s->GetWindow();
}

Anon_TreeViewEvent::Anon_TreeViewEvent	( wxEventType commandType, int id ) : wxCommandEvent( commandType, id ) {
	_ctor();
}

Anon_TreeViewEvent::Anon_TreeViewEvent	( const Anon_TreeViewEvent& event ) : wxCommandEvent( event ) {
	_ctor();
}

void Anon_TreeViewEvent::_ctor() {
	item_ = NULL;
}

wxEvent* Anon_TreeViewEvent::Clone() const {
	return new Anon_TreeViewEvent(*this);
}

void 	Anon_TreeViewItem_Sizer::RecalcSizes () {
	B::RecalcSizes();

	const wxWindowList & header = tree->body()->header_->GetChildren();
	size_t n = GetItemCount();
	if( header.GetCount() < n ) n = header.GetCount();;
	
	//set each cell width as same as header
	wxWindowList::compatibility_iterator it = header.GetFirst();		
	for( size_t i=0; i<n; i++, it = it->GetNext() ) {
		wxWindow* hdr  = it->GetData();
		wxWindow* cell = GetItem(i)->GetWindow();
		if( ! cell ) continue;
		
		wxPoint pos = cell->GetPosition();
		pos.x = hdr->GetPosition().x;
		cell->SetPosition( pos );

		wxSize size = cell->GetSize();
		size.x = hdr->GetSize().x;
		cell->SetSize( size );
	}
}

