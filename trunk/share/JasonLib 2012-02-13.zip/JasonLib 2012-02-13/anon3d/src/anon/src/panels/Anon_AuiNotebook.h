#ifndef __Anon_AuiNotebook_h__
#define __Anon_AuiNotebook_h__

#include "../Anon_common.h"
#include "../Anon_MainWindow.h"
#include "../Anon_App.h"
#include "../Anon_Settings.h"


class Anon_AuiNotebook : public wxAuiNotebook {
	typedef	wxAuiNotebook B;
public:
	Anon_AuiNotebook( wxWindow* parent, wxWindowID id, const wxPoint & pos, const wxSize & size, long style );
};

#endif //__Anon_AuiNotebook_h__
