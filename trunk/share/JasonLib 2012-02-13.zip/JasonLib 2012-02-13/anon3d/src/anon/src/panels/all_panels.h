#ifndef __Anon_panel_all_h__
#define __Anon_panel_all_h__

#include "Anon_Panel.h"

#include "Anon_SceneViewer.h"
#include "Anon_Inspector.h"
#include "Anon_Outliner.h"
#include "Anon_MainToolBar.h"
#include "Anon_AuiNotebook.h"
#include "Anon_GraphEditor.h"


#endif //__Anon_pane_all_h__
