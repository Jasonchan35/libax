#ifndef Anon_Inspector_h
#define Anon_Inspector_h

#include "Anon_Panel.h"
#include "../widgets/Anon_TreeView.h"
#include "../widgets/Anon_NumberCtrl.h"

class Anon_Inspector_Grid;

class Anon_Inspector : public Anon_Panel {
	typedef		Anon_Inspector	CLASS;
	typedef		Anon_Panel		B;
public:
	Anon_Inspector( wxWindow* parent );


	void	onCommandEvent		( wxCommandEvent &ev );

	Anon_TreeViewItem*	findItem( anAttr & attr );

	void	reloadColorScheme	();

private:
	void	onSelectionDidChange();
	void	onNodeAttrDidChange	( anAttr & attr );
	void	onNodeNameDidChange	( anNode & node );

	axEventFunc<CLASS,void>		hookSelectionDidChange;
	axEventFunc<CLASS,anAttr>	hookNodeAttrDidChange;
	axEventFunc<CLASS,anNode>	hookNodeNameDidChange;

	void	rebuildTree					( anNode* node );
	void	onAttr_NumberCtrl_BeginChange	( Anon_NumberCtrlEvent  & ev );
	void	onAttr_NumberCtrl_Changing		( Anon_NumberCtrlEvent  & ev );
	void	onAttr_NumberCtrl_Changed		( Anon_NumberCtrlEvent  & ev );
	void	onAttr_CheckBox					( wxCommandEvent		& ev );

	axStatus	addAttr			( Anon_TreeViewItem* parent, anAttr attr );
	axStatus	attrValueToUI	( anAttr & attr );

	Anon_TreeViewItem*	_findItem( Anon_TreeViewItem* item, const anAttrId & attrId, axSize level );

	anNode*	node_;

	wxBitmap	icon_input;
	wxBitmap	icon_output;
	wxBitmap	icon_input_output;

	bool		attr_changing_by_myself_;

	Anon_TreeView*	tree_;
};

#endif
