#include "Anon_App.h"
#include "Anon_MainWindow.h"

IMPLEMENT_APP( Anon_App )

Anon_App* my_app = NULL;


#ifdef axOS_WIN

int main( int argc, char *argv[] ) {
	return ::WinMain( (HINSTANCE)GetModuleHandle(NULL), (HINSTANCE)NULL, GetCommandLineA(), SW_SHOW );
}

#endif


Anon_App::Anon_App() {
	my_app = this;
	mainWindow = NULL;
	wxInitAllImageHandlers();
}

bool Anon_App::OnInit() {

	defaultFont.SetFamily( wxFONTFAMILY_MODERN );
#if axOS_MacOSX
	defaultFont.SetPointSize( 13 );
#elif axOS_WIN
	defaultFont.SetPointSize( 11 );
#endif


/*
	UIntSet		test;

	test.add( 10, 20 );
	test.add( 7, 8 );
	test.add( 40, 50 );
	test.sub( 44, 46 );

	awe_print( L"test {?}\n" ) % test;
*/

/*
	Status	st;
	my_app = this;

	StringW	tmp;
	get_user_home_dir( tmp );
	awe_print( L"home_dir {?}\n" ) % tmp;

	change_dir_to_process();
#ifdef _WIN32
	change_dir( L"../../" );
#else
	change_dir( L"../../../" );
#endif

	StringA	path;
	get_current_dir( path );
	log_info( L"cwd {?}" ) % path; 


	wxLocale::AddCatalogLookupPathPrefix( L"resource/lang" );
	_locale.Init( wxLANGUAGE_CHINESE_TRADITIONAL );
	_locale.AddCatalog( L"Anon" );
	log_info( L"lang={?}") % _locale.GetCanonicalName();


	select_cursor = wxCursor( L"resource/cursor/pick.cur", wxBITMAP_TYPE_CUR );
	
	st = ao.create();		if( !st ) { assert( false ); return false; }
	ao.history.set_undo_limit( 200 );
		
	tool_reg.set_block_size(0);
	
	st = register_tool<SelectTool>( L"Select Tool" );				if( !st ) return st;
	st = register_tool<MoveTool>( L"Move Tool");					if( !st ) return st;
	st = register_tool<SplitPolygonTool>( L"Split Polygon Tool" );	if( !st ) return st;
	
//	log_debug( L"{?}" ) % ao.root_scene;


	ao.run_js_file( L"script/startup.js" );
	*/
//	wxSize size = wxGetDisplaySize();
	wxSize size( 1400, 800 );

    mainWindow = new Anon_MainWindow( NULL, wxID_ANY, wxDefaultPosition, size );
    SetTopWindow( mainWindow );

    mainWindow->Show();
//	mainWindow->view3d->view3d_ogl->SetFocus();
	
//	set_current_tool( ToolBase::t_move_tool );
//	set_current_tool( ToolBase::t_split_polygon_tool );

	axStatus st;
	st = ctx.create();	if( !st ) return false;
//	anNodeSpecRegistry::getInstance()->print();

	ctx.history.setLimit( 100 );

	scene.newObject();

	ax_log("sizeof(anAttrConnection) = {?}", sizeof( anAttrConnection) );
	ax_log("sizeof(anMesh3f) = {?}", sizeof( anMesh3f ) );
	ax_log("sizeof(anAttrInst_int) = {?}", sizeof( anAttrInst_int ) );

	mainWindow->test_load();

    return true;
}

//virtual 
int	Anon_App::OnExit() {
	return 0;
}

wxBitmap	Anon_App::resourceImage(  const char* filename ) {
	axStatus st;
	
	axTempStringA	app_data;
	st = axApp::getAppResourceDir( app_data );		if( !st ) return wxBitmap();

	wxString fullpath = wxString::Format("%s/%s", app_data.c_str(), filename );
	//ax_log("{?}, size = {?}", fullpath, p->GetSize() );
	
	wxBitmap bmp = wxBitmap( fullpath, wxBITMAP_TYPE_ANY );
	if( ! bmp.IsOk() ) return wxBitmap();

	return bmp;
}
