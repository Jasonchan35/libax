//
//  Anon_Slider.h
//  Anon
//
//  Created by Jason Chan on 2011-11-07.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_Anon_Slider_h
#define Anon_Anon_Slider_h

#include "../Anon_common.h"

class Anon_SliderEvent : public wxCommandEvent {
public:
    Anon_SliderEvent	( wxEventType commandType, int id );
    Anon_SliderEvent	( const Anon_SliderEvent & event );
 	
    virtual wxEvent* 	Clone	() const;
			void		Set( wxObject *obj );
private:
	void	_ctor();
};

typedef void (wxEvtHandler::*Anon_SliderEventFunction)(Anon_SliderEvent&);

wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_SLIDER_BEGIN_CHANGE,	Anon_SliderEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_SLIDER_CHANGING,		Anon_SliderEvent );
wxDECLARE_EXPORTED_EVENT( WXDLL_ANON, wxEVT_ANON_SLIDER_CHANGED,		Anon_SliderEvent );

class Anon_Slider : public wxControl {
	typedef	Anon_Slider	CLASS;
	typedef	wxControl 	B;
public:
	Anon_Slider( wxWindow* parent, wxWindowID id, double value, double minValue, double maxValue, 
					const wxPoint &pos=wxDefaultPosition, const wxSize &size=wxDefaultSize, long style=0 );
	
	void	SetValue		( double value, bool sendEvent = true );
	double	GetValue		();

	void	SetColor		( const wxColor & color, const wxColor & bgColor );
		
	void	SetMinValue		( double minValue );
	void	SetMaxValue		( double maxValue );

private:
	void	onMouseEvent	( wxMouseEvent & ev );
	void	onPaintEvent	( wxPaintEvent & ev );
	
	void	Command_BeginChange	();
	void	Command_Changing	();
	void	Command_Changed		();
	
	double	value_;

	double	startValue_;
	double	virtualSlider_;
	wxPoint	lastMousePos_;

	double	minValue_;
	double	maxValue_;

	wxPen	pen_;
	wxBrush	fgBrush_;
	wxBrush bgBrush_;
	wxColor	color_;
	wxColor	bgColor_;
};


#endif
