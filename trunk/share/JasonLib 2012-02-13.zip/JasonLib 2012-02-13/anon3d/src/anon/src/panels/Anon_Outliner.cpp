#include "Anon_Outliner.h"

class Anon_Outliner_ItemData : public wxTreeItemData {
	typedef	Anon_Outliner_ItemData CLASS;
public:
	Anon_Outliner_ItemData( wxTreeCtrl* tree, anNode *node ) {
		this->tree = tree;
		this->node = node;
		if( node ) {
			hookNodeDeleted.hook		( node->evNodeDeleted,			this, &CLASS::onNodeDeleted );
			hookNodeNameDidChange.hook	( node->evNodeNameDidChange,	this, &CLASS::onNodeNameDidChange );
		}
	}

	void	onNodeDeleted( anNode & node ) {
		hookNodeDeleted.unhook();
		tree->Delete( GetId() );
	}

	void	onNodeNameDidChange( anNode & node ) {
		tree->SetItemText( GetId(), node.name() );
	}

	wxTreeCtrl*		tree;
	anNode*			node;
	axEventFunc<CLASS,anNode>	hookNodeDeleted;
	axEventFunc<CLASS,anNode>	hookNodeNameDidChange;
};

Anon_Outliner_ItemData*	Anon_Outliner::itemData_		(const wxTreeItemId& item) {
	return (Anon_Outliner_ItemData*) tree_->GetItemData( item );
}

Anon_Outliner::Anon_Outliner( wxWindow* parent ) : B( parent, wxID_ANY ) {
	wxBoxSizer *sizer = new wxBoxSizer( wxVERTICAL );

	toolbar_ = new Anon_ToolBar( this );
	sizer->Add( toolbar_, 0, wxEXPAND );

	toolbar_->AddLabel( wxID_ANY, "Btn1" );
	toolbar_->Realize();

	tree_ = new wxTreeCtrl( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, 
							wxTR_HAS_BUTTONS | wxTR_MULTIPLE | wxTR_LINES_AT_ROOT  | wxTR_TWIST_BUTTONS
							| wxTR_NO_LINES | wxWANTS_CHARS );

	tree_->SetFont( my_app->settings.editor.defaultFont );
	tree_->SetBackgroundColour( my_app->settings.editor.fieldColor );
	tree_->SetForegroundColour( my_app->settings.editor.textColor );
	
	tree_->Bind( wxEVT_COMMAND_TREE_SEL_CHANGED,		&CLASS::onTreeSelectChanged,	this );
	tree_->Bind( wxEVT_COMMAND_TREE_KEY_DOWN,			&CLASS::onTreeKeyDown,			this );
	tree_->Bind( wxEVT_COMMAND_TREE_ITEM_RIGHT_CLICK,	&CLASS::onTreeItemRightClick,	this );

	sizer->Add( tree_, 1, wxEXPAND );
	SetSizer( sizer );
}

void	Anon_Outliner::onCommandEvent ( wxCommandEvent &ev ) {
	/*
	switch( ev.GetId() ) {
		case cmd_wireframe:		{ view3d_ogl->b_wireframe = ( ev.GetInt() != 0 );	}break;
		case cmd_show_grid:		{ view3d_ogl->b_show_grid = ( ev.GetInt() != 0 );	}break;
	}
	*/
}

void	Anon_Outliner::onTreeSelectChanged	( wxTreeEvent &ev ) {
	axStatus st;

	wxArrayTreeItemIds sel;
	tree_->GetSelections( sel );

	anSelectionList		list;

	for( size_t i=0; i<sel.Count(); i++ ) {
		ItemData* data = itemData_( sel[i] );
		list.append( data->node );	
	}

	my_app->ctx.setSelection( list );
}

void Anon_Outliner::onTreeKeyDown( wxTreeEvent	&ev ) {
	int key = ev.GetKeyCode();
	switch( key ) {
		case WXK_DELETE: {
			doDeleteSelectedNode();
		}break;
	}
	ev.Skip();
}

void Anon_Outliner::doDeleteSelectedNode() {
	wxArrayTreeItemIds	list;
	tree_->GetSelections( list );

	size_t n = list.GetCount();
	size_t i;
	for( i=0; i<n; i++ ) {
		wxTreeItemId item = list[i];
		ItemData	*data = itemData_( item );
		if( !data ) continue;
		anNode* node = data->node;
		if( ! node ) continue;
		if( node->isSystemNode() ) continue;
		delete node;
	}
	my_app->evRenderNeeded();
}

void	Anon_Outliner::onTreeItemRightClick	( wxTreeEvent &ev ) {
}

void Anon_Outliner::myUpdate	() {
	tree_->DeleteAllItems();

	anNode* node = my_app->scene->sceneRoot();
	Anon_Outliner_ItemData* data = new Anon_Outliner_ItemData( tree_, node );

	wxTreeItemId root = tree_->AddRoot( node->name(), -1, -1, data );
	addNodeChildren( root, node );
	tree_->Expand( root );
}

axStatus Anon_Outliner::addNode( wxTreeItemId parent, anNode *node ) {
	axTempStringA	tmp;
	tmp.format( "{?}", node->name() );

	Anon_Outliner_ItemData* data = new Anon_Outliner_ItemData( tree_, node );
	
	wxTreeItemId item = tree_->AppendItem( parent, tmp.c_str(), -1, -1, data );
	return addNodeChildren( item, node );
}

axStatus Anon_Outliner::addNodeChildren ( wxTreeItemId parent, anNode *node ) {
	axStatus st;
	anNode* c = node->firstChild();
	for( ; c; c=c->next() ) {
		st = addNode( parent, c );		if( !st ) return st;
	}
	return 0;
}
