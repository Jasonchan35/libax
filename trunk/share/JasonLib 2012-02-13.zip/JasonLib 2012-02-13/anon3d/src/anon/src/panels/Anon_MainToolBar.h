#ifndef __Anon_MainToolBar_h__
#define __Anon_MainToolBar_h__

#include "Anon_ToolBar.h"

class Anon_MainToolBar : public Anon_ToolBar {
	typedef Anon_ToolBar B;
public:
    Anon_MainToolBar( wxWindow* parent );

};


#endif //__Anon_MainToolBar_h__
