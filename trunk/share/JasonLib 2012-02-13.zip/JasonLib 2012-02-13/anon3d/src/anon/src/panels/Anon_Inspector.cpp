#include "Anon_Inspector.h"
#include "../widgets/Anon_NumberCtrl.h"

class Anon_Inspector_ItemData : public wxClientData {
public:
	Anon_Inspector_ItemData( const anAttr & a ) { attr = a; }
	anAttr	attr;
};

Anon_Inspector::Anon_Inspector( wxWindow* parent ) : B( parent, wxID_ANY ) {
	attr_changing_by_myself_ = false;
	node_ = NULL;

	icon_input  = my_app->resourceImage( "inspector/icon_input.png" );
	icon_output = my_app->resourceImage( "inspector/icon_output.png" );
	icon_input_output = my_app->resourceImage( "inspector/icon_input_output.png" );

	wxBoxSizer *sizer = new wxBoxSizer( wxVERTICAL );
	SetSizer( sizer );

	tree_ = new Anon_TreeView( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_SIMPLE );
	sizer->Add( tree_, 1, wxEXPAND );
	reloadColorScheme();

	tree_->SetFont( my_app->settings.editor.defaultFont );	

	tree_->AppendColumn( "Name",  4 );
	tree_->AppendColumn( "Value", 6 );
	tree_->AppendColumn( "...",   1 );

	hookSelectionDidChange.hook( my_app->ctx.evSelectionDidChange, this, &CLASS::onSelectionDidChange );
	SetSizer( sizer );
}

void	Anon_Inspector::reloadColorScheme() {
	Anon_Settings::Editor &e = my_app->settings.editor;

	SetBackgroundColour( e.fieldColor );

	tree_->SetLabelTextColor( e.textColor );
	tree_->SetLabelBGColor	( e.panelColor );
	tree_->SetCellBGColor	( e.panelColor );

	tree_->SetGridBGColor	( e.fieldColor );

	tree_->SetHeaderTextColor( e.textColor  );
	tree_->SetHeaderBGColor	( e.buttonColor );

}

void	Anon_Inspector::onNodeAttrDidChange ( anAttr & attr ) {
	attrValueToUI(attr);
}

void	Anon_Inspector::onNodeNameDidChange ( anNode & node ) {
//	nameProp_->SetValue( node.name() );
}

void	Anon_Inspector::onSelectionDidChange() {
	const anSelectionList & list = my_app->ctx.selection();
	anNode* node = list.size() ? list[0].node : NULL;
	if( node == node_ ) return;
	rebuildTree( node );
}

void	Anon_Inspector::rebuildTree ( anNode* node ) {
	axStatus st;
	wxWindow* body = (wxWindow*) tree_->body();
	wxWindowUpdateLocker	noUpdate( body );
	

	tree_->Clear();

	node_ = node;
	if( ! node ) {
		hookNodeAttrDidChange.unhook();
		hookNodeNameDidChange.unhook();
	}else{
		hookNodeAttrDidChange.hook( node_->evNodeAttrDidChange, this, &CLASS::onNodeAttrDidChange );
		hookNodeNameDidChange.hook( node_->evNodeNameDidChange, this, &CLASS::onNodeNameDidChange );

		axSize numAttr = node_->numAttr();
		for( axSize i=0; i<numAttr; i++ ) {
			anAttr attr = node_->attr(i);
			addAttr( NULL, attr );
		}
	}
	
	tree_->Layout();
}

axStatus	Anon_Inspector::addAttr( Anon_TreeViewItem* parent, anAttr attr ) {
	axStatus st;

	axTempStringA	_name;
	const char*		name = attr.name();
	
	if( attr.isElement() ) {
		_name.format("{?}[{?}]", name, attr.elementIndex() );
		name = _name;
	}
	
	Anon_TreeViewItem*	item = tree_->AppendItem( parent, name );
	tree_->SetItemClientData( item, new Anon_Inspector_ItemData( attr ) );

	const	int text_margin = 4;

//--- array ---
	if( attr.isArray() ) {
		axSize n = attr.numElements();
		for( axSize i=0; i<n; i++ ) {
			st = addAttr( item, attr.element(i) );	if( !st ) return st;
		}
	}else if( attr.numChildren() ) {
//-- has child --	
		axSize n = attr.numChildren();
		for( axSize i=0; i<n; i++ ) {
			st = addAttr( item, attr.child(i) );	if( !st ) return st;
		}
	}else{
		Anon_TreeViewCell* cell = tree_->GetCell( item, 0 );
		if( !cell ) return -1;
		
		switch( attr.type() ) {
			#define	TYPE_LIST( TYPE ) \
				case anAttrType_##TYPE: {	\
				anAttr_##TYPE	a( attr );	\
					Anon_NumberCtrl* c = new Anon_NumberCtrl( cell, wxID_ANY, a.value(), a.spec()->precision(), wxDefaultPosition, wxDefaultSize, wxBORDER_NONE ); \
					c->SetClientObject( new Anon_Inspector_ItemData(attr) ); \
					c->SetForegroundColour	( my_app->settings.editor.textColor );\
					c->SetBackgroundColour	( my_app->settings.editor.fieldColor );\
					c->SetMargins( text_margin ); \
					cell->sizer->Add( c, 1, wxEXPAND ); \
					if( a.spec()->uiHasSlider() ) {	\
						Anon_Slider* slider = c->AddSlider	( a.spec()->minValue(), a.spec()->maxValue() );	\
						slider->SetColor( to_wxColor( a.spec()->uiColor() ), my_app->settings.editor.sliderBGColor );\
					}\
					if( a.spec()->uiDialStep () ) {\
						Anon_Dial* dial = c->AddDial( a.spec()->minValue(), a.spec()->maxValue(), a.spec()->uiDialStep() );\
						dial->SetColor	( to_wxColor( a.spec()->uiColor() ), my_app->settings.editor.dialOutlineColor );\
					}\
					c->Bind( wxEVT_ANON_NUMBERCTRL_BEGIN_CHANGE, 	&CLASS::onAttr_NumberCtrl_BeginChange,	this );	\
					c->Bind( wxEVT_ANON_NUMBERCTRL_CHANGING, 		&CLASS::onAttr_NumberCtrl_Changing,		this );	\
					c->Bind( wxEVT_ANON_NUMBERCTRL_CHANGED, 		&CLASS::onAttr_NumberCtrl_Changed,		this );	\
				}break;\
			//------------
				TYPE_LIST( int    )
				TYPE_LIST( float  )
				TYPE_LIST( double )
			#undef TYPE_LIST

			case anAttrType_bool: {
				anAttr_bool	a( attr );
				wxCheckBox*	c = new wxCheckBox( cell, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE );
				c->SetClientObject( new Anon_Inspector_ItemData(attr) );
				cell->sizer->Add( c, 1, wxEXPAND );
				c->SetValue( a.value() );
				c->SetForegroundColour	( my_app->settings.editor.textColor );
				c->SetBackgroundColour	( my_app->settings.editor.fieldColor );
				c->Bind( wxEVT_COMMAND_CHECKBOX_CLICKED , &CLASS::onAttr_CheckBox, this );
			}break;

			default: {
				wxTextCtrl*	c = new wxTextCtrl( cell, wxID_ANY, attr.typeName(), wxDefaultPosition, wxDefaultSize, wxBORDER_NONE | wxTE_READONLY );
				c->SetClientObject( new Anon_Inspector_ItemData(attr) );
				cell->sizer->Add( c, 1, wxEXPAND );
				c->SetFont( tree_->GetFont() );
				c->SetMargins( text_margin );
				c->SetMinClientSize( wxSize(10,5) );
				c->SetForegroundColour	( my_app->settings.editor.textColor );
				c->SetBackgroundColour	( my_app->settings.editor.fieldColor );
			}break;
		}
	}


	wxBitmap icon; //    = icon_empty;

	anAttrConnection* inputConn  = attr.inputConnection();
	anAttrConnection* outputConn = attr.firstOutputConnection();

	if( inputConn ) {
		if( outputConn ) {
			icon = icon_input_output;
		}else{
			icon = icon_input;
			if( inputConn->source.nodeType() == anNodeType_AnimCurve ) {
//				cell.SetBgCol ( wxColor(255,255,200) );
			}else{
//				cell.SetBgCol ( wxColor(255,200,200) );
			}
		}
	}else if( outputConn ) {
		icon = icon_output;
	}

	tree_->AddItemIcon( item, icon );
	return 0;
}

Anon_TreeViewItem* Anon_Inspector::findItem( anAttr & attr ) {
	axStatus st;

	anAttrId	attrId;
	st = attr.getAttrId( attrId );		if( !st ) return NULL;
	return _findItem( tree_->GetRootItem(), attrId, 0 );	
}

Anon_TreeViewItem*	Anon_Inspector::_findItem( Anon_TreeViewItem* item, const anAttrId & attrId, axSize level ) {
	if( ! attrId.inBound( level ) ) return NULL;
	Anon_TreeViewItem* p = tree_->GetItemChild( item, attrId[level] );
	if( !p ) return NULL;
	
	level++;
	if( level == attrId.size() ) {
		return p;
	}else{
		return _findItem( p, attrId, level );
	}
}

axStatus	Anon_Inspector::attrValueToUI( anAttr & attr ) {
	if( attr_changing_by_myself_ ) return 0;

	axStatus	st;
	Anon_TreeViewItem* item = findItem( attr );
	if( ! item ) return -1;

	wxWindow* win = tree_->GetCellWindow( item, 0 );
	if( !win ) return -1;
	
	switch( attr.type() ) {
		#define	TYPE_LIST( TYPE )	\
			case anAttrType_##TYPE: {	\
			anAttr_##TYPE	a( attr );	\
				Anon_NumberCtrl* c = (Anon_NumberCtrl*) win; \
				if( !c ) return -1;	\
				c->SetValue( a.value(), false );	\
			}break;	\
		//----
			TYPE_LIST( int )
			TYPE_LIST( float )
			TYPE_LIST( double )
		#undef	TYPE_LIST
		
		case anAttrType_bool: {
			/*
			anAttr_bool	a( attr );
			wxCheckBox* c = (wxCheckBox*) tree_->GetCell( item, 0 );
			if( !c ) return -1;
			c->SetValue( a.value() );
			*/
		}break;

	}
	return 0;
}

void Anon_Inspector::onAttr_NumberCtrl_BeginChange ( Anon_NumberCtrlEvent  & ev ) {
	axScopeValue<bool>	s( attr_changing_by_myself_, true );
	Anon_NumberCtrl* ctrl = (Anon_NumberCtrl*) ev.GetEventObject();
	Anon_Inspector_ItemData* data = (Anon_Inspector_ItemData*) ctrl->GetClientObject();
	if( !data ) return;	

	my_app->ctx.history.newUndo( data->attr );
	my_app->ctx.setAttr( data->attr, ctrl->GetValue() );
	my_app->evRenderNeeded();
}

void Anon_Inspector::onAttr_NumberCtrl_Changed ( Anon_NumberCtrlEvent  & ev ) {
	axScopeValue<bool>	s( attr_changing_by_myself_, true );
	Anon_NumberCtrl* ctrl = (Anon_NumberCtrl*) ev.GetEventObject();
	Anon_Inspector_ItemData* data = (Anon_Inspector_ItemData*) ctrl->GetClientObject();
	if( !data ) return;	
	my_app->ctx.history.resetCurrentUndo();
	my_app->ctx.setAttr( data->attr, ctrl->GetValue() );
	my_app->evRenderNeeded();
}

void Anon_Inspector::onAttr_NumberCtrl_Changing ( Anon_NumberCtrlEvent  & ev ) {
	axScopeValue<bool>	s( attr_changing_by_myself_, true );
	
	Anon_NumberCtrl* ctrl = (Anon_NumberCtrl*) ev.GetEventObject();
	Anon_Inspector_ItemData* data = (Anon_Inspector_ItemData*) ctrl->GetClientObject();
	if( !data ) return;	

	my_app->ctx.history.resetCurrentUndo();
	my_app->ctx.setAttr( data->attr, ctrl->GetValue() );
	my_app->evRenderNeeded();
}

void	Anon_Inspector::onAttr_CheckBox	( wxCommandEvent & ev ) {
	axScopeValue<bool>	s( attr_changing_by_myself_, true );
	wxCheckBox* ctrl = (wxCheckBox*) ev.GetEventObject();
	Anon_Inspector_ItemData* data = (Anon_Inspector_ItemData*) ctrl->GetClientObject();
	if( !data ) return;

	my_app->ctx.history.newUndo( data->attr );
	my_app->ctx.setAttr( data->attr, ctrl->GetValue() );
	my_app->evRenderNeeded();
}

void	Anon_Inspector::onCommandEvent ( wxCommandEvent &ev ) {
	/*
	switch( ev.GetId() ) {
		case cmd_wireframe:		{ view3d_ogl->b_wireframe = ( ev.GetInt() != 0 );	}break;
		case cmd_show_grid:		{ view3d_ogl->b_show_grid = ( ev.GetInt() != 0 );	}break;
	}
	*/
}