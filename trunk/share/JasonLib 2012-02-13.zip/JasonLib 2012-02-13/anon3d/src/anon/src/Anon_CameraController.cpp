//
//  Anon_ViewMouse.cpp
//  Anon
//
//  Created by Jason Chan on 2011-11-13.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_CameraController.h"

bool	Anon_CameraController::checkMouseEvent( wxWindow* win, wxMouseEvent & ev ) {
	_reset();
	
	if( ev.GetWheelRotation() ) {
		if( ev.GetWheelAxis() == 0 ) { // Y-Axis
			dolly = ev.GetWheelRotation();
			return true;
		}
	}
		
	if( ! win->HasCapture() ) {
		if( ev.ButtonDown() ) {
			win->SetFocus();
			win->CaptureMouse();
			lastMousePos_ = to_axVec2f( ev.GetPosition() );
		}
		return false;	
	}
	
	if( ev.ButtonUp() ) {
		win->ReleaseMouse();
		return false;
	} 

	if( ! ev.Dragging() ) return false;
	
	bool	panMode   = false;
	bool	thumbMode = false;
	bool	dollyMode = false;

	axVec2f	pos = to_axVec2f( ev.GetPosition() );
	axVec2f d = lastMousePos_ - pos;
	lastMousePos_ = pos;

	if( wxGetKeyState(  WXK_SPACE ) ) {
		if( ev.ControlDown() || ev.RightIsDown() ) {
			dollyMode = true;
		}else{
			panMode = true;
		}
	}else if( ev.AltDown() ) {
		if( ev.MiddleIsDown() ) {
			panMode   = true;
		}else if( ev.ControlDown() || ev.RightIsDown() ) {
			dollyMode = true;
		}else{
			thumbMode = true;
		}
	}

	if( dollyMode ) {
		dolly = d.x + d.y;
		return true;
	}else if( panMode ) {
		pan = d;
		return true;
	}else if( thumbMode ) {
		thumb = d;
		return true;
	}
	
	return false;
}

Anon_CameraController::Anon_CameraController() {
	_reset();
}

void Anon_CameraController::_reset() {
	thumb.set(0,0);
	pan.set(0,0);
	dolly = 0;
	zoom  = 0;
}

