#include "Anon_GLView.h"
#include "../Anon_App.h"

int OGLView_attribList[] = { 
	WX_GL_RGBA,
	WX_GL_DOUBLEBUFFER,
	WX_GL_DEPTH_SIZE, 16, 
	NULL 
};

Anon_GLView::Anon_GLView( wxWindow* parent, wxWindowID wid ) 
	: B( parent, wid, OGLView_attribList, 
			wxDefaultPosition, wxDefaultSize, wxFULL_REPAINT_ON_RESIZE ),
	wx_ogl( this )
{
	SetBackgroundColour( wxNullColour );
	wx_ogl.SetCurrent( *this );
	ax_ogl._setAsCurrent();
	ax_ogl._createGL( NULL );
	
	Bind( wxEVT_PAINT, &CLASS::onPaintEvent, this );
}

void Anon_GLView::_OnEraseBackground(wxEraseEvent& ev) {
//	printf("%s\n", __func__ );
	//do nothing
}

void Anon_GLView::onPaint() {
	glClearColor( 0,0.5f,0,0 );
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );
}

void Anon_GLView::onPaintEvent( wxPaintEvent& ev ) {
    wxPaintDC dc(this);

    SetCurrent( wx_ogl );
	int w, h;
	GetClientSize(&w, &h);
	glViewport(0, 0, (GLint) w, (GLint) h);

	onPaint();

//    glFlush();
    SwapBuffers();
}
