#ifndef __Anon_MyApp_h__
#define __Anon_MyApp_h__

#include "Anon_common.h"
#include "Anon_Settings.h"

class Anon_MainWindow;

class Anon_App : public wxApp {
public:
	Anon_App();

    virtual bool	OnInit();
	virtual int		OnExit();

	wxCursor	select_cursor;
	
	Anon_Settings		settings;
	Anon_MainWindow*	mainWindow;

	anGLRenderRequest	renderReq;
	axAutoPtr<anScene>	scene;

	wxFont				defaultFont;
	wxBitmap			resourceImage( const char* filename );

	axEventCaster<void>	evRenderNeeded;

	anContext		ctx;	
private:

};


extern	Anon_App*	my_app;

DECLARE_APP(Anon_App)

#endif //__Anon_MyApp_h__

