#include "Anon_ToolBar.h"

class Art : public wxAuiDefaultToolBarArt {
	typedef	wxAuiDefaultToolBarArt B;
public:
	wxAuiToolBarArt* 	Clone () { return new Art( *this ); }

	virtual void 	DrawBackground (wxDC &dc, wxWindow *wnd, const wxRect &_rect){
		wxColor color = my_app->settings.editor.panelColor;
		wxRect rect = _rect;
		rect.height++;
#if 0
		wxColour start_colour = color.ChangeLightness(150);
		wxColour end_colour = color.ChangeLightness(90);
		dc.GradientFillLinear(rect, start_colour, end_colour, wxSOUTH);
#else	
		dc.SetBrush( color );
		dc.DrawRectangle( rect );
#endif
	}

	virtual void 	DrawLabel (wxDC &dc, wxWindow *wnd, const wxAuiToolBarItem &item, const wxRect &rect ) {
		dc.SetFont( my_app->settings.editor.defaultFont );
		dc.SetTextForeground( my_app->settings.editor.textColor );

		// we only care about the text height here since the text
		// will get cropped based on the width of the item
		int text_width = 0, text_height = 0;
		dc.GetTextExtent(wxT("ABCDHgj"), &text_width, &text_height);

		// set the clipping region
		wxRect clip_rect = rect;
		clip_rect.width -= 1;
		dc.SetClippingRegion(clip_rect);

		int text_x, text_y;
		text_x = rect.x + 1;
		text_y = rect.y + (rect.height-text_height)/2;
		dc.DrawText(item.GetLabel(), text_x, text_y);
		dc.DestroyClippingRegion();
	}
};



Anon_ToolBar::Anon_ToolBar( wxWindow* parent ) : B( parent, wxID_ANY ) {
	this->SetArtProvider( new Art );
}

wxAuiToolBarItem * 	Anon_ToolBar::AddIcon( int tool_id, const wxString & image_filename, 
													const wxString & short_help_string,
													const wxString & long_help_string,
													 wxObject *client_data )
{
	wxBitmap bmp  = my_app->resourceImage(image_filename);
	return AddTool( tool_id, bmp, bmp, false, client_data, short_help_string, long_help_string );
}

wxAuiToolBarItem * 	Anon_ToolBar::AddToggleIcon( int tool_id, const wxString & image_filename, 
													const wxString & short_help_string,
													const wxString & long_help_string,
													 wxObject *client_data )
{
	wxBitmap bmp  = my_app->resourceImage(image_filename);
	return AddTool( tool_id, bmp, bmp, true, client_data, short_help_string, long_help_string );
}