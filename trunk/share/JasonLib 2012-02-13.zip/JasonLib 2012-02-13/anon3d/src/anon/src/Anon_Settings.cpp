//
//  Anon_Settings.cpp
//  Anon
//
//  Created by Jason on 28/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include "Anon_Settings.h"

Anon_Settings::Scene::Scene() {
	bgColor.set( 0.6f, 0.6f, 0.6f );
	showGrid = true;
}

Anon_Settings::Editor::Editor() {
#ifdef _WIN32
	defaultFont = wxFont(8, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false );
#else
	defaultFont = wxFont(12, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_NORMAL, false );
#endif


	textColor.Set		( 200, 200, 200 );
	panelColor.Set		(  68,  68,  68 );
	fieldColor.Set		(  42,  42,  42 );
	buttonColor.Set		(  95,  95,  95 );
	dialOutlineColor.Set(  20,  20,  20 );

	sliderBGColor = fieldColor;
}