#ifndef __Anon_Panel_h__
#define __Anon_Panel_h__

#include "../Anon_common.h"
#include "../Anon_MainWindow.h"
#include "../Anon_App.h"
#include "../Anon_Settings.h"
#include "../Anon_CameraController.h"

class Anon_AuiDockArt : public wxAuiDefaultDockArt {
public:

	Anon_AuiDockArt() {
		SetColour( wxAUI_DOCKART_BACKGROUND_COLOUR, my_app->settings.editor.panelColor );
		SetColour( wxAUI_DOCKART_SASH_COLOUR,		my_app->settings.editor.panelColor );

		SetColour( wxAUI_DOCKART_INACTIVE_CAPTION_COLOUR,			my_app->settings.editor.fieldColor );
		SetColour( wxAUI_DOCKART_INACTIVE_CAPTION_GRADIENT_COLOUR,	my_app->settings.editor.panelColor );
		SetColour( wxAUI_DOCKART_INACTIVE_CAPTION_TEXT_COLOUR,		my_app->settings.editor.textColor );

		SetColour( wxAUI_DOCKART_ACTIVE_CAPTION_COLOUR,				my_app->settings.editor.panelColor );
		SetColour( wxAUI_DOCKART_ACTIVE_CAPTION_GRADIENT_COLOUR,	my_app->settings.editor.panelColor );
		SetColour( wxAUI_DOCKART_ACTIVE_CAPTION_TEXT_COLOUR,		my_app->settings.editor.textColor );

		SetColour( wxAUI_DOCKART_BORDER_COLOUR,		my_app->settings.editor.panelColor );
		SetColour( wxAUI_DOCKART_GRIPPER_COLOUR,	my_app->settings.editor.panelColor );
		m_border_size = 0;
	}
/*
	void DrawBorder(wxDC& dc, wxWindow *WXUNUSED(window), const wxRect& _rect, wxAuiPaneInfo& pane) {
		//dc.SetPen(m_border_pen);
//		dc.SetPen( my_app->settings.editor.panelColor );
		dc.SetPen( wxColor(255,0,0) );
		dc.SetBrush(*wxTRANSPARENT_BRUSH);

		wxRect rect = _rect;
		int i, border_width = GetMetric(wxAUI_DOCKART_PANE_BORDER_SIZE);

		if (pane.IsToolbar())
		{
			for (i = 0; i < border_width; ++i)
			{
				dc.SetPen(*wxWHITE_PEN);
				dc.DrawLine(rect.x, rect.y, rect.x+rect.width, rect.y);
				dc.DrawLine(rect.x, rect.y, rect.x, rect.y+rect.height);
				dc.SetPen(m_border_pen);
				dc.DrawLine(rect.x, rect.y+rect.height-1,
							rect.x+rect.width, rect.y+rect.height-1);
				dc.DrawLine(rect.x+rect.width-1, rect.y,
							rect.x+rect.width-1, rect.y+rect.height);
				rect.Deflate(1);
			}
		}
		else
		{
			for (i = 0; i < border_width; ++i)
			{
				dc.DrawRectangle(rect.x, rect.y, rect.width, rect.height);
				rect.Deflate(1);
			}
		}
	}
*/

};

class Anon_Panel : public wxPanel {
	DECLARE_EVENT_TABLE();
	typedef wxPanel B;
public:
    Anon_Panel( wxWindow* parent, wxWindowID wid );

};


#endif //__Anon_Panel_h__
