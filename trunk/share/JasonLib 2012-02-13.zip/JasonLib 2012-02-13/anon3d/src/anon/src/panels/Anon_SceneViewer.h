#ifndef __Anon_SceneViewer_h__
#define __Anon_SceneViewer_h__

#include "Anon_Panel.h"

class Anon_SceneViewer : public Anon_Panel {
	typedef Anon_Panel B;
public:

	enum {
		cmd_null,
		cmd_wireframe,
	};

	void	onCommandEvent		( wxCommandEvent &ev );

	Anon_SceneViewer			( wxWindow* parent );

private:
	class			GLView;
	GLView*			glview_;
	wxPanel*		border_;
};

#endif //__Anon_SceneViewer_h__
