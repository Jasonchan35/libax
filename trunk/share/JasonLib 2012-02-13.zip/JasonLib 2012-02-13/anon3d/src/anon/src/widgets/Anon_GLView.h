#ifndef __Anon_OGLView_h__
#define __Anon_OGLView_h__

#include "../Anon_common.h"

class Anon_GLView : public wxGLCanvas {
	typedef	Anon_GLView		CLASS;
	typedef wxGLCanvas 		B;
public:
	wxGLContext		wx_ogl;
	axGLContext		ax_ogl;

	Anon_GLView( wxWindow* parent, wxWindowID wid = wxID_ANY );

	virtual void onPaint();

	void onPaintEvent( wxPaintEvent& ev );

private:
    void _OnEraseBackground(wxEraseEvent& ev);
};

#endif //__Anon_OGLView_h__
