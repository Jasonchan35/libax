//
//  Anon_Settings.h
//  Anon
//
//  Created by Jason on 28/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#ifndef Anon_Settings_h
#define Anon_Settings_h

#include "Anon_common.h"

class Anon_Settings : public axNonCopyable {
public:
	class Scene {
	public:
		Scene();
		axColorRGBf		bgColor;
		bool			showGrid;
	};
	Scene	scene;

	class	Editor {
	public:
		Editor();
		wxFont		defaultFont;
		wxColor		textColor;
		wxColor		panelColor;
		wxColor		fieldColor;
		wxColor		buttonColor;
		wxColor		dialOutlineColor;
		wxColor		sliderBGColor;
	};
	Editor	editor;
};

#endif //Anon_Settings_h
