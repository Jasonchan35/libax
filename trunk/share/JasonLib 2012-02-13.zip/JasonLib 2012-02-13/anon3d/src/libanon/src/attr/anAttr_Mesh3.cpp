#include <libanon/attr/anAttr_Mesh3.h>

template<class T>
axStatus anAttrSpec_Mesh3<T>::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	return 0;
}

template<class T>
anAttrSpec_Mesh3<T>& anAttrSpec_Mesh3<T>::setDefaultValue( const anMesh3<T> &value ) {
	defaultValue_.set( const_cast< anMesh3<T> & >( value ) );
	return *this;
}

template<class T>
axStatus	anAttrInst_Mesh3<T>::onSetValueToDefault	( anAttr & attr ) {
	SPEC* sp = (SPEC*)attr.spec();
	ATTR(attr).setValue( sp->defaultValue() );
	return 0;
}

template<> axStatus	anAttrInst_Mesh3<float>::onSetValue	( anAttr & attr, anAttr & src ) {
	switch( src.type() ) {
		case anAttrType_Mesh3f: {
			ATTR(attr).setValue( anAttr_Mesh3f(src).value() );
		}break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return 0;
}

template<> axStatus	anAttrInst_Mesh3<double>::onSetValue	( anAttr & attr, anAttr & src ) {
//	ATTR* dst = (ATTR*)attr;
	switch( src.type() ) {
		case anAttrType_Mesh3d: {
			ATTR(attr).setValue( anAttr_Mesh3d(src).value() );
		}break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return 0;
}

template<class T>
axStatus	anAttrInst_Mesh3<T>::onToString	( anAttr & attr, axIStringA & out ) {
	return out.convert( value_ );
}

template<class T>
axStatus	anAttrInst_Mesh3<T>::onSerialize	( anAttr & attr, axSerializer	&s ) { return s.io(value_); }

template<class T>
axStatus	anAttrInst_Mesh3<T>::onSerialize	( anAttr & attr, axDeserializer	&s ) { return s.io(value_); }


//------
template<class T>
const anMesh3<T> & anAttr_Mesh3<T>::value	() { 
	if( ! isValid() ) { assert(false); return anMesh3<T>::kEmpty; }
	compute(); 	
	return ((INST*)_inst())->value_; 
}

template<class T>
axStatus	anAttr_Mesh3<T>::setValue( const anMesh3<T> & v ) {
	((INST*)_inst())->value_.set( const_cast< anMesh3<T>& >(v) );
	valueChanged(); 
	return 0;
}

template<class T>
axStatus	anAttr_Mesh3<T>::setVertexSet( const anMesh3<T> & v ) {
	((INST*)_inst())->value_.setVertexSet( const_cast< anMesh3<T>& >(v) );
	valueChanged(); 
	return 0;
}

template<class T>
axStatus	anAttr_Mesh3<T>::setTopology	( const anMesh3<T> & v ) {
	((INST*)_inst())->value_.setTopology( const_cast< anMesh3<T>& >(v) );
	valueChanged(); 
	return 0;
}

//The explicit instantiation
#define TYPE_LIST(T,NAME) \
	template<> const char*	anAttrSpec_Mesh3<T>::_typeName	= #NAME; \
	template<> anAttrType	anAttrSpec_Mesh3<T>::_type		= anAttrType_##NAME; \
	template class anAttrSpec_Mesh3<T>;	\
	template class anAttrInst_Mesh3<T>;	\
	template class anAttr_Mesh3<T>;	\
//---
	TYPE_LIST(float,	Mesh3f )
	TYPE_LIST(double,	Mesh3d )
#undef	TYPE_LIST
