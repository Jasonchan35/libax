#include <libanon/base/anActionHistory.h>
#include <libanon/base/anContext.h>

anAction::anAction() {
}

anAction::~anAction() {
}

//----------------------------

void anUndoStep::undo() {
	anAction *p = actions_.tail();
	for( ; p; p=p->prev() ) {
		p->undo();
	}
}

void anUndoStep::redo() {
	anAction *p = actions_.head();
	for( ; p; p=p->next() ) {
		p->redo();
	}
}

axStatus anUndoStep::addAction( anAction* a )	{ 
	actions_.append(a); 
	return 0;
}

//----------------------------

anActionHistory::anActionHistory() {
	limit_ = 0;
}

void anActionHistory::setLimit( axSize n )	{ 
	limit_ = n; 
	while( undo_.size() + redo_.size() > limit_ ) {
		anUndoStep* t = undo_.takeHead();
		delete t;
	}
}
	
axStatus anActionHistory::newUndo ( const char* name ) {
	axStatus st;
	axAutoPtr<anUndoStep> ap;
	st = ap.newObject();			if( !st ) return st;
	st = ap->setName( name );		if( !st ) return st;

	ax_log("new undo \"{?}\"", name );

	_addUndo( ap.unref() );
	return 0;
}

axStatus	anActionHistory::newUndo ( anAttr &	attr ) {
	axStatus st;
	axTempStringA	name;
	st = attr.getFullName( name, true );		if( !st ) return st;

	axTempStringA	str;
	st = str.format("setAttr {?}", name );		if( !st ) return st;
	st = newUndo( str );						if( !st ) return st;
	return 0;
}

void anActionHistory::_addUndo( anUndoStep* undo ) {
	redo_.clear();
	if( limit_ ) {
		undo_.append( undo );

		while( undo_.size() + redo_.size() > limit_ ) {
			//delete oldest undo action
			anUndoStep* t = undo_.takeHead();
			delete t;
		}
		evDidChange();
	}
}

void anActionHistory::addAction( anAction *action ) {
	redo_.clear();

	anUndoStep* t = undo_.tail();
	if( !t ) {
		delete action;
		return;
	}

	t->addAction( action );
}

axStatus	anActionHistory::undo() {
	anUndoStep *t = undo_.tail();
	if( !t ) return axStatus_Anon_no_mode_undo;

	ax_log("undo {?}", t->name() );

	undo_.remove( t );
	redo_.insert( t );
	t->undo();

	evDidChange();
	return 0;
}

axStatus	anActionHistory::resetCurrentUndo() {
	anUndoStep *t = undo_.tail();
	if( !t ) return axStatus_Anon_no_mode_undo;
	t->reset();
	return 0;
}

axStatus	anActionHistory::redo() {
	anUndoStep *t = redo_.head();
	if( !t ) return axStatus_Anon_no_mode_redo;
	ax_log("redo {?}", t->name() );

	redo_.remove( t );
	undo_.append( t );
	t->redo();

	evDidChange();
	return 0;
}
