#include <libanon/node/meshModifier/anNode_Deformer.h>

axStatus anNode_Deformer::onInitStaticSpec( anNodeSpec & spec ) {
	return 0;
}

axStatus	anNode_Deformer::onDeform( anVertex3f* dst, const anVertex3f* src, axSize numVertices ) {
	memcpy( dst, src, numVertices * sizeof(anVertex3f) );
	return 0;
}

axStatus	anNode_Deformer::onComputeOutMesh() {
	axStatus st;

	const anMesh3f & input = inMesh().value();

	axSize n = input.numVertices();
	st = outMesh_.setNumVertices( n );		if( !st ) return st;

	onDeform( outMesh_.vertexPtr(), input.vertexPtr(), n );

	outMesh().setValue( input ); //using input as base
	outMesh().setVertexSet( outMesh_ ); //override vertexSet
	return 0;
}
