#include <libanon/attr/anAttr.h>
#include <libanon/node/anNode.h>
#include <libanon/base/anContext.h>

#define	DEBUG_DIRTY	0

anAttr::anAttr() {
	node_ = NULL;
	spec_ = NULL;
	inst_ = NULL;
}

anAttr::anAttr( anNode* node, const anAttrSpec* spec, anAttrInst* inst ) {
	node_ = node;
	spec_ = spec;
	inst_ = inst;
}

bool anAttr::operator==( const anAttr & src ) {
	if( inst_ != src.inst_ ) return false;
	return true;
}

anNodeType	anAttr::nodeType () const {
	if( ! node_ ) return anNodeType_unknown;
	return node_->type();
}

const char*	anAttr::name() const {
	if( ! isValid() ) return "";
	return spec_->name(); 
}

axSize		anAttr::numElements	()  const {
	if( ! isValid() ) return 0;
	return inst_->onGetNumElements( const_cast<anAttr&>(*this) );
}

axStatus	anAttr::setNumElements( axSize n ) {
	if( ! isValid() ) return -1;
	return inst_->onSetNumElements( *this, n );
}

axSize		anAttr::elementIndex() const {
	if( ! isValid() ) return 0;
	return inst_->onGetElementIndex( const_cast<anAttr&>(*this) );
}

anAttr		anAttr::elementArray() {
	if( ! isValid() ) return anAttr();
	anAttrInst* p = inst_->onGetElementArray( *this );
	if( !p ) return anAttr();
	return anAttr( node_, spec_, p );
}

anAttr		anAttr::element( axSize index ) {
	if( ! isValid() ) return anAttr();
	anAttrInst* p = inst_->onGetElement(*this,index);
	if( !p ) return anAttr();
	return anAttr( node_, spec_, p );
}

axStatus	anAttr::onSerialize( axSerializer &s ) {
	if( ! isValid() ) return -1;
	if( ! spec_->saveToFile() ) return 0;
	compute();
	return inst_->onSerialize( *this, s );
}

axStatus	anAttr::onSerialize( axDeserializer &s ) {
	if( ! isValid() ) return -1;
	if( ! spec_->saveToFile() ) return 0;
	axStatus st = inst_->onSerialize( *this, s );		if( !st ) return st;
	valueChanged();
	return 0;
}

bool anAttr::isArray () const {
	return inst_ ? inst_->isArray() : false;
}

bool anAttr::isElement	() const {
	return inst_ ? inst_->isElement() : false;
}

void anAttr::setValueToDefault() {
	if( ! isValid() ) return;
	inst_->onSetValueToDefault( *this );
	valueChanged();
}

axStatus	anAttr::getFullName	( axIStringA &out, bool withNodeName ) {
	axStatus st;
	out.resize(0);

	if( !node_ ) return -1;
	if( withNodeName ) {
		st = out.set( node_->name() );	if( !st ) return st;
		st = out.append('.');			if( !st ) return st;
	}
	st = _getFullName( out );			if( !st ) return st;
	return 0;
}

axStatus	anAttr::_getFullName( axIStringA &out ) {
	axStatus	st;
	if( isElement() ) {
		anAttr a = elementArray();
		if( ! a.isValid() ) return -1;
		st = a._getFullName( out );			if( !st ) return st;
		st = out.appendFormat("[{?}]", elementIndex() );	if( !st ) return st;
	}else{
		anAttr p = parent();
		if( p.isValid() ) {
			st = p._getFullName( out );	if (!st) return st;
			st = out.appendFormat(".{?}", name() );	if( !st ) return st;
		}else{
			st = out.appendFormat("{?}", name() );	if( !st ) return st;
		}
	}
	return 0;
}

axStatus	anAttr::getAttrId	( anAttrId &out ) {
	out.resize(0);
	return _getAttrId( out );
}

axStatus	anAttr::_getAttrId( anAttrId & out ) {
	axStatus	st;
	if( isElement() ) {
		anAttr a = elementArray();
		if( ! a.isValid() ) return -1;
		st = a._getAttrId( out );			if( !st ) return st;
		st = out.append( elementIndex() );	if( !st ) return st;
	}else{
		anAttr p = parent();
		if( p.isValid() ) {
			st = p._getAttrId( out );	if (!st) return st;
		}
		st = out.append( spec_->attrSubId() );	if( !st ) return st;
	}
	return 0;
}

axStatus anAttr::toString( axIStringA &out ) const {
	if( ! isValid() ) { out.clear(); return -1; }
	return inst_->onToString( const_cast<anAttr&>( *this ), out );
}

axStatus anAttr::toStringFormat	( axStringFormat &f ) const {
	axStatus st;
	if( ! isValid() ) {
		return f.format("<NULL ATTR>");
	}

	anAttr* This = const_cast<anAttr*>( this );

	axTempStringA	fullname;
	This->getFullName( fullname, false );

	st = f.format("{?}", node_->name() );	if( !st ) return st;
	st = f.format(".{?}", fullname );		if( !st ) return st;

	if( ax_strchr(f.opt, 'v') ) {
		axTempStringA	tmp;
		toString( tmp );
		f.format("  value={?}\n", tmp );
	}

	if( ax_strchr( f.opt, 'c' ) ) {
		anAttrConnection* input = This->inputConnection();
		if( input ) {
			f.format("  input: {?}\n", *input );
		}
		
		anAttrConnection* output = This->firstOutputConnection();
		if( output ) {
			for( ; output; output=output->next() ) {
				f.format("  output: {?}\n", *output );
			}
		}
	}
	return 0;
}

void	anAttr::_onDelete	() {
	disconnectAll();
}

axStatus	anAttr::connect	( anAttr & dst ) {
	if( ! isValid() ) return -1;
	if( ! dst.isValid() ) return -1;

	axStatus st;
	st = inst_->conn.newObjectIfNull();			if( !st ) return st;
	st = dst.inst_->conn.newObjectIfNull();	if( !st ) return st;

	anAttrConnection & conn = dst.inst_->conn->input;

	conn.removeFromList();

	conn.source = *this;
	conn.sourceInfo._setByAttr( *this );
	conn.owner  = dst;
	inst_->conn->output.append( &conn );

	dst.setDirty();

//	ax_log("connected {?}", conn );
	return 0;
}

axStatus	anAttr::newInputConnection ( anNodeType nodeType, const char* nodeName, const char* attrName ) {
	axStatus st;
	anAttrId	attrId;

	anNodeSpecRegistry* reg = anNodeSpecRegistry::getInstance();

	st = reg->getAttrId( nodeType, attrName, attrId );			if( !st ) return st;
	st = newInputConnection  ( nodeType, nodeName, attrId );	if( !st ) return st;
	return 0;
}

axStatus	anAttr::newInputConnection ( anNodeType nodeType, const char* nodeName, const anAttrId & attrId ) {
	if( ! isValid() ) return -1;
	axStatus st;

	st = inst_->conn.newObjectIfNull();		if( !st ) return st;

	anAttrConnection & conn = inst_->conn->input;
	conn.removeFromList();

	conn.owner  = *this;
	conn.source = anAttr();
	conn.sourceInfo.nodeType = nodeType;
	conn.sourceInfo.attrId	 = attrId;
	st = conn.sourceInfo.nodeName.set( nodeName );	if( !st ) return st;
	return 0;
}

axStatus	anAttr::getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list ) {
	if( ! isValid() ) return 0;
	return inst_->getAllInputConnectionsRecursively( *this, list );
}

void	anAttr::disconnectAll() {
	if( ! isValid() ) return;
	inst_->disconnectAll( *this );
}

anAttrType	anAttr::type() const {
	if( ! isValid() ) return anAttrType_unknown;
	return spec_->type();
}

const char*		anAttr::typeName() const {
	if( ! isValid() ) return "";
	return spec_->typeName();
}

anAttrConnection*	anAttr::inputConnection() {
	if( ! isValid()   ) return NULL;
	if( ! inst_->conn ) return NULL;
	if( ! inst_->conn->input.owner.isValid() ) return NULL;
	return & inst_->conn->input;
}

anAttrConnection*	anAttr::firstOutputConnection() {
	if( ! isValid() ) return NULL;
	if( ! inst_->conn ) return NULL;
	return inst_->conn->output.head();
}

anAttr	anAttr::parent	() {
	if( ! isValid() ) return anAttr();
	if( inst_->isElement() ) return anAttr();

	const anAttrSpec* p = spec_->parent();
	if( !p ) return anAttr();

	return anAttr( node_, p, (anAttrInst*)( (char*)inst_ - spec_->instOffset() ) );
}

anAttr anAttr::child ( axSize idx ) { 
	if( ! isValid() ) return anAttr();
	if( isArray() ) return anAttr();

	axSize n = spec_->numChildren();
	if( idx >= n ) return anAttr();

	const anAttrSpec* c = spec_->child(idx);	if( !c ) return anAttr();
	return anAttr( node_, c, (anAttrInst*)( (char*)inst_ + c->instOffset() ) );
}

axSize anAttr::numChildren() const {
	if( ! isValid() ) return 0;
	return spec_->numChildren();
}

anAttr	anAttr::_affectedAttr ( axSize idx ) {
	if( ! isValid() ) return anAttr();

	axSize n = spec_->numAffected();
	if( idx >= n ) return anAttr();

	const anAttrSpec* c = spec_->affected(idx);
	axSize	instOffset  = 0;

	const anAttrSpec* p = c;
	while(p) {
		if( p->isArray() ) { 
			ax_log("affected attr cannot be array element");
			assert(false);
			return anAttr(); 
		}
		instOffset  += p->instOffset();
		p = p->parent();
	}

	return anAttr( node_, c, (anAttrInst*)( (char*)node_ + instOffset ) );
}

axStatus anAttr::setValue	( const anAttr & src ) {
	if( ! isValid() ) return -1;
	anAttr & s = const_cast<anAttr&>(src );
	inst_->onSetValue( *this, s );
	valueChanged();
	return 0;
}

axStatus anAttr::compute	()	{ 
	axStatus st;
	if( ! isValid() ) return -1;
	if( ! inst_->dirty()   ) return 0;
	if(	inst_->computing() ) return -1;
	inst_->_setComputing( true );

	anAttrConnection* conn = inputConnection();
	if( conn ) {
		// using value from input connection
		setValue( conn->source );
//		ax_print("attr copy {?} <= {?}\n", *this, conn->source );
	}else if( spec_->hasComputeFunc() ) {
		// using compute func
		st = spec_->callComputeFunc(this);
		if( !st ) {
			assert( false );
		}
	}else{
		// compute child instead
		axSize n = spec_->numChildren();
		for( axSize i=0; i<n; i++ ) {
			st = child(i).compute();	if( !st ) return st;
		}
	}

	inst_->_setComputing( false );
	clearDirty();
	return 0;
}

inline
void	anAttr::_setDirty_NoChild() {
	if( ! isValid() ) return;

	if( inst_->dirty() ) {

#if DEBUG_DIRTY
		axTempStringA	fullname;
		getFullName( fullname );
//		ax_print("alreadyDirty {?}.{?}\n", node()->name(), fullname );
#endif
		return;	//already dirty
	}
	inst_->setDirty(true);

#if DEBUG_DIRTY
	axTempStringA	fullname;
	getFullName( fullname );
	ax_print("setDirty     {?}.{?}\n", node()->name(), fullname );
#endif
	{ //set parent dirty
		anAttr p = parent();
		if( p.isValid() ) {
			p._setDirty_NoChild();
		}
	}

	if( isElement() ) {
		elementArray()._setDirty_NoChild();
	}

	{ //set affect attr dirty
		axSize n = spec_->numAffected();
		for( axSize i=0; i<n; i++ ) {
			_affectedAttr(i).setDirty();
		}
	}

	{ //set output connection dirty
		anAttrConnection* conn = firstOutputConnection();
		for( ; conn; conn=conn->next() ) {
			conn->owner.setDirty();
		}
	}

	node_->evNodeAttrDidChange( *this );
}

inline
void anAttr::_setDirty_Child () {
	if( ! isValid() ) return;
	if( isArray() ) { //set element dirty
		axSize n = numElements();
		for( axSize i=0; i<n; i++ )
			element(i).setDirty();
	}else{
		axSize n = spec_->numChildren();
		for( axSize i=0; i<n; i++ ) {
			child(i).setDirty();
		}
	}
}

void anAttr::setDirty () {
	_setDirty_NoChild();
	_setDirty_Child();
}

void	anAttr::clearDirty() {
	if( ! isValid() ) return;
	if( ! inst_->dirty() ) return;

#if DEBUG_DIRTY
	axTempStringA	fullname;
	getFullName( fullname );
	ax_print("clearDirty   {?}.{?}\n", node()->name(), fullname );
#endif
	inst_->setDirty(false);
}

void	anAttr::valueChanged() {
	setDirty();
	clearDirty();
}

void	anAttr::unshare	() {
	if( ! isValid() ) return;
	inst_->onUnshare( *this );
}


//----------------
