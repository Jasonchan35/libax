#include <libanon/node/anNodeType.h>

const char* anNodeTypeName( anAttrType t ) {
	switch( t ) {	
		#define anNodeType_enum(TYPE)	case anNodeType_##TYPE: return #TYPE;
			#include <libanon/node/anNodeType_enum.h>
		#undef	anNodeType_enum
	};
	return "Unknown";
}

