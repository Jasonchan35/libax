#include <libanon/node/meshModifier/anNode_BlendShape.h>

const char*	anAttrSpec_BlendShapeTarget::_typeName = "BlendShapeTarget";
anAttrType	anAttrSpec_BlendShapeTarget::_type	   = anAttrType_Custom_BlendShapeTarget;

axStatus anAttrSpec_BlendShapeTarget::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	anAttrSpec_INIT_CHILD( mesh );
	anAttrSpec_INIT_CHILD( weight )
		.setMinMax	( 0, 1 )
//		.uiAddGauge	()
//		.uiAddDial	(0.01);
		.uiAddSlider();
	return 0;
}

axStatus anNode_BlendShape::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( target, NULL );
	anAttrSpec_affect( target,	outMesh );
	return 0;
}

axStatus	anNode_BlendShape::onDeform( anVertex3f* dst, const anVertex3f* src, axSize numVertices ) {
	axStatus st;

	memcpy( dst, src, sizeof(anVertex3f) * numVertices );

	axSize n = target().numElements();
	for( axSize i=0; i<n; i++ ) {
		anAttr_BlendShapeTarget	a = target().element(i);
		const anMesh3f & mesh	= a.mesh().value();
				float	 weight	= a.weight().value();

		if( weight == 0 ) continue;

		if( mesh.numVertices() != numVertices ) continue;

			  axVec3f *d = dst;
		const axVec3f *s = src;
		
		const axVec3f *t = mesh.vertexPtr();
		const axVec3f *e = t + numVertices;

		for( ; t<e; d++, s++, t++) {
			*d += (*t - *s) * weight;
		}		
	}

	return 0;
}
