#include <libanon/node/anNode.h>
#include <libanon/base/anContext.h>

//--- spec -----
anNodeSpec&	anNode::staticSpec() { static anNodeSpec s; return s; }

axStatus	anNode::initStaticSpec() {
	axStatus	st;
	anNodeSpec	&s = staticSpec();
	if( s.alreadyCreated() ) return 0;

	st = s.create( NULL, anNodeType_Node, "Node", anNodeCreator< anNode >, sizeof(anNode) );
	st = onInitStaticSpec( s );	if( !st ) return st;
	
	return 0;
}

axStatus	anNode::onInitStaticSpec( anNodeSpec & spec ) {
//	axPRINT_FUNC_NAME;
	axStatus st;
//	an_attr_spec( node, NULL );
	return 0;
}

axStatus	anNode::FileHeader::toStringFormat( axStringFormat &f ) const {
	return f.format("{?} ({?}, {?} bytes)", name, anNodeTypeName( type ), byteSize );
}

//--------


anNode::anNode() {
	systemNode_ = false;
	spec_ = NULL;
	selected_ = false;
	scene_ = NULL;
	hashNode_.node = this;
}

anNode::~anNode() {
}

axStatus anNode::_onCreate( anNodeSpec *spec ) {
	axStatus st;
	spec_ = spec;

	axSize n = spec->numAttr();
	for( axSize i=0; i<n; i++ ) {
		attr(i).setValueToDefault();
	}
	return 0;
}

void anNode::_onDelete() {
	children_.clear();
	evNodeDeleted(*this);

	axSize n = numAttr();
	for( axSize i=0; i<n; i++ ) {
		attr(i)._onDelete();
	}
}

axStatus anNode::toStringFormat	( axStringFormat &f ) const {
	axStatus st;
	f.format("{?}: {?}\n", typeName(), name() );

	anNode* node = const_cast<anNode*>(this);

	f.format("--attr--\n" );
	axSize n = numAttr();

	for( axSize i=0; i<n; i++ ) {
		f.format("{?:cv}", node->attr(i) ); 
	}
	f.format("\n");
	return 0;
}


axStatus	anNode::setName	( const char* name ) {
	axStatus st;
	//remove before change the name, because it will affect the hashValue
	if( scene_ ) scene_->_removeNode	( this );

	st = name_.set( name );			
	if( scene_ ) scene_->_addNode	( this );
	if( st ) {
		evNodeNameDidChange(*this);
	}
	return st;
}

const char*	anNode::name () const {
	return name_.c_str();
}

axStatus	anNode::setParentName ( const char* name ) {
	return parentName_.set( name );
}

const char*		anNode::parentName	() const {
	return parentName_.c_str();
}

anNodeType	anNode::type() const {
	if( ! spec_ ) return anNodeType_unknown;
	return spec_->type();
}

const char*		anNode::typeName	() const {
	if( !spec_ ) return "";
	return spec_->name();
}

//virtual 
bool anNode::isKindOf	( anNodeType	type )	{ 
	return ( type == TYPE ); 
}

axSize anNode::numAttr () const {
	return spec_->numAttr();
}

anAttr  anNode::attr( axSize idx ) {
	axStatus st;
	anAttrSpec* s = spec_->attr(idx);
	if( !s ) return anAttr();
	return anAttr( this, s, (anAttrInst*)( (char*)this + s->instOffset() ) );
}

axStatus	anNode::findAttrById( anAttr & out, const anAttrId & attrId ) {
	axStatus st;

	if( attrId.size() == 0 ) return -1;

	out = attr( attrId[0] );
	if( ! out.isValid() ) return st;

	for( axSize lv=1; lv<attrId.size(); lv++ ) {
		axSize a = attrId[lv];
		if( out.isArray() ) {
			out = out.element(a);
		}else{
			out = out.child(a);
		}
		if( ! out.isValid() ) return -1;
	}
	return 0;
}

axStatus	anNode::findAttrByName	( anAttr & out, const char* name ) {
	axStatus st;
	anAttrId	attrId;
	st = spec_->getAttrId( name, attrId );	if( !st ) return st;
	return findAttrById( out, attrId );
}

template<class S>	inline
axStatus	anNode::_serialize_io( S	&s ) {
	axStatus st;
	st = s.io( parentName_ );		if( !st ) return st;	
	axSize n = spec_->numAttr();
	for( axSize i=0; i<n; i++ ) {
		st = attr(i).onSerialize(s);		if( !st ) return st;
	}
	st = onSerialize( s );		if( !st ) return st;
	return 0;
}

axStatus	anNode::serialize_io( axSerializer		&s ) { return _serialize_io(s); }
axStatus	anNode::serialize_io( axDeserializer	&s ) { return _serialize_io(s); }
axStatus	anNode::onSerialize	( axSerializer		&s ) { return 0; }
axStatus	anNode::onSerialize	( axDeserializer	&s ) { return 0; }

void	anNode::appendChild	( anNode* child ) {
	children_.append( child );
}

anNode*		anNode::firstChild	() {
	return children_.head();
}

axSize	anNode::numChildren() {
	return children_.size();
}

void	anNode::glRender	( anGLRenderRequest &req ) {
	onGLRender( req );
	onGLRenderChild( req );
}

void	anNode::onGLRenderChild	( anGLRenderRequest &req ) {
	anNode * c = firstChild();
	for( ; c; c=c->next() ) {
		c->glRender( req );
	}
}

void	anNode::onGLRender	( anGLRenderRequest &req ) {
}

void	anNode::_setSelected( const anSelection &sel, bool selected ) {
	if( ! sel.isComponent() ) {
		selected_ = selected;
	}
	_onSetSelected( sel, selected );
}

void	anNode::_onSetSelected( const anSelection &sel, bool selected ) {

}

axStatus	anNode::getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list ) {
	axStatus st;
	axSize n = numAttr();
	for( axSize i=0; i<n; i++ ) {
		st = attr(i).getAllInputConnectionsRecursively( list );	if( !st ) return st;
	}
	return 0;
}
