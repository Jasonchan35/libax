#include <libanon/attr/anAttrInst.h>

anAttrInst::anAttrInst() {
	dirty_		= false;
	computing_	= false;
	isArray_	= false;
	isElement_	= false;
}

anAttrInst::~anAttrInst() {

}

axSize		anAttrInst::onGetNumElements	( anAttr & attr )			{ return 0; }
axStatus	anAttrInst::onSetNumElements	( anAttr & attr, axSize n )	{ return -1; }
axSize		anAttrInst::onGetElementIndex	( anAttr & attr )			{ return 0; }
anAttrInst*	anAttrInst::onGetElement		( anAttr & attr, axSize index )	{ return NULL; }
anAttrInst*	anAttrInst::onGetElementArray	( anAttr & attr )			{ return NULL; }


axStatus	anAttrInst::getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list ) { 
	if( conn ) {
		if( conn->input.owner.isValid() ) {
			return list.append( & conn->input );
		}
	}
	return 0; 
}

void		anAttrInst::disconnectAll		( anAttr & attr ) {
	conn.unref();
}
