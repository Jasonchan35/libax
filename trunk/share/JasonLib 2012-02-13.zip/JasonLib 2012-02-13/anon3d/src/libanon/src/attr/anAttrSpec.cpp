#include <libanon/attr/anAttr.h>
#include <libanon/node/anNodeSpec.h>

anAttrSpec::anAttrSpec() {
	nodeSpec_	= NULL;
	parent_		= NULL;
	instOffset_	= 0;
	level_		= 0;
	isArray_	= false;
	created_	= false;
	saveToFile_ = true;

	uiColor_.set( 1, .9f, .5f );
	affected_.setCapacityIncrement( 8 );
}

anAttrType	anAttrSpec::type() const {
	return anAttrType_unknown;
}

axStatus	anAttrSpec::onCreate	( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) { assert(false); return 0; }

axStatus anAttrSpec::_create( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	axStatus st; 
	st = name_.set( name );		if( !st ) return st;

	nodeSpec_	= & nodeSpec;
	parent_		= parent;
	instOffset_ = instOffset;

	if( parent ) {
		attrSubId_ = parent->numChildren();
		st = parent->child_.append( this );		if( !st ) return st;
		st = fullName_.format( "{?}.{?}", parent->fullName(), name );	if( !st ) return st;

		level_ = parent->level_ + 1;

	}else{ //top level attr
		attrSubId_ = nodeSpec.numAttr();
		st = nodeSpec._addAttr( this );		if( !st ) return st;
		st = fullName_.set( name );			if( !st ) return st;
	}

	st = onCreate(name, nodeSpec, parent, instOffset);	if( !st ) return st;
	created_ = true;
	return 0;
}

void	anAttrSpec::_setComputeFunc	( ComputeFunc func ) { 
	computeFunc_ = func; 
}

axStatus	anAttrSpec::addAffected ( anAttrSpec* o ) {
	if( o->isArray() ) return axStatus_Anon_cannot_affect_array_attr;
	affected_.append(o);
	return 0;
}

const char*	anAttrSpec::name() const {
	return name_;
}

const char*	anAttrSpec::fullName() const {
	return fullName_;
}

axStatus anAttrSpec::toStringFormat	( axStringFormat &f ) const {
	f.format("({?:-10}) {?:-12}{?}, attrSubId={?}, inst={?}\n", 
				typeName(), fullName_, isArray_?"[]":"", attrSubId_, instOffset_ );

	axSize n = numChildren();
	for( axSize i=0; i<n; i++ ) {
		const anAttrSpec* c = child(i);
		f.repeat( ' ', c->level_*2 );
		f.format( "  {?}", *c );
	}
	return 0;
}

axStatus	anAttrSpec::_getAttrId( const char* fullName, axIArray<axSize> &out ) {
	axStatus st;
	if( ! fullName ) return -1;
	if( fullName[0] == 0 ) return 0;

	if( fullName[0] == '.' ) { //child
		const char* s = fullName+1;
		const char* p;
		size_t	len;
		p = ax_strchr( s, '.' );
		if( !p ) p = ax_strchr( s, '[' );

		if( p ) {
			len = p - s;
		}else{
			len = ax_strlen( s );
		}

		axSize n = child_.size();
		for( axSize i=0; i<n; i++ ) {
			anAttrSpec* a = child_[i];
			if( ax_strncmp( a->name(), s, len ) == 0 ) {
				st = out.append( a->attrSubId() );			if( !st ) return st;
				if( p ) {
					st = a->_getAttrId( p, out );		if( !st ) return st;
				}
				return 0;
			}
		}
	}

	return 0;
}

axStatus	anAttrSpec::callComputeFunc	 ( anAttr *attr ) const { 
	return (attr->node()->*computeFunc_)( attr );
}

void anAttrSpec::uiSetColor	( const axColorRGBf & color ) {
	uiColor_ = color;
}

const axColorRGBf & anAttrSpec::uiColor() const { return uiColor_; }