#include <libanon/base/anGLRenderRequest.h>

anGLRenderRequest::anGLRenderRequest() {
	reset();
}

void anGLRenderRequest::reset() {
	matrixStack_.resize(1);
	matrixStack_[0].setIdentity();
}

void	anGLRenderRequest::pushMatrix	( const axMatrix4f &m ) {
	matrixStack_.append( matrixStack_.last() * m );
}

void	anGLRenderRequest::popMatrix	() {
	matrixStack_.decSize(1);
}

const axMatrix4f& anGLRenderRequest::currentMatrix() const {
	return matrixStack_.last();
}