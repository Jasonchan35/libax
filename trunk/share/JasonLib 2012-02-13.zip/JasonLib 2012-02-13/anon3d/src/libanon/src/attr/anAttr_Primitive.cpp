#include <libanon/attr/anAttr_Primitive.h>
#include <libanon/base/an_convert.h>

template<class T>
anAttrSpec_Primitive<T>::anAttrSpec_Primitive() {
	precision_	= ax_min( axTypeOf<T>::precision(), 3 );
	minValue_	= axTypeOf<T>::valueMin();
	maxValue_	= axTypeOf<T>::valueMax();
	uiHasSlider_= false;
	uiDialStep_	= 0;
}

template<class T>
axStatus anAttrSpec_Primitive<T>::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	defaultValue_ = 0;
	return 0;
}

template<class T>
anAttrSpec_Primitive<T>& anAttrSpec_Primitive<T>::setDefaultValue( const T &defaultValue ) {
	defaultValue_ = defaultValue;
	return *this;
}

template<class T>	T	anAttrSpec_Primitive<T>::defaultValue	() const	{ return defaultValue_; }


template<class T>
anAttrSpec_Primitive<T>& anAttrSpec_Primitive<T>::setPrecision( int precision  ) {
	precision_ = precision;
	return *this;
}

template<class T>
int anAttrSpec_Primitive<T>::precision() const {
	return precision_;
}

template<class T> 
anAttrSpec_Primitive<T>& anAttrSpec_Primitive<T>::uiAddSlider() { 
	uiHasSlider_ = true; 
	return *this;
}

template<class T>
anAttrSpec_Primitive<T>& anAttrSpec_Primitive<T>::uiAddDial( double step ) {
	uiDialStep_ = step;
	return *this;
}

template<class T>
double anAttrSpec_Primitive<T>::uiDialStep() const {
	return uiDialStep_;
}

template<class T>
anAttrSpec_Primitive<T>& anAttrSpec_Primitive<T>::setMinMax( const T & minValue, const T & maxValue ) {
	minValue_ = minValue;
	maxValue_ = maxValue;
	return *this;
}

template<class T> bool 	anAttrSpec_Primitive<T>::uiHasSlider() const { return uiHasSlider_ ; }

template<class T> T 	anAttrSpec_Primitive<T>::minValue() const { return minValue_; }
template<class T> T 	anAttrSpec_Primitive<T>::maxValue() const { return maxValue_; }

//-------
template<class T>
axStatus	anAttrInst_Primitive<T>::onSetValueToDefault ( anAttr & attr ) {
	SPEC* sp = (SPEC*)attr.spec();
	value_ = sp->defaultValue();
	return 0;
}

template<class T>
axStatus	anAttrInst_Primitive<T>::onToString	( anAttr & attr, axIStringA & out ) {
	return out.convert( value_ );
}

template<class T>
axStatus	anAttrInst_Primitive<T>::onSetValue	( anAttr & attr, anAttr & src ) {
	switch( src.type() ) {
		case anAttrType_int:	an_convert( value_, anAttr_int   (src).value() );	break;
		case anAttrType_int64:	an_convert( value_, anAttr_int64 (src).value() );	break;
		case anAttrType_float:	an_convert( value_, anAttr_float (src).value() );	break;
		case anAttrType_double:	an_convert( value_, anAttr_double(src).value() );	break;
		case anAttrType_bool:	an_convert( value_, anAttr_bool  (src).value() );	break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return 0;
}

//-------
template<class T>
T	anAttr_Primitive<T>::value	() { 
	if( ! isValid() ) { assert(false); return 0; }
	compute(); 	
	return ((INST*)_inst())->value_; 
}

template<class T>
axStatus	anAttr_Primitive<T>::setValue( const T & v ) {
	if( ! isValid() ) return -1;
	((INST*)_inst())->value_ = v; 
	valueChanged();
	return 0;
}

//The explicit instantiation

#define TYPE_LIST(T,NAME) \
	template<> const char*	anAttrSpec_Primitive<T>::_typeName = #NAME; \
	template<> anAttrType	anAttrSpec_Primitive<T>::_type	   = anAttrType_##NAME;	\
	template class anAttrSpec_Primitive<T>;	\
	template class anAttrInst_Primitive<T>;	\
	template class anAttr_Primitive<T>;	\
//---
	TYPE_LIST(int,		int   )
	TYPE_LIST(int64_t,	int64 )
	TYPE_LIST(float,	float )
	TYPE_LIST(double,	double)
	TYPE_LIST(bool,		bool  )
#undef	TYPE_LIST
