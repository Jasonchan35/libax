#include <libanon/node/shader/anNode_Shader.h>

axStatus anNode_Shader::onInitStaticSpec( anNodeSpec & spec ) {


	return 0;
}