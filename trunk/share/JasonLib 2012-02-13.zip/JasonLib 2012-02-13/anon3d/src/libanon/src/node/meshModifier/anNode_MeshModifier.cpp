#include <libanon/node/meshModifier/anNode_MeshModifier.h>

axStatus anNode_MeshModifier::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( outMesh, NULL )
		.setSaveToFile( false )
		.setComputeFunc( &CLASS::_onComputeOutMesh );

	anAttrSpec_INIT( inMesh, NULL );

	anAttrSpec_affect( inMesh,	outMesh );

	return 0;
}

axStatus anNode_MeshModifier::onComputeOutMesh() {
	return outMesh().setValue( inMesh().value() );
}

axStatus anNode_MeshModifier::_onComputeOutMesh ( anAttr *attr ) {
	return onComputeOutMesh();
}