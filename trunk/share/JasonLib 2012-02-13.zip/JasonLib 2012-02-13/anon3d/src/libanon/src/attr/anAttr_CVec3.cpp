#include <libanon/attr/anAttr_CVec3.h>

template<class T>
axStatus anAttrSpec_CVec3<T>::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	const float c = 0.25f;

	anAttrSpec_INIT_CHILD( x )
		.uiSetColor( axColorRGBf(1,c,c) );
	anAttrSpec_INIT_CHILD( y )
		.uiSetColor( axColorRGBf(c,1,c) );
	anAttrSpec_INIT_CHILD( z )
		.uiSetColor( axColorRGBf(c,c,1) );
	return 0;
}

template<class T>
anAttrSpec_CVec3<T>&	anAttrSpec_CVec3<T>::setDefaultValue( const axVec3<T>& v ) { 
	return setDefaultValue(v.x, v.y, v.z); 
}

template<class T>
anAttrSpec_CVec3<T>& anAttrSpec_CVec3<T>::setDefaultValue( T xx, T yy, T zz ) {
	x.setDefaultValue( xx );
	y.setDefaultValue( yy );
	z.setDefaultValue( zz );
	return *this;
}

template<class T>
anAttrSpec_CVec3<T>& anAttrSpec_CVec3<T>::setMinMax	( T minValue, T maxValue )	{ 
	return setMinMax( axVec3<T>(minValue,minValue,minValue), axVec3<T>(maxValue,maxValue,maxValue) ); 
}

template<class T>
anAttrSpec_CVec3<T>& anAttrSpec_CVec3<T>::setMinMax ( const axVec3<T>& minValue, const axVec3<T>& maxValue ) {
	x.setMinMax( minValue.x, maxValue.x );
	y.setMinMax( minValue.y, maxValue.y );
	z.setMinMax( minValue.z, maxValue.z );
	return *this;
}

template<class T>
anAttrSpec_CVec3<T>&	anAttrSpec_CVec3<T>::uiAddSlider () {
	x.uiAddSlider();
	y.uiAddSlider();
	z.uiAddSlider();
	return *this;
}

template<class T>
anAttrSpec_CVec3<T>&	anAttrSpec_CVec3<T>::uiAddDial ( double step ) {
	x.uiAddDial( step );
	y.uiAddDial( step );
	z.uiAddDial( step );
	return *this;
}

//------

template<class T>
axStatus	anAttrInst_CVec3<T>::onSetValue ( anAttr & attr, anAttr & src ) {
	axVec3<T> v;
	switch( src.type() ) {
		case anAttrType_CVec3f: an_convert( v, anAttr_CVec3f(src).value() ); break;
		case anAttrType_CVec3d: an_convert( v, anAttr_CVec3d(src).value() ); break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return ATTR(attr).setValue(v);
}


//------

template<class T>
template<class S>
axStatus	anAttrInst_CVec3<T>::_serialize_io( S &s ) {
	axStatus st;
	st = s.io( x );		if( !st ) return st;
	st = s.io( y );		if( !st ) return st;
	st = s.io( z );		if( !st ) return st;
	return 0;
}

//------

template<class T>
axVec3<T>	anAttr_CVec3<T>::value() { 
	if( ! isValid() ) { assert(false); return axVec3<T>(0,0,0); }
	compute(); 	
	return axVec3<T>( x().value(), y().value(), z().value() ); 
}

template<class T>
axStatus	anAttr_CVec3<T>::setValue( T xx, T yy, T zz ) { 
	x().setValue(xx);
	y().setValue(yy);
	z().setValue(zz);
	return 0;
}

//The explicit instantiation
#define TYPE_LIST(T,NAME) \
	template<> const char*	anAttrSpec_CVec3<T>::_typeName = #NAME; \
	template<> anAttrType	anAttrSpec_CVec3<T>::_type	  = anAttrType_##NAME; \
	template class anAttrSpec_CVec3<T>;	\
	template class anAttrInst_CVec3<T>;	\
	template class anAttr_CVec3<T>;	\
//---
	TYPE_LIST(float,	CVec3f )
	TYPE_LIST(double,	CVec3d )
#undef	TYPE_LIST
