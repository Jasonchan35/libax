#include <libanon/base/anMesh3.h>
#include <libanon/base/anContext.h>


template<class T> const	typename anMesh3<T>::Topology &		anMesh3<T>::topology	() const { return ( topology_  ) ? *topology_  : Topology::kEmpty; }
template<class T> const	typename anMesh3<T>::VertexSet &	anMesh3<T>::vertexSet	() const { return ( vertexSet_ ) ? *vertexSet_ : VertexSet::kEmpty; }

template<class T>
const	typename anMesh3<T>::UVSet &	anMesh3<T>::uvSet		( axSize i ) const	{
	if( ! uvSets_.inBound(i) ) return UVSet::kEmpty;
	return ( uvSets_[i] ) ? *uvSets_[i] : UVSet::kEmpty; 
}



template<class T>
void	anMesh3<T>::set	( anMesh3<T> & src ) {
	setVertexSet	( src );
	setTopology		( src );
}

template<class T>
axStatus anMesh3<T>::toStringFormat( axStringFormat &f ) const {
	return f.format("Mesh face={?}, vertex={?}", numFaces(), numVertices() );
}

template<class T>
axStatus anMesh3<T>::onTake( anMesh3 & src ) {
	axStatus st;
	st = ax_take( topology_,  src.topology_ );	if( !st ) return st;
	st = ax_take( vertexSet_, src.vertexSet_ );	if( !st ) return st;
	return 0;
}

template<class T>
anMesh3<T>::IndexSet::IndexSet() { 
	indexMax = ax_type_max(indexMax);
}

template<class T>
axStatus	anMesh3<T>::IndexSet::onTake( IndexSet & src ) { 
	axStatus st;
	st = ax_take( indices,	src.indices  );		if( !st ) return st;
	st = ax_take( indexMax,	src.indexMax  );	if( !st ) return st;
	return 0;
}

template<class T>
axStatus	anMesh3<T>::IndexSet::setIndices( const axIArray<uint32_t> &src ) {
	axStatus st;
	st = indices.copy( src );	if( !st ) return st;
	recalcIndexMax();
	return 0;
}

template<class T>
void	anMesh3<T>::IndexSet::recalcIndexMax() {
	uint32_t* p = indices.ptr();
	indexMax = 0;
	axSize n = indices.size();
	for( axSize i=0; i<n; i++ ) {
		ax_max_it( indexMax, p[i] );
	}
}

template<class T>
axStatus	anMesh3<T>::unshare	() {
	axStatus st;
	st = vertexSet_.unshare();		if( !st ) return st;
	st = topology_.unshare();		if( !st ) return st;
	return 0;
}

template<class T>
axStatus anMesh3<T>::serialize_io( axSerializer &s ) {
//	axPRINT_FUNC_NAME
	axStatus st;
	st = s.io( (VertexSet&) vertexSet() );		if( !st ) return st;
	st = s.io( (Topology& ) topology() );		if( !st ) return st;

/*
	for( axSize i=0; i<numUVSets(); i++ ) {
		st = s.io( (UVSet&)uvSet(i) );			if( !st ) return st;
	}
*/
	return 0;
}

template<class T>
axStatus anMesh3<T>::serialize_io( axDeserializer &s ) {
//	axPRINT_FUNC_NAME
	axStatus st;

	st = vertexSet_.newObjectIfNull();		if( !st ) return st;
	st = s.io( *vertexSet_ );				if( !st ) return st;

	st = topology_.newObjectIfNull();		if( !st ) return st;
	st = s.io( *topology_ );				if( !st ) return st;

	return 0;
}

template<class T>
axStatus	anMesh3<T>::setVertices	( const axIArray< axVec3<T> > &v ) {
	axStatus st;
	st = vertexSet_.newObjectIfNull();		if( !st ) return st;
	st = vertexSet_->vertices.copy( v );	if( !st ) return st;
	return 0;
}

template<class T>
const axIArray< axVec3<T> >	&	anMesh3<T>::vertices() const {
	return vertexSet().vertices;
}

template<class T>
axVec3<T>*	anMesh3<T>::vertexPtr	() {
	if( ! vertexSet_ ) return NULL;
	return vertexSet_->vertices.ptr();
}

template<class T>
const axVec3<T>*	anMesh3<T>::vertexPtr	() const {
	if( ! vertexSet_ ) return NULL;
	return vertexSet_->vertices.ptr();
}

template<class T>
axStatus	anMesh3<T>::setNumVertices	( axSize n ) {
	axStatus st;
	st = vertexSet_.newObjectIfNull();		if( !st ) return st;
	vertexSet_->vertices.resize(n, false);
	return 0;
}

template<class T>
axSize		anMesh3<T>::numVertices	() const {
	return vertexSet().vertices.size();
}

template<class T>
axStatus	anMesh3<T>::setFaceVertices	( const axIArray<Index> & faceVertexCounts, const axIArray<Index> & faceVertexIndices ) {
	axStatus st;
	st = topology_.newObjectIfNull();		if( !st ) return st;

	st = topology_->faceVertices.setIndices( faceVertexIndices );		if( !st ) return st;

	axSize numFaces = faceVertexCounts.size();
	st = topology_->faces.resize( numFaces );	if( !st ) return st;
	Face* face = topology_->faces.ptr();

	const Index* pCount = faceVertexCounts.ptr();
	const Index* eCount = pCount + faceVertexCounts.size();
	Index	offset = 0;
	for( ; pCount < eCount; pCount++, face++ ) {
		face->vertexOffset = offset;
		offset += *pCount;
		face->vertexCount  = *pCount;
	}
	return 0;
}

template<class T>
axSize	anMesh3<T>::numFaces() const {
	return topology().faces.size();
}

template<class T>
const typename anMesh3<T>::Face*	anMesh3<T>::facePtr() const {
	if( ! topology_ ) return NULL;
	return topology_->faces.ptr();
}

template<class T>
axSize	anMesh3<T>::numUVSets() const {
	return topology().faceVertexUVSets.size();
}

//-------- glDraw ----
template<class T>
void	anMesh3<T>::glDrawVertices( anGLRenderRequest &req ) const {
	if( ! vertexSet_ ) return;
	axScopeGLVertexPointer vp( vertexSet_->vertices.ptr() );
	glDrawArrays( GL_POINTS, 0, (GLsizei) vertexSet_->vertices.size() );
}

template<class T>
void	anMesh3<T>::glDrawVertexIDs	( anGLRenderRequest &req ) const {
	if( ! vertexSet_ ) return;
/*
	axStringA_<16>	str;

	axGLContext* gl = axGLContext::getCurrent();
	if( !gl ) return;

	axSize n  = vertexSet_->vertices.size();
	const Vertex* v = vertexSet_->vertices.ptr();
	for( axSize i=0; i<n; i++, v++ ) {
		str.format("{?}", i );
//		gl->drawText( to_axVec3f(*v), str );
	}
 */
}

template<class T>
void	anMesh3<T>::glDrawFaces( anGLRenderRequest &req ) const {
	if( ! vertexSet_ ) return;
	if( ! topology_  ) return;

//validate
	axSize numFaces = topology_->faces.size();
	if( numFaces == 0 ) return;
	if( ! vertexSet_->vertices.inBound( topology_->faceVertices.indexMax ) ) { /*assert(false);*/ return; }

//draw
	axScopeGLVertexPointer	vp( vertexSet_->vertices.ptr() );
	const Index *s = topology_->faceVertices.indices.ptr();

	const Face* face = topology_->faces.ptr();
	for( axSize i=0; i<numFaces; i++ ) {
		Index c = face[i].vertexCount;
		glDrawElements( GL_LINE_LOOP, (GLsizei)c, s );
		s += c;
	}

}

template<class T>
void	anMesh3<T>::glDrawTriangles( anGLRenderRequest &req, bool fill ) const {
	TriMesh	triMesh;
	triMesh.triangulate( *this );
	triMesh.update( *this );


	axScopeGLVertexPointer	vp( triMesh.vertices.ptr() );

	if( fill ) {
		glDrawElements( GL_TRIANGLES, triMesh.triIndices );
	}else{
		TriIndex *p = triMesh.triIndices.ptr();
		axSize numTri = triMesh.triIndices.size() / 3;
		for( TriIndex i=0; i<numTri; i++ ) {
			glDrawElements( GL_LINE_LOOP, 3, p );
			p += 3;
		}
	}
}

template<class T>
axStatus	anMesh3<T>::TriMesh::update	( const anMesh3<T> & mesh ) {
	axStatus st;
	axSize n = vertexInMesh.indices.size();

	{	st = vertices.resize(n);	if( !st ) return st;
		Index*  index = vertexInMesh.indices.ptr();
		const Vertex* src   = mesh.vertexPtr();
			  Vertex* dst   = vertices.ptr();
			  Vertex* e     = dst+n;
		for( ; dst<e; dst++, index++ ) {
			*dst = src[*index];
		}
	}

	return 0;
}

template<class T>
axStatus anMesh3<T>::TriMesh::triangulate( const anMesh3<T> &mesh ) {
	axStatus st;

	axSize numFaces = mesh.numFaces();
	const Face* face = mesh.facePtr();		if( !face ) return 0;
	const Face* e    = face + numFaces;
	for( ; face<e; face++ ) {
		st = triangulateFace_( mesh, *face );	if( !st ) return st;
	}

	return 0;
}

template<class T>
axStatus	anMesh3<T>::TriMesh::addTriangle_	( const anMesh3<T> & mesh, TriIndex triVertexStart, Index a, Index b, Index c ) {
	axStatus st;
	Polygon	polygon;
	st = polygon.resize(3);		if( !st ) return st;
	polygon[0] = a;
	polygon[1] = b;
	polygon[2] = c;
	st = addTriangleFan_( mesh, triVertexStart, polygon );		if( !st ) return st;
	return 0;
}

template<class T>
axStatus	anMesh3<T>::TriMesh::appendFaceVertex_ ( IndexSet & dst, const Face & face, const IndexSet & src ) {
	axStatus st;

	axSize n   = face.vertexCount;
	if( face.vertexOffset + n > src.indices.size() ) { 
		assert(false);
		return -1;
	}

	axSize old = dst.indices.size();
	st = dst.indices.incSize(n);			if( !st ) return st;
		  Index* d = & dst.indices[old];
	const Index* s = & src.indices[ face.vertexOffset ];
	const Index* e = s + n;
 
	for( ; s<e; s++, d++ ) {
		*d = *s;
	}
	return 0;
}

template<class T>
axStatus	anMesh3<T>::TriMesh::addTriangleFan_ ( const anMesh3<T> & mesh, TriIndex triVertexStart, const Polygon & polygon ) {
	axStatus st;
//	const Topology & topo = mesh.topology();

// Triangle Indices
	Index  n = (Index) polygon.size();
	Index  numTri = n-2;

	TriIndex  old = (TriIndex) triIndices.size();
	st = triIndices.incSize( numTri * 3 );		if( !st ) return st;
	TriIndex* dst = & triIndices[old];
	
	if( triVertexStart + n > vertexInMesh.indices.size() ) {
		assert(false);
		return -1;
	}

	const TriIndex* v = polygon.ptr();
		  TriIndex  fanOrigin = triVertexStart + v[0];	
	  
	v++;
	for( axSize i=0; i<numTri; i++ ) {
		*dst = fanOrigin;					dst++;
		*dst = triVertexStart + (*v);	dst++;	v++;
		*dst = triVertexStart + (*v);	dst++;	v++;
	}
	return 0;
}



template<class T>
axStatus	anMesh3<T>::TriMesh::sweepX_( const anMesh3<T> & mesh, TriIndex triVertexStart, Polygon &polygon, bool &outSplitePolygon ) {
//	ax_log("sweep {?}\n", polygon );

	axStatus st;
	outSplitePolygon = false;
	
	const axIArray<Vertex>	& meshVertex	  = mesh.vertices();
	const axIArray<Index>	& meshVertexIndex = vertexInMesh.indices;

	Index	numVertex = (Index)polygon.size();
	axArray<Vertex,64>	vertex;

	st = vertex.resize( numVertex );	if( !st ) return st;
	for( Index i=0; i<numVertex; i++ ) {
		vertex[i] = meshVertex[ meshVertexIndex[ polygon[i] ] ];
		//ax_log("vertex {?} {?}", i, vertex[i] );
	}


	Index	cur;
	Index   cur_x = 0;
	Index	cur_y = 0;
	Index	cur_z = 0;
	
	Vertex		vtx = vertex[0];
	axVec3<T>	vtx_min = vtx;
	axVec3<T>	vtx_max = vtx;

	for( Index i=1; i<numVertex; i++ ) {
		vtx = vertex[i];
		if( vtx.x > vtx_max.x ) { vtx_max.x = vtx.x; }
		if( vtx.y > vtx_max.y ) { vtx_max.y = vtx.y; }
		if( vtx.z > vtx_max.z ) { vtx_max.z = vtx.z; }

		if( vtx.x < vtx_min.x ) { vtx_min.x = vtx.x; cur_x = i; }
		if( vtx.y < vtx_min.y ) { vtx_min.y = vtx.y; cur_y = i; }
		if( vtx.z < vtx_min.z ) { vtx_min.z = vtx.z; cur_z = i;	}
	}

	//choose most wide axis
	Vertex vtx_d = vtx_max - vtx_min;
	if( vtx_d.x > vtx_d.y ) {
		if( vtx_d.x > vtx_d.z ) {
			cur = cur_x;
		}else{
			cur = cur_z;
		}
	}else{
		if( vtx_d.y > vtx_d.z ) {
			cur = cur_y;
		}else{
			cur = cur_z;
		}
	}
	
	Index last = (Index)numVertex - 1;
	Index prev = ( cur == 0 ) ? last : cur - 1;
	Index next = ( cur == last ) ? 0 : cur + 1;
	
	Vertex	prev_vertex = vertex[prev];
	Vertex	next_vertex = vertex[next];
	Vertex	cur_vertex  = vertex[cur];
	
	Vertex	pn_dir = ( prev_vertex - next_vertex ).normal();
	Vertex	cn_dir = ( cur_vertex  - next_vertex ).normal();
	
//	ax_log("start = {?} {?}", meshVertexIndex[polygon[cur]], vertex[cur]);

	if( cn_dir.isParallel( pn_dir ) ) {	
		st = addTriangle_( mesh, triVertexStart, polygon[prev], polygon[cur], polygon[next] );	if( !st ) return st;
//		ax_log("remove vertex = {?}", polygon[cur] );
		polygon.remove( cur );
		return 0;
	}
	
	//find the far intersected vertex
	axPlane3<T>	sweepPlane( next_vertex, cn_dir.reflectHalf( pn_dir ).normal() );
	
	Index	far_idx = cur;
	T		far_dis = -1;
	for( Index i=0; i<numVertex; i++ ) {
		if( i == cur  ) continue;
		if( i == prev ) continue;
		if( i == next ) continue;

		if( ! vertex[i].isInsideTriangle( prev_vertex, cur_vertex, next_vertex ) ) continue;

		T	dis = sweepPlane.distance( vertex[i] );
//		if( dis < 0 ) continue; //skip back side
	
		if( dis > far_dis ) { //find vertex that inside this triangle and farthest to sweep plane
			far_dis = dis;
			far_idx = i;
		}
	}	
	
	if( far_idx == cur  ){ //no intersect
		st = addTriangle_( mesh, triVertexStart, polygon[prev], polygon[cur], polygon[next] );	if( !st ) return st;
//		ax_log("remove vertex = {?}", meshVertexIndex[polygon[cur]] );
		polygon.remove( cur );
		return 0;
	}

//	ax_log("split {?},{?}", meshVertexIndex[polygon[cur]], meshVertexIndex[polygon[far_idx]]);
	
	//split polygon	
	outSplitePolygon = true;
	Index start = ax_min( far_idx, cur );
	Index end   = ax_max( far_idx, cur );
	
	Polygon newPolygon1, newPolygon2;

	// polygon1
	// start to end
	st = newPolygon1.setValues	( &polygon[start], end - start + 1 );	if( !st ) return st;

	// poylgon2
	//  0 to start
	st = newPolygon2.setValues	( &polygon[0], start+1 );				if( !st ) return st;
	//  end to numVi
	st = newPolygon2.appendN	( &polygon[end], numVertex - end );		if( !st ) return st;

//	ax_log("split numVi={?},start={?} end={?}\n{?}\n{?}\n{?}\n", numVertex, start, end, polygon, newPolygon1, newPolygon2 );

	st = polygonArray.appendByTake( newPolygon1 );					if( !st ) return st;
	st = polygonArray.appendByTake( newPolygon2 );					if( !st ) return st;

	polygonArray.remove(0);

	return 0;
}


template<class T>
axStatus anMesh3<T>::TriMesh::triangulateFace_( const anMesh3<T> & mesh, const Face & face ) {
//	axPRINT_FUNC_NAME

	axStatus st;
	const Topology & topo = mesh.topology();

	if( face.vertexCount > kTriMesh_NumVertexMax ) {
		assert(false);
		return -1;
	}
	if( vertexInMesh.indices.size() > kTriMesh_NumVertexMax - face.vertexCount ) {
		assert(false);
		return -1;
	}

	TriIndex triVertexStart = (TriIndex) vertexInMesh.indices.size();
	TriIndex n = (TriIndex) face.vertexCount;

	st = appendFaceVertex_( vertexInMesh, face, topo.faceVertices );		if( !st ) return st;

	//add first polygon
	{	st = polygonArray.resize(1);		if( !st ) return st;
		Polygon & polygon = polygonArray[0];

		st = polygon.resize( n );			if( !st ) return st;

		TriIndex* s = polygon.ptr();
		for( TriIndex i=0; i<n; i++, s++ ) {
			*s = i;
		}
	}

	for( TriIndex i=0; i<n; i++ ) {
		if( polygonArray.size() == 0 ) break; 
		
		Polygon	& polygon = polygonArray[0];

		if( polygon.size() == 0 ) {
			polygonArray.remove(0);
			continue;
		}

		if( polygon.size() < 3 ) {
			ax_log(" error polygon vertices {?} < 3", polygon.size() );
			//assert(false);
			polygonArray.remove(0);
			continue;
		}
		
		if( polygon.size() == 3 ) {
			st = addTriangleFan_( mesh, triVertexStart, polygon );		if( !st ) return st;
		//	ax_log("polygon vertices == 3");
			polygonArray.remove(0);
			continue;
		}
		
		bool splitePolygon;
		st = sweepX_( mesh, triVertexStart, polygon, splitePolygon );	if( !st ) return st;
	}
	
	// all polygon reminded should be convex
	for( axSize i=0; i<polygonArray.size(); i++ ) {
		st = addTriangleFan_( mesh, triVertexStart, polygonArray[i] );	if( !st ) return st;
	}
	return 0;
}

template<class T>	const anMesh3<T>						anMesh3<T>::kEmpty;
template<class T>	const typename anMesh3<T>::Topology		anMesh3<T>::Topology::kEmpty;
template<class T>	const typename anMesh3<T>::VertexSet	anMesh3<T>::VertexSet::kEmpty;
template<class T>	const typename anMesh3<T>::UVSet		anMesh3<T>::UVSet::kEmpty;

//--- The explicit instantiation
template	class anMesh3<float >;
template	class anMesh3<double>;
	
