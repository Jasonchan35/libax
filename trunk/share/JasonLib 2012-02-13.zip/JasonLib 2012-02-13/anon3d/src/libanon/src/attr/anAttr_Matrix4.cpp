#include <libanon/attr/anAttr_Matrix4.h>

template<class T>
axStatus anAttrSpec_Matrix4<T>::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	defaultValue_.setIdentity();
	return 0;
}

template<class T>
anAttrSpec_Matrix4<T>& anAttrSpec_Matrix4<T>::setDefaultValue( const axMatrix4<T> &value ) {
	defaultValue_ = value;
	return *this;
}

template<class T>
axStatus	anAttrInst_Matrix4<T>::onSetValue	( anAttr & attr, anAttr & src ) {
	switch( src.type() ) {
		case anAttrType_Matrix4f: an_convert( value_, anAttr_Matrix4f(src).value() ); break;
		case anAttrType_Matrix4d: an_convert( value_, anAttr_Matrix4d(src).value() ); break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return 0;
}

template<class T>
axStatus	anAttrInst_Matrix4<T>::onSetValueToDefault	( anAttr & attr ) {
	SPEC* sp = (SPEC*)attr.spec();
	value_ = sp->defaultValue();
	return 0;
}

template<class T>
axStatus	anAttrInst_Matrix4<T>::onToString	( anAttr & attr, axIStringA & out ) {
	return out.convert( value_ );
}

template<class T>
axStatus	anAttrInst_Matrix4<T>::onSerialize	( anAttr & attr, axSerializer	&s ) { return s.io(value_); }

template<class T>
axStatus	anAttrInst_Matrix4<T>::onSerialize	( anAttr & attr, axDeserializer	&s ) { return s.io(value_); }

//------
template<class T>
axMatrix4<T> anAttr_Matrix4<T>::value	() { 
	if( ! isValid() ) { assert(false); return axMatrix4<T>::kIdentity; }
	compute(); 	
	return ((INST*)_inst())->value_; 
}

template<class T>
axStatus	anAttr_Matrix4<T>::setValue( const axMatrix4<T> & v ) {
	((INST*)_inst())->value_ = v; 
	valueChanged();
	return 0;
}

//The explicit instantiation
#define TYPE_LIST(T,NAME) \
	template<> const char*	anAttrSpec_Matrix4<T>::_typeName = #NAME;	\
	template<> anAttrType	anAttrSpec_Matrix4<T>::_type = anAttrType_##NAME; \
	template class anAttrSpec_Matrix4<T>;	\
	template class anAttrInst_Matrix4<T>;	\
	template class anAttr_Matrix4<T>;	\
//---
	TYPE_LIST(float,	Matrix4f )
	TYPE_LIST(double,	Matrix4d )
#undef	TYPE_LIST
