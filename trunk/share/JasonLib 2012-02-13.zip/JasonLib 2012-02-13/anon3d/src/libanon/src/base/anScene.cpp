#include <libanon/base/anScene.h>
#include <libanon/base/anContext.h>
#include <libanon/base/anGLRenderRequest.h>

anScene::anScene() {
//	nodeTable_.setSize( 128 );
	axStatus st;
	st = createNode( sceneRoot_, anNode_SceneRoot::kName );	if( !st ) return;
}

anScene::~anScene() {
	deleteAllNodes();
}

void anScene::deleteAllNodes() {
	nodeTable_.clear();
}

anScene::FileHeader::FileHeader() {
	signature.set( "AnonScene" );
	version = 0x0100;
	numNodes = 0;
	numConnections = 0;
}

axStatus	anScene::toStringFormat	( axStringFormat &f ) const {
	NodeTable::Iterator it(nodeTable_);

	for( ; it; it.goNext() ) {
		f.format("{?}", *it->node );
	}
	return 0;
}

axStatus	anScene::_addNode	( anNode* node ) {
	return nodeTable_.append( &node->hashNode_ );
}

axStatus	anScene::_removeNode	( anNode* node ) {
	return nodeTable_.remove( &node->hashNode_ );
}

axStatus anScene::createNodeByType( anNode* &node, anNodeType type, const char* name ) {
	axStatus st;
	node = NULL; //for safty
	anNodeSpecRegistry* reg = anNodeSpecRegistry::getInstance();

	anNode* np;
	st = reg->createNodeByType( np, type, name );		if( !st ) return st;

	axAutoPtr<anNode>	ap;
	ap.ref( np );
	ap->_setScene( this );
	st = nodeTable_.append( & ap->hashNode_ );	if( !st ) return st;

	node = ap.unref();
	return 0;
}

anNode* anScene::findNode( const char* name ) {
	uint32_t hash = ax_string_hash( name );
	anNode::HashNode* p = nodeTable_.getListHead( hash );
	for( ; p; p=p->next() ) {
		anNode* node = p->node;
		if( ax_strcmp( node->name(), name ) != 0 ) continue;
		return node;
	}
	return NULL;
}

axStatus anScene::_findAttr	( anAttr & out, const anAttrConnectionInfo &info ) {
	anNode* p = findNode( info.nodeName );
	if( !p ) return -1;
	if( ! p->isKindOf( info.nodeType ) ) return -1;
	return p->findAttrById( out, info.attrId );
}

axStatus anScene::loadFile( const char* filename ) {
	axStatus st;

	axMemMap	mm;
	st = mm.openRead( filename );		if( !st ) return st;

	FileHeader		sceneHdr;
	axDeserializer	de( mm );

	st = de.io( sceneHdr );				if( !st ) return st;

	ax_log( "numNodes={?}, numConnections={?}", sceneHdr.numNodes, sceneHdr.numConnections );

	for( uint32_t i=0; i<sceneHdr.numNodes; i++ ) {
		anNode::FileHeader	nodeHdr;
		st = de.io( nodeHdr );								if( !st ) return st;
		st = de.checkRemain( nodeHdr.byteSize );			if( !st ) return st;

		anNode* node;
		st = createNodeByType( node, nodeHdr.type, nodeHdr.name );	if( !st ) return st;

		axExternalByteArray		nodeBuf( (uint8_t*)de.r_, nodeHdr.byteSize );
		axDeserializer	de_node( nodeBuf );
		st = de_node.io( *node );							if( !st ) return st;

		if( node->type() == anNodeType_SceneRoot ) {
			sceneRoot_.ref( (anNode_SceneRoot*)node );
		}

		de._advance( nodeHdr.byteSize );
	}

//set parent of Nodes
	NodeTable::Iterator it(nodeTable_);
	for( ; it; it.goNext() ) {
		anNode* node = it->node;
		if( node == sceneRoot_ ) continue;
		anNode* parentNode = findNode( node->parentName() );
		if( parentNode ) {
			parentNode->appendChild( node );
		}else{
			sceneRoot_->appendChild( node );
		}
	}

//read connections
	anAttrConnectionInfo	connOwner, connSrc;
	for( uint32_t i=0; i<sceneHdr.numConnections; i++ ) {
		st = de.io( connOwner );	if( !st ) return st;
		st = de.io( connSrc	  );	if( !st ) return st;

		anAttr	attr;
		st = _findAttr( attr, connOwner );		
		if( !st ) return -1;

		anAttr	src;
		st = _findAttr( src, connSrc );
		if( st ) {
			st = src.connect( attr );	if( !st ) return st;
		}else{
			st = attr.newInputConnection( connSrc.nodeType, connSrc.nodeName, connSrc.attrId );
			if( !st )return -1;
		}
	}

	return 0;
}

axStatus	anScene::saveFile( const char* filename ) {
	axStatus	st;

	axFile	file;
	st = file.openWrite( filename, true );		if( !st ) return st;

	axByteArray	buf;
	buf.reserve( 16 * 1024 );
	axByteArray_<256>	hdrBuf;

	anScene::FileHeader	sceneHdr;
	st = ax_safe_assign( sceneHdr.numNodes, numNodes() );				if( !st ) return st;

	axArray< anAttrConnection* >	connections;
	st = getAllInputConnectionsRecursively( connections );				if( !st ) return st;
	st = ax_safe_assign( sceneHdr.numConnections, connections.size() );	if( !st ) return st;

	//write scene file header
	st = ax_serialize_to_buf( hdrBuf, sceneHdr );	if( !st ) return st;
	file.write( hdrBuf );


	NodeTable::Iterator it(nodeTable_);
	for( ; it; it.goNext() ) {
		anNode* node = it->node;
		st = ax_serialize_to_buf( buf, *node );		if( !st ) return st;

	//header
		anNode::FileHeader	nodeHdr;
		nodeHdr.type = node->type();
		st = nodeHdr.name.set( node->name() );						if( !st ) return st;
		st = ax_safe_assign( nodeHdr.byteSize, buf.size() );		if( !st ) return st;
		st = ax_serialize_to_buf( hdrBuf, nodeHdr );				if( !st ) return st;

	//write
		st = file.write( hdrBuf );		if( !st ) return st;
		st = file.write( buf );			if( !st ) return st;

		ax_log( "write node {?}", nodeHdr );
	}

	//save connection
	for( axSize i=0; i<connections.size(); i++ ) {
		anAttrConnection* c = connections[i];
//		ax_log( "{?}", *c );
		anAttrConnectionInfo	connOwner;
		st = connOwner._setByAttr( c->owner );		if( !st ) return st;

		buf.resize(0);

		axSerializer	se( buf );
		st = se.io( connOwner );				if( !st ) return st;
		st = se.io( c->sourceInfo );			if( !st ) return st;

		st = file.write( buf );
	}
	return 0;
}

axStatus	anScene::getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list ) {
	axStatus st;

	NodeTable::Iterator it(nodeTable_);
	for( ; it; it.goNext() ) {
		anNode* node = it->node;
		st = node->getAllInputConnectionsRecursively( list );		if( !st ) return st;
	}
	return 0;
}

anNode_SceneRoot* anScene::sceneRoot() {
	return sceneRoot_;
}

axStatus	anScene::renderGL	( anGLRenderRequest &req ) {
	if( ! sceneRoot_ ) return 0;
	sceneRoot_->glRender( req );
	return 0;
}

void		anScene::advanceTime	( double seconds ) {
	if( ! sceneRoot_ ) return;
	anAttr_double t = sceneRoot_->currentTime();
	t.setValue( t.value() + seconds );
}
