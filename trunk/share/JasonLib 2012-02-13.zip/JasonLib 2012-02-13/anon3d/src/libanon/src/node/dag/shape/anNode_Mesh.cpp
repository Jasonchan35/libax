#include <libanon/node/dag/shape/anNode_Mesh.h>

axStatus anNode_Mesh::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( inMesh, NULL );

	anAttrSpec_INIT( outMesh, NULL )
		.setSaveToFile( false )
		.setComputeFunc( &CLASS::onComputeOutMesh );

	anAttrSpec_affect( inMesh,	outMesh );
	return 0;
}

axStatus anNode_Mesh::onComputeOutMesh ( anAttr *attr ) {
	return outMesh().setValue( inMesh().value() );
}

void	anNode_Mesh::onGLRender		( anGLRenderRequest &req ) {
	if( ! visible().value() ) return;
	/*
	if( shader ) {
		shader->addRenderToQueue( this );
	}
	*/

	const anMesh3f&	mesh = outMesh().value();

	axScopeGLMultMatrix	currentMatrix( req.currentMatrix() );

//---
//	glColor3f( 0,1,0 );
//	mesh.glDrawTriangles( req, false );
//---
	glColor4f( 0,0,1, 1 );
	mesh.glDrawTriangles( req, true );
//---
	glColor3f( 1,1,1 );
	mesh.glDrawFaces( req );
//---
	/*
	glPointSize( 5 );
	glColor3f( 1,1,0 );
	mesh.glDrawVertices( req );
	glPointSize( 1 );
*/
//---
//	mesh.glDrawVertexIDs( req );

//---
	glColor3f( 1,1,1 );
//	axGLDrawAxis();
}