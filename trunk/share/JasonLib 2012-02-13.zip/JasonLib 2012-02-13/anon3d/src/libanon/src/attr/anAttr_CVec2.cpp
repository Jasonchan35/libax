#include <libanon/attr/anAttr_CVec2.h>

template<class T>
axStatus anAttrSpec_CVec2<T>::onCreate( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
	anAttrSpec_INIT_CHILD( x );
	anAttrSpec_INIT_CHILD( y );
	return 0;
}

template<class T>
anAttrSpec_CVec2<T>& anAttrSpec_CVec2<T>::setDefaultValue( T xx, T yy ) {
	x.setDefaultValue( xx );
	y.setDefaultValue( yy );
	return *this;
}

template<class T>
anAttrSpec_CVec2<T>&	anAttrSpec_CVec2<T>::setDefaultValue( const axVec2<T>& v ) { 
	return setDefaultValue(v.x, v.y); 
}


template<class T>
anAttrSpec_CVec2<T>&	anAttrSpec_CVec2<T>::setMinMax	( T minValue, T maxValue )	{ 
	return setMinMax( axVec2<T>(minValue,minValue), axVec2<T>(maxValue,maxValue) ); 
}

template<class T>
anAttrSpec_CVec2<T>& anAttrSpec_CVec2<T>::setMinMax( const axVec2<T>& minValue, const axVec2<T>& maxValue ) {
	x.setMinMax( minValue.x, maxValue.x );
	y.setMinMax( minValue.y, maxValue.y );
	return *this;
}

template<class T>
anAttrSpec_CVec2<T>&	anAttrSpec_CVec2<T>::uiAddSlider ()	{ 
	x.uiAddSlider();
	y.uiAddSlider();
	return *this;
}

template<class T>
anAttrSpec_CVec2<T>& anAttrSpec_CVec2<T>::uiAddDial( double step ) {
	x.uiAddDial( step );
	y.uiAddDial( step );
	return *this;
}

//--------

template<class T>
axStatus	anAttrInst_CVec2<T>::onSetValue ( anAttr & attr, anAttr & src ) {
	axVec2<T> v;
	switch( src.type() ) {
		case anAttrType_CVec2f: an_convert( v, anAttr_CVec2f(src).value() ); break;
		case anAttrType_CVec2d: an_convert( v, anAttr_CVec2d(src).value() ); break;
		default: return axStatus_Anon_unsupport_value_type;
	}
	return ATTR(attr).setValue(v);
}
//------

template<class T>
axVec2<T>	anAttr_CVec2<T>::value() { 
	if( ! isValid() ) { assert(false); return axVec2<T>(0,0); }
	compute();
	return axVec2<T>( x().value(), y().value() ); 
}

template<class T>
axStatus anAttr_CVec2<T>::setValue( T xx, T yy ) { 
	x().setValue(xx);
	y().setValue(yy);
	return 0;
}

//The explicit instantiation
#define TYPE_LIST(T,NAME) \
	template<> const char*	anAttrSpec_CVec2<T>::_typeName = #NAME; \
	template<> anAttrType	anAttrSpec_CVec2<T>::_type	  = anAttrType_##NAME; \
	template class anAttrSpec_CVec2<T>;	\
	template class anAttrInst_CVec2<T>;	\
	template class anAttr_CVec2<T>;	\
//---
	TYPE_LIST(float,	CVec2f )
	TYPE_LIST(double,	CVec2d )
#undef	TYPE_LIST
