#include <libanon/attr/anAttrConnection.h>
#include <libanon/base/anContext.h>

axStatus	anAttrConnectionInfo::toStringFormat( axStringFormat &f ) const {
	return f.format("type={?}, name={?}, attrId={?}", nodeType, nodeName, attrId );
}

axStatus	anAttrConnectionInfo::_setByAttr( anAttr & a ) {
	if( ! a.isValid() ) return -1;
	axStatus st;
	anNode* p = a.node();
	nodeType = p->type();
	st = nodeName.set( p->name() );		if( !st ) return st;
	st = a.getAttrId( attrId );			if( !st ) return st;
	return 0;
}

//---------

anAttrConnection::anAttrConnection() {
	setOwnedByList( false );
}

axStatus	anAttrConnection::toStringFormat( axStringFormat &f ) const {
	return f.format("owner({?})\n   <= source({?}, {?})", owner, source, sourceInfo );
}

void anAttrConnection::onWillRemoveFromList() {
	owner.unshare();
}
