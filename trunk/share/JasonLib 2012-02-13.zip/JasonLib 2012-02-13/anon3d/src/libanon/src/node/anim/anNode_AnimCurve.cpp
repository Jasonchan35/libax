#include <libanon/node/anim/anNode_AnimCurve.h>

const float sMachineTolerance = ax_fp_epsilon<float>();
const float	k_1_over_3 = 1.0f / 3.0f;
const float k_tangentMax  = 5729.57789f; 

static float inCycle( float s, float e, float v, float &cycle ) {
	float d = v-s;
	float w = e-s;
	if( w <= 0 ) {
		cycle = 0;
		return s;
	}

	cycle = floor( d/w );
	float r = d - (cycle * w);

	if( r < 0 ) { r += w; cycle--; }
	return r + s;
}

axStatus anNode_AnimCurve::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( output,	NULL )
		.setComputeFunc( &CLASS::onComputeOutput );

	anAttrSpec_INIT( input,		NULL );

	anAttrSpec_affect( input, output );
	return 0;
}

anNode_AnimCurve::anNode_AnimCurve() {
	preInfinityType_  = it_constant;
	postInfinityType_ = it_constant;
	weightedCurve_ = false;
	isStaticCurve_ = false;
}

void	anNode_AnimCurve::setPreInfinityType( uint8_t t ) {
	preInfinityType_ = t;
}

uint8_t	anNode_AnimCurve::preInfinityType	() const {
	return 	preInfinityType_;
}

void	anNode_AnimCurve::setPostInfinityType( uint8_t t ) {
	postInfinityType_ = t;
}

uint8_t	anNode_AnimCurve::postInfinityType	() const {
	return 	postInfinityType_;
}

template<class S> inline
axStatus	anNode_AnimCurve::_onSerialize( S &s ) {
	axStatus	st;
	st = B::onSerialize( s );		if( !st ) return st;
	st = s.io( preInfinityType_ );	if( !st ) return st;
	st = s.io( postInfinityType_);	if( !st ) return st;

	st = s.io( keys_ );				if( !st ) return st;
	return 0;
}

axStatus	anNode_AnimCurve::onSerialize	( axSerializer		&s ) { return _onSerialize(s); }
axStatus	anNode_AnimCurve::onSerialize	( axDeserializer	&s ) { return _onSerialize(s); }

axStatus	anNode_AnimCurve::onComputeOutput( anAttr* attr ) {
	axStatus st;
	float value = 0;
	st = evaluate( value, input().value() );		if( !st ) return st;
//	ax_print("{?}.{?} time={?} value={?}\n", attr->node()->name(), attr->fullName(), value, input().value() );
	return output().setValue( value );
}

axStatus	anNode_AnimCurve::setKeys( const axIArray<Key>	& keys ) {
	keys_.copy( keys );
	keyCacheDirty_ = true;
	return 0;
}

axStatus anNode_AnimCurve::_buildKeyCache() {
	axStatus st;
	if( ! keyCacheDirty_ ) return 0;
	keyCacheDirty_ = false;

	if( keys_.size() <= 1 ) return 0;

	//check static
	float value = keys_[0].value;
	axSize n = keys_.size();

	isStaticCurve_ = true;
	for( axSize i=1; i<n; i++ ) {
		if( value == keys_[i].value ) {
			isStaticCurve_ = false;
		}
	}

	if ( weightedCurve_ ) {
		//currently not support
	}else{
		axSize n = keys_.size()-1;
		for( axSize i=0; i<n; i++ ) {
			st = _buildHermiteCache( keys_[i], keys_[i+1] ); if( !st ) return st;
		}
	}
	return 0;
}

axStatus anNode_AnimCurve::_buildHermiteCache( Key &sk, Key &ek ) {
	float x1 = sk.time;
	float y1 = sk.value;

	float x2 = sk.time  + sk.outTangent.x * k_1_over_3;
	float y2 = sk.value + sk.outTangent.y * k_1_over_3;

	float x3 = ek.time  - ek.inTangent.x  * k_1_over_3;
	float y3 = ek.value - ek.inTangent.y  * k_1_over_3;

	float x4 = ek.time;
	float y4 = ek.value;

	float w = x4 - x1;
	float h = y4 - y1;

	//the sk.time and ek.time cannot be the same
	if( !w ) { assert(false); return -2001; }

	float tan_x;

	float m1 = k_tangentMax;
	tan_x = x2 - x1;
	if (tan_x != 0) m1 = (y2 - y1) / tan_x;

	float m2 = k_tangentMax;
	tan_x = x4 - x3;
	if (tan_x != 0) m2 = (y4 - y3) / tan_x;

	float length = 1.0f / (w * w);
	float d1 = w * m1;
	float d2 = w * m2;

	sk._c[0] = (d1 + d2 - h - h) * length / w;
	sk._c[1] = (h + h + h - d1 - d1 - d2) * length;
	sk._c[2] = m1;
	sk._c[3] = y1;
	return 0;
}

axStatus	anNode_AnimCurve::evaluate( float & value, float time ) {
	_buildKeyCache();

	axStatus st;
	if( keys_.size() == 0 ) return -1;
	if( isStaticCurve_ || keys_.size() < 2 ) {
		value = keys_[0].value;
		return 0;
	}

	Key	&fk = keys_[0];
	Key	&lk = keys_.last();
	float time_range = lk.time - fk.time;

	//---- pre-infinity -----
	if( time < fk.time ) {	
		float dt = fk.time - time;

		switch( preInfinityType_ ) {
			case it_constant: {
				value =  fk.value;
				return 0;
			}break;

			case it_linear: {
				axVec2f &tan = fk.inTangent;
				if( tan.x == 0 ) {
					value = fk.value;
					return 0;
				}else{
					value = fk.value - ( dt * tan.y ) / tan.x;
					return 0;
				}
			}break;

			case it_cycle: {
				float nCycles;
				float in_time = time_range - inCycle( fk.time, lk.time, time, nCycles );
				return _evaluateInRange( value, in_time );
			}break;
			
			case it_cycle_relative: {
				float nCycles;
				float in_time = time_range - inCycle( fk.time, lk.time, time, nCycles );
				float offset = lk.value - fk.value;
				st = _evaluateInRange( value, in_time );		if( !st ) return st;
				value += (nCycles-1) * offset;
				return 0;
			}break;
			
			case it_oscillate: {
				float nCycles;
				float in_time = inCycle( fk.time, lk.time, time, nCycles ) - fk.time;

				float tmp;
				if( ax_modf( nCycles / 2.0f, &tmp ) ) {
					return _evaluateInRange( value, time_range - in_time + fk.time );
				}else{
					return _evaluateInRange( value, in_time + fk.time );
				}
			}break;
		}
	}

	// --- post-infinity ----
	if( time > lk.time ) {	
		float dt = time - lk.time;
		switch( postInfinityType_ ) {
			case it_constant: {
				value = lk.value;
				return 0;
			}break;

			case it_linear: {
				axVec2f &tan = lk.outTangent;
				if( tan.x == 0 ) {
					value = lk.value;
					return 0;
				}else{
					value = lk.value + ( dt * tan.y ) / tan.x;
					return 0;
				}
			}break;

			case it_cycle: {
				float nCycles;
				float in_time = inCycle( fk.time, lk.time, time, nCycles );
				return _evaluateInRange( value, in_time );
			}break;
			
			case it_cycle_relative: {
				float nCycles;
				float in_time = inCycle( fk.time, lk.time, time, nCycles );
				float offset = lk.value - fk.value;
				st = _evaluateInRange( value, in_time  );		if( !st ) return st;
				value += nCycles * offset;
				return 0;
			}break;
			
			case it_oscillate: {
				float nCycles;
				float in_time = inCycle( fk.time, lk.time, time, nCycles ) -fk.time;

				float tmp;
				if( ax_modf( nCycles / 2.0f, &tmp ) ) {
					return _evaluateInRange( value, time_range - in_time + fk.time );
				}else{
					return _evaluateInRange( value, in_time + fk.time );
				}
			}break;
		}
	}

	return _evaluateInRange( value, time );
}


axStatus anNode_AnimCurve::_evaluateInRange( float & value, float time ) {
	axStatus st;
	if( keys_.size() == 0 ) {
		assert( false ); return 0;
	}

	if( time < keys_[0].time || time > keys_.last().time ) {
		assert( false ); return 0;
	}

	axSize index;
	st = findKey( index, time );		if( !st ) return st;

	Key &sk = keys_[index];
	
	if( index+1 >= keys_.size() ) {
		value = sk.value;	
		return 0;
	}
	
	Key &ek = keys_[index+1];

	if( ax_math_equals( time, sk.time ) ) {
		value = sk.value;	
		return 0;
	}
	if( sk.outTangentType == tt_step ) {
		value = sk.value;	
		return 0;
	}
	
	if( sk.outTangentType == tt_step_next ) {
		value = ek.value;
		return 0;
	}

	//! \todo	tt_plateau,   not implement yet

	if( sk.outTangentType == tt_linear && ek.inTangentType == tt_linear ) {
		float t = ( time - sk.time ) / ( ek.time - sk.time ); 
		value = ax_lerp( sk.value, ek.value, t );
		return 0;
	}

	float t = time - sk.time;
	if ( weightedCurve_ ) {
		//current not support
	}else{
		//hermite curve
		float *c = sk._c;
		value = (t * (t * (t * c[0] + c[1]) + c[2]) + c[3]);
		return 0;
	}
	return 0;
}

axStatus anNode_AnimCurve::findKey( axSize &outIndex, float time ) {
	if( !keys_.size() ) return -1;
	if( time < keys_[0].time ) return -1;

	size_t s   = 0;
	size_t e   = keys_.size() - 1;

	if( time >= keys_[ e ].time ) {
		outIndex = e;
		return true;
	}

	size_t mid;
	for(;;) {
		mid = (e-s) / 2 + s;
		if( time < keys_[mid].time ) {
			e = mid;
		}else{
			if( e-mid == 1 ) {
				outIndex = mid;
				return true;
			}
			s = mid;
		}
	}
}