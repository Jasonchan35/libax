#include <libanon/node/anNode_SceneRoot.h>

const char*	anNode_SceneRoot::kName = "<SceneRoot>";

axStatus anNode_SceneRoot::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( currentTime, NULL );
	return 0;
}
