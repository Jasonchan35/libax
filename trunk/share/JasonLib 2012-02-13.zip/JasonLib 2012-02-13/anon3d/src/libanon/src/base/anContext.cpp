#include <libanon/base/anContext.h>

anContext::anContext() {
}

axStatus anContext::create() {
	axStatus st;

	anNodeSpecRegistry* reg = anNodeSpecRegistry::getInstance();
	if( !reg ) return -1;
	reg->_create();

	return 0;
}

axStatus	anContext::setNodeName		( anNode* node, const char* name ) {
	if( !node ) return -1;
	axStatus st;

	axAutoPtr<anAction_SetNodeName>	ap;
	st = ap.newObject();					if( !st ) return st;
	ap->node = node;
	st = ap->oldName.set( node->name() );	if( !st ) return st;
	st = ap->newName.set( name );			if( !st ) return st;

	st = ap->redo();						if( !st ) return st;
	history.addAction( ap.unref() );
	return 0;
}

template<class ATTR>
axStatus anContext::_setAttr( ATTR & attr, const typename ATTR::VALUE & newValue ) {
	if( ! attr.isValid() ) return -1;
	axStatus st;

	axAutoPtr< anAction_SetAttr<ATTR> >	ap;
	st = ap.newObject();				if( !st ) return st;
	ap->attr = attr;
	ap->oldValue = attr.value();
	ap->newValue = newValue;

	st = ap->redo();					if( !st ) return st;
	history.addAction( ap.unref() );
	return 0;
}

axStatus	anContext::setAttr	( anAttr_bool	&attr, bool		value ) { return _setAttr( attr, value ); }
axStatus	anContext::setAttr	( anAttr_int	&attr, int		value ) { return _setAttr( attr, value ); }
axStatus	anContext::setAttr	( anAttr_float	&attr, float	value ) { return _setAttr( attr, value ); }
axStatus	anContext::setAttr	( anAttr_double	&attr, double	value ) { return _setAttr( attr, value ); }

axStatus	anContext::_makeSelectionUndo() {
/*
	if( actionHistory_.hasUndo() ) {
		AutoPtr< aoAction_add_select > undo;
		st = undo.init();									if( !st ) return st;
		st = undo->old_selection.copy( _selection );		if( !st ) return st;
		st = undo->sel.copy( sel );							if( !st ) return st;
		history.add_action( undo.unref() );
	}
*/
	return 0;
}

axStatus	anContext::setSelection	( const anSelectionList & list ) {
	axStatus	st;
	st = _makeSelectionUndo();				if( !st ) return st;
	st = _removeSelection( selection_ );	if( !st ) return st;
	st = _addSelection( list );				if( !st ) return st;
	evSelectionDidChange();
	return 0;
}

axStatus	anContext::addSelection	( const anSelectionList & list ) {
	axStatus st;
	st = _makeSelectionUndo();		if( !st ) return st;
	st = _addSelection( list );		if( !st ) return st;
	evSelectionDidChange();
	return 0;
}

axStatus	anContext::removeSelection( const anSelectionList & list ) {
	axStatus st;
	st = _makeSelectionUndo();			if( !st ) return st;
	st = _removeSelection( list );		if( !st ) return st;
	evSelectionDidChange();
	return 0;
}

axStatus	anContext::clearSelection	() {
	axStatus st;
	st = _makeSelectionUndo();				if( !st ) return st;
	st = _removeSelection( selection_ );	if( !st ) return st;
	evSelectionDidChange();
	return 0;
}

axStatus anContext::_addSelection( const anSelectionList & list ) {
	//remove duplicate selection first
	_removeSelection( list );

	for( axSize i=0; i<list.size(); i++ ) {
		const anSelection & s = list[i];
		s.node->_setSelected( s, true );
	}
	selection_.append( list );
	return 0;	
}

axStatus anContext::_removeSelection( const anSelectionList & list ) {
	axStatus	st;
	anSelectionList	result;
	st = selection_.remove( list, &result );		if( !st ) return st;

	axSize n = result.size();
	for( axSize i=0; i<n; i++ ) {
		anSelection & s = result[i];
		s.node->_setSelected( s, false );
	}

	return 0;
}
