#include <libanon/node/dag/shape/anNode_Shape.h>

axStatus anNode_Shape::onInitStaticSpec( anNodeSpec & spec ) {

	return 0;
}
