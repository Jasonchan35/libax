#include <libanon/node/all_anNode.h>

anNodeSpecRegistry*	anNodeSpecRegistry::getInstance		() {
	static	anNodeSpecRegistry	s;
	return &s;
}

axStatus	anNodeSpecRegistry::_create() {
	axStatus st;
	if( created_ ) { assert(false); return 0; }
	created_ = true;

	st = nodeSpec_.resize( anNodeType_max );		if( !st ) return st;
	nodeSpec_.setAll( NULL );

	#define anNodeType_enum( TYPE )  \
		st = anNode_##TYPE::initStaticSpec();  \
		if( !st ) return st; \
		nodeSpec_[ anNodeType_##TYPE ] = &anNode_##TYPE::staticSpec();  \
	//end of macro
		#include <libanon/node/anNodeType_enum.h>
	#undef aoNodeType_enum

	return 0;
}

anNodeSpecRegistry::anNodeSpecRegistry() {
	created_ = false;
}

axStatus	anNodeSpecRegistry::createNodeByType( anNode* &node, anNodeType type, const char* name ) {
	axStatus st;
	if( ! nodeSpec_.inBound( type ) ) return axStatus_Anon_invalid_node_type;

	anNodeSpec*	ns = nodeSpec_[type];
	if( !ns ) return axStatus_Anon_invalid_node_type;
	node = ns->createNode();
	st = node->setName( name );	if( !st ) { delete node; return st; }
	st = node->_onCreate(ns);	if( !st ) { delete node; return st; }
	return 0;
}

void	anNodeSpecRegistry::print() {
	for( axSize i=0; i<nodeSpec_.size(); i++ ) {
		anNodeSpec* p = nodeSpec_[i];
		if( !p ) continue;
		ax_print( "{?}\n", *p );
	}
}

anNodeSpec*	anNodeSpecRegistry::nodeSpec( anNodeType t ) {
	if( ! nodeSpec_.inBound(t) ) return NULL;
	return nodeSpec_[t];
}

axStatus	anNodeSpecRegistry::getAttrId ( anNodeType nodeType, const char* fullName, anAttrId & out ) {
	anNodeSpec* s = getInstance()->nodeSpec( nodeType );
	if( !s ) return axStatus_Anon_invalid_node_type;
	return s->getAttrId( fullName, out );
}

//------
anNodeSpec::anNodeSpec() {
	setOwnedByList( false );
	created_ = false;
	sizeofNode_ = 0;
	attr_.setCapacityIncrement( 16 );
}

bool	anNodeSpec::alreadyCreated() {
	return created_;
}

axStatus	anNodeSpec :: create( anNodeSpec* baseClass, anNodeType type, const char* name, anNodeCreatorFunc creatorFunc, axSize sizeofNode ) {
	axStatus st;
	if( created_ ) return 0;
	created_ = true;	

	creatorFunc_	= creatorFunc;
	type_			= type;
	name_			= name;
	sizeofNode_		= sizeofNode;

	if( baseClass ) {
		baseClass_ = baseClass;
		baseClass->derivedClass_.append( this );

		st = attr_.copy( baseClass->attr_ );	if( !st ) return st;
	}
	return 0;
}

anNode* anNodeSpec::createNode() {
	if( ! creatorFunc_ ) return NULL;
	return creatorFunc_();
}

anNodeType	anNodeSpec::type	() const {
	return type_;
}

axStatus anNodeSpec::_addAttr	( anAttrSpec* spec ) {
	axStatus st;
	st = attr_.append( spec );		if( !st ) return st;

	return 0;
}

const char* anNodeSpec::name() const { return name_; }

axStatus anNodeSpec::toStringFormat	( axStringFormat &f ) const {
	f.format("nodeSpec: {?}, {?} bytes\n", name_, sizeofNode_ );

	if( baseClass_ ) {
		f.format("  baseClass: {?}\n", baseClass_->name() );
	}

	f.format("--attr--\n" );
	for( axSize i=0; i<attr_.size(); i++ ) {
		anAttrSpec*	a = attr_[i];
		f.format("  {?}", *a ); 
	}
	f.format("\n");
	return 0;
}

axStatus anNodeSpec::getAttrId( const char* fullName, anAttrId & out ) {
	axStatus st;
	if( ! fullName ) return -1;

	out.clear();

	const char* p;

	size_t	len;
	p = ax_strchr( fullName, '.' );
	if( !p ) p = ax_strchr( fullName, '[' );

	if( p ) {
		len = p - fullName;
	}else{
		len = ax_strlen( fullName );
	}

	axSize n = attr_.size();
	for( axSize i=0; i<n; i++ ) {
		anAttrSpec* a = attr_[i];
		if( ax_strncmp( a->name(), fullName, len ) == 0 ) {
			st = out.append( a->attrSubId() );		if( !st ) return st;

			if( p ) {
				st = a->_getAttrId( p, out );		if( !st ) return st;
			}
			return 0;
		}
	}

	return -1; //not fonud
}

anAttrSpec* anNodeSpec::attr ( axSize idx )	{ 
	if( ! attr_.inBound(idx) ) return NULL;
	return attr_[idx];   
}

axSize	anNodeSpec::numAttr	() const {
	return attr_.size(); 
}
