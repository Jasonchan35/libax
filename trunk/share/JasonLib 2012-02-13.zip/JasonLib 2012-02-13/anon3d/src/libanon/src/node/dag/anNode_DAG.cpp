#include <libanon/node/dag/anNode_DAG.h>

axStatus anNode_DAG::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( visible, NULL );
	return 0;
}

void	anNode_DAG::onGLRenderChild ( anGLRenderRequest &req ) {
	if( ! visible().value() ) return;
	B::onGLRenderChild( req );
}
