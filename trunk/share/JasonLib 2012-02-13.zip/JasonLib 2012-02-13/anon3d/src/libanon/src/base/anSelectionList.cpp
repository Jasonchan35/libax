#include <libanon/base/anSelectionList.h>
#include <libanon/node/anNode.h>

void anSelection::_init() {
	node = NULL;
	componentIds.setCapacityIncrement(0);
}

anSelection::anSelection() {
	_init();
}

anSelection::anSelection( anNode* _node ) {
	_init();
	set( _node );
}

axStatus	anSelection::set	( anNode* _node ) {
	node = _node;
	componentType = anComponentType_null;
	return 0;
}

axStatus	anSelection::set	( anNode* _node, anComponentType _componentType, const axIArray<anComponentId> & _componentIds ) {
	axStatus st;
	node = _node;
	componentType = _componentType;
	st = componentIds.copy( _componentIds );
	return 0;
}

axStatus	anSelection::toStringFormat	( axStringFormat &f ) const {
	f.format( "{?}", node->name() );
	return 0;
}

axStatus	anSelection::onTake	( anSelection & src ) { 
	axStatus st;
	node = src.node;
	componentType = src.componentType;
	st = ax_take( componentIds, src.componentIds );	if( !st ) return st;
	return 0; 
}

//------

anSelectionList::anSelectionList() {
}

axStatus	anSelectionList::append		( const anSelectionList & list ) {
	axStatus st;
	axSize n = list.size();

	for( axSize i=0; i<n; i++ ) {
		st = append( list[i] );		if( !st ) return st;
	}
	return 0;
}

axStatus anSelectionList::append( const anSelection & s ) {
	axStatus st;

	//combine Ids when same node and componentType
	if( list_.size() ) {
		anSelection & o = list_.last();
		if( o.node == s.node && o.componentType == s.componentType ) {		
			st = o.componentIds.appendN( s.componentIds );		if( !st ) return st;
			return 0;
		}
	}

	st = list_.append( s );			if( !st ) return st;
	return 0;
}

axStatus	anSelectionList::copy	( const anSelectionList & list ) {
	list_.clear();
	return append( list );
}

axStatus	anSelectionList::onTake	( anSelectionList & list ) {
	return ax_take( list_, list.list_ );
}

axStatus anSelectionList::toStringFormat	( axStringFormat &f ) const {
	return f.out( list_ );
}

axStatus	anSelectionList::remove	( const anSelectionList & list, anSelectionList* removedResult ) {
	axStatus st;
	axSize	numSelA = list_.size();
	axSize	numSelB = list.size();

	List	newList;

	axArray< bool, 1024 >	lookup;
	anSelection				result;

	for( axSize a=0; a<numSelA; a++ ) {
		anSelection & selA = list_[a];
		
		bool	keep = true;
		
		for( axSize b=0; b<numSelB; b++ ) {
			const anSelection & selB = list.list_[b];
			
			if( selA.node != selB.node ) continue;
			if( selA.componentType != selB.componentType ) continue;
			
			if( selB.isObject() ) {
				//remove this node
				keep = false;
				if( removedResult ) {
					removedResult->append( selB );
				}
				break;
			}
			
			//component

			//build lookup
			anComponentId		maxId = 0;

			axSize	numCompA = selA.componentIds.size();
			axSize	numCompB = selB.componentIds.size();

					anComponentId* compA = selA.componentIds.ptr();
			const	anComponentId* compB = selB.componentIds.ptr();

			for( axSize i=0; i<numCompA; i++ ) {
				ax_max_it( maxId, compA[i] );
			}

			st = lookup.resize( maxId, false );		if( !st ) return st;
			lookup.setAll( false );

			for( axSize i=0; i<numCompA; i++ ) {
				lookup[ compA[i] ] = true;
			}

			result.node = selB.node;
			result.componentType = selB.componentType;
			result.componentIds.clear();
			if( removedResult ) {
				result.componentIds.reserve( maxId );
			}
		
			for( axSize i=0; i<numCompB; i++ ) {
				if( compB[i] >= maxId ) continue;
				if( lookup[ compB[i] ] ) {
					lookup[ compB[i] ] = false;

					if( removedResult ) {
						result.componentIds.append( compB[i] );
					}
				}
			}

			//rebuild selA
			selA.componentIds.clear();
			for( anComponentId i=0; i<maxId; i++ ) {
				if( lookup[i] ) {
					selA.componentIds.append(i);
				}
			}

			if( selA.componentIds.size() == 0 ) {
				keep = false;
			}
			break;
		}

		if( keep ) {
			st = newList.append( selA );			if( !st ) return st;
		}
	}

	return list_.onTake( newList );
}
