#include <libanon/node/dag/transform/anNode_Transform.h>

axStatus anNode_Transform::onInitStaticSpec( anNodeSpec & spec ) {
	anAttrSpec_INIT( translate, NULL )
		.uiAddDial( 0.1 );

	anAttrSpec_INIT( rotate,	NULL )
		.uiAddDial( 1 );

	anAttrSpec_INIT( scale,		NULL )
		.setDefaultValue( 1,1,1 )
		.uiAddDial( 0.1 );

	anAttrSpec_INIT( matrix, NULL )
		.setComputeFunc( &CLASS::_onComputeMatrix )
		.setSaveToFile( false );

	anAttrSpec_affect( translate,	matrix );
	anAttrSpec_affect( rotate,		matrix );
	anAttrSpec_affect( scale,		matrix );
	return 0;
}

void	anNode_Transform::onGLRenderChild ( anGLRenderRequest &req ) {
	req.pushMatrix( matrix().value() );
	B::onGLRenderChild( req );
	req.popMatrix();
}


axStatus	anNode_Transform::onComputeMatrix	( axMatrix4f &mat ) {
	axVec3f	t = translate().value();
	axVec3f	r = rotate().value();
	axVec3f	s = scale().value();

	mat.setTranslate( t );

	mat.rotateX( ax_deg_to_rad( r.x ) );
	mat.rotateY( ax_deg_to_rad( r.y ) );
	mat.rotateZ( ax_deg_to_rad( r.z ) );
	
	mat.scale( s );
	
//	ax_print("mat = {?}\n", mat );

	return 0;
}

axStatus	anNode_Transform::_onComputeMatrix ( anAttr* attr ) {
	axMatrix4f	mat;
	onComputeMatrix(mat);
	matrix().setValue( mat );
	return 0;
}
