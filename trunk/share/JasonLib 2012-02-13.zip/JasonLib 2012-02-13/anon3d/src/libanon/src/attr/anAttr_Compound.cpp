#include <libanon/attr/anAttr_Compound.h>

template<class S> inline
axStatus	anAttrInst_Compound::_onSerielize( anAttr & attr, S &s ) {
	axStatus st;
	axSize n = attr.numChildren();
	for( axSize i=0; i<n; i++ ) {
		st = attr.child(i).onSerialize(s);		if( !st ) return st;
	}
	return 0;
}

axStatus	anAttrInst_Compound::onSetValue	( anAttr & attr, anAttr & src ) {
	if( attr.spec() != src.spec() ) return axStatus_Anon_unsupport_value_type;
	axStatus st;
	axSize n = attr.numChildren();
	for( axSize i=0; i<n; i++ ) {
		st = attr.child(i).setValue( src.child(i) );		if( !st ) return st;
	}
	return 0;
}

axStatus	anAttrInst_Compound::onSerialize( anAttr & attr, axSerializer	  &s ) { return _onSerielize(attr,s); }
axStatus	anAttrInst_Compound::onSerialize( anAttr & attr, axDeserializer &s ) { return _onSerielize(attr,s); }

axStatus	anAttrInst_Compound::onSetValueToDefault	( anAttr & attr ) {
	axStatus st;
	axSize n = attr.numChildren();
	for( axSize i=0; i<n; i++ ) {
		attr.child(i).setValueToDefault();
	}
	return 0;
}

axStatus	anAttrInst_Compound::onToString	( anAttr & attr, axIStringA & out ) {
	axStatus st;
	axSize n = attr.numChildren();

	out.set("{");
	axTempStringA	tmp;
	for( axSize i=0; i<n; i++ ) {
		st = attr.child(i).toString(tmp);		if( !st ) return st;
		if( i==0 ) {
			out.appendFormat("{?}", tmp );
		}else{
			out.appendFormat(",{?}", tmp );
		}
	}
	out.append("}");
	return 0;
}

axStatus	anAttrInst_Compound::getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list ) { 
	axStatus st;
	st = B::getAllInputConnectionsRecursively( attr, list );	if( !st ) return st;

	axSize n = attr.numChildren();
	for( axSize i=0; i<n; i++ ) {
		st = attr.child(i).getAllInputConnectionsRecursively( list );	if( !st ) return st;
	}
	return 0; 
}

void		anAttrInst_Compound::onUnshare	( anAttr & attr ) {
	axSize n = attr.numChildren();
	for( axSize i=0; i<n; i++ ) {
		attr.child(i).unshare();
	}
}
