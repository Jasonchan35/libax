#include "sceneoutliner.h"
#include "ui_sceneoutliner.h"

SceneOutliner::SceneOutliner(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SceneOutliner)
{
    ui->setupUi(this);
}

SceneOutliner::~SceneOutliner()
{
    delete ui;
}
