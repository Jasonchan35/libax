#ifndef OBJECTINSPECTOR_H
#define OBJECTINSPECTOR_H

#include <QWidget>

namespace Ui {
    class ObjectInspector;
}

class ObjectInspector : public QWidget
{
    Q_OBJECT

public:
    explicit ObjectInspector(QWidget *parent = 0);
    ~ObjectInspector();

private:
    Ui::ObjectInspector *ui;
};

#endif // OBJECTINSPECTOR_H
