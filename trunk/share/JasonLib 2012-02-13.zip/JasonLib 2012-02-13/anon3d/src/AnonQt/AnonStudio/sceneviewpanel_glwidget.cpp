#include "sceneviewpanel_glwidget.h"

SceneViewPanel_GLWidget::SceneViewPanel_GLWidget(QGLWidget *parent) :
    QGLWidget(parent)
{
}
