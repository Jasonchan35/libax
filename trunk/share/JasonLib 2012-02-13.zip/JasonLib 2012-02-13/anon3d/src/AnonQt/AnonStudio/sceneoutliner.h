#ifndef SCENEOUTLINER_H
#define SCENEOUTLINER_H

#include <QWidget>

namespace Ui {
    class SceneOutliner;
}

class SceneOutliner : public QWidget
{
    Q_OBJECT

public:
    explicit SceneOutliner(QWidget *parent = 0);
    ~SceneOutliner();

private:
    Ui::SceneOutliner *ui;
};

#endif // SCENEOUTLINER_H
