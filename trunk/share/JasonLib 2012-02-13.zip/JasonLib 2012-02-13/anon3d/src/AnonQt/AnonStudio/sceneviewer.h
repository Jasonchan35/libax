#ifndef SCENEVIEWER_H
#define SCENEVIEWER_H

#include <QWidget>

namespace Ui {
    class SceneViewer;
}

class SceneViewer : public QWidget
{
    Q_OBJECT

public:
    explicit SceneViewer(QWidget *parent = 0);
    ~SceneViewer();

private:
    Ui::SceneViewer *ui;
};

#endif // SCENEVIEWER_H
