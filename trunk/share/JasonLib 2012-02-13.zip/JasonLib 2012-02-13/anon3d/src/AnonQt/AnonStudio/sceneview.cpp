#include "sceneview.h"
#include "ui_sceneview.h"

SceneView::SceneView(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SceneView)
{
    ui->setupUi(this);
}

SceneView::~SceneView()
{
    delete ui;
}
