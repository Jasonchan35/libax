#ifndef SCENEVIEWPANEL_GLWIDGET_H
#define SCENEVIEWPANEL_GLWIDGET_H

#include <QGLWidget>

class SceneViewPanel_GLWidget : public QGLWidget
{
    Q_OBJECT
public:
	explicit SceneViewPanel_GLWidget(QGLWidget *parent = 0);

signals:

public slots:

};

#endif // SCENEVIEWPANEL_GLWIDGET_H
