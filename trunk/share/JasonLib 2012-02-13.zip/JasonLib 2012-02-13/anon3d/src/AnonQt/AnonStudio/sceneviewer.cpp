#include "sceneviewer.h"
#include "ui_sceneviewer.h"

#include <QHBoxLayout>
#include <QGLWidget>

class GLWidget : public QGLWidget {
public:
	GLWidget( QWidget *parent )
		: QGLWidget( QGLFormat(QGL::SampleBuffers), parent)
	{

	}

	virtual void initializeGL() {
	}

	virtual void resizeGL(int width, int height) {
		int side = qMin(width, height);
		glViewport((width - side) / 2, (height - side) / 2, side, side);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glMatrixMode(GL_MODELVIEW);
	}

	virtual void paintGL() {
		//qDebug("p");
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		glBegin( GL_LINE_LOOP );
			glVertex3f( 0,   0.5, 0 );
			glVertex3f(-0.5, 0,   0 );
			glVertex3f( 0.5, 0,   0 );
		glEnd();
	}
};

SceneViewer::SceneViewer(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SceneViewer)
{
    ui->setupUi(this);

	QHBoxLayout* layout = new QHBoxLayout(this);
	GLWidget* p = new GLWidget(this);
	layout->setMargin(0);
	layout->setSpacing(0);
	layout->addWidget(p);

	ui->widget->setLayout(layout);

}

SceneViewer::~SceneViewer()
{
    delete ui;
}
