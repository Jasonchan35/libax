#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QDockWidget>
#include "sceneoutliner.h"
#include "sceneviewer.h"
#include "objectinspector.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

	SceneViewer *s = new SceneViewer(this);

	setCentralWidget(s);

	on_actionSceneTree_triggered();
	on_actionInspector_triggered();
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::on_actionSceneTree_triggered() {
	QDockWidget* dock = new QDockWidget("Scene Outliner");
	SceneOutliner* p = new SceneOutliner(dock);
	dock->setWidget(p);
	addDockWidget( Qt::LeftDockWidgetArea , dock );
}

void MainWindow::on_actionInspector_triggered() {
	QDockWidget* dock = new QDockWidget("Object Inspector");
	ObjectInspector* p = new ObjectInspector(dock);
	dock->setWidget(p);
	addDockWidget( Qt::RightDockWidgetArea , dock );
}
