#ifndef SCENEVIEW_H
#define SCENEVIEW_H

#include <QWidget>

namespace Ui {
    class SceneView;
}

class SceneView : public QWidget
{
    Q_OBJECT

public:
    explicit SceneView(QWidget *parent = 0);
    ~SceneView();

private:
    Ui::SceneView *ui;
};

#endif // SCENEVIEW_H
