#ifndef __anSelectionList_h__
#define __anSelectionList_h__

#include "libanon_define.h"
class anNode;

class anSelection {
public:
	anSelection();
	anSelection( anNode* _node );

	axStatus	set	( anNode* _node );
	axStatus	set	( anNode* _node, anComponentType _componentType, const axIArray<anComponentId> & _componentIds );

	void		clear();

	bool		isObject	() const	{ return componentType == anComponentType_Object; }
	bool		isComponent	() const	{ return componentType != anComponentType_Object; }
	
	bool		operator==( const anSelection &s );
	bool		operator!=( const anSelection &s )	{ return ! operator==(s); }

	axStatus	onTake	( anSelection & src );
	axStatus	toStringFormat	( axStringFormat &f ) const;

	anNode*		node;
	anComponentType				componentType;
	axArray< anComponentId >	componentIds;

private:
	void	_init();
};

class anSelectionList : public axNonCopyable {
public:
	anSelectionList();

	void		clear		();
	axStatus	append		( const anSelectionList & list );
	axStatus	append		( const anSelection & sel );

			axSize			size() const					{ return list_.size(); }

			anSelection&	operator[]( axSize idx )		{ return list_[idx]; }
	const	anSelection&	operator[]( axSize idx ) const	{ return list_[idx]; }

			anSelection&	last	( axSize idx=0 )		{ return list_.last(idx); }
	const	anSelection&	last	( axSize idx=0 ) const	{ return list_.last(idx); }

	axStatus	copy	( const anSelectionList & list );
	axStatus	onTake	( anSelectionList & list );

	axStatus	toStringFormat	( axStringFormat &f ) const;


	axStatus	remove	( const anSelectionList & list, anSelectionList* removedResult=NULL );

private:
	typedef		axArray< anSelection, 16 >	List;
	List	list_;
};

#endif //__anSelectionList_h__
