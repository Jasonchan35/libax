#ifndef __anScene_h__
#define __anScene_h__

#include "../node/anNode_SceneRoot.h"
class anGLRenderRequest;
class anContext;
class anAttrConnectionInfo;

class anScene : public axNonCopyable {
public:
	anScene();
	~anScene();

	axStatus	loadFile	( const char* filename );
	axStatus	saveFile	( const char* filename );

	axStatus	renderGL	( anGLRenderRequest &req );

	struct	FileHeader {
		FileHeader();
		axLocalStringA<16>	signature;
		uint32_t			version;
		uint32_t			numNodes;	
		uint32_t			numConnections;

		template<class S>	axStatus	serialize_io( S &s );
	};

			axStatus	toStringFormat	( axStringFormat &f ) const;

	anNode_SceneRoot*	sceneRoot();
			void		advanceTime		( double seconds );

	template<class T>	axStatus	createNode ( T*			  &node, const char* name );
	template<class T>	axStatus	createNode ( axAutoPtr<T> &node, const char* name );
			axStatus	createNodeByType( anNode* &node, anNodeType type, const char* name );

			void		deleteAllNodes();

			axSize		numNodes	() { return nodeTable_.nodeCount(); }

			axStatus	getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list );

			anNode*		findNode	( const char* name );
			axStatus	_findAttr	( anAttr & out, const anAttrConnectionInfo &info );


			axStatus	_addNode	( anNode* node );
			axStatus	_removeNode	( anNode* node );
private:
	typedef axHashTable< anNode::HashNode >	NodeTable;

	axStatus	_reconnect	( anAttrConnectionEnd & end );
	NodeTable	nodeTable_;
	axAutoPtr<anNode_SceneRoot>	sceneRoot_;
};

template<class T> inline
axStatus	anScene::createNode ( T* &node, const char* name ) {
	anNode* np;
	axStatus st = createNodeByType( np, T::TYPE, name );	if( !st ) return st;
	node = (T*)np;
	return 0;
}

template<class T> inline
axStatus	anScene::createNode ( axAutoPtr<T> &node, const char* name ) {
	anNode* np;
	axStatus st = createNodeByType( np, T::TYPE, name );	if( !st ) return st;
	node.ref( (T*) np );
	return 0;
}

template<class S> inline
axStatus anScene::FileHeader::serialize_io( S &s ) {
	axStatus st;
	st = s.io( signature );			if( !st ) return st;
	st = s.io( version );			if( !st ) return st;
	st = s.io( numNodes );			if( !st ) return st;
	st = s.io( numConnections );	if( !st ) return st;
	return 0;
}

#endif //__anScene_h__
