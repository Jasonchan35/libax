#ifndef __anProject_h__
#define __anProject_h__

#include "anObject.h"

class anProject : public axNonCopyable {
public:

	axStatus	loadProject( const char* path );


private:
	axStringA	projectPath_;
};

#endif //__anProject_h__
