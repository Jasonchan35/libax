#ifndef __anGLRenderRequest_h__
#define __anGLRenderRequest_h__

#include "libanon_define.h"

class anNode_Shape;

class anGLRenderRequest {
public:
	anGLRenderRequest	();
	void	reset		();
	

	void	pushMatrix	( const axMatrix4f &m );
	void	popMatrix	();

	const axMatrix4f&	currentMatrix() const;
private:

	axLocalArray< axMatrix4f, 64 >	matrixStack_;

};

#endif //__anGLRenderRequest_h__
