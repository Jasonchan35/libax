#ifndef __anContext_h__
#define __anContext_h__

#include "anScene.h"
#include "anSelectionList.h"
#include "anActionHistory.h"

class anContext : public axNonCopyable {
public:
			anContext();

			axStatus	create();

			axStatus	setSelection	( const anSelectionList & list );

			axStatus	clearSelection	();
			axStatus	addSelection	( const anSelectionList & list );
			axStatus	removeSelection	( const anSelectionList & list );

	const anSelectionList&	selection	()	{ return selection_; }

			axStatus	setNodeName		( anNode* node, const char* name );

	template<class T>
			axStatus	setAttr			( anAttr		&attr, T		value );

			axStatus	setAttr			( anAttr_bool	&attr, bool		value );
			axStatus	setAttr			( anAttr_int	&attr, int		value );
			axStatus	setAttr			( anAttr_float	&attr, float	value );
			axStatus	setAttr			( anAttr_double	&attr, double	value );

	anActionHistory		history;

//--- event
	axEventCaster< void >		evSelectionDidChange;

private:
	template<class ATTR> axStatus _setAttr( ATTR & attr, const typename ATTR::VALUE & newValue );


	axStatus	_addSelection			( const anSelectionList & list );
	axStatus	_removeSelection		( const anSelectionList & list );
	axStatus	_makeSelectionUndo		();

	anSelectionList			selection_;
};

template<class T> inline
axStatus anContext::setAttr( anAttr & attr, T value ) {
	axStatus st;
	switch( attr.type() ) {
		case anAttrType_bool: {
			anAttr_bool		a(attr);
			bool v;			an_convert( v, value );
			st = _setAttr( a, v );	if( !st ) return st;
		}break;

		case anAttrType_int: {
			anAttr_int		a(attr);
			int v;			an_convert( v, value );
			st = _setAttr( a, v );		if( !st ) return st;
		}break;

		case anAttrType_float: {
			anAttr_float	a(attr);
			float v;		an_convert( v, value );
			st = _setAttr( a, v );	if( !st ) return st;
		}break;

		case anAttrType_double: {
			anAttr_double	a(attr);
			double v;		an_convert( v, value );
			st = _setAttr( a, v );	if( !st ) return st;
		}break;
	}
	return 0;
}

#endif //__anContext_h__
