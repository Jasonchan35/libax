#ifndef __libanon_define_h__
#define __libanon_define_h__

#include <ax/ax_App.h>

enum {
	axStatus_Anon_start = -5000,
	#define axStatus_enum(n)	axStatus_Anon_##n,
		#include "anStatus_enum.h"
	#undef	axStatus_enum
	axStatus_Anon_end,
};

typedef	uint32_t	anNodeType;
typedef uint32_t	anAttrType;

typedef	uint32_t	anComponentId;
typedef uint32_t	anComponentType;

typedef	axSize	anAttrSubID;

typedef	axArray< anAttrSubID, 4 >	anAttrId;

#define	anNodeName_LocalBuf	16
typedef	axStringA_<anNodeName_LocalBuf>	anNodeName;

enum {
	anComponentType_null = 0,
	anComponentType_Object,
};


enum {
	anAttrType_Custom = 1000, 
	anAttrType_Custom_BlendShapeTarget,
};

//---- Event ----
class anEvent {
public:
};

typedef axEventCaster	< anEvent > anEventCaster;
template<class OBJ>	class anEventFunc : public axEventFunc < OBJ, anEvent > {};

//--------



#endif //__libanon_define_h__
