#ifndef __anMesh3_h__
#define __anMesh3_h__

#include "libanon_define.h"
#include "anMesh3.h"
#include "anGLRenderRequest.h"

template<class T>
class anMesh3 : public axNonCopyable {
public:
	enum {
		kUVSets_LocalBuf = 2,
		kTriMesh_NumVertexMax = 30000,
	};

	typedef	axVec3<T>	Vertex;
	typedef axVec3<T>	Normal;
	typedef	axVec2<T>	UV;
	typedef	uint32_t	Index;
	typedef	uint16_t	TriIndex;	//! OpenGL ES only support up to uint16 index

	struct	Face {
		uint32_t		shader;
		Index			vertexCount;
		Index			vertexOffset;	//offset in topology faceVertices
		Index			normalOffset;	//offset in topology faceVertexNormals

		Normal			faceNormal;
		axStatus		onTake( Face & src ) { *this = src; return 0; }
		template<class S> axStatus	serialize_io( S &s );
	};

	struct IndexSet {
		IndexSet();

		axArray<Index>	indices;
		Index			indexMax;

		axStatus		setIndices( const axIArray<Index> &src );

		void			recalcIndexMax();
		axStatus		onTake( IndexSet & src );
		axStatus		serialize_io( axSerializer   &s );
		axStatus		serialize_io( axDeserializer &s );
	};

	struct Topology : public axSharedPte {
		Topology() {}
		axArray<Face>	faces;		
		IndexSet		faceVertices;
		IndexSet		faceVertexNormals;
		axArray< IndexSet, kUVSets_LocalBuf >	faceVertexUVSets;

		IndexSet		fvTriIndices;
		template<class S> axStatus	serialize_io( S &s );

		static	const Topology	kEmpty; 
		Topology*	onClone() const { return new Topology(*this); }
	};

	struct VertexSet : public axSharedPte {
		VertexSet() {}
		axArray<Vertex>	vertices;
		template<class S> axStatus	serialize_io( S &s );
		static	const VertexSet	kEmpty; 
		VertexSet*	onClone() const { return new VertexSet(*this); }
	};

	struct UVSet : public axSharedPte {
		UVSet() {}
		axArray<UV>		uv;
		template<class S> axStatus	serialize_io( S &s );
		static	const UVSet		kEmpty;
	};

	class TriMesh {
	public:
		IndexSet			vertexInMesh;
		IndexSet			normalInMesh;

		axArray<Vertex>		vertices;
		axArray<Normal>		normals;
		axArray<TriIndex>	triIndices; //for drawing
		template<class S> axStatus	serialize_io( S &s );

		axStatus	triangulate			( const anMesh3<T> & mesh );
		axStatus	update				( const anMesh3<T> & mesh );

	private:
		typedef	axArray<TriIndex,32>	Polygon;
		axArray< Polygon, 16 >			polygonArray;

		axStatus	triangulateFace_	( const anMesh3<T> & mesh, const Face & face );
		axStatus	appendFaceVertex_	( IndexSet & dst, const Face & face, const IndexSet & srcFromMesh );

		axStatus	sweepX_				( const anMesh3<T> & mesh, TriIndex triVertexStart, Polygon &polygon, bool &outSplited );
		axStatus	addTriangleFan_		( const anMesh3<T> & mesh, TriIndex triVertexStart, const Polygon & polygon );
		axStatus	addTriangle_		( const anMesh3<T> & mesh, TriIndex triVertexStart, Index a, Index b, Index c );
	};

	struct ShadingGroup {
		TriMesh		triMesh;
	};


			axStatus	setVertices		( const axIArray<Vertex> & v );

	const axIArray< Vertex >	&	vertices() const;

			Vertex*		vertexPtr		();
	const	Vertex*		vertexPtr		() const;

			axStatus	setNumVertices	( axSize n );
			axSize		numVertices		() const;

	const	Face*		facePtr			() const;
			axSize		numFaces		() const;
			axSize		numUVSets		() const;

			axStatus	setFaceVertices	( const axIArray<Index> & faceVertexCounts, const axIArray<Index> & faceVertexIndices );

			void		glDrawVertices	( anGLRenderRequest &req ) const;
			void		glDrawVertexIDs	( anGLRenderRequest &req ) const;

			void		glDrawFaces		( anGLRenderRequest &req ) const;
			void		glDrawTriangles	( anGLRenderRequest &req, bool fill=true ) const;

			axStatus	serialize_io	( axSerializer	 &s );
			axStatus	serialize_io	( axDeserializer &s );
			axStatus	toStringFormat	( axStringFormat &f ) const;

			axStatus	onTake			( anMesh3 & src );

	axStatus	unshare	();

	void	set				( anMesh3<T> & src );
	void	setVertexSet	( anMesh3<T> & src )			{ vertexSet_ = src.vertexSet_; }
	void	setTopology		( anMesh3<T> & src )			{ topology_  = src.topology_;  }

	const	Topology &		topology	() const;
	const	VertexSet &		vertexSet	() const;
	const	UVSet &			uvSet		( axSize i ) const;

	static	const	anMesh3<T>	kEmpty;	
	anMesh3() {}
private:
	axSharedPtr< Topology >		topology_;
	axSharedPtr< VertexSet >	vertexSet_;
	axArray< axSharedPtr< UVSet >, kUVSets_LocalBuf >	uvSets_;

};

typedef	anMesh3<float>		anMesh3f;
typedef	anMesh3<double>		anMesh3d;

typedef anMesh3f::Vertex	anVertex3f;
typedef anMesh3d::Vertex	anVertex3d;


template<class T>
template<class S> inline
axStatus anMesh3<T>::VertexSet::serialize_io( S &s ) {
	axStatus st;
	st = s.io( vertices );		if( !st ) return st;
	return 0;
}

template<class T> inline
axStatus anMesh3<T>::IndexSet::serialize_io( axSerializer &s ) {
	axStatus st;
	st = s.io_vary( indices );		if( !st ) return st;
	return 0;
}

template<class T> inline
axStatus anMesh3<T>::IndexSet::serialize_io( axDeserializer &s ) {
	axStatus st;
	st = s.io_vary( indices );		if( !st ) return st;
	recalcIndexMax();
	return 0;
}


template<class T>
template<class S> inline
axStatus anMesh3<T>::UVSet::serialize_io( S &s ) {
	axStatus st;
	st = s.io( uv );			if( !st ) return st;
	return 0;
}

template<class T>
template<class S> inline
axStatus anMesh3<T>::Topology::serialize_io( S &s ) {
	axStatus st;
	st = s.io( faces );					if( !st ) return st;
	st = s.io( faceVertices );			if( !st ) return st;
	st = s.io( faceVertexNormals );		if( !st ) return st;
	st = s.io( faceVertexUVSets );		if( !st ) return st;
	return 0;
}

template<class T>
template<class S> inline
axStatus	anMesh3<T>::Face::serialize_io( S & s ) { 
	axStatus st;
	st = s.io( shader  );			if( !st ) return st;
	st = s.io( vertexCount );		if( !st ) return st;
	st = s.io( vertexOffset );		if( !st ) return st;
	st = s.io( normalOffset );		if( !st ) return st;
	return 0;
}

#endif //__anMesh3_h__
