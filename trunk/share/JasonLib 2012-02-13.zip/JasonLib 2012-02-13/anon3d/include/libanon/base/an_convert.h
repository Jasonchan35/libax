#ifndef __an_convert_h__
#define __an_convert_h__

//--- int ---
inline void an_convert( int		 & dst, int		src ) { dst = (int)src; }
inline void an_convert( int		 & dst, int64_t src ) { dst = (int)src; }
inline void an_convert( int		 & dst, float	src ) { dst = (int)ax_round(src); }
inline void an_convert( int		 & dst, double	src ) { dst = (int)ax_round(src); }
inline void an_convert( int		 & dst, bool	src ) { dst = src ? 1:0; }

//--- int64 ---
inline void an_convert( int64_t  & dst, int		src ) { dst = (int64_t)src; }
inline void an_convert( int64_t  & dst, int64_t src ) { dst = (int64_t)src; }
inline void an_convert( int64_t  & dst, float	src ) { dst = (int64_t)ax_round(src); }
inline void an_convert( int64_t  & dst, double	src ) { dst = (int64_t)ax_round(src); }
inline void an_convert( int64_t  & dst, bool	src ) { dst = src ? 1:0; }

//--- float ---
inline void an_convert( float	 & dst, int		src ) { dst = (float)src; }
inline void an_convert( float	 & dst, int64_t src ) { dst = (float)src; }
inline void an_convert( float	 & dst, float	src ) { dst = (float)src; }
inline void an_convert( float	 & dst, double	src ) { dst = (float)src; }
inline void an_convert( float	 & dst, bool	src ) { dst = src ? 1.0f : 0.0f; }

//--- double ---
inline void an_convert( double	 & dst, int		src ) { dst = (double)src; }
inline void an_convert( double	 & dst, int64_t src ) { dst = (double)src; }
inline void an_convert( double	 & dst, float	src ) { dst = (double)src; }
inline void an_convert( double	 & dst, double	src ) { dst = (double)src; }
inline void an_convert( double	 & dst, bool	src ) { dst = src ? 1.0 : 0.0; }

//--- bool ---
inline void an_convert( bool	 & dst, int		src ) { dst = (src != 0 ); }
inline void an_convert( bool	 & dst, int64_t src ) { dst = (src != 0 ); }
inline void an_convert( bool	 & dst, float	src ) { dst = (src != 0 ); }
inline void an_convert( bool	 & dst, double	src ) { dst = (src != 0 ); }
inline void an_convert( bool	 & dst, bool	src ) { dst = src; }

//--- Vec2f ---
inline void an_convert( axVec2f	 & dst, const axVec2f & src ) { dst = src; }
inline void an_convert( axVec2f	 & dst, const axVec2d & src ) { dst = to_axVec2f(src); }

//--- Vec2d ---
inline void an_convert( axVec2d	 & dst, const axVec2f & src ) { dst = to_axVec2d(src); }
inline void an_convert( axVec2d	 & dst, const axVec2d & src ) { dst = src; }

//--- Vec3f ---
inline void an_convert( axVec3f	 & dst, const axVec3f & src ) { dst = src; }
inline void an_convert( axVec3f	 & dst, const axVec3d & src ) { dst = to_axVec3f(src); }

//--- Vec3f ---
inline void an_convert( axVec3d	 & dst, const axVec3f & src ) { dst = to_axVec3d(src); }
inline void an_convert( axVec3d	 & dst, const axVec3d & src ) { dst = src; }

//--- Matrix4f ---
inline void an_convert( axMatrix4f & dst, const axMatrix4f & src ) { dst = src; }
inline void an_convert( axMatrix4f & dst, const axMatrix4d & src ) { dst = to_axMatrix4f(src); }

//--- Matrix4d ---
inline void an_convert( axMatrix4d & dst, const axMatrix4f & src ) { dst = to_axMatrix4d(src); }
inline void an_convert( axMatrix4d & dst, const axMatrix4d & src ) { dst = src; }



#endif //__an_convert_h__
