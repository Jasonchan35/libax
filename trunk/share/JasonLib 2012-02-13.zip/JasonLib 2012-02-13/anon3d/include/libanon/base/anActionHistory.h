#ifndef __anActionHistory_h__
#define __anActionHistory_h__

#include "libanon_define.h"

class anContext;
class anAttr;

class anAction : public axDListNode< anAction > {
public:
	anAction();
	virtual ~anAction();
	virtual axStatus	undo() = 0;
	virtual axStatus	redo() = 0;
};

class anUndoStep : public axDListNode< anUndoStep > {
public:
	void		undo();
	void		redo();

	axStatus	addAction( anAction* a );

	axStatus	setName	( const char* name )		{ return name_.set(name); }
	const char*	name	()							{ return name_; }

	void		reset	()							{ undo(); actions_.clear(); }

private:
	axStringA_<32>		name_;
	axDList< anAction >	actions_;
};

class anActionHistory : public axNonCopyable {
public:
	anActionHistory();
	
	axStatus	newUndo	( const char*	name );
	axStatus	newUndo	( anAttr &		attr );

	void		addAction	( anAction*		action );

	anUndoStep*	firstUndo	() { return undo_.head(); }
	anUndoStep*	firstRedo	() { return redo_.head(); }

	axStatus	undo		();
	axStatus	redo		();

	axStatus	resetCurrentUndo();

	axSize		limit		()		{ return limit_; }
	void		setLimit	( axSize n );

	axEventCaster< void >	evDidChange;

private:
	void		_addUndo		( anUndoStep*	undo );

	axSize	limit_;
	axDList< anUndoStep >	undo_;
	axDList< anUndoStep >	redo_;
};



#endif //__anActionHistory_h__
