#ifndef __anAttrTypeId_h__
#define __anAttrTypeId_h__

#include "../base/libanon_define.h"
#include "../base/anMesh3.h"

class anNode;
class anAttr;
class anBlendShapeTarget;

enum {
	anAttrType_unknown = 0,
	#define anAttrType_enum(TYPE,NAME)		anAttrType_##NAME,
		#include "anAttrType_enum.h"
	#undef	anAttrType_enum
	anAttrType_max,
};

const char* anAttrTypeName( anAttrType t );

template< class T >	anAttrType	anAttrTypeOf() { return T::_type; }

#endif //__anAttrTypeId_h__

