#ifndef __anAttr_h__
#define __anAttr_h__

#include "anAttrSpec.h"

class anNode;
class anAttrInst;
class anAttrConnection;
class anAttrConnectionEnd;

class anAttr { 
public:
	anAttr();
	anAttr( const anAttr & src )	{ operator=(src); }
	anAttr( anNode* node, const anAttrSpec* spec, anAttrInst* inst );
		
	anNode*				node()			{ return node_; }
	const anAttrSpec*	spec() const	{ return spec_; }

	anNodeType		nodeType	() const;

	const char*		name		() const;

	axStatus		getFullName	( axIStringA &out, bool withNodeName );

	anAttrType		type		() const;
	const char*		typeName	() const;

	axStatus		toString	( axIStringA &out ) const;

	bool			isValid		() const	{ return inst_ != NULL; }
	bool			isArray		() const;
	bool			isElement	() const;

	axSize			numElements	()  const;
	axStatus		setNumElements( axSize n );

	anAttr			element		( axSize index );

	axSize			elementIndex() const;
	anAttr			elementArray();

	axStatus		onSerialize	( axSerializer	 &s );
	axStatus		onSerialize ( axDeserializer &s );

	void			setValueToDefault();
	axStatus		toStringFormat	( axStringFormat &f ) const;

	axStatus		compute		();

	anAttr			parent		();
	anAttr			child		( axSize idx );
	axSize			numChildren	() const;

	axStatus		connect		( anAttr & dst );

	axStatus		newInputConnection ( anNodeType nodeType, const char* nodeName, const char*		 attrName );
	axStatus		newInputConnection ( anNodeType nodeType, const char* nodeName, const anAttrId & attrId   );

	axStatus		getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list );
	void			disconnectAll();

	anAttrConnection*	inputConnection			();
	anAttrConnection*	firstOutputConnection	();

	void			setDirty	();
	void			clearDirty	();

	axStatus		setValue	( const anAttr & src );
	void			valueChanged();

	bool			operator==( const anAttr & src );

	void			unshare		();
	anAttrInst*		_inst		()	{ return inst_; }
	axStatus		getAttrId	( anAttrId &out );

	void			_onDelete	();
	anAttr			_affectedAttr( axSize idx );

private:
	axStatus		_getAttrId	( anAttrId &out ) ;
	axStatus		_getFullName( axIStringA &out );

	void			_setDirty_Child	  ();
	void			_setDirty_NoChild ();

	template<class S> axStatus _onSerialize( S &s );

	anNode*				node_;
	const anAttrSpec*	spec_;
	anAttrInst*			inst_;
};

//---- Event ----
class anAttrEvent {
public:
	anAttrEvent( anAttr & attr ) { attr_ = attr; }

	anAttr	attr() { return attr_; }
private:
	anAttr	attr_;
};

typedef axEventCaster	< anAttrEvent > anAttrEventCaster;
template<class OBJ>	class anAttrEventFunc : public axEventFunc < OBJ, anAttrEvent > {};

//--------

#define	anAttr_DECLARE( TYPE, NAME ) \
	static anAttrSpec_##TYPE&		attr_spec_##NAME() { static anAttrSpec_##TYPE a; return a; }	\
	anAttrInst_##TYPE				attr_inst_##NAME;	\
	anAttr_##TYPE					NAME() { return anAttr_##TYPE(this, &attr_spec_##NAME(), &attr_inst_##NAME ); }	\
//----

#define	anAttr_CHILD(TYPE, NAME) \
	anAttr_##TYPE	NAME	()	{ \
		const anAttrSpec* c = &(spec()->NAME); \
		return anAttr_##TYPE( node(), c, (anAttrInst*)( (char*)_inst() + c->instOffset() ) ); \
	} \
//-----

#define anAttr_DECLARE_ARRAY( TYPE, NAME ) \
	static anAttrSpec_##TYPE&				attr_spec_##NAME() { static anAttrSpec_Array<anAttrSpec_##TYPE> a; return a; } \
	anAttrInst_Array< anAttrInst_##TYPE >	attr_inst_##NAME;	\
	anAttr_Array< anAttr_##TYPE >	NAME()			 { return anAttr_Array< anAttr_##TYPE >(this, &attr_spec_##NAME(), &attr_inst_##NAME ); } \
	anAttr_##TYPE					NAME(axSize idx) { return anAttr_##TYPE(this, &attr_spec_##NAME(), &attr_inst_##NAME.element(idx) ); } \
//----

#define anAttr_COMMON( TYPE ) \
	typedef	anAttrInst_##TYPE	INST;	\
	typedef anAttrSpec_##TYPE	SPEC;	\
	anAttr_##TYPE() {}	\
	anAttr_##TYPE( anNode* node, const anAttrSpec* spec, anAttrInst* inst ) : B(node, spec, inst) {}	\
	anAttr_##TYPE( anAttr & src ) { \
		if( src.type() == anAttrSpec_##TYPE::_type ) { \
			*(anAttr*)this = src; \
		}else{ \
			assert(false); \
		}\
	} \
	const anAttrSpec_##TYPE*	spec()  { return (anAttrSpec_##TYPE*) B::spec(); } \
//----

#if axCOMPILER_GCC
	#pragma GCC diagnostic ignored "-Winvalid-offsetof"
#endif


#define anAttrSpec_INIT( NAME, PARENT ) \
	attr_spec_##NAME().create( #NAME, CLASS::staticSpec(), PARENT, offsetof(CLASS, attr_inst_##NAME) ) \
//----
#define anAttrSpec_INIT_CHILD(NAME) \
	NAME.create( #NAME, nodeSpec, this, offsetof(INST,NAME) )	\
//-----	
#define	anAttrSpec_COMMON( TYPE )	\
	typedef	anAttrSpec_##TYPE		CLASS; \
	typedef anAttrInst_##TYPE		INST;  \
	typedef anAttr_##TYPE			ATTR;  \
	CLASS&	create		( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) { \
		_create( name, nodeSpec, parent, instOffset );	return *this; \
	} \
	CLASS&	setSaveToFile			( bool b )	{ B::_setSaveToFile(b); return *this; } \
	static	anAttrType	_type;	\
	static	const char*	_typeName; \
	virtual	anAttrType	type		() const { return CLASS::_type; }	\
	virtual	const char*	typeName	() const { return CLASS::_typeName; }	\
	virtual	axStatus	onCreate	( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ); \
	template<class Node> CLASS& setComputeFunc( axStatus (Node::*func)(anAttr* attr))	{ _setComputeFunc( (ComputeFunc) func ); return *this; }	\
//-----

#define anAttrSpec_affect( SRC, DST ) \
	attr_spec_##SRC().addAffected( &attr_spec_##DST() );	\
//----

#endif //__anAttr_h__
