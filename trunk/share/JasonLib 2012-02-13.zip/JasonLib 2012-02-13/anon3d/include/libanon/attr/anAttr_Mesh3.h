#ifndef __anAttr_Mesh3_h__
#define __anAttr_Mesh3_h__

#include "anAttr_Primitive.h"
#include "../base/anMesh3.h"

template<class T> class anAttr_Mesh3;
template<class T> class anAttrSpec_Mesh3;

template<class T>
class anAttrInst_Mesh3 : public anAttrInst {
	typedef	anAttrInst			B;
	typedef	anAttrSpec_Mesh3<T>	SPEC;
	typedef	anAttr_Mesh3<T>		ATTR;
public:
	virtual	axStatus	onSetValue			( anAttr & attr, anAttr & src );
	virtual axStatus	onSetValueToDefault	( anAttr & attr );
	virtual axStatus	onToString			( anAttr & attr, axIStringA & out );
	virtual	axStatus	onSerialize			( anAttr & attr, axSerializer	&s );
	virtual	axStatus	onSerialize			( anAttr & attr, axDeserializer	&s );

	virtual	void		onUnshare			( anAttr & attr ) { value_.unshare(); }

	anMesh3<T>	value_;
};

template<class T>
class anAttrSpec_Mesh3 : public anAttrSpec {
	typedef	anAttrSpec	B;
public:
	anAttrSpec_COMMON( Mesh3<T> );
	CLASS& setDefaultValue( const anMesh3<T> &value );

	const anMesh3<T>& defaultValue() { return defaultValue_; }

private:
	anMesh3<T>	defaultValue_;
};

template<class T>
class anAttr_Mesh3 : public anAttr {
	typedef	anAttr	B;
public:
	anAttr_COMMON( Mesh3<T> );

	const anMesh3<T> &	value ();
			axStatus	setValue	( const anMesh3<T> & v );
			axStatus	setVertexSet( const anMesh3<T> & v );
			axStatus	setTopology	( const anMesh3<T> & v );
};

typedef	anAttrSpec_Mesh3<float>		anAttrSpec_Mesh3f;
typedef	anAttrInst_Mesh3<float>		anAttrInst_Mesh3f;
typedef	anAttr_Mesh3<float>			anAttr_Mesh3f;

typedef	anAttrSpec_Mesh3<double>	anAttrSpec_Mesh3d;
typedef	anAttrInst_Mesh3<double>	anAttrInst_Mesh3d;
typedef	anAttr_Mesh3<double>		anAttr_Mesh3d;

#endif //__anAttr_Mesh3_h__
