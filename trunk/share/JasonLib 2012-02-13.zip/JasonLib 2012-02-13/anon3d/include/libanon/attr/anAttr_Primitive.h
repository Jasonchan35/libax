#ifndef __anAttr_Primitive_h__
#define __anAttr_Primitive_h__

#include "anAttr.h"
#include "anAttrInst.h"

template<class T> class anAttr_Primitive;
template<class T> class anAttrInst_Primitive;
template<class T> class anAttrSpec_Primitive;

template<class T>
class anAttrInst_Primitive : public anAttrInst {
	typedef	anAttrInst	B;
	typedef anAttrSpec_Primitive<T>		SPEC;
public:
	virtual	axStatus	onSetValue		( anAttr & attr, anAttr & src );

	virtual	axStatus	onSerialize		( anAttr & attr, axSerializer   &s ) { return _onSerielize(attr,s); }
	virtual	axStatus	onSerialize		( anAttr & attr, axDeserializer &s ) { return _onSerielize(attr,s); }

	virtual axStatus	onToString		( anAttr & attr, axIStringA & out );
	virtual axStatus	onSetValueToDefault	( anAttr & attr );


friend class anAttr_Primitive<T>;
protected:
	T	value_;
private:
	template<class S>	axStatus _onSerielize( anAttr & attr, S &s ) { return s.io(value_); }
};

template<class T>
class anAttrSpec_Primitive : public anAttrSpec {
	typedef	anAttrSpec	B;
public:
	anAttrSpec_Primitive();
	anAttrSpec_COMMON( Primitive<T> );
	CLASS&	setDefaultValue ( const T& defaultValue );
	T		defaultValue	() const;

	CLASS&	setMinMax		( const T & minValue, const T & maxValue );
	T		minValue	() const;
	T		maxValue	() const;

	CLASS&	setPrecision	( int precision );
	int		precision		() const;

	CLASS&	uiAddSlider	();
	bool	uiHasSlider	() const;

	CLASS&	uiAddDial	( double step );
	double	uiDialStep	() const;
		
private:
	int			precision_;
	T			defaultValue_;
	T			minValue_;
	T			maxValue_;
	double		uiDialStep_;
	bool		uiHasSlider_	: 1;
};

template<class T>
class anAttr_Primitive : public anAttr {
	typedef	anAttr	B;
public:
	typedef	T	VALUE;
	anAttr_COMMON( Primitive<T> );

	T			value	();
	axStatus	setValue( const T & v );
};

#define TYPE_LIST(T,NAME) \
	typedef	anAttrSpec_Primitive<T>	anAttrSpec_##NAME;	\
	typedef	anAttrInst_Primitive<T>	anAttrInst_##NAME;	\
	typedef	anAttr_Primitive<T>		anAttr_##NAME;		\
//---
	TYPE_LIST(int,		int   )
	TYPE_LIST(int64_t,	int64 )
	TYPE_LIST(float,	float )
	TYPE_LIST(double,	double)
	TYPE_LIST(bool,		bool  )
#undef	TYPE_LIST


#endif //__anAttr_Primitive_h__
