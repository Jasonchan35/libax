#ifndef __anAttr_Matrix4_h__
#define __anAttr_Matrix4_h__

#include "anAttr_Primitive.h"

template<class T> class anAttr_Matrix4;
template<class T> class anAttrSpec_Matrix4;

template<class T>
class anAttrInst_Matrix4 : public anAttrInst {
	typedef	anAttrInst	B;
	typedef	anAttrSpec_Matrix4<T>	SPEC;
public:
	virtual	axStatus	onSetValue			( anAttr & attr, anAttr & src );

	virtual axStatus	onSetValueToDefault	( anAttr & attr );
	virtual axStatus	onToString			( anAttr & attr, axIStringA	& out );

	virtual	axStatus	onSerialize			( anAttr & attr, axSerializer	&s );
	virtual	axStatus	onSerialize			( anAttr & attr, axDeserializer	&s );

	axMatrix4<T>	value_;
};

template<class T>
class anAttrSpec_Matrix4 : public anAttrSpec {
	typedef	anAttrSpec	B;
public:
	anAttrSpec_COMMON( Matrix4<T> );
	CLASS& setDefaultValue( const axMatrix4<T> &value );

	const axMatrix4<T>& defaultValue() { return defaultValue_; }
private:
	axMatrix4<T>	defaultValue_;
};

template<class T>
class anAttr_Matrix4 : public anAttr {
	typedef	anAttr	B;
public:
	anAttr_COMMON( Matrix4<T> );

	axMatrix4<T>	value	();
	axStatus		setValue( const axMatrix4<T> & v );
};

typedef	anAttrSpec_Matrix4<float>		anAttrSpec_Matrix4f;
typedef	anAttrInst_Matrix4<float>		anAttrInst_Matrix4f;
typedef	anAttr_Matrix4<float>			anAttr_Matrix4f;

typedef	anAttrSpec_Matrix4<double>		anAttrSpec_Matrix4d;
typedef	anAttrInst_Matrix4<double>		anAttrInst_Matrix4d;
typedef	anAttr_Matrix4<double>			anAttr_Matrix4d;


#endif //__anAttr_Matrix4_h__
