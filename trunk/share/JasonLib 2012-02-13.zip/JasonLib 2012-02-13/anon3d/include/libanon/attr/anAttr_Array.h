#ifndef __anAttrArray_h__
#define __anAttrArray_h__

#include "anAttr.h"

template<class INST>
class anAttrInst_Element : public INST {
	typedef	INST	B;
public:
	anAttrInst_Element()	{ B::_setIsElement( true ); }

	virtual axSize		onGetElementIndex	( anAttr & attr )		{ return elementIndex_; }
	virtual anAttrInst*	onGetElementArray	( anAttr & attr )		{ return array_; }

	void	_init( anAttrInst* _array, axSize elementIndex );
private:
	axSize		elementIndex_;
	anAttrInst*	array_;
};

template<class INST>
class anAttrInst_Array : public anAttrInst {
	typedef	anAttrInst B;
	typedef	anAttrInst_Element<INST>	Element;
public:
	anAttrInst_Array() { B::_setIsArray( true ); }

			INST&	indexOf		( axSize i )		{ return elements_[i]; }
	const	INST&	indexOf		( axSize i ) const	{ return elements_[i]; }

			INST&	element		( axSize i )		{ return elements_[i]; }
	const	INST&	element		( axSize i ) const	{ return elements_[i]; }

	virtual	axStatus	onSetNumElements	( anAttr & attr, axSize n );
	virtual	axSize		onGetNumElements	( anAttr & attr );
	virtual anAttrInst*	onGetElement		( anAttr & attr, axSize index );

	virtual axStatus	onSetValueToDefault	( anAttr & attr );
	virtual axStatus	onToString			( anAttr & attr, axIStringA & out );

	virtual axStatus	onSetValue			( anAttr & attr, anAttr & src );

	virtual axStatus	onSerialize			( anAttr & attr, axSerializer   &s );
	virtual axStatus	onSerialize			( anAttr & attr, axDeserializer &s );

	virtual	void		setDirty	( bool b )	{ /* do nothing */ }
	virtual	axStatus	getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list );

private:
	axChunkArray<Element,16,4>	elements_;
};


template<class SPEC>
class anAttrSpec_Array : public SPEC {
	typedef SPEC	B;
	typedef	anAttrSpec_Array<SPEC>	CLASS;
	typedef typename B::INST		INST;
	typedef anAttrInst_Array<INST>	INST_ARRAY;
public:
	anAttrSpec_Array() { SPEC::_setIsArray(true); }

	CLASS&	create		( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset ) {
		SPEC::_create( name, nodeSpec, parent, instOffset );	return *this;
	}
	template<class Node> CLASS& setComputeFunc( axStatus (Node::*func)(anAttr* attr))	{ 
		SPEC::_setComputeFunc( ( anAttrSpec::ComputeFunc) func ); return *this; 
	}
};


template<class ATTR>
class anAttr_Array : public anAttr {
	typedef anAttr	B;
	typedef	anAttrInst_Array< typename ATTR::INST >	INST_ARRAY;
public:
	anAttr_Array() {}
	anAttr_Array( anNode* node, anAttrSpec* spec, anAttrInst* inst ) : B(node, spec, inst) {}

	ATTR	element( axSize index );
	ATTR	operator[]( axSize index )	{ return element(index); }
};

//--------------
template<class ATTR> inline
ATTR anAttr_Array<ATTR>::element ( axSize index ) { 
	if( ! isValid() ) return ATTR();
	anAttrInst* p = _inst()->onGetElement(*this,index);
	if( !p ) return ATTR();
	return ATTR(node(), spec(), p );
}


//--------------

template<class INST> inline
axStatus anAttrInst_Array<INST>::onSetNumElements ( anAttr & attr, axSize n ) { 
	axStatus st;
	axSize o = elements_.size();
	st = elements_.resize(n);	if( !st ) return st;
	for( axSize i=o; i<n; i++ ) {
		elements_[i]._init(this,i);
	}
	return 0;
}

template<class INST> inline
axSize anAttrInst_Array<INST>::onGetNumElements ( anAttr & attr ) { 
	return elements_.size();
}

template<class INST> inline
anAttrInst*	anAttrInst_Array<INST>::onGetElement ( anAttr & attr, axSize index ) {
	if( ! elements_.inBound(index) ) return NULL;
	return &elements_[index];
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::onSetValueToDefault	( anAttr & attr ) {
	axStatus st;
	axSize n = attr.numElements();
	for( axSize i=0; i<n; i++ ) {
		attr.element(i).setValueToDefault();
	}
	return 0;
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::onToString	( anAttr & attr, axIStringA & out ) {
	axStatus st;
	out.set("[");
	axSize n = attr.numElements();
	axTempStringA	tmp;
	for( axSize i=0; i<n; i++ ) {
		st = attr.element(i).toString(tmp);		if( !st ) return st;
		if( i==0 ) {
			out.appendFormat("\n  {?}", tmp );
		}else{
			out.appendFormat(",\n  {?}", tmp );
		}
	}
	out.append("\n]");
	return 0;
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::onSetValue	( anAttr & attr, anAttr & src ) {
	if( attr.spec() != src.spec() ) return axStatus_Anon_unsupport_value_type;
	axStatus st;
	axSize n = attr.numElements();
	st = src.setNumElements( n );			if( !st ) return st;
	for( axSize i=0; i<n; i++ ) {
		st = attr.element(i).setValue( src.element(i) );		if( !st ) return st;
	}
	return 0;
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::onSerialize	( anAttr & attr, axSerializer   &s ) {
	axStatus st;
	axSize n = attr.numElements();
	st = s.io_vary( n );		if( !st ) return st;
	for( axSize i=0; i<n; i++ ) {
		st = attr.element(i).onSerialize(s);		if( !st ) return st;
	}
	return 0;
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::onSerialize	( anAttr & attr, axDeserializer &s ) {
	axStatus st;
	axSize n;
	st = s.io_vary( n );			if( !st ) return st;
	st = attr.setNumElements(n);	if( !st ) return st;	
	for( axSize i=0; i<n; i++ ) {
		st = attr.element(i).onSerialize(s);		if( !st ) return st;
	}
	return 0;
}

template<class INST> inline
axStatus	anAttrInst_Array<INST>::getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list ) {
	axStatus st;
	st = B::getAllInputConnectionsRecursively( attr, list );	if( !st ) return st;
	axSize n = attr.numElements();
	for( axSize i=0; i<n; i++ ) {
		st = attr.element(i).getAllInputConnectionsRecursively(list);		if( !st ) return st;
	}
	return 0;
}

//--------------

template<class INST> inline
void anAttrInst_Element<INST>::_init ( anAttrInst* _array, axSize elementIndex ) { 
	array_ = _array;
	elementIndex_ = elementIndex;
}



#endif //__anAttrArray_h__
