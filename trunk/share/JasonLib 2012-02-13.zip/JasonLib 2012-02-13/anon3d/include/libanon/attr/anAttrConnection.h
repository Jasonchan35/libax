#ifndef __anAttrConnection_h__
#define __anAttrConnection_h__

#include "anAttr.h"

class	anAttrConnectionInfo {
public:
	anNodeType		nodeType;
	anNodeName		nodeName;
	anAttrId		attrId;
	template<class S> axStatus	serialize_io( S & s );
	axStatus	toStringFormat( axStringFormat &f ) const;

	axStatus	_setByAttr( anAttr & a );
};


class anAttrConnection : public axDListNode< anAttrConnection > {
public:
	anAttrConnection();

	anAttr		owner;
	anAttr		source;

	void        onWillRemoveFromList();

	axStatus	toStringFormat( axStringFormat &f ) const;

	anAttrConnectionInfo	sourceInfo;
};

//--- inline ---

template<class S> inline
axStatus	anAttrConnectionInfo::serialize_io( S &s ) {
	axStatus st;
	st = s.io( nodeType );	if( !st ) return st;
	st = s.io( nodeName );	if( !st ) return st;
	st = s.io( attrId   );	if( !st ) return st;
	return 0;
}

#endif //__anAttrConnection_h__

