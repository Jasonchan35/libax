#ifndef __anAttr_Compound_h__
#define __anAttr_Compound_h__

#include "anAttr_Primitive.h"


class anAttrSpec_Compound  : public anAttrSpec {
public:

};

class anAttrInst_Compound : public anAttrInst {
	typedef	anAttrInst	B;
public:
	virtual axStatus	onSetValueToDefault	( anAttr & attr );
	virtual axStatus	onToString	( anAttr & attr, axIStringA & out );

	virtual	axStatus	onSetValue	( anAttr & attr, anAttr & src );

	virtual	axStatus	onSerialize	( anAttr & attr, axSerializer	&s );
	virtual	axStatus	onSerialize	( anAttr & attr, axDeserializer	&s );

	virtual	void		setDirty	( bool b )	{ /* do nothing */ }
	virtual	axStatus	getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list );

	virtual	void		onUnshare	( anAttr & attr );

private:
	template<class S>	axStatus _onSerielize( anAttr & attr, S &s );
};

class anAttr_Compound : public anAttr {
	typedef	anAttr	B;
public:
	anAttr_Compound() {}
	anAttr_Compound( anNode* node, const anAttrSpec* spec, anAttrInst* inst ) : B(node, spec, inst ) {}

};


#endif //__anAttr_Compound_h__
