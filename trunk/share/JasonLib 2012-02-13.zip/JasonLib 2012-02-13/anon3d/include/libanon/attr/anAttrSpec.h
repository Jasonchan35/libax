#ifndef __anAttrSpec_h__
#define __anAttrSpec_h__

#include "anAttrType.h"
#include "../base/an_convert.h"

class anNodeSpec;

class anAttrSpec : public axNonCopyable {
	typedef		anAttrSpec	CLASS;
public:
	typedef	axStatus (anNode::*ComputeFunc)( anAttr* );

	anAttrSpec();	

	virtual		axStatus	onCreate	( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset );
				bool		isCreated	() const			{ return created_; }

	virtual		anAttrType	type		() const;

	virtual		const char*	typeName	() const { return "unknown"; }

				const char*	name		() const;
				const char*	fullName	() const;

				anAttrSubID	attrSubId	() const			{ return attrSubId_; }

				bool		isArray		() const			{ return isArray_; }
				bool		saveToFile	() const			{ return saveToFile_; }
	
			 	anAttrSpec*	parent		()		 			{ return parent_; }
		const 	anAttrSpec*	parent		() const 			{ return parent_; }
				anAttrSpec*	child		( axSize i )		{ return child_[i]; }
		const	anAttrSpec*	child		( axSize i ) const	{ return child_[i]; }
				axSize		numChildren	() const			{ return child_.size(); }

				axStatus	toStringFormat	( axStringFormat &f ) const;

				axSize		instOffset	() const			{ return instOffset_; }

				axStatus	addAffected			( anAttrSpec* o );
				anAttrSpec*	affected			( axSize i )		{ return affected_[i]; }
		const	anAttrSpec*	affected			( axSize i ) const	{ return affected_[i]; }
				axSize		numAffected			() const			{ return affected_.size(); }

				void		uiSetColor			( const axColorRGBf & color );
	const	axColorRGBf &	uiColor				() const;

				bool		hasComputeFunc		() const			{ return computeFunc_ != NULL; }
				axStatus	callComputeFunc		( anAttr *attr ) const;

				axStatus	_create				( const char* name, anNodeSpec & nodeSpec, anAttrSpec* parent, axSize instOffset );
				axStatus	_getAttrId			( const char* fullName, axIArray<axSize> & out );

				void		_setComputeFunc		( ComputeFunc func );

				void		_setIsArray			( bool b )	{ isArray_ = b; }
				void		_setSaveToFile		( bool b )	{ saveToFile_ = b; }
private:
	axStringA_<32>	name_;
	axStringA_<32>	fullName_;

	anNodeSpec*		nodeSpec_;
	anAttrSpec*		parent_;
	
	axArray< anAttrSpec* >	child_;
	axArray< anAttrSpec* >	affected_;

	axSize			level_;
	axSize			instOffset_;
	ComputeFunc		computeFunc_;
	anAttrSubID		attrSubId_;

	axColorRGBf		uiColor_;

	bool			isArray_ : 1;
	bool			created_ : 1;
	bool			saveToFile_ : 1;
};


#endif //__anAttrSpec_h__

