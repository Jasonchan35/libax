#ifndef __anAttr_CVec3_h__
#define __anAttr_CVec3_h__

#include "anAttr_Compound.h"

template<class T> class anAttr_CVec3;

template<class T>
class anAttrInst_CVec3 : public anAttrInst_Compound {
	typedef	anAttrInst_Compound	B;
	typedef anAttr_CVec3<T>		ATTR;
public:
	axStatus	onSetValue	( anAttr & attr, anAttr & src );

	anAttrInst_Primitive<T>	x, y, z;
private:
	template<class S>	axStatus _serialize_io( S &s );
};

template<class T>
class anAttrSpec_CVec3 : public anAttrSpec_Compound {
	typedef	anAttrSpec_Compound	B;
public:
	anAttrSpec_COMMON( CVec3<T> );

	anAttrSpec_CVec3<T>&		setDefaultValue( const axVec3<T>& v );
	anAttrSpec_CVec3<T>&		setDefaultValue( T xx, T yy, T zz );

	anAttrSpec_CVec3<T>&		setMinMax	( T minValue, T maxValue );
	anAttrSpec_CVec3<T>&		setMinMax	( const axVec3<T>& minValue, const axVec3<T>& maxValue );

	anAttrSpec_CVec3<T>&		uiAddSlider	();
	anAttrSpec_CVec3<T>&		uiAddDial	( double step );

	anAttrSpec_Primitive<T>	x, y, z;
private:
};

template<class T>
class anAttr_CVec3 : public anAttr_Compound {
	typedef	anAttr_Compound	B;
public:
	anAttr_COMMON( CVec3<T> );

	anAttr_CHILD( Primitive<T>,	x );
	anAttr_CHILD( Primitive<T>,	y );
	anAttr_CHILD( Primitive<T>,	z );

	axVec3<T>	value	();
	axStatus	setValue( const axVec3<T> & v )	{ return setValue(v.x, v.y, v.z); }
	axStatus	setValue( T xx, T yy, T zz );
};


typedef	anAttrSpec_CVec3<float>		anAttrSpec_CVec3f;
typedef	anAttrInst_CVec3<float>		anAttrInst_CVec3f;
typedef	anAttr_CVec3<float>			anAttr_CVec3f;

typedef	anAttrSpec_CVec3<double>		anAttrSpec_CVec3d;
typedef	anAttrInst_CVec3<double>		anAttrInst_CVec3d;
typedef	anAttr_CVec3<double>			anAttr_CVec3d;


#endif //__anAttr_CVec3_h__
