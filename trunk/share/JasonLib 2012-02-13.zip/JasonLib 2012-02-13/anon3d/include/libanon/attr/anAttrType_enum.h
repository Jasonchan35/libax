//anAttrType_enum( [C++ type],	[name] )
anAttrType_enum( int32_t,		int )
anAttrType_enum( int64_t,		int64 )
anAttrType_enum( float,			float )
anAttrType_enum( double,		double )
anAttrType_enum( bool,			bool )
anAttrType_enum( axStringA,		String )

anAttrType_enum( axVec2f,		CVec2f )
anAttrType_enum( axVec2d,		CVec2d )

anAttrType_enum( axVec3f,		CVec3f )
anAttrType_enum( axVec3d,		CVec3d )

anAttrType_enum( axVec4f,		CVec4f )
anAttrType_enum( axVec4d,		CVec4d )

anAttrType_enum( axMatrix4f,	Matrix4f )
anAttrType_enum( axMatrix4d,	Matrix4d )

anAttrType_enum( anMesh3f,		Mesh3f )
anAttrType_enum( anMesh3d,		Mesh3d )

//anAttrType_enum( anBlendShapeTarget, BlendShapeTarget )
