#ifndef __all_anAttr_h__
#define __all_anAttr_h__

#include "anAttr_Primitive.h"
#include "anAttr_CVec2.h"
#include "anAttr_CVec3.h"
#include "anAttr_Matrix4.h"
#include "anAttr_Mesh3.h"
#include "anAttr_Array.h"

#endif //__all_anAttr_h__
