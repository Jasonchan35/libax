#ifndef __anAttrInst_h__
#define __anAttrInst_h__

#include "anAttrSpec.h"
#include "anAttrConnection.h"

class anAttrInst : public axNonCopyable {
public:
	anAttrInst();
	virtual ~anAttrInst();

	virtual axStatus	onSetValueToDefault	( anAttr & attr ) = 0;
	virtual axStatus	onToString			( anAttr & attr, axIStringA & out ) = 0;

	virtual axStatus	onSetValue			( anAttr & attr, anAttr & src ) = 0;

	virtual axStatus	onSerialize			( anAttr & attr, axSerializer   &s ) = 0;
	virtual axStatus	onSerialize			( anAttr & attr, axDeserializer &s ) = 0;

			axStatus	connect				( anAttr & attr, anAttr & dst );
	//Array
			bool		isArray				() const { return isArray_; }
	virtual	axSize		onGetNumElements	( anAttr & attr );
	virtual axStatus	onSetNumElements	( anAttr & attr, axSize n );

	//Array Element
			bool		isElement	() const { return isElement_; }
	virtual axSize		onGetElementIndex	( anAttr & attr );
	virtual anAttrInst*	onGetElement		( anAttr & attr, axSize index );
	virtual anAttrInst*	onGetElementArray	( anAttr & attr );

	virtual	void		onUnshare			( anAttr & attr )	{}

	virtual	axStatus	getAllInputConnectionsRecursively( anAttr & attr, axIArray<anAttrConnection*> & list );
			void		disconnectAll		( anAttr & attr );

	virtual	void		setDirty		( bool b )	{ dirty_ = b; }
			bool		dirty			()			{ return dirty_; }

			bool		computing		()			{ return computing_; }

			void		_setComputing	( bool b )	{ computing_ = b; }
			void		_setIsArray		( bool b )	{ isArray_ = b; }
			void		_setIsElement	( bool b )	{ isElement_ = b; }

	class	Conn {
	public:
		anAttrConnection			input;
		axDList< anAttrConnection >	output;
	};

	axAutoPtr< Conn >	conn;

private:
	bool		isArray_	: 1;
	bool		isElement_	: 1;
	bool		dirty_		: 1;
	bool		computing_	: 1;
};

#endif //__anAttrInst_h__
