#ifndef __anAttr_Vec2_h__
#define __anAttr_Vec2_h__

#include "anAttr_Compound.h"

template<class T> class anAttr_CVec2;

template<class T>
class anAttrInst_CVec2 : public anAttrInst_Compound {
	typedef	anAttrInst_Compound	B;
	typedef anAttr_CVec2<T>		ATTR;
public:
	virtual	axStatus	onSetValue	( anAttr & attr, anAttr & src );

	anAttrInst_Primitive<T>	x, y;
};

template<class T>
class anAttrSpec_CVec2 : public anAttrSpec_Compound {
	typedef	anAttrSpec_Compound	B;
public:
	anAttrSpec_COMMON( CVec2<T> );
	anAttrSpec_CVec2<T>&		setDefaultValue( const axVec2<T>& v );
	anAttrSpec_CVec2<T>&		setDefaultValue( T xx, T yy );

	anAttrSpec_CVec2<T>&		setMinMax	( T minValue, T maxValue );
	anAttrSpec_CVec2<T>&		setMinMax	( const axVec2<T>& minValue, const axVec2<T>& maxValue );

	anAttrSpec_CVec2<T>&		uiAddSlider	();
	anAttrSpec_CVec2<T>&		uiAddDial	( double step );

	anAttrSpec_Primitive<T>	x, y;
};

template<class T>
class anAttr_CVec2 : public anAttr_Compound {
	typedef	anAttr_Compound	B;
public:
	anAttr_COMMON( CVec2<T> );

	anAttr_CHILD( Primitive<T>,	x );
	anAttr_CHILD( Primitive<T>,	y );

	axVec2<T>	value	();
	axStatus	setValue( const axVec2<T> & v ) { return setValue(v.x, v.y); }
	axStatus	setValue( T xx, T yy );
};


typedef	anAttrSpec_CVec2<float>		anAttrSpec_CVec2f;
typedef	anAttrInst_CVec2<float>		anAttrInst_CVec2f;
typedef	anAttr_CVec2<float>			anAttr_CVec2f;

typedef	anAttrSpec_CVec2<double>	anAttrSpec_CVec2d;
typedef	anAttrInst_CVec2<double>	anAttrInst_CVec2d;
typedef	anAttr_CVec2<double>		anAttr_CVec2d;



#endif //__anAttr_Vec2_h__
