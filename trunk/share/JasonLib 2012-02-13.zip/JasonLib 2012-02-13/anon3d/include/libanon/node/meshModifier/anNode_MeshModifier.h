#ifndef __anNode_MeshModifier_h__
#define __anNode_MeshModifier_h__

#include "../anNode.h"

anNode_CLASS( MeshModifier, Node ) 
public:
	anAttr_DECLARE( Mesh3f,	outMesh );
	anAttr_DECLARE( Mesh3f,	inMesh );
	anAttr_DECLARE( bool,	byPass  );

	virtual		axStatus	onComputeOutMesh();

private:
	axStatus	_onComputeOutMesh ( anAttr *attr );

};

#endif //__anNode_Mesh_h__
