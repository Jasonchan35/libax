#ifndef __anNode_Shape_h__
#define __anNode_Shape_h__


#include "../anNode_DAG.h"

anNode_CLASS( Shape, DAG ) 
public:


private:

};



#endif //__anNode_Shape_h__
