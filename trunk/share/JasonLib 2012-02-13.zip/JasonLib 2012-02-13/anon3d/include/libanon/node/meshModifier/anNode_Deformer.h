#ifndef __anNode_Deformer_h__
#define __anNode_Deformer_h__

#include "anNode_MeshModifier.h"

anNode_CLASS( Deformer, MeshModifier ) 
public:

	virtual		axStatus	onDeform( anVertex3f* dst, const anVertex3f* src, axSize numVertices );
private:
	virtual		axStatus	onComputeOutMesh();
	anMesh3f	outMesh_;
};

#endif //__anNode_Deformer_h__
