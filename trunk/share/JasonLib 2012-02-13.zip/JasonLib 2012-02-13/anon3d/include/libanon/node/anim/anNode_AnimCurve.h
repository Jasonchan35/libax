#ifndef __anNode_AnimCurve_h__
#define __anNode_AnimCurve_h__

#include "../anNode.h"

anNode_CLASS( AnimCurve, Node ) 
public:
	anAttr_DECLARE( float,	input );
	anAttr_DECLARE( float,	output );

	enum { //tangent type
			tt_global = 0,
			tt_fixed,
			tt_linear,
			tt_flat,
			tt_smooth, 
			tt_step,
			tt_slow, //OBSOLETE
			tt_fast, //OBSOLETE
			tt_clamped, 
			tt_plateau,
			tt_step_next
		};
	static const char* tangentTypeName( int t );

	enum{ //infinity type
		it_constant = 0,
		it_linear = 1,
		it_cycle = 3,
		it_cycle_relative = 4,
		it_oscillate = 5
	};
	static const char* infintyTypeName( int t );

	void	setPreInfinityType	( uint8_t t );
	uint8_t	preInfinityType		() const;
	
	void	setPostInfinityType	( uint8_t t );
	uint8_t	postInfinityType	() const;


	struct Key {
		float		time;
		float		value;

		uint8_t		inTangentType;
		uint8_t		outTangentType;

		axVec2f		inTangent;
		axVec2f		outTangent;

		template<class S>
			axStatus	serialize_io( S &s );

		axStatus	toStringFormat( axStringFormat &f ) const;
		axStatus	onTake( Key & src ) { operator=(src); return 0; }

		float		_c[4]; //coeff cache
	};

	axStatus	setKeys	( const axIArray<Key> & keys );

	axStatus	findKey	( axSize &outIndex, float time );

	axStatus	evaluate( float & value,	float time );

	virtual	axStatus	onSerialize	( axSerializer		&s );
	virtual	axStatus	onSerialize	( axDeserializer	&s );

	template<class S>		
			axStatus	_onSerialize( S &s );

	anNode_AnimCurve();

private:
	axArray<Key>	keys_;

	uint8_t			preInfinityType_;
	uint8_t			postInfinityType_;

	axStatus		onComputeOutput( anAttr* attr );

	axStatus		_buildKeyCache();
	axStatus		_buildHermiteCache( Key &sk, Key &ek );
	axStatus		_evaluateInRange( float & value, float time );

	bool			keyCacheDirty_ : 1;
	bool			weightedCurve_ : 1;
	bool			isStaticCurve_ : 1;
};

template<class S> inline
axStatus	anNode_AnimCurve::Key::serialize_io( S &s ) {
	axStatus st;
	st = s.io( time );				if( !st ) return st;
	st = s.io( value );				if( !st ) return st;
	st = s.io( inTangentType);		if( !st ) return st;
	st = s.io( outTangentType );	if( !st ) return st;
	st = s.io( inTangent);			if( !st ) return st;
	st = s.io( outTangent );		if( !st ) return st;
	return 0;
}

inline
axStatus	anNode_AnimCurve::Key::toStringFormat( axStringFormat &f ) const {
	f.format("time:{?}, value:{?}, inTangent={?}:{?}, outTangent={?}:{?}", 
				time, value, 
				inTangentType, inTangent, 
				outTangentType, outTangent );
	return 0;
}

#endif //__anNode_AnimCurve_h__
