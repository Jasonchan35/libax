#ifndef __anNode_Transform_h__
#define __anNode_Transform_h__

#include "../anNode_DAG.h"

anNode_CLASS( Transform, DAG ) 
public:
	anAttr_DECLARE( CVec3f,		translate );
	anAttr_DECLARE( CVec3f,		rotate );
	anAttr_DECLARE( CVec3f,		scale );

	anAttr_DECLARE( Matrix4f,	matrix );

	virtual	axStatus	onComputeMatrix	( axMatrix4f &mat );
	virtual	void		onGLRenderChild	( anGLRenderRequest &req );

private:
	axStatus	_onComputeMatrix	( anAttr* attr );

};


#endif //__anNode_Transform_h__
