// the order below can not be change
// please append only, to keep the number for anScene file compatibility

anNodeType_enum( Node )
anNodeType_enum( SceneRoot )

anNodeType_enum( Shader )
anNodeType_enum( AnimCurve )

anNodeType_enum( DAG )
anNodeType_enum( Transform )

anNodeType_enum( Shape )

anNodeType_enum( Mesh )
anNodeType_enum( MeshModifier )
anNodeType_enum( Deformer )
anNodeType_enum( BlendShape )
