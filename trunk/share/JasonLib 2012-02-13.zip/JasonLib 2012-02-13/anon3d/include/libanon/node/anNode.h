#ifndef __anNode_h__
#define __anNode_h__

#include "anNodeSpec.h"
#include "../attr/all_anAttr.h"
#include "../base/anGLRenderRequest.h"
#include "../base/anSelectionList.h"
#include "../base/anActionHistory.h"

class anScene;

class anNodeEvent {
public:
	anNodeEvent( anNode* node ) { node_ = node; }
	anNode*	node() { return node_; }
private:
	anNode* node_;
};

typedef axEventCaster	< anNodeEvent > anNodeEventCaster;
template<class OBJ>	class anNodeEventFunc: public axEventFunc < OBJ, anNodeEvent > {};


class anNode : public axDListNode< anNode > {
public:
	virtual bool			isKindOf		( anNodeType	type );

			axStatus		setName			( const char* name );
			const char*		name			() const;

			axStatus		setParentName	( const char* name );
			const char*		parentName		() const;

			anAttr			attr			( axSize idx );
			axSize			numAttr			() const;

			axStatus		findAttrById	( anAttr & out, const anAttrId & attrId );
			axStatus		findAttrByName	( anAttr & out, const char* name );

	virtual	anNodeType		type			() const;
			const char*		typeName		() const;

			axStatus		toStringFormat	( axStringFormat &f ) const;

			anNodeSpec*		spec			() const	{ return spec_; }

			void			appendChild		( anNode* child );
			anNode*			firstChild		();
			axSize			numChildren		();

			void			glRender		( anGLRenderRequest &req );
	virtual	void			onGLRenderChild	( anGLRenderRequest &req );
	virtual	void			onGLRender		( anGLRenderRequest &req );

			bool			isSystemNode	()		{ return systemNode_; }
			anScene*		scene			()		{ return scene_; }

	//! remember to call Base Class onSerialize
	virtual	axStatus		onSerialize		( axSerializer		&s );

	//! remember to call Base Class onSerialize
	virtual	axStatus		onSerialize		( axDeserializer	&s );

			axStatus		getAllInputConnectionsRecursively( axIArray<anAttrConnection*> & list );

			void			_setSystemNode	( bool b )	{ systemNode_ = b; }
//--- event
		axEventCaster< anAttr >		evNodeAttrDidChange;
		axEventCaster< anNode >		evNodeDeleted;
		axEventCaster< anNode >		evNodeNameDidChange;

//--- spec ---
	enum	{ TYPE = anNodeType_Node };
	static	anNodeSpec&		staticSpec		();
	static	axStatus		initStaticSpec	();
	static	axStatus		onInitStaticSpec( anNodeSpec &spec );

	struct FileHeader {
		anNodeType		type;
		uint32_t		byteSize;
		axTempStringA	name;
		template<class S> axStatus	serialize_io( S &s );
		axStatus	toStringFormat( axStringFormat &f ) const;
	};

//--- internal ----
			void		_setSelected	( const anSelection &sel, bool selected );
			void		_onSetSelected	( const anSelection &sel, bool selected );

	virtual axStatus	_onCreate	( anNodeSpec *spec );
	virtual	void		_onDelete	();

			axStatus	serialize_io( axSerializer		&s );
			axStatus	serialize_io( axDeserializer	&s );

	template< class S >		axStatus	_serialize_io( S &s );

	void		_setScene	( anScene* scene )	{ scene_ = scene; }

	anNode();
	virtual	~anNode();

	class HashNode : public axHashTableNode< HashNode > {
		typedef	axHashTableNode< HashNode > B;
	public:
		anNode*		node;
		uint32_t	hashTableValue() { return ax_string_hash( node->name() ); }
		HashNode() { B::setOwnedByList(false); }
	};
	HashNode	hashNode_;

private:
	anNodeName			name_;
	anNodeSpec*			spec_;
	anNodeName			parentName_;
	anScene*			scene_;
	axDList< anNode >	children_;
	bool	selected_	: 1;
	bool	systemNode_	: 1;
};

typedef	anNode	anNode_Node;
template<class T>	inline anNode* anNodeCreator() { return new T; }

template<class S> inline
axStatus	anNode::FileHeader::serialize_io( S &s ) {
	axStatus st;
	st = s.io( type   );	if( !st ) return st;
	st = s.io( byteSize );	if( !st ) return st;
	st = s.io( name );		if( !st ) return st;
	return 0;
}

class anAction_SetNodeName : public anAction {
public:
	virtual axStatus	undo() { return node->setName(oldName); }
	virtual axStatus	redo() { return node->setName(newName); }

	anNode*		node;
	anNodeName	oldName;
	anNodeName	newName;
};

template<class ATTR>
class	anAction_SetAttr : public anAction {
public:
	virtual axStatus	undo() { return attr.setValue(oldValue); }
	virtual axStatus	redo() { return attr.setValue(newValue); }

	ATTR	attr;
	typename	ATTR::VALUE	oldValue;
	typename	ATTR::VALUE	newValue;
};


#define	anNode_CLASS( THIS_CLASS, BASE_CLASS )	\
	class anNode_##THIS_CLASS : public anNode_##BASE_CLASS { \
		typedef anNode_##THIS_CLASS	CLASS;				\
		typedef anNode_##BASE_CLASS	B;					\
	public: \
		typedef	anNode_##BASE_CLASS	_BASE_CLASS;		\
		static anNodeSpec&		staticSpec() { static anNodeSpec s; return s; }	\
		enum { TYPE = anNodeType_##THIS_CLASS }; \
		virtual ~anNode_##THIS_CLASS	() { _onDelete(); } \
		virtual bool		isKindOf	( anNodeType type )	{ return ( type == TYPE ) ? true : B::isKindOf( type ); } \
		static	axStatus	onInitStaticSpec( anNodeSpec &spec );	\
		static	axStatus	initStaticSpec() {						\
			axStatus st;									\
			anNodeSpec &s  = staticSpec();					\
			anNodeSpec &bs = B::staticSpec();				\
			if( s.alreadyCreated() )	return 0;			\
			st = B::initStaticSpec();	if( !st ) return st; \
			st = s.create( &bs, TYPE, #THIS_CLASS, anNodeCreator<CLASS>, sizeof(anNode_##THIS_CLASS) );	\
			st = onInitStaticSpec( s );	if( !st ) return st; \
			return st;	\
		} \
//-----


#endif //__anNode_h__

