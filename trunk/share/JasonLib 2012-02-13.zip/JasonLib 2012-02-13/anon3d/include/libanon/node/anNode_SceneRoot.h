#ifndef __anNode_SceneRoot_h__
#define __anNode_SceneRoot_h__

#include "anNode.h"

anNode_CLASS( SceneRoot, Node ) 
public:
	anAttr_DECLARE( double, currentTime );
	static	const char*	kName;
private:
};

#endif //__anNode_SceneRoot_h__
