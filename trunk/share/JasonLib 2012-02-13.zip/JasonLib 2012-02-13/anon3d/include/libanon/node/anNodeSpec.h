#ifndef __anNodeSpec_h__
#define __anNodeSpec_h__

#include "anNodeType.h"

class anNode;
class anAttrSpec;

typedef anNode* (*anNodeCreatorFunc)();
template<class T>	inline anNode* anNodeCreator();


class anNodeSpec : public axDListNode< anNodeSpec > {
public:
	anNodeSpec();

	bool	alreadyCreated();

	axStatus		create		( anNodeSpec* baseClass, anNodeType typeId, const char* name, anNodeCreatorFunc creatorFunc, axSize sizeofNode );
	anNode*			createNode	();

	anNodeType		type		() const;

	axStatus		_addAttr	( anAttrSpec* spec );

	axStatus		toStringFormat	( axStringFormat &f ) const;

	const char*		name		() const;

	anAttrSpec*		attr		( axSize idx );
	axSize			numAttr		() const;

	axStatus		getAttrId	( const char* fullName, anAttrId & out );
	axSize			sizeofNode	() const		{ return sizeofNode_; }

private:
	const char*				name_;
	anNodeSpec*				baseClass_;
	axDList<anNodeSpec>		derivedClass_;
	anNodeType				type_;
	anNodeCreatorFunc		creatorFunc_;
	axArray<anAttrSpec*>	attr_;
	axSize					sizeofNode_;

	bool					created_	: 1;
};

class	anNodeSpecRegistry : axNonCopyable { 
public:
	static	anNodeSpecRegistry*	getInstance		();

	anNodeSpecRegistry();

	template<class T>	
			axStatus	createNode		 ( axAutoPtr<T> &node, const char* name );
			axStatus	createNodeByType( anNode* &node, anNodeType type, const char* name );

			axStatus	getAttrId		( anNodeType nodeType, const char* fullName, anAttrId & out );

			anNodeSpec*	nodeSpec		( anNodeType t );
			void		print			();

			axStatus	_create();
private:
	axArray<anNodeSpec*>	nodeSpec_;
	bool	created_;
};

template<class T> inline
axStatus	anNodeSpecRegistry::createNode ( axAutoPtr<T> &node, const char* name ) {
	anNode* p;
	axStatus st = createNodeByType( p, T::TYPE, name );
	if( !st ) return st;
	node.ref( (T*) p);
	return 0;
}

#endif //__anNodeSpec_h__
