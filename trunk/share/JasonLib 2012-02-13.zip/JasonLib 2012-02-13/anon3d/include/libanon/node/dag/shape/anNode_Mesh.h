#ifndef __anNode_Mesh_h__
#define __anNode_Mesh_h__

#include "anNode_Shape.h"

anNode_CLASS( Mesh, Shape ) 
public:
	anAttr_DECLARE( Mesh3f,	outMesh );
	anAttr_DECLARE( Mesh3f,	inMesh );

	virtual	void		onGLRender	( anGLRenderRequest &req );

private:
	axStatus	onComputeOutMesh ( anAttr *attr );
};

#endif //__anNode_Mesh_h__
