#ifndef __anNode_BlendShape_h__
#define __anNode_BlendShape_h__

#include "anNode_Deformer.h"

class	anAttrInst_BlendShapeTarget : public anAttrInst_Compound {
public:
	anAttrInst_Mesh3f	mesh;
	anAttrInst_float	weight;
};

class	anAttr_BlendShapeTarget;

class	anAttrSpec_BlendShapeTarget : public anAttrSpec_Compound {
	typedef	anAttrSpec_Compound	B;
public:
	anAttrSpec_COMMON( BlendShapeTarget );

	anAttrSpec_Mesh3f	mesh;
	anAttrSpec_float	weight;
};

class	anAttr_BlendShapeTarget : public anAttr_Compound {
	typedef	anAttr_Compound	B;
public:
	anAttr_COMMON( BlendShapeTarget );

	anAttr_CHILD( Mesh3f,	mesh );
	anAttr_CHILD( float,	weight );
};


anNode_CLASS( BlendShape, Deformer ) 
public:
	anAttr_DECLARE_ARRAY( BlendShapeTarget, target );

	virtual		axStatus	onDeform( anVertex3f* dst, const anVertex3f* src, axSize numVertices );
private:
};



#endif //__anNode_BlendShape_h__
