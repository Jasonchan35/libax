#ifndef __anNodeType_h__
#define __anNodeType_h__

#include "../base/libanon_define.h"

enum {
	anNodeType_unknown = 0,
	#define anNodeType_enum(TYPE)		anNodeType_##TYPE,
		#include "anNodeType_enum.h"
	#undef	anNodeType_enum
	anNodeType_max,
};

const char* anNodeTypeName( anAttrType t );

#endif //__anNodeType_h__
