#ifndef __anNode_Shader_h__
#define __anNode_Shader_h__

#include "../anNode.h"

anNode_CLASS( Shader, Node ) 
public:

private:
};

#endif //__anNode_Shader_h__
