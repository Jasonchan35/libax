#ifndef __anNode_DAG_h__
#define __anNode_DAG_h__


#include "../anNode.h"

anNode_CLASS( DAG, Node ) 
public:
	anAttr_DECLARE( bool,		visible );

	virtual	void		onGLRenderChild	( anGLRenderRequest &req );

private:
};

#endif //__anNode_DAG_h__
