#ifndef __libanon_h__
#define __libanon_h__

#include "base/anContext.h"
#include "node/all_anNode.h"


#ifdef axCOMPILER_VC
	#pragma comment( lib, "libanon.lib" )
#endif

#endif //__libanon_h__
